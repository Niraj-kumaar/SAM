import httpx

TIMEOUT = 15.0


async def call(url: str, params: dict | None = None) -> dict:
    """GET a URL and return parsed JSON, with an explicit error shape."""
    async with httpx.AsyncClient(timeout=TIMEOUT,
                                 headers={"User-Agent": "sam/1.0"}) as client:
        resp = await client.get(url, params=params)
        resp.raise_for_status()          # never swallow a 4xx/5xx
        return resp.json()


if __name__ == "__main__":
    import asyncio
    print(asyncio.run(call("https://api.frankfurter.app/latest", {"base": "USD"})))
