"""SAM backend package: ``backend.app.research``."""
