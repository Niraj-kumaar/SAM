"""Optional external agent integrations for SAM."""
