"""Opt-in OpenClaw gateway adapter scaffold.

This module deliberately does not guess OpenClaw's version-specific wire protocol.
Implement the transport only after pinning and reviewing the installed gateway version.
"""
from __future__ import annotations
import os
from dataclasses import dataclass

@dataclass(frozen=True)
class OpenClawConfig:
    enabled: bool
    gateway_url: str | None

    @classmethod
    def from_env(cls) -> "OpenClawConfig":
        url = os.getenv("OPENCLAW_GATEWAY_URL", "").strip()
        enabled = os.getenv("OPENCLAW_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
        return cls(enabled=enabled and bool(url), gateway_url=url or None)

class OpenClawNotConfigured(RuntimeError):
    pass

def status() -> dict[str, object]:
    """Return local configuration status; does not claim the remote gateway is healthy."""
    cfg = OpenClawConfig.from_env()
    if not cfg.enabled:
        return {"configured": False, "enabled": False, "reachable": None,
                "message": "OpenClaw is disabled or OPENCLAW_GATEWAY_URL is missing."}
    return {"configured": True, "enabled": True, "reachable": None,
            "gateway_url": cfg.gateway_url,
            "message": "Configured only. Remote health/protocol has not been verified."}

def require_enabled() -> OpenClawConfig:
    cfg = OpenClawConfig.from_env()
    if not cfg.enabled or not cfg.gateway_url:
        raise OpenClawNotConfigured("OpenClaw is not enabled. Configure OPENCLAW_ENABLED and OPENCLAW_GATEWAY_URL after verifying the gateway API.")
    return cfg
