"""
backend.app.security.risk_engine
================================

Classifies every proposed SAM action into LOW / MEDIUM / HIGH / CRITICAL.

The classification is rule-based, deterministic and fully configurable, so a
user can always understand *why* SAM asked for confirmation.

Scoring model
-------------
Each rule contributes points. The total maps to a level:

=============  =====
points         level
0-2            LOW
3-6            MEDIUM
7-11           HIGH
12+            CRITICAL
=============  =====

``SECURITY_RISK_MODE`` shifts the whole scale:

* ``strict``     -> everything is at least MEDIUM
* ``balanced``   -> default
* ``permissive`` -> only HIGH/CRITICAL rules apply (LOW/MEDIUM collapse to LOW)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import RiskLevel

log = get_logger("security.risk")


@dataclass
class RiskAssessment:
    level: RiskLevel
    score: int
    reasons: List[str] = field(default_factory=list)
    requires_confirmation: bool = False
    confirmation_style: str = "simple"      # simple | typed | passphrase
    capability: str = ""
    action: str = ""
    target: str = ""
    reversible: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "level": self.level.value,
            "score": self.score,
            "reasons": self.reasons,
            "requires_confirmation": self.requires_confirmation,
            "confirmation_style": self.confirmation_style,
            "capability": self.capability,
            "action": self.action,
            "target": self.target,
            "reversible": self.reversible,
        }


# ---------------------------------------------------------------------------
# Rule tables
# ---------------------------------------------------------------------------
# (regex on "capability action target", points, human reason, reversible?)
CRITICAL_PATTERNS: List[Tuple[str, int, str, bool]] = [
    (r"\bformat\b.*\b[dA-Z]:\\|\bformat\b\s+/dev/", 14, "formats a whole disk", False),
    (r"\b(shutdown|poweroff)\b.*(-s|/s|now|-h)", 13, "shuts the machine down", False),
    (r"\brm\s+-rf?\s+(/|~|\$HOME|\*)", 14, "recursive delete of a root path", False),
    (r"\bdel\s+/[sq].*\\windows|\brmdir\s+/s.*\\windows", 14, "deletes system directories", False),
    (r"\breg\s+delete\b.*HKLM", 12, "deletes a machine-wide registry key", False),
    (r"\bcipher\s+/w|\bvssadmin\s+delete\s+shadows", 13, "destroys backups / shadow copies", False),
    (r"\bbitlocker\b.*\b(disable|delete|remove)", 12, "disables disk encryption", False),
    (r"\bdefender\b.*\b(disable|off)\b|\bSet-MpPreference\b.*Disable", 12, "disables antivirus", False),
    (r"\bnet\s+user\b.*\b(add|delete)\b|\bnet\s+localgroup\b.*administrators", 12, "changes user accounts", False),
    (r"\b(purchase|checkout|payment|buy\s+now|place\s+order)", 12, "spends money", False),
    (r"\bsend\b.*\b(bulk|mass|everyone|all\s+contacts)\b", 12, "mass communication", False),
    (r"\bfactory\s*reset\b|\bwipe\b", 14, "wipes a device", False),
    (r"\bcurl\b.*\|\s*(ba)?sh|\biwr\b.*\|\s*iex|Invoke-Expression\s*\(.*Download", 13,
     "pipes a remote script into a shell", False),
    (r"\bgit\s+push\b.*--force|\bgit\s+reset\s+--hard", 11, "destroys git history", False),
    (r"\bDROP\s+(TABLE|DATABASE)|\bTRUNCATE\s+TABLE|\bDELETE\s+FROM\b(?!.*WHERE)", 13,
     "destructive SQL", False),
]

HIGH_PATTERNS: List[Tuple[str, int, str, bool]] = [
    (r"pc\.power\.(restart|shutdown|signout|sleep)", 8, "changes power state", True),
    (r"\b(reg\s+(add|delete)|Set-ItemProperty.*HKLM)", 8, "modifies the registry", False),
    (r"\b(sc|net)\s+(stop|start|delete)\b.*service", 7, "controls a system service", True),
    (r"\btaskkill\b|\bStop-Process\b|\bkill\s+-9", 7, "force-kills processes", True),
    (r"pc\.terminal\.(run|dangerous)", 7, "executes shell commands", True),
    (r"files\.delete", 7, "deletes files", False),
    (r"\brm\s+-r|\bRemove-Item\b.*-Recurse|\bdel\s+/s", 7, "recursive delete", False),
    (r"browser\.credentials|browser\.purchase", 8, "uses a logged-in session for a sensitive flow", True),
    (r"phone\.sms\.send|phone\.call|email\.send|social\.post", 8, "sends communication to another person", False),
    (r"phone\.accessibility", 8, "drives another app through Accessibility", True),
    (r"\bchmod\s+777|\bicacls\b.*grant.*Everyone", 7, "opens filesystem permissions", False),
    (r"\bsudo\b|\brunas\b|\bStart-Process\b.*-Verb\s+RunAs", 7, "escalates privileges", True),
    (r"\bpip\s+install\b|\bnpm\s+install\b.*-g|\bwinget\s+install|\bapt\s+install", 6, "installs software", True),
    (r"\bgit\s+(commit|push|rebase|merge)\b", 6, "changes a repository", True),
    (r"pc\.settings\.write", 6, "changes system settings", True),
    (r"phone\.settings\.write", 6, "changes phone settings", True),
    (r"\bencrypt|\bdecrypt\b.*\bkey\b", 6, "touches cryptographic material", True),
]

MEDIUM_PATTERNS: List[Tuple[str, int, str, bool]] = [
    (r"pc\.apps\.(launch|close)", 4, "launches or closes applications", True),
    (r"pc\.keyboard|pc\.mouse|pc\.ui_automation", 4, "controls input devices", True),
    (r"pc\.windows\.manage", 3, "rearranges windows", True),
    (r"files\.(write|move|archive|upload)", 4, "modifies or moves files", True),
    (r"browser\.(open|interact|download)", 4, "drives the browser", True),
    (r"vision\.screen_capture|vision\.camera", 4, "captures visual data", True),
    (r"voice\.microphone|voice\.wake_word", 4, "captures audio", True),
    (r"pc\.clipboard\.read", 4, "reads the clipboard", True),
    (r"phone\.(apps\.launch|alarm|calendar|media|files)", 3, "changes phone state", True),
    (r"phone\.notifications\.read", 4, "reads notifications", True),
    (r"email\.read|calendar\.write|automation\.create", 3, "reads or writes personal data", True),
    (r"coding\.(execute|test|git|file\.write|project\.create)", 4, "runs or writes code", True),
    (r"creative\.document\.generate", 3, "generates a document", True),
    (r"memory\.delete", 4, "erases stored memory", False),
]

# Patterns that always downgrade to LOW (pure reads / conversation).
LOW_PATTERNS: List[Tuple[str, int, str, bool]] = [
    (r"ai\.(chat|reasoning|model_routing|local_model)", 0, "conversation / reasoning", True),
    (r"\.(info|list|read|search|status)\b", 0, "read-only inspection", True),
    (r"vision\.(image_analysis|ocr)|files\.search|files\.index", 1, "read-only analysis", True),
    (r"memory\.read|calendar\.read|research\.", 1, "read-only lookup", True),
    (r"voice\.speaker", 0, "plays audio locally", True),
]

# Words that add a little extra caution wherever they appear.
AMPLIFIERS: List[Tuple[str, int, str]] = [
    (r"\ball\b|\bevery\b|\brecursive(ly)?\b|\bbulk\b", 2, "operates on everything at once"),
    (r"\bpermanent(ly)?\b|\birreversib", 3, "cannot be undone"),
    (r"\bsystem\b|\bOS\b|\bboot\b|\bfirmware\b", 2, "touches the operating system"),
    (r"\bpassword\b|\bcredential\b|\bsecret\b|\bapi[_-]?key\b|\btoken\b", 3, "touches credentials"),
    (r"\bfinancial\b|\bbank\b|\bcard\b|\bupi\b|\bpayment\b", 4, "touches money"),
    (r"\bhealth\b|\bmedical\b", 2, "touches sensitive personal data"),
    (r"\boutside\b.*\b(allowed|root)|\bunknown\b.*\b(path|source)", 2, "target is outside a known-safe area"),
]


def _match(text: str, table: List[Tuple[str, int, str, bool]]) -> List[Tuple[int, str, bool]]:
    hits: List[Tuple[int, str, bool]] = []
    for pattern, points, reason, reversible in table:
        if re.search(pattern, text, re.IGNORECASE):
            hits.append((points, reason, reversible))
    return hits


class RiskEngine:
    """Stateless rule engine — deterministic and explainable."""

    def assess(
        self,
        *,
        capability: str = "",
        action: str = "",
        target: str = "",
        params: Optional[Dict[str, Any]] = None,
        permission_requires_confirmation: bool = False,
        batch_size: int = 1,
    ) -> RiskAssessment:
        blob = " ".join(
            [
                capability,
                action,
                target,
                " ".join(f"{k}={v}" for k, v in (params or {}).items() if isinstance(v, (str, int, float, bool))),
            ]
        ).strip()

        score = 0
        reasons: List[str] = []
        reversible = True

        critical_hits = _match(blob, CRITICAL_PATTERNS)
        for points, reason, rev in critical_hits:
            score += points
            reasons.append(f"CRITICAL: {reason}")
            reversible = reversible and rev

        # Once a CRITICAL rule fires we stop stacking HIGH/MEDIUM rules for the
        # same action, so one dangerous command is not counted three times.
        if not critical_hits:
            for points, reason, rev in _match(blob, HIGH_PATTERNS):
                score += points
                reasons.append(f"HIGH: {reason}")
                reversible = reversible and rev
            for points, reason, rev in _match(blob, MEDIUM_PATTERNS):
                score += points
                reasons.append(f"MEDIUM: {reason}")
                reversible = reversible and rev

        if score == 0:
            for points, reason, rev in _match(blob, LOW_PATTERNS):
                score += points
                reasons.append(f"LOW: {reason}")
                reversible = reversible and rev
        for pattern, points, reason in AMPLIFIERS:
            if re.search(pattern, blob, re.IGNORECASE):
                score += points
                reasons.append(f"AMPLIFIER: {reason}")

        # batch operations scale the risk
        if batch_size > 10:
            score += 2
            reasons.append(f"batch of {batch_size} items")
        if batch_size > 100:
            score += 3
            reasons.append(f"very large batch of {batch_size} items")

        if not reasons:
            reasons.append("no risk rule matched — treated as low risk")

        level = self._to_level(score)
        level, reasons = self._apply_mode(level, reasons)

        requires_confirmation = self._needs_confirmation(level, permission_requires_confirmation)
        style = "simple"
        if level == RiskLevel.HIGH:
            style = "typed"
        elif level == RiskLevel.CRITICAL:
            style = "passphrase"

        assessment = RiskAssessment(
            level=level,
            score=score,
            reasons=reasons,
            requires_confirmation=requires_confirmation,
            confirmation_style=style,
            capability=capability,
            action=action,
            target=target,
            reversible=reversible,
        )
        emit(Topics.RISK_ASSESSED, **assessment.to_dict())
        log.debug("risk=%s score=%d cap=%s action=%s", level.value, score, capability, action[:60])
        return assessment

    # ------------------------------------------------------------------
    @staticmethod
    def _to_level(score: int) -> RiskLevel:
        if score >= 12:
            return RiskLevel.CRITICAL
        if score >= 7:
            return RiskLevel.HIGH
        if score >= 3:
            return RiskLevel.MEDIUM
        return RiskLevel.LOW

    @staticmethod
    def _apply_mode(level: RiskLevel, reasons: List[str]) -> Tuple[RiskLevel, List[str]]:
        mode = settings.security_risk_mode
        if mode == "strict" and level == RiskLevel.LOW:
            return RiskLevel.MEDIUM, reasons + ["strict risk mode escalates LOW to MEDIUM"]
        if mode == "permissive" and level in (RiskLevel.MEDIUM,):
            return RiskLevel.LOW, reasons + ["permissive risk mode downgrades MEDIUM to LOW"]
        return level, reasons

    @staticmethod
    def _needs_confirmation(level: RiskLevel, permission_requires_confirmation: bool) -> bool:
        if level == RiskLevel.LOW:
            return False
        if level == RiskLevel.MEDIUM:
            return settings.security_require_confirmation_medium or permission_requires_confirmation
        # HIGH and CRITICAL always need explicit approval
        return True

    # ------------------------------------------------------------- helpers
    def is_blocked(self, level: RiskLevel) -> bool:
        """CRITICAL actions are never auto-executed — they always need a human."""
        return level == RiskLevel.CRITICAL

    def explain(self, assessment: RiskAssessment) -> str:
        lines = [
            f"Risk level: {assessment.level.value} (score {assessment.score})",
            f"Capability: {assessment.capability or '-'}",
            f"Action:     {assessment.action or '-'}",
            f"Target:     {assessment.target or '-'}",
            f"Reversible: {'yes' if assessment.reversible else 'NO'}",
            "Why:",
        ]
        lines += [f"  - {r}" for r in assessment.reasons]
        lines.append(
            "Confirmation: "
            + ("required (" + assessment.confirmation_style + ")" if assessment.requires_confirmation else "not required")
        )
        return "\n".join(lines)


risk_engine = RiskEngine()
