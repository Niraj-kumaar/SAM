"""
backend.app.security.audit
==========================

Append-only activity history. Every action SAM takes — allowed, denied,
confirmed, failed — lands here so the user can answer
*"what exactly did SAM do on my machine?"*

Storage
-------
* ``data/logs/audit.log`` — JSON-lines, human + machine readable
* ``audit_events`` table  — queryable from the Security Dashboard
* event bus ``security.audit`` — live tail in the UI
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import delete, func, select

from backend.app.config import settings
from backend.app.core.database import SessionLocal
from backend.app.core.event_bus import Topics, bus, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import AuditEvent

log = get_logger("security.audit")
audit_log = get_logger("audit")  # writes to sam.audit -> audit.log


class AuditTrail:
    """Facade over the audit log. Safe to call from anywhere."""

    def __init__(self) -> None:
        self._buffer: List[Dict[str, Any]] = []
        self._buffer_limit = 500

    # ---------------------------------------------------------------- record
    def record(
        self,
        *,
        action: str,
        target: str = "",
        result: str = "ok",          # ok | denied | failed | confirmed | skipped
        risk: str = "LOW",
        confirmation: str = "not_required",
        agent: str = "core",
        device: str = "pc",
        task_id: Optional[str] = None,
        detail: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "device": device,
            "agent": agent,
            "action": action,
            "target": target[:2000],
            "result": result,
            "risk": risk,
            "confirmation": confirmation,
            "task_id": task_id,
            "detail": detail or {},
        }
        self._buffer.append(entry)
        if len(self._buffer) > self._buffer_limit:
            self._buffer = self._buffer[-self._buffer_limit :]

        if settings.security_audit_enabled:
            audit_log.info(json.dumps(entry, default=str, ensure_ascii=False))
            emit(Topics.AUDIT, **entry)
            self._persist_soon(entry)
        return entry

    # -------------------------------------------------------------- helpers
    def allowed(self, action: str, target: str = "", **kw: Any) -> Dict[str, Any]:
        return self.record(action=action, target=target, result="ok", **kw)

    def denied(self, action: str, target: str = "", reason: str = "", **kw: Any) -> Dict[str, Any]:
        return self.record(action=action, target=target, result="denied",
                           detail={"reason": reason}, **kw)

    def failed(self, action: str, target: str = "", error: str = "", **kw: Any) -> Dict[str, Any]:
        return self.record(action=action, target=target, result="failed",
                           detail={"error": error}, **kw)

    def _persist_soon(self, entry: Dict[str, Any]) -> None:
        """Fire-and-forget DB write (never blocks the caller)."""
        import asyncio

        async def _write() -> None:
            try:
                async with SessionLocal() as db:
                    db.add(
                        AuditEvent(
                            ts=datetime.fromisoformat(entry["ts"]),
                            device=entry["device"],
                            agent=entry["agent"],
                            action=entry["action"],
                            target=entry["target"],
                            result=entry["result"],
                            risk=entry["risk"],
                            confirmation=entry["confirmation"],
                            task_id=entry["task_id"],
                            detail_json=json.dumps(entry["detail"], default=str),
                        )
                    )
                    await db.commit()
            except Exception as exc:  # pragma: no cover
                log.debug("audit persist failed: %s", exc)

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(_write())
        except RuntimeError:
            pass  # no loop yet (startup) — the JSONL file already captured it

    # ---------------------------------------------------------------- query
    async def query(
        self,
        limit: int = 100,
        offset: int = 0,
        device: Optional[str] = None,
        agent: Optional[str] = None,
        result: Optional[str] = None,
        risk: Optional[str] = None,
        since_hours: Optional[int] = None,
        search: Optional[str] = None,
    ) -> Dict[str, Any]:
        async with SessionLocal() as db:
            stmt = select(AuditEvent)
            count_stmt = select(func.count(AuditEvent.id))
            if device:
                stmt = stmt.where(AuditEvent.device == device)
                count_stmt = count_stmt.where(AuditEvent.device == device)
            if agent:
                stmt = stmt.where(AuditEvent.agent == agent)
                count_stmt = count_stmt.where(AuditEvent.agent == agent)
            if result:
                stmt = stmt.where(AuditEvent.result == result)
                count_stmt = count_stmt.where(AuditEvent.result == result)
            if risk:
                stmt = stmt.where(AuditEvent.risk == risk)
                count_stmt = count_stmt.where(AuditEvent.risk == risk)
            if since_hours:
                cutoff = datetime.now(timezone.utc) - timedelta(hours=since_hours)
                stmt = stmt.where(AuditEvent.ts >= cutoff)
                count_stmt = count_stmt.where(AuditEvent.ts >= cutoff)
            if search:
                like = f"%{search}%"
                stmt = stmt.where(AuditEvent.action.ilike(like) | AuditEvent.target.ilike(like))
                count_stmt = count_stmt.where(AuditEvent.action.ilike(like) | AuditEvent.target.ilike(like))

            total = (await db.execute(count_stmt)).scalar_one()
            rows = (
                (await db.execute(stmt.order_by(AuditEvent.ts.desc()).limit(limit).offset(offset)))
                .scalars()
                .all()
            )
            return {"total": total, "items": [r.to_dict() for r in rows]}

    async def clear(self, older_than_days: Optional[int] = None) -> int:
        """Clear local history. ``older_than_days=None`` clears everything."""
        async with SessionLocal() as db:
            stmt = delete(AuditEvent)
            if older_than_days:
                cutoff = datetime.now(timezone.utc) - timedelta(days=older_than_days)
                stmt = stmt.where(AuditEvent.ts < cutoff)
            res = await db.execute(stmt)
            await db.commit()
            n = res.rowcount or 0
        self._buffer.clear()
        self.record(action="audit.cleared", target=f"older_than_days={older_than_days}",
                    result="ok", risk="MEDIUM", agent="security")
        return n

    async def stats(self) -> Dict[str, Any]:
        async with SessionLocal() as db:
            total = (await db.execute(select(func.count(AuditEvent.id)))).scalar_one()
            by_result: Dict[str, int] = {}
            for res, cnt in (
                await db.execute(select(AuditEvent.result, func.count(AuditEvent.id)).group_by(AuditEvent.result))
            ).all():
                by_result[res] = cnt
            by_risk: Dict[str, int] = {}
            for rsk, cnt in (
                await db.execute(select(AuditEvent.risk, func.count(AuditEvent.id)).group_by(AuditEvent.risk))
            ).all():
                by_risk[rsk] = cnt
            last = (
                await db.execute(select(AuditEvent).order_by(AuditEvent.ts.desc()).limit(1))
            ).scalar_one_or_none()
        return {
            "total": total,
            "by_result": by_result,
            "by_risk": by_risk,
            "last": last.to_dict() if last else None,
            "buffered": len(self._buffer),
        }

    def recent(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._buffer[-limit:][::-1]


audit_trail = AuditTrail()


# Keep the bus and the trail in sync for events raised anywhere in the codebase.
def _mirror_permission_denied(ev) -> None:
    p = ev.payload or {}
    audit_trail.denied(action=p.get("capability", "unknown"), target=p.get("reason", ""),
                       risk="MEDIUM", agent="security")


bus.on(Topics.PERMISSION_DENIED, _mirror_permission_denied)

_t0 = time.time()


def uptime_seconds() -> float:
    return round(time.time() - _t0, 1)
