"""
backend.app.security.confirmation_engine
========================================

Human-in-the-loop gate. When the Risk Engine (or the Permission Engine) says an
action needs approval, the Confirmation Engine:

1. creates a pending confirmation with a unique id,
2. publishes ``security.confirmation_required`` so the UI can show the dialog,
3. suspends the calling agent on an ``asyncio.Event``,
4. resumes when the user approves / rejects (or when it times out -> reject).

Approval styles
---------------
``simple``     one tap Approve / Deny            (MEDIUM)
``typed``      user must type ``CONFIRM``        (HIGH)
``passphrase`` user must type the exact target   (CRITICAL)

"Remember this decision" stores a session-scoped allow/deny rule so repeated
identical actions do not nag the user.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import RiskLevel

log = get_logger("security.confirmation")


@dataclass
class PendingConfirmation:
    id: str
    capability: str
    action: str
    target: str
    risk: RiskLevel
    reasons: List[str] = field(default_factory=list)
    style: str = "simple"          # simple | typed | passphrase
    prompt: str = ""
    expected_phrase: str = ""
    task_id: Optional[str] = None
    device: str = "pc"
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0
    decision: Optional[bool] = None
    note: str = ""
    resolved_at: Optional[float] = None
    _event: asyncio.Event = field(default_factory=asyncio.Event, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "capability": self.capability,
            "action": self.action,
            "target": self.target,
            "risk": self.risk.value,
            "reasons": self.reasons,
            "style": self.style,
            "prompt": self.prompt,
            "expected_phrase": self.expected_phrase,
            "task_id": self.task_id,
            "device": self.device,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "decision": self.decision,
            "resolved": self.decision is not None,
            "note": self.note,
        }


@dataclass
class MemoryRule:
    """Session-scoped 'remember my answer' rule."""

    key: str
    allow: bool
    created_at: float = field(default_factory=time.time)


class ConfirmationEngine:
    def __init__(self) -> None:
        self._pending: Dict[str, PendingConfirmation] = {}
        self._rules: Dict[str, MemoryRule] = {}
        self._history: List[Dict[str, Any]] = []
        self._lock = asyncio.Lock()

    # ---------------------------------------------------------------- keys
    @staticmethod
    def _rule_key(capability: str, action: str, target: str) -> str:
        return f"{capability}|{action}|{target}".lower()

    def remember(self, capability: str, action: str, target: str, allow: bool) -> None:
        self._rules[self._rule_key(capability, action, target)] = MemoryRule(
            key=self._rule_key(capability, action, target), allow=allow
        )

    def remembered(self, capability: str, action: str, target: str) -> Optional[bool]:
        rule = self._rules.get(self._rule_key(capability, action, target))
        return rule.allow if rule else None

    def clear_rules(self) -> int:
        n = len(self._rules)
        self._rules.clear()
        return n

    # ------------------------------------------------------------ request
    async def request(
        self,
        *,
        capability: str,
        action: str,
        target: str = "",
        risk: RiskLevel = RiskLevel.MEDIUM,
        reasons: Optional[List[str]] = None,
        style: str = "simple",
        prompt: str = "",
        task_id: Optional[str] = None,
        device: str = "pc",
        timeout: Optional[int] = None,
        auto_deny_critical: bool = False,
    ) -> PendingConfirmation:
        """Create a pending confirmation and wait for the user's answer."""
        remembered = self.remembered(capability, action, target)
        if remembered is not None and risk not in (RiskLevel.CRITICAL,):
            pc = PendingConfirmation(
                id=f"cf_{uuid.uuid4().hex[:10]}",
                capability=capability,
                action=action,
                target=target,
                risk=risk,
                reasons=(reasons or []) + ["resolved from a remembered decision"],
                style="auto",
                decision=remembered,
                resolved_at=time.time(),
            )
            self._history.append(pc.to_dict())
            emit(Topics.CONFIRMATION_RESOLVED, **pc.to_dict())
            return pc

        ttl = timeout if timeout is not None else settings.security_confirmation_timeout_seconds
        pc = PendingConfirmation(
            id=f"cf_{uuid.uuid4().hex[:10]}",
            capability=capability,
            action=action,
            target=target,
            risk=risk,
            reasons=reasons or [],
            style=style,
            prompt=prompt or self._default_prompt(capability, action, target, risk),
            expected_phrase=target if style == "passphrase" else ("CONFIRM" if style == "typed" else ""),
            task_id=task_id,
            device=device,
            expires_at=time.time() + ttl,
        )

        async with self._lock:
            self._pending[pc.id] = pc

        emit(Topics.CONFIRMATION_REQUIRED, **pc.to_dict())
        emit(Topics.NOTIFICATION, kind="confirmation", title="SAM needs your approval",
             body=pc.prompt, confirmation_id=pc.id, risk=risk.value)
        log.info("confirmation %s required for %s (%s)", pc.id, action, risk.value)

        if auto_deny_critical and risk == RiskLevel.CRITICAL:
            await self.resolve(pc.id, False, note="critical actions are never auto-executed")
            return pc

        try:
            await asyncio.wait_for(pc._event.wait(), timeout=ttl)
        except asyncio.TimeoutError:
            await self.resolve(pc.id, False, note="confirmation timed out")
        return pc

    @staticmethod
    def _default_prompt(capability: str, action: str, target: str, risk: RiskLevel) -> str:
        head = {
            RiskLevel.LOW: "SAM wants to run a low-risk action.",
            RiskLevel.MEDIUM: "SAM needs your permission for a medium-risk action.",
            RiskLevel.HIGH: "SAM needs explicit approval for a HIGH-RISK action.",
            RiskLevel.CRITICAL: "CRITICAL — SAM will not run this without you typing the exact target.",
        }[risk]
        bits = [head, f"Capability: {capability}", f"Action: {action}"]
        if target:
            bits.append(f"Target: {target}")
        return "\n".join(bits)

    # ------------------------------------------------------------ resolve
    async def resolve(
        self,
        confirmation_id: str,
        approved: bool,
        note: str = "",
        phrase: str = "",
        remember: bool = False,
    ) -> Dict[str, Any]:
        async with self._lock:
            pc = self._pending.get(confirmation_id)
            if pc is None:
                return {"ok": False, "error": "unknown or expired confirmation", "id": confirmation_id}
            if pc.decision is not None:
                return {"ok": True, "id": confirmation_id, "decision": pc.decision, "already_resolved": True}

            # typed / passphrase validation
            if approved and pc.style == "typed" and phrase.strip().upper() != "CONFIRM":
                return {"ok": False, "id": confirmation_id,
                        "error": "type CONFIRM exactly to approve a high-risk action"}
            if approved and pc.style == "passphrase" and phrase.strip() != pc.expected_phrase:
                return {"ok": False, "id": confirmation_id,
                        "error": f"type the exact target ({pc.expected_phrase}) to approve"}

            pc.decision = bool(approved)
            pc.note = note
            pc.resolved_at = time.time()
            pc._event.set()
            self._pending.pop(confirmation_id, None)

        if remember:
            self.remember(pc.capability, pc.action, pc.target, pc.decision)

        record = pc.to_dict()
        self._history.append(record)
        if len(self._history) > 500:
            self._history = self._history[-500:]
        emit(Topics.CONFIRMATION_RESOLVED, **record)
        log.info("confirmation %s -> %s", confirmation_id, "APPROVED" if pc.decision else "DENIED")
        return {"ok": True, "id": confirmation_id, "decision": pc.decision}

    # ------------------------------------------------------------- introspect
    def pending(self) -> List[Dict[str, Any]]:
        now = time.time()
        out = [pc.to_dict() for pc in self._pending.values() if pc.expires_at > now]
        return sorted(out, key=lambda d: d["created_at"])

    def history(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._history[-limit:][::-1]

    async def cancel_all(self, reason: str = "cancelled") -> int:
        ids = list(self._pending.keys())
        for cid in ids:
            await self.resolve(cid, False, note=reason)
        return len(ids)


confirmation_engine = ConfirmationEngine()
