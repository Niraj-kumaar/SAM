"""
backend.app.security.permissions
================================

The Permission Engine. Every SAM capability is registered here with:

* a **category** (READ / WRITE / EXECUTE / COMMUNICATE / FINANCIAL / SYSTEM /
  PRIVACY / DEVICE)
* a **default grant** (off until the user turns it on for sensitive ones)
* whether it **requires confirmation**
* an optional **scope** (path globs, app allow-lists, domains, etc.)

Flow::

    USER -> SAM -> RISK ANALYZER -> PERMISSION ENGINE -> ACTION

Nothing in the tool layer executes without ``permission_engine.check()``
returning ``ALLOW``.
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from sqlalchemy import select

from backend.app.core.database import SessionLocal
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import PermissionGrant
from backend.app.core.schemas import PermissionCategory

log = get_logger("security.permissions")


@dataclass
class Capability:
    """A single thing SAM can do."""

    name: str
    category: PermissionCategory
    description: str = ""
    default_granted: bool = False
    requires_confirmation: bool = True
    scope: Dict[str, Any] = field(default_factory=dict)
    os_requirement: str = ""     # extra OS-level gate, e.g. "windows", "android:accessibility"


class Decision:
    ALLOW = "ALLOW"
    DENY = "DENY"
    CONFIRM = "CONFIRM"


@dataclass
class PermissionResult:
    decision: str
    capability: str
    reason: str = ""
    requires_confirmation: bool = False
    category: str = "SYSTEM"

    @property
    def allowed(self) -> bool:
        return self.decision == Decision.ALLOW

    def to_dict(self) -> Dict[str, Any]:
        return {
            "decision": self.decision,
            "capability": self.capability,
            "reason": self.reason,
            "requires_confirmation": self.requires_confirmation,
            "category": self.category,
        }


# ---------------------------------------------------------------------------
# Capability registry
# ---------------------------------------------------------------------------
C = PermissionCategory

CAPABILITIES: List[Capability] = [
    # ---- conversation / reasoning -------------------------------------
    Capability("ai.chat", C.READ, "Converse and reason with the user", True, False),
    Capability("ai.reasoning", C.READ, "Multi-step reasoning and planning", True, False),
    Capability("ai.model_routing", C.READ, "Choose between model providers", True, False),
    Capability("ai.local_model", C.READ, "Run a local model (Ollama)", True, False),
    Capability("ai.cloud_model", C.PRIVACY, "Send prompts to a cloud provider", False, False,
               os_requirement="cloud"),

    # ---- voice ---------------------------------------------------------
    Capability("voice.microphone", C.PRIVACY, "Capture microphone audio", False, True),
    Capability("voice.speaker", C.READ, "Play synthesised speech", True, False),
    Capability("voice.wake_word", C.PRIVACY, "Always-on wake word detection", False, True),

    # ---- vision --------------------------------------------------------
    Capability("vision.screen_capture", C.PRIVACY, "Capture the PC screen", False, True),
    Capability("vision.image_analysis", C.READ, "Analyse user-supplied images", True, False),
    Capability("vision.camera", C.PRIVACY, "Access a camera", False, True),
    Capability("vision.ocr", C.READ, "Optical character recognition", True, False),

    # ---- PC: applications ----------------------------------------------
    Capability("pc.apps.list", C.READ, "List installed/running applications", True, False),
    Capability("pc.apps.launch", C.EXECUTE, "Launch an application", True, True),
    Capability("pc.apps.close", C.EXECUTE, "Close an application", True, True),
    Capability("pc.windows.manage", C.SYSTEM, "Focus/minimise/maximise/move/resize windows", True, True),

    # ---- PC: input ------------------------------------------------------
    Capability("pc.keyboard", C.EXECUTE, "Send keystrokes and shortcuts", False, True),
    Capability("pc.mouse", C.EXECUTE, "Move the cursor and click", False, True),
    Capability("pc.clipboard.read", C.PRIVACY, "Read the clipboard", False, True),
    Capability("pc.clipboard.write", C.WRITE, "Write to the clipboard", True, False),
    Capability("pc.ui_automation", C.EXECUTE, "Drive apps through UI Automation", False, True),

    # ---- PC: system -----------------------------------------------------
    Capability("pc.system.info", C.READ, "Read CPU/RAM/disk/network/battery state", True, False),
    Capability("pc.system.processes", C.READ, "List running processes", True, False),
    Capability("pc.system.services", C.READ, "List Windows services", False, False),
    Capability("pc.settings.read", C.READ, "Read Windows settings", True, False),
    Capability("pc.settings.write", C.SYSTEM, "Change Windows settings", False, True),
    Capability("pc.power.lock", C.SYSTEM, "Lock the PC", False, True),
    Capability("pc.power.sleep", C.SYSTEM, "Put the PC to sleep", False, True),
    Capability("pc.power.restart", C.SYSTEM, "Restart the PC", False, True),
    Capability("pc.power.shutdown", C.SYSTEM, "Shut down the PC", False, True),
    Capability("pc.power.signout", C.SYSTEM, "Sign the user out", False, True),

    # ---- PC: terminal ---------------------------------------------------
    Capability("pc.terminal.run", C.EXECUTE, "Run a shell command", False, True),
    Capability("pc.terminal.dangerous", C.SYSTEM, "Run a command flagged high-risk", False, True),
    Capability("pc.dev.tools", C.EXECUTE, "Use git / node / python / package managers", True, True),

    # ---- files ----------------------------------------------------------
    Capability("files.read", C.READ, "Read files inside the allowed roots", True, False),
    Capability("files.write", C.WRITE, "Create or modify files", True, True),
    Capability("files.delete", C.WRITE, "Delete files", False, True),
    Capability("files.move", C.WRITE, "Move or rename files", True, True),
    Capability("files.archive", C.WRITE, "Compress or extract archives", True, True),
    Capability("files.search", C.READ, "Search files by name/content/meaning", True, False),
    Capability("files.index", C.READ, "Build the local semantic index", True, False),
    Capability("files.upload", C.PRIVACY, "Upload a file anywhere", False, True),
    Capability("files.convert", C.WRITE, "Convert between document formats", True, False),

    # ---- browser --------------------------------------------------------
    Capability("browser.open", C.EXECUTE, "Open the browser / tabs / URLs", True, True),
    Capability("browser.read", C.READ, "Read page content", True, False),
    Capability("browser.interact", C.EXECUTE, "Click, type and fill forms", False, True),
    Capability("browser.download", C.WRITE, "Download files", True, True),
    Capability("browser.credentials", C.PRIVACY, "Use the logged-in browser session", False, True),
    Capability("browser.purchase", C.FINANCIAL, "Complete any purchase flow", False, True),

    # ---- research -------------------------------------------------------
    Capability("research.web_search", C.READ, "Search the public web", True, False),
    Capability("research.fetch_page", C.READ, "Fetch and read a web page", True, False),

    # ---- coding ---------------------------------------------------------
    Capability("coding.project.create", C.WRITE, "Scaffold a new project", True, True),
    Capability("coding.file.write", C.WRITE, "Write source files", True, True),
    Capability("coding.execute", C.EXECUTE, "Execute generated code", False, True),
    Capability("coding.test", C.EXECUTE, "Run a test suite", True, True),
    Capability("coding.git", C.EXECUTE, "Run git commands", True, True),

    # ---- creative -------------------------------------------------------
    Capability("creative.image.generate", C.WRITE, "Generate images", True, False),
    Capability("creative.image.edit", C.WRITE, "Edit images", True, False),
    Capability("creative.document.generate", C.WRITE, "Create DOCX/PPTX/XLSX/PDF", True, True),

    # ---- phone ----------------------------------------------------------
    Capability("phone.connect", C.DEVICE, "Pair with the Android companion", False, True),
    Capability("phone.state.read", C.DEVICE, "Read battery/wifi/storage state", True, False),
    Capability("phone.apps.launch", C.DEVICE, "Launch a phone app", True, True),
    Capability("phone.settings.write", C.DEVICE, "Change phone settings", False, True),
    Capability("phone.notifications.read", C.PRIVACY, "Read phone notifications", False, True),
    Capability("phone.notifications.post", C.DEVICE, "Post a phone notification", True, False),
    Capability("phone.alarm", C.DEVICE, "Create alarms and timers", True, True),
    Capability("phone.calendar", C.DEVICE, "Read/write phone calendar", False, True),
    Capability("phone.sms.send", C.COMMUNICATE, "Send an SMS", False, True),
    Capability("phone.call", C.COMMUNICATE, "Place a phone call", False, True),
    Capability("phone.contacts", C.PRIVACY, "Read contacts", False, True),
    Capability("phone.files", C.DEVICE, "Access phone storage", False, True),
    Capability("phone.media", C.DEVICE, "Control media playback / camera", True, True),
    Capability("phone.accessibility", C.EXECUTE, "Drive apps via Accessibility Service", False, True),
    Capability("phone.location", C.PRIVACY, "Read device location", False, True),

    # ---- communication --------------------------------------------------
    Capability("email.read", C.PRIVACY, "Read email", False, True),
    Capability("email.draft", C.WRITE, "Compose an email draft (never sends)", True, False),
    Capability("email.send", C.COMMUNICATE, "Send email", False, True),
    Capability("calendar.read", C.READ, "Read calendar", True, False),
    Capability("calendar.write", C.WRITE, "Create/modify calendar events", True, True),
    Capability("calendar.manage", C.WRITE, "Create, change or delete calendar events", True, True),
    Capability("social.post", C.COMMUNICATE, "Publish to a social platform", False, True),

    # ---- memory ---------------------------------------------------------
    Capability("memory.read", C.READ, "Recall stored context", True, False),
    Capability("memory.write", C.PRIVACY, "Store long-term memory", True, False),
    Capability("memory.delete", C.WRITE, "Delete stored memory", True, True),

    # ---- files: backup / cleanup ---------------------------------------
    Capability("files.backup", C.WRITE, "Create backups of folders", True, True),
    Capability("files.clean", C.WRITE, "Delete temporary and cache files", False, True),

    # ---- scheduling / automation ---------------------------------------
    Capability("scheduler.create", C.WRITE, "Create scheduled jobs", True, True),
    Capability("scheduler.read", C.READ, "List scheduled jobs", True, False),
    Capability("scheduler.update", C.WRITE, "Change or reschedule a job", True, True),
    Capability("scheduler.delete", C.WRITE, "Cancel a scheduled job", True, True),
    Capability("automation.create", C.WRITE, "Create automations and schedules", True, True),
    Capability("automation.read", C.READ, "List automation rules", True, False),
    Capability("automation.update", C.WRITE, "Change, enable or delete a rule", True, True),
    Capability("automation.run", C.EXECUTE, "Execute an automation", True, False),
    Capability("proactive.monitor", C.PRIVACY, "Monitor approved signals proactively", False, False),

    # ---- Market Analyzer brain (analysis + paper trading only) -----------
    Capability("market.data.read", C.READ, "Read public market prices and feeds", True, False),
    Capability("market.analysis", C.READ, "Run technical analysis and produce signals", True, False),
    Capability("market.backtest", C.READ, "Backtest a strategy on historical data", True, False),
    Capability("market.news", C.READ, "Read market news and sentiment", True, False),
    Capability("market.alerts", C.WRITE, "Create and manage price alerts", True, False),
    Capability("market.journal", C.WRITE, "Keep a trading journal", True, False),
    Capability("market.paper_trading", C.FINANCIAL, "Open/close VIRTUAL (paper) trades", True, True),
    Capability("market.live_trading", C.FINANCIAL,
               "Place a real order through a broker bridge (disabled by policy)", False, True,
               os_requirement="broker"),
    Capability("market.broker_credentials", C.PRIVACY,
               "Store broker API credentials (never done by default)", False, True),

    # ---- ChatGPT-style text + developer utilities ------------------------
    Capability("text.transform", C.READ, "Analyse and transform text locally (counts, cases, "
                                         "extract, diff, redact)", True, False),
    Capability("text.generate", C.WRITE, "Generate or rewrite text with a language model", True, False),
    Capability("code.utilities", C.READ, "Developer utilities: regex, JSON/YAML/CSV, hashing, "
                                         "encoding, JWT, cron, colour", True, False),
    Capability("code.sql", C.WRITE, "Run SQL against a local SQLite database", True, True),
    Capability("code.artifact", C.WRITE, "Save a generated artifact into the workspace", True, False),
    Capability("ai.agent_loop", C.READ, "Let a model drive multi-step tool calls", True, False),
]

BY_NAME: Dict[str, Capability] = {c.name: c for c in CAPABILITIES}


class PermissionEngine:
    """Runtime permission store with DB-backed user overrides."""

    def __init__(self) -> None:
        self._overrides: Dict[str, PermissionGrant] = {}
        self._loaded = False

    # ----------------------------------------------------------------- load
    async def load(self) -> None:
        """Load user overrides from the DB; seed defaults on first run."""
        try:
            async with SessionLocal() as db:
                rows = (await db.execute(select(PermissionGrant))).scalars().all()
                existing = {r.capability: r for r in rows}
                for cap in CAPABILITIES:
                    if cap.name not in existing:
                        db.add(
                            PermissionGrant(
                                capability=cap.name,
                                category=cap.category.value,
                                granted=cap.default_granted,
                                requires_confirmation=cap.requires_confirmation,
                                scope_json="{}",
                                note=cap.description,
                            )
                        )
                await db.commit()
                rows = (await db.execute(select(PermissionGrant))).scalars().all()
                self._overrides = {r.capability: r for r in rows}
            self._loaded = True
            log.info("permission engine loaded %d capabilities", len(self._overrides))
        except Exception as exc:  # pragma: no cover
            log.warning("permission load failed (%s) — using defaults", exc)
            self._overrides = {}

    # ----------------------------------------------------------------- read
    def capability(self, name: str) -> Optional[Capability]:
        return BY_NAME.get(name)

    def state(self) -> List[Dict[str, Any]]:
        out = []
        for cap in CAPABILITIES:
            row = self._overrides.get(cap.name)
            out.append(
                {
                    "capability": cap.name,
                    "category": cap.category.value,
                    "description": cap.description,
                    "granted": bool(row.granted) if row else cap.default_granted,
                    "requires_confirmation": bool(row.requires_confirmation)
                    if row
                    else cap.requires_confirmation,
                    "os_requirement": cap.os_requirement,
                }
            )
        return out

    def granted(self, name: str) -> bool:
        cap = BY_NAME.get(name)
        if cap is None:
            return False
        row = self._overrides.get(name)
        return bool(row.granted) if row else cap.default_granted

    def summary(self) -> Dict[str, bool]:
        """Compact dashboard view grouped by top-level namespace."""
        groups: Dict[str, List[bool]] = {}
        for cap in CAPABILITIES:
            key = cap.name.split(".")[0]
            groups.setdefault(key, []).append(self.granted(cap.name))
        return {k: any(v) for k, v in groups.items()}

    # ---------------------------------------------------------------- write
    async def set_grant(
        self,
        name: str,
        granted: Optional[bool] = None,
        requires_confirmation: Optional[bool] = None,
        note: Optional[str] = None,
    ) -> Dict[str, Any]:
        if name not in BY_NAME:
            raise KeyError(f"unknown capability: {name}")
        if not self._loaded:
            await self.load()
        cap = BY_NAME[name]
        async with SessionLocal() as db:
            row = (
                await db.execute(select(PermissionGrant).where(PermissionGrant.capability == name))
            ).scalar_one_or_none()
            if row is None:
                row = PermissionGrant(capability=name, category=cap.category.value)
                db.add(row)
            if granted is not None:
                row.granted = granted
            if requires_confirmation is not None:
                row.requires_confirmation = requires_confirmation
            if note is not None:
                row.note = note
            row.scope_json = "{}"
            await db.commit()
            self._overrides[name] = row
            result = {
                "capability": name,
                "granted": row.granted,
                "requires_confirmation": row.requires_confirmation,
            }
        emit(Topics.AUDIT, action="permission.changed", target=name, detail=result)
        return result

    async def grant_group(self, prefix: str, granted: bool) -> int:
        n = 0
        for cap in CAPABILITIES:
            if cap.name.startswith(prefix):
                await self.set_grant(cap.name, granted=granted)
                n += 1
        return n

    async def reset(self) -> int:
        """Restore every capability to its built-in default grant state."""
        n = 0
        for cap in CAPABILITIES:
            await self.set_grant(cap.name, granted=cap.default_granted,
                                 requires_confirmation=cap.requires_confirmation,
                                 note="reset to default")
            n += 1
        emit(Topics.PERMISSION_DENIED, event="reset", count=n)
        log.warning("all permissions reset to defaults (%d capabilities)", n)
        return n

    # --------------------------------------------------------------- check
    def check(
        self,
        capability: str,
        *,
        context: Optional[Dict[str, Any]] = None,
        path: Optional[str] = None,
    ) -> PermissionResult:
        """
        Decide whether ``capability`` may run right now.

        Returns ALLOW / DENY / CONFIRM. The caller (Action Engine) is
        responsible for routing CONFIRM through the Confirmation Engine.
        """
        from backend.app.config import settings

        cap = BY_NAME.get(capability)
        if cap is None:
            return PermissionResult(Decision.DENY, capability, "capability is not registered")

        row = self._overrides.get(capability)
        granted = bool(row.granted) if row else cap.default_granted
        confirm = bool(row.requires_confirmation) if row else cap.requires_confirmation

        # global privacy-mode gates -------------------------------------
        if settings.sam_mode == "local" and cap.os_requirement == "cloud":
            return PermissionResult(Decision.DENY, capability, "Local Mode: cloud calls are disabled",
                                    category=cap.category.value)
        if settings.privacy_cloud_ai and cap.os_requirement == "cloud":
            return PermissionResult(Decision.DENY, capability, "Privacy Mode: cloud AI is off",
                                    category=cap.category.value)
        if not settings.web_enabled and capability.startswith(
                ("research.", "browser.", "market.data.", "market.analysis", "market.backtest",
                 "market.news")):
            return PermissionResult(Decision.DENY, capability, "Privacy Mode: external web access is off",
                                    category=cap.category.value)
        if not settings.privacy_phone_sync and capability.startswith("phone."):
            return PermissionResult(Decision.DENY, capability, "Phone sync is disabled in Privacy Mode",
                                    category=cap.category.value)

        # per-feature master switches ------------------------------------
        gate = {
            "pc.": settings.pc_control_enabled,
            "files.": settings.files_enabled,
            "browser.": settings.browser_enabled,
            "phone.": settings.phone_enabled,
            "voice.": settings.voice_enabled,
        }
        for prefix, enabled in gate.items():
            if capability.startswith(prefix) and not enabled:
                return PermissionResult(Decision.DENY, capability,
                                        f"{prefix.rstrip('.')} layer is disabled in configuration",
                                        category=cap.category.value)

        # phone sub-permissions ------------------------------------------
        if capability == "phone.accessibility" and not settings.phone_allow_accessibility:
            return PermissionResult(Decision.DENY, capability,
                                    "PHONE_ALLOW_ACCESSIBILITY=false in .env", category=cap.category.value)
        if capability == "phone.sms.send" and not settings.phone_allow_sms:
            return PermissionResult(Decision.DENY, capability,
                                    "PHONE_ALLOW_SMS=false in .env", category=cap.category.value)
        if capability == "phone.call" and not settings.phone_allow_calls:
            return PermissionResult(Decision.DENY, capability,
                                    "PHONE_ALLOW_CALLS=false in .env", category=cap.category.value)
        if capability == "phone.contacts" and not settings.phone_allow_contacts:
            return PermissionResult(Decision.DENY, capability,
                                    "PHONE_ALLOW_CONTACTS=false in .env", category=cap.category.value)
        if capability == "market.live_trading" and not settings.market_allow_live_trading:
            return PermissionResult(Decision.DENY, capability,
                                    "MARKET_ALLOW_LIVE_TRADING=false in .env — SAM is in "
                                    "analysis + paper-trading mode and will not place real orders",
                                    category=cap.category.value)
        if capability.startswith("market.") and not settings.market_enabled:
            return PermissionResult(Decision.DENY, capability,
                                    "The Market Analyzer brain is disabled (MARKET_ENABLED=false)",
                                    category=cap.category.value)
        if capability.startswith("pc.power.") and not settings.pc_power_control_enabled:
            return PermissionResult(Decision.DENY, capability,
                                    "PC_POWER_CONTROL_ENABLED=false in .env", category=cap.category.value)

        if not granted:
            emit(Topics.PERMISSION_DENIED, capability=capability, category=cap.category.value,
                 reason="not granted")
            return PermissionResult(Decision.DENY, capability,
                                    "permission not granted — enable it in the Security Center",
                                    category=cap.category.value)

        # scope checks ----------------------------------------------------
        if path and not self._path_allowed(path):
            emit(Topics.PERMISSION_DENIED, capability=capability, reason="path outside allowed roots")
            return PermissionResult(Decision.DENY, capability,
                                    f"path is outside the allowed roots: {path}",
                                    category=cap.category.value)

        if confirm and settings.security_risk_mode != "permissive":
            return PermissionResult(Decision.CONFIRM, capability,
                                    "capability requires user confirmation", True, cap.category.value)

        return PermissionResult(Decision.ALLOW, capability, "granted", False, cap.category.value)

    # ------------------------------------------------------------- helpers
    @staticmethod
    def _path_allowed(path: str) -> bool:
        from backend.app.config import settings
        from pathlib import Path

        try:
            p = Path(path).expanduser().resolve()
        except Exception:
            return False
        for denied in settings.denied_patterns:
            if fnmatch.fnmatch(p.as_posix(), denied) or fnmatch.fnmatch(p.name, denied):
                return False
        roots = settings.allowed_roots
        if not roots:
            return True
        return any(p == r or r in p.parents for r in roots)


permission_engine = PermissionEngine()
