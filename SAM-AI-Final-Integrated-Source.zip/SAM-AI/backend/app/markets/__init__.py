"""
backend.app.markets
===================

SAM's **Market Analyzer brain** (the 18th brain).

Sub-modules
-----------
================  =========================================================
``data_feed``     keyless market data: forex, crypto, stocks, indices,
                  commodities, FX tables, feed health
``indicators``    the technical-analysis library (trend, momentum, volatility,
                  volume, levels, patterns, divergence)
``signals``       indicator-vote scoring → bias, confidence, reasons, regime,
                  forex trade plans, binary-options expiry analysis
``risk``          position sizing, pip value, Kelly, risk of ruin, drawdown,
                  margin, portfolio risk, expectancy, stake plans
``backtest``      rule replay with costs, walk-forward folds, binary backtest
``journal``       trade journal, price alerts, virtual (paper) trading account
``alerts``        the background poller that watches alerts
================  =========================================================

**Boundary:** this package *reads public data* and *computes*. It never places a
real order, never stores broker credentials, and never bypasses a broker's or a
regulator's controls. Paper trading is the default. See ``signals.BINARY_WARNING``
for the regulatory note that is attached to every binary-options analysis.
"""

from __future__ import annotations

__all__ = ["data_feed", "indicators", "signals", "risk", "backtest", "journal", "alerts"]
