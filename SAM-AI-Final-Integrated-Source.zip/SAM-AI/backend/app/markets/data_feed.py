"""
backend.app.markets.data_feed
=============================

**Market data for SAM's Market Analyzer brain — every source is keyless.**

===============  =========================================================  ================
Asset class      Source                                                     Data
===============  =========================================================  ================
Forex (spot)     Yahoo Finance ``/v8/finance/chart/EURUSD=X``               1m … 1mo OHLCV
Forex (daily)    Frankfurter (ECB reference rates)                          daily closes, 1999→
Crypto           Yahoo ``BTC-USD`` + CoinGecko ``/ohlc`` ``/market_chart``   1m … 1d OHLCV
Stocks / ETF     Yahoo ``AAPL``, ``RELIANCE.NS``, ``TCS.NS``                1m … 1mo OHLCV
Indices          Yahoo ``^NSEI``, ``^BSESN``, ``^GSPC``, ``^IXIC``          1m … 1mo OHLCV
Commodities      Yahoo ``GC=F`` (gold), ``CL=F`` (WTI), ``SI=F`` (silver)   1m … 1mo OHLCV
FX rate table    open.er-api.com / Frankfurter                              150+ currencies
News/sentiment   Google News RSS                                            headlines
===============  =========================================================  ================

If the user adds a paid key later (``MARKET_DATA_PROVIDER=alpha_vantage`` +
``ALPHA_VANTAGE_API_KEY``, or ``TWELVEDATA_API_KEY``), :func:`candles` upgrades
automatically — the tool layer does not change.

Nothing here trades. This module only **reads public price data**.
"""

from __future__ import annotations

import asyncio
import re
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.utils import net

log = get_logger("markets.data")

YAHOO_CHART = "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"

# ---------------------------------------------------------------------------
# symbol resolution
# ---------------------------------------------------------------------------
# filler words between two currency names: "dollar to rupee", "usd vs inr"
_FX_CONNECTORS = {"to", "into", "in", "against", "vs", "versus", "per", "from", "and", "1", "one"}

# the ECB reference basket that frankfurter.app actually publishes
ECB_CURRENCIES = {
    "EUR", "USD", "JPY", "GBP", "CHF", "AUD", "CAD", "CNY", "INR", "KRW", "MXN", "NZD",
    "SEK", "NOK", "DKK", "PLN", "HUF", "CZK", "RON", "BGN", "HRK", "ISK", "TRY", "ZAR",
    "BRL", "IDR", "MYR", "PHP", "SGD", "THB", "ILS", "RUB",
}

FOREX_CCY = {
    "usd": "USD", "dollar": "USD", "dollars": "USD", "eur": "EUR", "euro": "EUR",
    "gbp": "GBP", "pound": "GBP", "sterling": "GBP", "jpy": "JPY", "yen": "JPY",
    "chf": "CHF", "swiss": "CHF", "cad": "CAD", "loonie": "CAD", "aud": "AUD",
    "nzd": "NZD", "cny": "CNY", "yuan": "CNY", "renminbi": "CNY", "inr": "INR",
    "rupee": "INR", "rupees": "INR", "sgd": "SGD", "hkd": "HKD", "sek": "SEK",
    "nok": "NOK", "dkk": "DKK", "mxn": "MXN", "zar": "ZAR", "rand": "ZAR",
    "try": "TRY", "lira": "TRY", "pln": "PLN", "zloty": "PLN", "krw": "KRW",
    "won": "KRW", "brl": "BRL", "real": "BRL", "aed": "AED", "dirham": "AED",
    "sar": "SAR", "thb": "THB", "baht": "THB", "myr": "MYR", "idr": "IDR",
    "rupiah": "IDR", "php": "PHP", "peso": "PHP", "czk": "CZK", "huf": "HUF",
    "ils": "ILS", "shekel": "ILS", "rub": "RUB", "ruble": "RUB",
}

CRYPTO_ALIASES = {
    "btc": "bitcoin", "bitcoin": "bitcoin", "eth": "ethereum", "ethereum": "ethereum",
    "sol": "solana", "solana": "solana", "xrp": "ripple", "ripple": "ripple",
    "doge": "dogecoin", "dogecoin": "dogecoin", "ada": "cardano", "cardano": "cardano",
    "bnb": "binancecoin", "avax": "avalanche-2", "avalanche": "avalanche-2",
    "dot": "polkadot", "polkadot": "polkadot", "matic": "matic-network",
    "pol": "polygon-ecosystem-token", "polygon": "polygon-ecosystem-token",
    "link": "chainlink", "chainlink": "chainlink", "ltc": "litecoin",
    "litecoin": "litecoin", "tron": "tron", "trx": "tron", "shib": "shiba-inu",
    "atom": "cosmos", "near": "near", "apt": "aptos", "arb": "arbitrum",
    "op": "optimism", "uni": "uniswap", "aave": "aave", "xlm": "stellar",
    "stellar": "stellar", "etc": "ethereum-classic", "fil": "filecoin",
    "sui": "sui", "ton": "the-open-network", "usdt": "tether", "usdc": "usd-coin",
}

# coingecko id -> the base symbol the price feeds use ("bitcoin" -> "BTC-USD")
CRYPTO_TICKER = {
    "bitcoin": "BTC", "ethereum": "ETH", "solana": "SOL", "ripple": "XRP",
    "dogecoin": "DOGE", "cardano": "ADA", "binancecoin": "BNB", "avalanche-2": "AVAX",
    "polkadot": "DOT", "matic-network": "MATIC", "polygon-ecosystem-token": "POL",
    "chainlink": "LINK", "litecoin": "LTC", "tron": "TRX", "shiba-inu": "SHIB",
    "cosmos": "ATOM", "near": "NEAR", "aptos": "APT", "arbitrum": "ARB",
    "optimism": "OP", "uniswap": "UNI", "aave": "AAVE", "stellar": "XLM",
    "ethereum-classic": "ETC", "filecoin": "FIL", "sui": "SUI",
    "the-open-network": "TON", "tether": "USDT", "usd-coin": "USDC",
}

INDICES = {
    "nifty": "^NSEI", "nifty50": "^NSEI", "nifty 50": "^NSEI", "nse": "^NSEI",
    "sensex": "^BSESN", "bse": "^BSESN", "niftybank": "^NSEBANK",
    "banknifty": "^NSEBANK", "bank nifty": "^NSEBANK", "nifty bank": "^NSEBANK", "finnifty": "^CNXFIN", "sp500": "^GSPC",
    "s&p": "^GSPC", "s&p 500": "^GSPC", "nasdaq": "^IXIC", "dow": "^DJI",
    "dow jones": "^DJI", "russell": "^RUT", "vix": "^VIX", "india vix": "^INDIAVIX",
    "dax": "^GDAXI", "ftse": "^FTSE", "nikkei": "^N225", "hangseng": "^HSI",
    "shanghai": "000001.SS", "cac": "^FCHI",
}

COMMODITIES = {
    "gold": "GC=F", "xau": "GC=F", "silver": "SI=F", "xag": "SI=F",
    "crude": "CL=F", "wti": "CL=F", "crude oil": "CL=F", "oil": "CL=F",
    "brent": "BZ=F", "natural gas": "NG=F", "natgas": "NG=F",
    "copper": "HG=F", "platinum": "PL=F", "palladium": "PA=F",
    "wheat": "ZW=F", "corn": "ZC=F", "coffee": "KC=F", "sugar": "SB=F",
    "cotton": "CT=F",
}

# Yahoo interval/range constraints (it rejects impossible combinations)
INTERVAL_RANGE = {
    "1m": ("1d", 7), "2m": ("5d", 60), "5m": ("5d", 60), "15m": ("5d", 60),
    "30m": ("1mo", 60), "60m": ("3mo", 730), "1h": ("3mo", 730), "90m": ("1mo", 60),
    "1d": ("2y", None), "1wk": ("5y", None), "1mo": ("max", None),
}
ALIAS_INTERVAL = {
    "1min": "1m", "5min": "5m", "15min": "15m", "30min": "30m", "hourly": "1h",
    "60min": "1h", "daily": "1d", "day": "1d", "weekly": "1wk", "month": "1mo",
    "monthly": "1mo", "minute": "1m", "h1": "1h", "h4": "4h", "m15": "15m", "m5": "5m",
    "m30": "30m", "d1": "1d", "w1": "1wk",
}


class Symbol:
    """A resolved tradable instrument."""

    def __init__(self, text: str, asset_class: str, ticker: str, display: str,
                 base: str = "", quote: str = "", crypto_id: str = "", meta: Optional[Dict[str, Any]] = None):
        self.text = text
        self.asset_class = asset_class       # forex | crypto | stock | index | commodity
        self.ticker = ticker                 # what the data feed needs
        self.display = display               # what the user sees
        self.base = base
        self.quote = quote
        self.crypto_id = crypto_id
        self.meta = meta or {}

    @property
    def pair(self) -> str:
        return f"{self.base}/{self.quote}" if self.base and self.quote else self.display

    def to_dict(self) -> Dict[str, Any]:
        return {"input": self.text, "asset_class": self.asset_class, "ticker": self.ticker,
                "symbol": self.display, "pair": self.pair, "base": self.base,
                "quote": self.quote, "crypto_id": self.crypto_id, **self.meta}


def resolve_symbol(text: str) -> Symbol:
    """
    Turn anything a human types into a tradable symbol.

    Handles ``EURUSD``, ``EUR/USD``, ``eur usd``, ``euro dollar``, ``btc``,
    ``BTCUSDT``, ``bitcoin price``, ``nifty``, ``gold``, ``RELIANCE.NS``,
    ``AAPL``, ``^NSEI``, ``crude oil``.
    """
    raw = (text or "").strip()
    if not raw:
        raise ValueError("no symbol given")
    low = raw.lower()
    low = re.sub(r"\b(price|quote|chart|rate|rates|of|the|in\s+usd|now|today|live|spot|pair|"
                 r"how\s+much|what\s+is|what's|forex|fx|crypto|coin|stock|share|index)\b",
                 " ", low)
    low = re.sub(r"\s+", " ", low).strip(" .?!,")

    # ---- explicit yahoo ticker -------------------------------------------
    if raw.startswith("^") or re.fullmatch(r"[A-Z]{1,6}\.[A-Z]{1,3}", raw) or "=" in raw:
        return Symbol(raw, _guess_class(raw), raw.upper(), raw.upper())

    # ---- indices ----------------------------------------------------------
    if low in INDICES:
        return Symbol(raw, "index", INDICES[low], INDICES[low].lstrip("^").upper(),
                      meta={"digits": 2})

    # ---- commodities ------------------------------------------------------
    if low in COMMODITIES:
        return Symbol(raw, "commodity", COMMODITIES[low], low.title(), meta={"digits": 2,
                                                                            "currency": "USD"})

    # ---- forex pair: EURUSD, EUR/USD, EUR-USD, eur usd, euro dollar -------
    # (crypto aliases are excluded: "BTC-USD" matches the same 3+3 shape but
    #  BTCUSD=X does not exist on the feed)
    m = re.fullmatch(r"([a-z]{3})\s*[/\-]?\s*([a-z]{3})", low)
    if m and m.group(1) not in CRYPTO_ALIASES:
        b = FOREX_CCY.get(m.group(1), m.group(1).upper())
        q = FOREX_CCY.get(m.group(2), m.group(2).upper())
        if len(b) == 3 and len(q) == 3 and b.isupper() and q.isupper() and b != q:
            return Symbol(raw, "forex", f"{b}{q}=X", f"{b}/{q}", b, q,
                          meta={"pip_size": 0.01 if q == "JPY" else 0.0001,
                                "digits": 3 if q == "JPY" else 5})
    words = [w for w in low.split() if w not in _FX_CONNECTORS]
    if len(words) == 2 and words[0] in FOREX_CCY and words[1] in FOREX_CCY:
        b, q = FOREX_CCY[words[0]], FOREX_CCY[words[1]]
        return Symbol(raw, "forex", f"{b}{q}=X", f"{b}/{q}", b, q,
                      meta={"digits": 3 if q == "JPY" else 5})

    # ---- crypto pair: BTCUSDT, ETH/INR ------------------------------------
    m = re.fullmatch(r"([a-z]{2,6})\s*[/\-]?\s*(usdt|usdc|usd|inr|btc|eth|eur|gbp)", low)
    if m and m.group(1) in CRYPTO_ALIASES:
        cid = CRYPTO_ALIASES[m.group(1)]
        quote = m.group(2).upper()
        yq = {"USDT": "USD", "USDC": "USD"}.get(quote, quote)
        base_up = CRYPTO_TICKER.get(cid, m.group(1).upper())
        return Symbol(raw, "crypto", f"{base_up}-{yq}", f"{base_up}/{quote}", base_up, quote,
                      crypto_id=cid, meta={"digits": 2 if yq in ("USD", "INR") else 6})

    # ---- single crypto ----------------------------------------------------
    key = low.replace(" ", "")
    if key in CRYPTO_ALIASES:
        cid = CRYPTO_ALIASES[key]
        up = CRYPTO_TICKER.get(cid, key.upper())
        return Symbol(raw, "crypto", f"{up}-USD", f"{up}/USD", up, "USD", crypto_id=cid,
                      meta={"digits": 2})

    # ---- anything else: treat as a stock ticker ---------------------------
    ticker = raw.upper().replace(" ", "")
    if re.fullmatch(r"[A-Z]{1,6}", ticker):
        return Symbol(raw, "stock", ticker, ticker, meta={"digits": 2})
    return Symbol(raw, _guess_class(ticker), ticker, ticker, meta={"digits": 2})


def _guess_class(ticker: str) -> str:
    if ticker.startswith("^"):
        return "index"
    if ticker.endswith("=X"):
        return "forex"
    if ticker.endswith("=F"):
        return "commodity"
    if "-" in ticker:
        return "crypto"
    return "stock"


def normalise_interval(interval: str) -> str:
    iv = (interval or "1h").strip().lower()
    iv = ALIAS_INTERVAL.get(iv, iv)
    if iv == "4h":                      # Yahoo has no 4h; use 1h and resample
        return "4h"
    if iv not in ("1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h", "1d", "5d", "1wk", "1mo"):
        return "1h"
    return iv


# ---------------------------------------------------------------------------
# candles
# ---------------------------------------------------------------------------
async def candles(symbol: str, interval: str = "1h", limit: int = 300,
                  *, sym: Optional[Symbol] = None) -> Dict[str, Any]:
    """
    Fetch OHLCV candles. Returns ``{"ok", "symbol", "interval", "candles":[{ts,
    open, high, low, close, volume}], "meta", "source"}``.

    Order: paid provider (if keyed) → Yahoo → CoinGecko (crypto) → Frankfurter
    (forex daily).
    """
    resolved = sym or resolve_symbol(symbol)
    iv = normalise_interval(interval)
    want = max(2, min(int(limit), 2000))

    paid = await _paid_candles(resolved, iv, want)
    if paid:
        return paid

    try:
        out = await _yahoo_candles(resolved, iv, want)
        if out.get("candles"):
            return out
    except Exception as exc:
        log.debug("yahoo candles failed for %s: %s", resolved.ticker, exc)

    if resolved.asset_class == "crypto" and resolved.crypto_id:
        try:
            out = await _coingecko_candles(resolved, iv, want)
            if out.get("candles"):
                return out
        except Exception as exc:
            log.debug("coingecko candles failed: %s", exc)

    if resolved.asset_class == "forex" and iv in ("1d", "1wk", "1mo"):
        try:
            out = await _frankfurter_candles(resolved, want)
            if out.get("candles"):
                return out
        except Exception as exc:
            log.debug("frankfurter candles failed: %s", exc)

    return {"ok": False, "symbol": resolved.display, "ticker": resolved.ticker,
            "interval": iv, "candles": [],
            "error": f"no price data available for '{symbol}' ({resolved.ticker}). "
                     f"Check the symbol spelling, or the internet connection."}


async def _paid_candles(sym: Symbol, interval: str, limit: int) -> Optional[Dict[str, Any]]:
    """Optional keyed providers. Returns None when no key is configured."""
    if getattr(settings, "twelvedata_api_key", ""):
        try:
            data = await net.get_json("https://api.twelvedata.com/time_series",
                                      params={"symbol": sym.ticker.replace("=X", ""),
                                              "interval": {"1h": "1h", "1d": "1day",
                                                           "5m": "5min", "15m": "15min",
                                                           "1m": "1min"}.get(interval, interval),
                                              "outputsize": limit,
                                              "apikey": settings.twelvedata_api_key},
                                      cache=False)
            rows = data.get("values") or []
            if rows:
                cs = [{"ts": r.get("datetime"), "open": float(r["open"]), "high": float(r["high"]),
                       "low": float(r["low"]), "close": float(r["close"]),
                       "volume": float(r.get("volume") or 0)} for r in reversed(rows)]
                return {"ok": True, "symbol": sym.display, "ticker": sym.ticker,
                        "asset_class": sym.asset_class, "interval": interval,
                        "candles": cs, "source": "twelvedata", "meta": sym.meta}
        except Exception as exc:
            log.debug("twelvedata failed: %s", exc)
    if getattr(settings, "alpha_vantage_api_key", ""):
        try:
            fn = "FX_INTRADAY" if sym.asset_class == "forex" else "TIME_SERIES_INTRADAY"
            params: Dict[str, Any] = {"function": fn, "interval": interval,
                                      "outputsize": "full",
                                      "apikey": settings.alpha_vantage_api_key}
            if sym.asset_class == "forex":
                params.update({"from_symbol": sym.base, "to_symbol": sym.quote})
            else:
                params["symbol"] = sym.ticker
            data = await net.get_json("https://www.alphavantage.co/query", params=params, cache=False)
            key = next((k for k in data if "Time Series" in k), None)
            rows = data.get(key) or {}
            if rows:
                cs = []
                for ts, r in sorted(rows.items()):
                    cs.append({"ts": ts, "open": float(r["1. open"]), "high": float(r["2. high"]),
                               "low": float(r["3. low"]), "close": float(r["4. close"]),
                               "volume": float(r.get("5. volume") or 0)})
                return {"ok": True, "symbol": sym.display, "ticker": sym.ticker,
                        "asset_class": sym.asset_class, "interval": interval,
                        "candles": cs[-limit:], "source": "alpha_vantage", "meta": sym.meta}
        except Exception as exc:
            log.debug("alphavantage failed: %s", exc)
    return None


async def _yahoo_candles(sym: Symbol, interval: str, limit: int) -> Dict[str, Any]:
    resample_4h = interval == "4h"
    yiv = "1h" if resample_4h else interval
    default_range, _max_days = INTERVAL_RANGE.get(yiv, ("1mo", None))
    # pick the smallest range that can hold `limit` candles
    per_range = {"1m": 390, "2m": 195, "5m": 78, "15m": 26, "30m": 13, "60m": 7, "90m": 5,
                 "1h": 7, "1d": 1, "1wk": 0.2, "1mo": 0.05}
    need_days = max(1, int(limit / max(per_range.get(yiv, 7), 0.05)) + 2)
    order = ["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "max"]
    allowed_max = INTERVAL_RANGE.get(yiv, ("1mo", None))[0]
    ceiling = order.index(allowed_max) if allowed_max in order else len(order) - 1
    rng = default_range
    for cand in order[: ceiling + 1]:
        rng = cand
        approx = {"1d": 1, "5d": 5, "1mo": 30, "3mo": 91, "6mo": 182, "1y": 365,
                  "2y": 730, "5y": 1825, "max": 9999}[cand]
        if approx >= need_days:
            break

    params = {"interval": yiv, "range": rng, "includePrePost": "false",
              "events": "div,split"}
    if yiv == "1m":
        params["range"] = min_range_for_1m(limit)
    data = await net.get_json(YAHOO_CHART.format(symbol=sym.ticker), params=params,
                              cache=True, ttl=45.0)
    result = ((data.get("chart") or {}).get("result") or [None])[0]
    if not result:
        err = ((data.get("chart") or {}).get("error") or {}).get("description", "no data")
        return {"ok": False, "symbol": sym.display, "candles": [], "error": err}
    meta = result.get("meta") or {}
    stamps = result.get("timestamp") or []
    quote = ((result.get("indicators") or {}).get("quote") or [{}])[0]
    adj = ((result.get("indicators") or {}).get("adjclose") or [{}])
    o, h, l, c = quote.get("open") or [], quote.get("high") or [], \
        quote.get("low") or [], quote.get("close") or []
    v = quote.get("volume") or []
    closes: List[float] = []
    candles: List[Dict[str, Any]] = []
    for i, ts in enumerate(stamps):
        if i >= len(c) or c[i] is None or o[i] is None:
            continue
        candles.append({
            "ts": datetime.fromtimestamp(int(ts), tz=timezone.utc).isoformat(),
            "epoch": int(ts),
            "open": float(o[i]), "high": float(h[i] if h[i] is not None else o[i]),
            "low": float(l[i] if l[i] is not None else o[i]), "close": float(c[i]),
            "volume": float(v[i]) if i < len(v) and v[i] is not None else 0.0,
        })
        closes.append(float(c[i]))
    if resample_4h and candles:
        candles = resample(candles, 4)
    candles = candles[-limit:]
    return {
        "ok": bool(candles), "symbol": sym.display, "ticker": sym.ticker,
        "asset_class": sym.asset_class, "interval": interval, "range": params["range"],
        "count": len(candles), "candles": candles, "source": "yahoo-finance",
        "meta": {**sym.meta, "currency": meta.get("currency"),
                 "exchange": meta.get("fullExchangeName") or meta.get("exchangeName"),
                 "instrument_type": meta.get("instrumentType"),
                 "timezone": meta.get("exchangeTimezoneName"),
                 "regular_market_price": meta.get("regularMarketPrice"),
                 "previous_close": meta.get("chartPreviousClose") or meta.get("previousClose"),
                 "market_time": meta.get("regularMarketTime"),
                 "is_live": bool(meta.get("regularMarketPrice"))},
        "error": None if candles else "the feed returned no candles",
    }


def min_range_for_1m(limit: int) -> str:
    return "1d" if limit <= 390 else "5d" if limit <= 1950 else "7d"


async def _coingecko_candles(sym: Symbol, interval: str, limit: int) -> Dict[str, Any]:
    days = {"1m": 1, "5m": 1, "15m": 1, "30m": 7, "1h": 7, "4h": 30,
            "1d": max(30, limit), "1wk": 365, "1mo": "max"}.get(interval, 30)
    data = await net.get_json(f"https://api.coingecko.com/api/v3/coins/{sym.crypto_id}/ohlc",
                              params={"vs_currency": "usd", "days": days})
    candles = [{"ts": datetime.fromtimestamp(int(r[0]) / 1000, tz=timezone.utc).isoformat(),
                "epoch": int(r[0]) // 1000, "open": float(r[1]), "high": float(r[2]),
                "low": float(r[3]), "close": float(r[4]), "volume": 0.0}
               for r in data if isinstance(r, list) and len(r) == 5]
    return {"ok": bool(candles), "symbol": sym.display, "ticker": sym.ticker,
            "asset_class": "crypto", "interval": interval, "count": len(candles),
            "candles": candles[-limit:], "source": "coingecko", "meta": sym.meta,
            "note": "CoinGecko OHLC has no volume column"}


async def _frankfurter_candles(sym: Symbol, limit: int) -> Dict[str, Any]:
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=max(limit * 2, 400))
    data = await net.get_json(f"https://api.frankfurter.app/{start.isoformat()}..{end.isoformat()}",
                              params={"base": sym.base, "symbols": sym.quote})
    rates = data.get("rates") or {}
    candles = []
    prev = None
    for day in sorted(rates):
        close = float(rates[day][sym.quote])
        candles.append({"ts": f"{day}T00:00:00+00:00", "open": prev if prev else close,
                        "high": max(prev or close, close), "low": min(prev or close, close),
                        "close": close, "volume": 0.0, "epoch":
                        int(datetime.fromisoformat(day).replace(tzinfo=timezone.utc).timestamp())})
        prev = close
    return {"ok": bool(candles), "symbol": sym.display, "ticker": sym.ticker,
            "asset_class": "forex", "interval": "1d", "count": len(candles),
            "candles": candles[-limit:], "source": "frankfurter-ecb", "meta": sym.meta,
            "note": "ECB reference rates are published once per business day — "
                    "high/low are approximated from the previous close"}


def resample(candles: List[Dict[str, Any]], factor: int) -> List[Dict[str, Any]]:
    """Group N consecutive candles into one (used for the 4h timeframe)."""
    out: List[Dict[str, Any]] = []
    for i in range(0, len(candles), factor):
        chunk = candles[i:i + factor]
        if not chunk:
            continue
        out.append({"ts": chunk[0]["ts"], "epoch": chunk[0].get("epoch"),
                    "open": chunk[0]["open"], "close": chunk[-1]["close"],
                    "high": max(c["high"] for c in chunk), "low": min(c["low"] for c in chunk),
                    "volume": sum(c.get("volume") or 0 for c in chunk)})
    return out


# ---------------------------------------------------------------------------
# spot rates / tables
# ---------------------------------------------------------------------------
async def fx_table(base: str = "USD", quotes: Optional[List[str]] = None) -> Dict[str, Any]:
    """Full FX rate table (ECB / open.er-api.com)."""
    quotes = quotes or list(FOREX_CCY.values())
    try:
        wanted = sorted({q.upper() for q in quotes} - {base.upper()})
        # frankfurter 4xx's the whole request if any symbol is outside the ECB
        # basket, so filter first and let open.er-api.com fill the rest
        ecb = [c for c in wanted if c in ECB_CURRENCIES]
        data = await net.get_json("https://api.frankfurter.app/latest",
                                  params={"base": base.upper(), "symbols": ",".join(ecb or wanted)},
                                  ttl=180.0)
        if not (data.get("rates") or {}):
            raise ValueError("frankfurter returned no rates")
        rates = data.get("rates") or {}
        src = "frankfurter-ecb"
        as_of = data.get("date")
    except Exception as exc:
        log.debug("frankfurter table failed: %s", exc)
        rates = {}
        fallback = await net.exchange_rates(base.upper())
        merged = {k: float(v) for k, v in (fallback or {}).items()}
        merged.update(rates)
        rates, src, as_of = merged, "frankfurter-ecb + open.er-api.com", None
    rates = {k: float(v) for k, v in rates.items() if v}
    rates[base.upper()] = 1.0
    return {"ok": True, "base": base.upper(), "rates": rates, "source": src, "as_of": as_of}


async def crypto_markets(limit: int = 20, vs: str = "usd",
                         order: str = "market_cap_desc") -> List[Dict[str, Any]]:
    data = await net.get_json("https://api.coingecko.com/api/v3/coins/markets",
                              params={"vs_currency": vs, "order": order,
                                      "per_page": min(int(limit), 250), "page": 1,
                                      "sparkline": "false",
                                      "price_change_percentage": "1h,24h,7d"})
    out = []
    for c in data:
        out.append({"id": c.get("id"), "symbol": (c.get("symbol") or "").upper(),
                    "name": c.get("name"), "price": c.get("current_price"),
                    "market_cap": c.get("market_cap"), "market_cap_rank": c.get("market_cap_rank"),
                    "volume_24h": c.get("total_volume"), "high_24h": c.get("high_24h"),
                    "low_24h": c.get("low_24h"),
                    "change_24h_percent": c.get("price_change_percentage_24h"),
                    "change_1h_percent": c.get("price_change_percentage_1h_in_currency"),
                    "change_7d_percent": c.get("price_change_percentage_7d_in_currency"),
                    "ath": c.get("ath"), "ath_change_percent": c.get("ath_change_percentage"),
                    "circulating_supply": c.get("circulating_supply")})
    return out


async def quote(sym: Symbol) -> Dict[str, Any]:
    """Best-effort live quote for any asset class."""
    if sym.asset_class == "crypto":
        try:
            data = await net.get_json("https://api.coingecko.com/api/v3/simple/price",
                                      params={"ids": sym.crypto_id, "vs_currencies": "usd,inr",
                                              "include_24hr_change": "true",
                                              "include_24hr_vol": "true",
                                              "include_market_cap": "true"})
            row = data.get(sym.crypto_id) or {}
            if row:
                return {"ok": True, **sym.to_dict(), "price": row.get("usd"),
                        "price_inr": row.get("inr"),
                        "change_24h_percent": row.get("usd_24h_change"),
                        "volume_24h": row.get("usd_24h_vol"),
                        "market_cap": row.get("usd_market_cap"), "source": "coingecko"}
        except Exception as exc:
            log.debug("crypto quote failed: %s", exc)
    try:
        data = await net.get_json(YAHOO_CHART.format(symbol=sym.ticker),
                                  params={"interval": "1d", "range": "5d"}, ttl=30.0)
        result = ((data.get("chart") or {}).get("result") or [{}])[0]
        meta = result.get("meta") or {}
        price = meta.get("regularMarketPrice")
        prev = meta.get("chartPreviousClose") or meta.get("previousClose")
        closes = (((result.get("indicators") or {}).get("quote") or [{}])[0].get("close")) or []
        closes = [c for c in closes if c is not None]
        if price is None and closes:
            price = closes[-1]
        if price is None:
            return {"ok": False, **sym.to_dict(), "error": "feed returned no price"}
        change = (price - prev) if prev else None
        return {"ok": True, **sym.to_dict(), "price": round(float(price), 6),
                "previous_close": prev, "currency": meta.get("currency"),
                "exchange": meta.get("fullExchangeName") or meta.get("exchangeName"),
                "day_high": meta.get("regularMarketDayHigh"),
                "day_low": meta.get("regularMarketDayLow"),
                "volume": meta.get("regularMarketVolume"),
                "change": round(change, 6) if change is not None else None,
                "change_percent": round(change / prev * 100, 4) if change is not None and prev else None,
                "fifty_two_week_high": meta.get("fiftyTwoWeekHigh"),
                "fifty_two_week_low": meta.get("fiftyTwoWeekLow"),
                "market_time": meta.get("regularMarketTime"),
                "market_state": "live" if meta.get("regularMarketPrice") else "delayed/closed",
                "recent_closes": [round(c, 6) for c in closes[-5:]],
                "source": "yahoo-finance"}
    except Exception as exc:
        return {"ok": False, **sym.to_dict(), "error": f"quote failed: {type(exc).__name__}: {exc}"}


# ---------------------------------------------------------------------------
# health
# ---------------------------------------------------------------------------
async def feed_health() -> Dict[str, Any]:
    """Probe every data source and report latency. Used by the Markets dashboard."""
    async def probe(name: str, coro: Any) -> Dict[str, Any]:
        t0 = time.perf_counter()
        try:
            data = await asyncio.wait_for(coro, timeout=20)
            ms = int((time.perf_counter() - t0) * 1000)
            ok = bool(data) and not (isinstance(data, dict) and data.get("error"))
            return {"source": name, "ok": ok, "latency_ms": ms,
                    "error": None if ok else str(data)[:120] if data else "empty"}
        except Exception as exc:
            return {"source": name, "ok": False,
                    "latency_ms": int((time.perf_counter() - t0) * 1000),
                    "error": f"{type(exc).__name__}: {exc}"[:160]}

    results = await net.gather(
        probe("yahoo-finance", net.get_json(YAHOO_CHART.format(symbol="EURUSD=X"),
                                            params={"interval": "1d", "range": "5d"})),
        probe("frankfurter-ecb", net.get_json("https://api.frankfurter.app/latest",
                                              params={"base": "USD", "symbols": "EUR"})),
        probe("coingecko", net.get_json("https://api.coingecko.com/api/v3/simple/price",
                                        params={"ids": "bitcoin", "vs_currencies": "usd"})),
        probe("open.er-api", net.get_json("https://open.er-api.com/v6/latest/USD")),
        probe("google-news-rss", net.google_news_rss("forex market", 1)),
    )
    feeds = [r for r in results if isinstance(r, dict)]
    return {"ok": all(f["ok"] for f in feeds), "feeds": feeds,
            "ready": sum(1 for f in feeds if f["ok"]), "total": len(feeds),
            "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}


def closes_of(data: Dict[str, Any]) -> List[float]:
    return [float(c["close"]) for c in data.get("candles") or []]


def highs_of(data: Dict[str, Any]) -> List[float]:
    return [float(c["high"]) for c in data.get("candles") or []]


def lows_of(data: Dict[str, Any]) -> List[float]:
    return [float(c["low"]) for c in data.get("candles") or []]


def volumes_of(data: Dict[str, Any]) -> List[float]:
    return [float(c.get("volume") or 0) for c in data.get("candles") or []]
