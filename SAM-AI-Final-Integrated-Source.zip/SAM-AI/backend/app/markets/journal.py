"""
backend.app.markets.journal
===========================

**Persistence for the Market Analyzer brain: journal, alerts and paper trading.**

Three things a trader needs and a chatbot does not have:

1. **A journal** (``MarketTrade``) — every plan SAM produced, whether the user
   took it, and how it turned out. Statistics over the journal are the only
   honest way to know whether the analysis helps.
2. **Alerts** (``PriceAlert``) — conditions watched in the background; when one
   fires SAM emits an event (desktop toast / phone notification / voice) and
   writes an audit row.
3. **Paper trading** (``PaperPosition`` + ``PaperAccount``) — a virtual account
   with a real balance, so the user can test a strategy *without money*. SAM's
   default and recommended mode. Live-money execution is never performed by
   this module.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import delete as sa_delete
from sqlalchemy import select

from backend.app.core.database import session_scope
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import MarketTrade, PaperAccount, PaperPosition, PriceAlert

log = get_logger("markets.journal")

ALERT_CONDITIONS = ("above", "below", "cross_up", "cross_down", "percent_change",
                    "rsi_above", "rsi_below", "atr_spike", "signal_flip", "target_hit",
                    "stop_hit")


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ===========================================================================
# 1. TRADE JOURNAL
# ===========================================================================
class TradeJournal:
    """CRUD + statistics over the market trade journal."""

    async def add(self, *, symbol: str, direction: str = "long", product: str = "spot",
                  asset_class: str = "forex", status: str = "planned", account: str = "journal",
                  timeframe: str = "1h", strategy: str = "", entry: Optional[float] = None,
                  stop: Optional[float] = None, units: float = 0.0, stake: float = 0.0,
                  targets: Optional[List[float]] = None, signal_score: float = 0.0,
                  confidence: float = 0.0, reasons: Optional[List[str]] = None,
                  notes: str = "", tags: str = "", expiry_minutes: int = 0,
                  payout_percent: float = 0.0) -> Dict[str, Any]:
        async with session_scope() as s:
            row = MarketTrade(
                symbol=symbol.upper(), direction=direction.lower(), product=product,
                asset_class=asset_class, status=status, account=account, timeframe=timeframe,
                strategy=strategy, entry=entry, stop=stop, units=float(units or 0),
                stake=float(stake or 0), targets_json=json.dumps(targets or []),
                signal_score=float(signal_score or 0), confidence=float(confidence or 0),
                reasons_json=json.dumps(reasons or []), notes=notes or "", tags=tags or "",
                expiry_minutes=int(expiry_minutes or 0), payout_percent=float(payout_percent or 0),
                opened_at=_now(),
            )
            s.add(row)
            await s.flush()
            data = row.to_dict()
        emit(Topics.AUDIT, action="market.journal.add", target=symbol, detail=data.get("id"))
        return data

    async def close(self, trade_id: int, *, exit_price: float, result: str = "",
                    fees: float = 0.0, notes: str = "", review: str = "") -> Dict[str, Any]:
        async with session_scope() as s:
            row = (await s.execute(select(MarketTrade).where(MarketTrade.id == int(trade_id)))).scalar_one_or_none()
            if row is None:
                return {"ok": False, "error": f"no journal trade with id {trade_id}"}
            row.exit = float(exit_price)
            row.closed_at = _now()
            row.fees = float(fees or 0)
            if notes:
                row.notes = (row.notes + "\n" + notes).strip()
            if review:
                row.review = review
            # P&L
            direction = 1 if row.direction in ("long", "up", "buy") else -1
            if row.product == "binary":
                payout = row.payout_percent or 80.0
                won = result == "win" or (not result and direction * (row.exit - (row.entry or row.exit)) > 0)
                row.pnl = (row.stake * payout / 100) if won else -row.stake
                row.result = "win" if won else "loss"
                row.pnl_percent = round(row.pnl / row.stake * 100, 3) if row.stake else 0.0
            else:
                units = row.units or 1.0
                row.pnl = round(direction * (row.exit - (row.entry or row.exit)) * units - row.fees, 6)
                base = (row.entry or row.exit) * units
                row.pnl_percent = round(row.pnl / base * 100, 4) if base else 0.0
                if row.entry and row.stop and row.stop != row.entry:
                    risk = abs(row.entry - row.stop) * units
                    row.r_multiple = round(row.pnl / risk, 3) if risk else 0.0
                if not result:
                    result = "win" if row.pnl > 0 else "loss" if row.pnl < 0 else "tie"
                row.result = result
            row.status = "closed"
            data = row.to_dict()
        emit(Topics.AUDIT, action="market.journal.close", target=data["symbol"],
             detail={"pnl": data["pnl"], "result": data["result"]})
        return {"ok": True, "trade": data}

    async def list(self, *, symbol: str = "", status: str = "", product: str = "",
                   result: str = "", limit: int = 50, offset: int = 0,
                   days: Optional[int] = None) -> Dict[str, Any]:
        async with session_scope() as s:
            q = select(MarketTrade)
            if symbol:
                q = q.where(MarketTrade.symbol == symbol.upper())
            if status:
                q = q.where(MarketTrade.status == status)
            if product:
                q = q.where(MarketTrade.product == product)
            if result:
                q = q.where(MarketTrade.result == result)
            if days:
                q = q.where(MarketTrade.opened_at >= _now() - timedelta(days=int(days)))
            total = len((await s.execute(q)).scalars().all())
            rows = (await s.execute(q.order_by(MarketTrade.id.desc())
                                    .limit(int(limit)).offset(int(offset)))).scalars().all()
            return {"ok": True, "count": total, "returned": len(rows),
                    "trades": [r.to_dict() for r in rows]}

    async def get(self, trade_id: int) -> Optional[Dict[str, Any]]:
        async with session_scope() as s:
            row = (await s.execute(select(MarketTrade).where(MarketTrade.id == int(trade_id)))).scalar_one_or_none()
            return row.to_dict() if row else None

    async def review(self, trade_id: int, review: str, tags: str = "") -> Dict[str, Any]:
        async with session_scope() as s:
            row = (await s.execute(select(MarketTrade).where(MarketTrade.id == int(trade_id)))).scalar_one_or_none()
            if row is None:
                return {"ok": False, "error": f"no trade {trade_id}"}
            row.review = review
            if tags:
                row.tags = ",".join(sorted({*(row.tags or "").split(","), *tags.split(",")}) - {""})
            return {"ok": True, "trade": row.to_dict()}

    async def delete(self, trade_id: int) -> Dict[str, Any]:
        async with session_scope() as s:
            row = (await s.execute(select(MarketTrade).where(MarketTrade.id == int(trade_id)))).scalar_one_or_none()
            if row is None:
                return {"ok": False, "error": f"no trade {trade_id}"}
            await s.delete(row)
        return {"ok": True, "deleted": int(trade_id)}

    async def stats(self, *, days: Optional[int] = None, symbol: str = "",
                    product: str = "") -> Dict[str, Any]:
        async with session_scope() as s:
            q = select(MarketTrade).where(MarketTrade.status == "closed")
            if days:
                q = q.where(MarketTrade.opened_at >= _now() - timedelta(days=int(days)))
            if symbol:
                q = q.where(MarketTrade.symbol == symbol.upper())
            if product:
                q = q.where(MarketTrade.product == product)
            rows = (await s.execute(q)).scalars().all()
        if not rows:
            return {"ok": True, "closed_trades": 0,
                    "note": "no closed trades in the journal yet — plan a trade with "
                            "market.forex_plan or market.binary_analysis, then close it here"}
        pnls = [r.pnl for r in rows]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]
        gross_profit, gross_loss = sum(wins), abs(sum(losses))
        by_symbol: Dict[str, Dict[str, Any]] = {}
        by_strategy: Dict[str, Dict[str, Any]] = {}
        by_result: Dict[str, int] = {}
        by_product: Dict[str, Dict[str, Any]] = {}
        by_direction: Dict[str, Dict[str, Any]] = {}
        for r in rows:
            by_result[r.result or "unknown"] = by_result.get(r.result or "unknown", 0) + 1
            for bucket, key in ((by_product, r.product or "unspecified"),
                                (by_direction, (r.direction or "unspecified").lower())):
                cell = bucket.setdefault(key, {"trades": 0, "pnl": 0.0, "wins": 0})
                cell["trades"] += 1
                cell["pnl"] = round(cell["pnl"] + r.pnl, 4)
                cell["wins"] += 1 if r.pnl > 0 else 0
            sym = by_symbol.setdefault(r.symbol, {"trades": 0, "pnl": 0.0, "wins": 0})
            sym["trades"] += 1
            sym["pnl"] = round(sym["pnl"] + r.pnl, 4)
            sym["wins"] += 1 if r.pnl > 0 else 0
            st = by_strategy.setdefault(r.strategy or "unspecified", {"trades": 0, "pnl": 0.0, "wins": 0})
            st["trades"] += 1
            st["pnl"] = round(st["pnl"] + r.pnl, 4)
            st["wins"] += 1 if r.pnl > 0 else 0
        for bucket in (by_symbol, by_strategy, by_product, by_direction):
            for v in bucket.values():
                v["win_rate_percent"] = round(v["wins"] / v["trades"] * 100, 2) if v["trades"] else 0
        r_multiples = [r.r_multiple for r in rows if r.r_multiple]
        conf_win = [r for r in rows if r.confidence >= 0.6]
        conf_lose = [r for r in rows if r.confidence < 0.45]
        streaks = _streaks([r.pnl for r in rows])
        avg_win = sum(wins) / len(wins) if wins else 0
        avg_loss = sum(losses) / len(losses) if losses else 0
        win_rate = len(wins) / len(pnls) * 100
        return {
            "ok": True, "closed_trades": len(rows), "wins": len(wins), "losses": len(losses),
            "ties": by_result.get("tie", 0),
            "win_rate_percent": round(win_rate, 2),
            "net_pnl": round(sum(pnls), 4), "gross_profit": round(gross_profit, 4),
            "gross_loss": round(gross_loss, 4),
            "profit_factor": round(gross_profit / gross_loss, 3) if gross_loss else None,
            "expectancy_per_trade": round((win_rate / 100 * avg_win) + ((1 - win_rate / 100) * avg_loss), 4),
            "average_win": round(avg_win, 4), "average_loss": round(avg_loss, 4),
            "payoff_ratio": round(abs(avg_win / avg_loss), 3) if avg_loss else None,
            "average_r_multiple": round(sum(r_multiples) / len(r_multiples), 3) if r_multiples else None,
            "best_trade": round(max(pnls), 4), "worst_trade": round(min(pnls), 4),
            "longest_win_streak": streaks[0], "longest_loss_streak": streaks[1],
            "by_symbol": by_symbol, "by_strategy": by_strategy, "by_result": by_result,
            "by_product": by_product, "by_direction": by_direction,
            "high_confidence_trades": {"count": len(conf_win),
                                       "win_rate_percent": round(sum(1 for r in conf_win if r.pnl > 0)
                                                                 / len(conf_win) * 100, 2)
                                       if conf_win else None},
            "low_confidence_trades": {"count": len(conf_lose),
                                      "win_rate_percent": round(sum(1 for r in conf_lose if r.pnl > 0)
                                                                / len(conf_lose) * 100, 2)
                                      if conf_lose else None},
            "days": days, "period_start": min(r.opened_at for r in rows).isoformat() if rows else None,
            "lessons": _lessons(win_rate, gross_profit, gross_loss, streaks, r_multiples, rows),
        }

    async def clear(self, *, symbol: str = "", older_than_days: Optional[int] = None) -> int:
        async with session_scope() as s:
            q = sa_delete(MarketTrade)
            if symbol:
                q = q.where(MarketTrade.symbol == symbol.upper())
            if older_than_days:
                q = q.where(MarketTrade.opened_at < _now() - timedelta(days=int(older_than_days)))
            res = await s.execute(q)
            return int(res.rowcount or 0)


def _streaks(pnls: List[float]) -> tuple:
    win = loss = bw = bl = 0
    for p in pnls:
        if p > 0:
            win, loss = win + 1, 0
            bw = max(bw, win)
        else:
            loss, win = loss + 1, 0
            bl = max(bl, loss)
    return bw, bl


def _lessons(win_rate: float, gross_profit: float, gross_loss: float,
             streaks: tuple, r_multiples: List[float], rows: List[MarketTrade]) -> List[str]:
    lessons: List[str] = []
    pf = gross_profit / gross_loss if gross_loss else None
    if pf is not None and pf < 1:
        lessons.append(f"the journal is net negative (profit factor {pf:.2f}) — stop increasing size "
                       f"and re-test the rule on paper")
    closed = [r for r in rows if r.status == "closed"]
    if len(closed) < 10:
        lessons.append(f"only {len(closed)} closed trade(s) — far too few for these statistics to "
                       f"mean anything; 30+ trades is the bare minimum, 100+ is useful")
    if win_rate < 40 and pf is not None and pf < 1.5:
        lessons.append(f"win rate {win_rate:.0f}% with a payoff that does not compensate — either "
                       f"take profits further or take fewer, better setups")
    if win_rate > 65 and pf is not None and pf < 1.2:
        lessons.append("high win rate but a weak profit factor: the losses are much bigger than the "
                       "wins — cut losers faster, the stop is doing its job only if you let it")
    if streaks[1] >= 5:
        lessons.append(f"a {streaks[1]}-trade losing streak happened — size the account so that "
                       f"{streaks[1] + 2} losses in a row is survivable")
    if r_multiples:
        avg_r = sum(r_multiples) / len(r_multiples)
        lessons.append(f"average trade closed at {avg_r:+.2f}R")
    planned_not_taken = [r for r in rows if r.status == "planned"]
    if planned_not_taken:
        lessons.append(f"{len(planned_not_taken)} planned trades were never resolved — close or "
                       f"cancel them so the statistics stay honest")
    if not lessons:
        lessons.append("the journal looks consistent — keep the same rules and keep recording")
    return lessons


journal = TradeJournal()


# ===========================================================================
# 2. PRICE ALERTS
# ===========================================================================
class AlertStore:
    async def add(self, *, symbol: str, condition: str = "above", threshold: float = 0.0,
                  timeframe: str = "1h", window_minutes: int = 60, message: str = "",
                  channel: str = "desktop", once: bool = True,
                  cooldown_minutes: int = 60) -> Dict[str, Any]:
        if condition not in ALERT_CONDITIONS:
            return {"ok": False, "error": f"unknown condition '{condition}'. "
                                          f"Use one of: {', '.join(ALERT_CONDITIONS)}"}
        async with session_scope() as s:
            row = PriceAlert(symbol=symbol.upper(), condition=condition, threshold=float(threshold),
                             timeframe=timeframe, window_minutes=int(window_minutes),
                             message=message or f"{symbol.upper()} {condition} {threshold}",
                             channel=channel, once=once, cooldown_minutes=int(cooldown_minutes),
                             created_at=_now())
            s.add(row)
            await s.flush()
            return {"ok": True, "alert": row.to_dict()}

    async def list(self, *, enabled_only: bool = False, symbol: str = "") -> List[Dict[str, Any]]:
        async with session_scope() as s:
            q = select(PriceAlert)
            if enabled_only:
                q = q.where(PriceAlert.enabled.is_(True))
            if symbol:
                q = q.where(PriceAlert.symbol == symbol.upper())
            rows = (await s.execute(q.order_by(PriceAlert.id.desc()))).scalars().all()
            return [r.to_dict() for r in rows]

    async def toggle(self, alert_id: int, enabled: Optional[bool] = None) -> Dict[str, Any]:
        async with session_scope() as s:
            row = (await s.execute(select(PriceAlert).where(PriceAlert.id == int(alert_id)))).scalar_one_or_none()
            if row is None:
                return {"ok": False, "error": f"no alert {alert_id}"}
            row.enabled = bool(enabled) if enabled is not None else not row.enabled
            return {"ok": True, "alert": row.to_dict()}

    async def remove(self, alert_id: int) -> Dict[str, Any]:
        async with session_scope() as s:
            row = (await s.execute(select(PriceAlert).where(PriceAlert.id == int(alert_id)))).scalar_one_or_none()
            if row is None:
                return {"ok": False, "error": f"no alert {alert_id}"}
            await s.delete(row)
        return {"ok": True, "deleted": int(alert_id)}

    async def clear_triggered(self) -> int:
        async with session_scope() as s:
            res = await s.execute(sa_delete(PriceAlert).where(PriceAlert.triggered_count > 0,
                                                              PriceAlert.once.is_(True)))
            return int(res.rowcount or 0)

    async def mark(self, alert_id: int, price: float, triggered: bool) -> None:
        async with session_scope() as s:
            row = (await s.execute(select(PriceAlert).where(PriceAlert.id == int(alert_id)))).scalar_one_or_none()
            if row is None:
                return
            row.last_checked_at = _now()
            row.last_price = float(price)
            if triggered:
                row.triggered_count += 1
                row.triggered_at = _now()
                row.trigger_price = float(price)
                if row.once:
                    row.enabled = False


alerts = AlertStore()


def evaluate_alert(alert: Dict[str, Any], price: float, *, prev_price: Optional[float] = None,
                   rsi: Optional[float] = None, atr_percent: Optional[float] = None,
                   signal_score: Optional[float] = None, change_percent: Optional[float] = None,
                   target: Optional[float] = None, stop: Optional[float] = None) -> bool:
    """Pure function: does this alert fire at this price?"""
    cond = alert.get("condition")
    thr = float(alert.get("threshold") or 0)
    if price is None:
        return False
    if cond == "above":
        return price >= thr
    if cond == "below":
        return price <= thr
    if cond == "cross_up":
        return prev_price is not None and prev_price < thr <= price
    if cond == "cross_down":
        return prev_price is not None and prev_price > thr >= price
    if cond == "percent_change":
        return change_percent is not None and abs(change_percent) >= thr
    if cond == "rsi_above":
        return rsi is not None and rsi >= thr
    if cond == "rsi_below":
        return rsi is not None and rsi <= thr
    if cond == "atr_spike":
        return atr_percent is not None and atr_percent >= thr
    if cond == "signal_flip":
        return signal_score is not None and abs(signal_score) >= thr
    if cond == "target_hit":
        return target is not None and ((price >= target) if target > price or True else False)
    if cond == "stop_hit":
        return stop is not None and price <= stop
    return False


# ===========================================================================
# 3. PAPER TRADING (virtual money only)
# ===========================================================================
class PaperBroker:
    """
    A simulated broker.

    It exists so a user can prove a strategy over weeks **without risking
    money**. It never talks to a real broker, never holds credentials and never
    places an order anywhere.
    """

    async def account(self, currency: str = "USD", starting: float = 10_000.0,
                      risk_percent: float = 1.0) -> Dict[str, Any]:
        async with session_scope() as s:
            row = (await s.execute(select(PaperAccount).where(PaperAccount.id == "default"))).scalar_one_or_none()
            if row is None:
                row = PaperAccount(id="default", currency=currency,
                                   starting_balance=float(starting), balance=float(starting),
                                   risk_per_trade_percent=float(risk_percent), updated_at=_now())
                s.add(row)
                await s.flush()
            return {"ok": True, "account": row.to_dict(), "virtual": True}

    async def open(self, *, symbol: str, direction: str, units: float, entry: float,
                   stop: Optional[float] = None, targets: Optional[List[float]] = None,
                   asset_class: str = "forex", notes: str = "") -> Dict[str, Any]:
        acct = await self.account()
        balance = acct["account"]["balance"]
        direction = direction.lower()
        if direction not in ("long", "short", "up", "down"):
            return {"ok": False, "error": "direction must be long/short (or up/down for binary)"}
        if units <= 0:
            return {"ok": False, "error": "units must be > 0 — use market.risk to size the trade"}
        if entry <= 0:
            return {"ok": False, "error": "entry price must be > 0"}
        notional = units * entry
        if notional > balance * 50:
            return {"ok": False, "error": f"notional {notional:,.2f} is more than 50× the virtual "
                                          f"balance {balance:,.2f} — that is not a trade, it is a bet",
                    "suggestion": "use market.risk position_size with risk_percent=1"}
        risk_amount = units * abs(entry - stop) if stop else 0.0
        async with session_scope() as s:
            row = PaperPosition(symbol=symbol.upper(), asset_class=asset_class,
                                direction=direction, units=float(units), entry=float(entry),
                                stop=float(stop) if stop else None,
                                targets_json=json.dumps(targets or []), status="open",
                                risk_amount=round(float(risk_amount), 4), notes=notes,
                                opened_at=_now())
            s.add(row)
            await s.flush()
            data = row.to_dict()
        emit(Topics.NOTIFICATION, kind="paper_trade_opened", symbol=data["symbol"],
             direction=direction, entry=entry, position_id=data["id"])
        return {"ok": True, "position": data, "virtual": True,
                "risk_amount": round(risk_amount, 4),
                "note": "paper trade — no real order was placed anywhere"}

    async def positions(self, *, status: str = "open") -> Dict[str, Any]:
        acct = await self.account()
        async with session_scope() as s:
            q = select(PaperPosition)
            if status != "all":
                q = q.where(PaperPosition.status == status)
            rows = (await s.execute(q.order_by(PaperPosition.id.desc()))).scalars().all()
            positions = [r.to_dict() for r in rows]
        return {"ok": True, "positions": positions, "count": len(positions),
                "account": acct["account"], "virtual": True}

    async def close(self, position_id: int, exit_price: float, *, notes: str = "") -> Dict[str, Any]:
        async with session_scope() as s:
            row = (await s.execute(select(PaperPosition).where(
                PaperPosition.id == int(position_id)))).scalar_one_or_none()
            if row is None:
                return {"ok": False, "error": f"no open paper position {position_id}"}
            if row.status != "open":
                return {"ok": False, "error": f"position {position_id} is already {row.status}"}
            direction = 1 if row.direction in ("long", "up", "buy") else -1
            pnl = direction * (float(exit_price) - row.entry) * row.units
            row.exit = float(exit_price)
            row.pnl = round(pnl, 6)
            row.status = "closed"
            row.closed_at = _now()
            if notes:
                row.notes = (row.notes + "\n" + notes).strip()
            pos = row.to_dict()
            acct = (await s.execute(select(PaperAccount).where(
                PaperAccount.id == "default"))).scalar_one_or_none()
            if acct is None:
                acct = PaperAccount(id="default")
                s.add(acct)
            acct.balance = round(acct.balance + pnl, 4)
            acct.realised_pnl = round(acct.realised_pnl + pnl, 4)
            acct.trades_closed += 1
            if pnl > 0:
                acct.wins += 1
            else:
                acct.losses += 1
            acct.updated_at = _now()
            account = acct.to_dict()
        # mirror it into the journal so statistics cover paper trades too
        try:
            await journal.add(symbol=pos["symbol"], direction=pos["direction"], product="paper",
                              asset_class=pos["asset_class"], status="closed", account="paper",
                              entry=pos["entry"], stop=pos.get("stop"), units=pos["units"],
                              targets=pos.get("targets") or [], notes=notes or "paper trade")
            data = await journal.list(symbol=pos["symbol"], limit=1)
            if data.get("trades"):
                await journal.close(data["trades"][0]["id"], exit_price=float(exit_price),
                                    notes=notes or "closed from the paper account")
        except Exception as exc:  # pragma: no cover - journal is best-effort
            log.debug("paper close could not mirror into the journal: %s", exc)
        emit(Topics.NOTIFICATION, kind="paper_trade_closed", symbol=pos["symbol"],
             pnl=pos["pnl"], balance=account["balance"])
        return {"ok": True, "position": pos, "account": account, "virtual": True}

    async def reset(self, starting: float = 10_000.0, currency: str = "USD") -> Dict[str, Any]:
        async with session_scope() as s:
            await s.execute(sa_delete(PaperPosition))
            row = (await s.execute(select(PaperAccount).where(PaperAccount.id == "default"))).scalar_one_or_none()
            if row is None:
                row = PaperAccount(id="default")
                s.add(row)
            row.starting_balance = float(starting)
            row.balance = float(starting)
            row.realised_pnl = 0.0
            row.trades_closed = row.wins = row.losses = 0
            row.currency = currency
            row.updated_at = _now()
            data = row.to_dict()
        return {"ok": True, "account": data, "closed_positions": "all",
                "note": "paper account reset — the journal keeps its history"}


paper_broker = PaperBroker()


def alert_poller_status() -> Dict[str, Any]:
    """Status of the background alert poller (lazy import avoids a cycle)."""
    try:
        from backend.app.markets.alerts import alert_poller

        return alert_poller.status()
    except Exception as exc:  # pragma: no cover
        return {"ok": False, "running": False, "error": f"{type(exc).__name__}: {exc}"}
