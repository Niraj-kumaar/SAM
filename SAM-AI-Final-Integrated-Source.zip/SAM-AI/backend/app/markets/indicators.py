"""
backend.app.markets.indicators
==============================

**The technical-analysis library of the Market Analyzer brain.**

Pure Python (no TA-Lib, no C extension) so it installs anywhere SAM runs.
Every function takes plain ``list[float]`` and returns plain lists/floats that
are JSON-safe — ``None`` where a lookback window is not yet full, so a chart can
plot them directly.

Indicator set
-------------
Trend      : ``sma`` ``ema`` ``wma`` ``dema`` ``tema`` ``vwap`` ``psar`` ``adx`` ``ichimoku``
Momentum   : ``rsi`` ``stochastic`` ``macd`` ``roc`` ``williams_r`` ``cci`` ``mfi`` ``momentum``
Volatility : ``bollinger`` ``atr`` ``keltner`` ``true_range`` ``historical_volatility``
           ``expected_move``
Volume     : ``obv`` ``volume_sma`` ``accumulation_distribution``
Levels     : ``support_resistance`` ``pivot_points`` ``fibonacci`` ``round_levels``
Structure  : ``trend_state`` ``higher_timeframe_bias`` ``candle_patterns`` ``chart_patterns``
           ``squeeze`` ``divergence``
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Sequence, Tuple

Num = Optional[float]


# ---------------------------------------------------------------------------
# primitives
# ---------------------------------------------------------------------------
def _clean(values: Sequence[Num]) -> List[float]:
    return [float(v) for v in values if v is not None and not math.isnan(float(v))]


def sma(values: Sequence[float], period: int) -> List[Num]:
    v = _clean(values)
    out: List[Num] = [None] * len(v)
    if period <= 0 or len(v) < period:
        return out
    window = sum(v[:period])
    out[period - 1] = window / period
    for i in range(period, len(v)):
        window += v[i] - v[i - period]
        out[i] = window / period
    return out


def ema(values: Sequence[float], period: int) -> List[Num]:
    v = _clean(values)
    out: List[Num] = [None] * len(v)
    if period <= 0 or len(v) < period:
        return out
    k = 2 / (period + 1)
    seed = sum(v[:period]) / period
    out[period - 1] = seed
    prev = seed
    for i in range(period, len(v)):
        prev = v[i] * k + prev * (1 - k)
        out[i] = prev
    return out


def wma(values: Sequence[float], period: int) -> List[Num]:
    v = _clean(values)
    out: List[Num] = [None] * len(v)
    denom = period * (period + 1) / 2
    for i in range(period - 1, len(v)):
        chunk = v[i - period + 1: i + 1]
        out[i] = sum(w * x for w, x in zip(range(1, period + 1), chunk)) / denom
    return out


def dema(values: Sequence[float], period: int) -> List[Num]:
    e1 = ema(values, period)
    filled = [x for x in e1 if x is not None]
    if len(filled) < period:
        return [None] * len(_clean(values))
    e2 = ema(filled, period)
    pad = len(e1) - len(filled) + (len(e2) and len(filled) - len(e2) or 0)
    out: List[Num] = [None] * len(e1)
    offset = len(e1) - len(e2)
    for i, val in enumerate(e2):
        if val is None:
            continue
        j = offset + i
        if j < len(e1) and e1[j] is not None:
            out[j] = 2 * e1[j] - val
    return out


def tema(values: Sequence[float], period: int) -> List[Num]:
    v = _clean(values)
    e1 = ema(v, period)
    f1 = [x for x in e1 if x is not None]
    if len(f1) < period:
        return [None] * len(v)
    e2 = ema(f1, period)
    f2 = [x for x in e2 if x is not None]
    if len(f2) < period:
        return [None] * len(v)
    e3 = ema(f2, period)
    out: List[Num] = [None] * len(v)
    n = len(e3)
    for i in range(n):
        a = e3[i]
        if a is None:
            continue
        j = len(v) - n + i
        b = e2[len(e2) - n + i] if len(e2) - n + i >= 0 else None
        c = e1[len(e1) - n + i] if len(e1) - n + i >= 0 else None
        if b is not None and c is not None:
            out[j] = 3 * c - 3 * b + a
    return out


def last(series: Sequence[Num]) -> Num:
    for v in reversed(list(series)):
        if v is not None:
            return round(float(v), 6)
    return None


def rsi(values: Sequence[float], period: int = 14) -> List[Num]:
    """Wilder's RSI."""
    v = _clean(values)
    out: List[Num] = [None] * len(v)
    if len(v) <= period:
        return out
    gains, losses = [], []
    for i in range(1, period + 1):
        delta = v[i] - v[i - 1]
        gains.append(max(delta, 0.0))
        losses.append(max(-delta, 0.0))
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    out[period] = 100.0 if avg_loss == 0 else 100 - 100 / (1 + avg_gain / avg_loss)
    for i in range(period + 1, len(v)):
        delta = v[i] - v[i - 1]
        gain, loss = max(delta, 0.0), max(-delta, 0.0)
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
        out[i] = 100.0 if avg_loss == 0 else 100 - 100 / (1 + avg_gain / avg_loss)
    return [round(x, 4) if x is not None else None for x in out]


def stochastic(high: Sequence[float], low: Sequence[float], close: Sequence[float],
               k_period: int = 14, d_period: int = 3, smooth: int = 3) -> Dict[str, List[Num]]:
    h, l, c = _clean(high), _clean(low), _clean(close)
    n = min(len(h), len(l), len(c))
    raw_k: List[Num] = [None] * n
    for i in range(k_period - 1, n):
        hh = max(h[i - k_period + 1: i + 1])
        ll = min(l[i - k_period + 1: i + 1])
        raw_k[i] = 100.0 * (c[i] - ll) / (hh - ll) if hh != ll else 50.0
    k_vals = [x for x in raw_k if x is not None]
    k_smooth = sma(k_vals, smooth) if smooth > 1 else k_vals
    d_vals = sma([x for x in k_smooth if x is not None], d_period)
    pad_k = n - len(k_smooth)
    pad_d = len(k_smooth) - len(d_vals)
    return {"k": [None] * max(pad_k, 0) + [round(x, 4) if x is not None else None for x in k_smooth],
            "d": [None] * max(pad_k + pad_d, 0) + [round(x, 4) if x is not None else None for x in d_vals],
            "raw_k": [round(x, 4) if x is not None else None for x in raw_k]}


def macd(values: Sequence[float], fast: int = 12, slow: int = 26,
         signal: int = 9) -> Dict[str, List[Num]]:
    v = _clean(values)
    ef, es = ema(v, fast), ema(v, slow)
    line: List[Num] = [None] * len(v)
    for i in range(len(v)):
        if ef[i] is not None and es[i] is not None:
            line[i] = ef[i] - es[i]
    filled = [x for x in line if x is not None]
    sig_filled = sma(filled, signal) if len(filled) >= signal else [None] * len(filled)
    sig: List[Num] = [None] * (len(line) - len(sig_filled)) + list(sig_filled)
    hist: List[Num] = [None] * len(v)
    for i in range(len(v)):
        if line[i] is not None and i < len(sig) and sig[i] is not None:
            hist[i] = line[i] - sig[i]
    return {"macd": [round(x, 6) if x is not None else None for x in line],
            "signal": [round(x, 6) if x is not None else None for x in sig],
            "histogram": [round(x, 6) if x is not None else None for x in hist]}


def true_range(high: Sequence[float], low: Sequence[float],
                 close: Sequence[float]) -> List[float]:
    h, l, c = _clean(high), _clean(low), _clean(close)
    n = min(len(h), len(l), len(c))
    tr = [h[0] - l[0]] if n else []
    for i in range(1, n):
        tr.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))
    return tr


def atr(high: Sequence[float], low: Sequence[float], close: Sequence[float],
        period: int = 14) -> Dict[str, Any]:
    tr = true_range(high, low, close)
    if not tr:
        return {"series": [], "value": None, "percent": None}
    series: List[Num] = [None] * len(tr)
    if len(tr) >= period:
        series[period - 1] = sum(tr[:period]) / period
        prev = series[period - 1]
        for i in range(period, len(tr)):
            prev = (prev * (period - 1) + tr[i]) / period
            series[i] = prev
    value = last(series)
    c = _clean(close)
    return {"series": [round(x, 6) if x is not None else None for x in series],
            "value": value, "true_range": round(tr[-1], 6),
            "percent": round(value / c[-1] * 100, 4) if value and c else None}


def bollinger(values: Sequence[float], period: int = 20,
              num_std: float = 2.0) -> Dict[str, List[Num]]:
    v = _clean(values)
    mid = sma(v, period)
    upper: List[Num] = [None] * len(v)
    lower: List[Num] = [None] * len(v)
    width: List[Num] = [None] * len(v)
    percent_b: List[Num] = [None] * len(v)
    for i in range(period - 1, len(v)):
        m = mid[i]
        if m is None:
            continue
        chunk = v[i - period + 1: i + 1]
        var = sum((x - m) ** 2 for x in chunk) / period
        sd = math.sqrt(var)
        upper[i] = m + num_std * sd
        lower[i] = m - num_std * sd
        width[i] = (upper[i] - lower[i]) / m * 100 if m else None
        percent_b[i] = ((v[i] - lower[i]) / (upper[i] - lower[i])) if upper[i] != lower[i] else None
    return {"middle": _r(mid), "upper": _r(upper), "lower": _r(lower),
            "bandwidth_percent": _r(width), "percent_b": _r(percent_b), "std_dev": num_std,
            "period": period}


def keltner(high: Sequence[float], low: Sequence[float], close: Sequence[float],
            period: int = 20, mult: float = 2.0) -> Dict[str, List[Num]]:
    c = _clean(close)
    mid = ema(c, period)
    a = atr(high, low, close, period)["series"]
    upper: List[Num] = [None] * len(c)
    lower: List[Num] = [None] * len(c)
    for i in range(len(c)):
        if i < len(mid) and i < len(a) and mid[i] is not None and a[i] is not None:
            upper[i] = mid[i] + mult * a[i]
            lower[i] = mid[i] - mult * a[i]
    return {"middle": _r(mid), "upper": _r(upper), "lower": _r(lower)}


def roc(values: Sequence[float], period: int = 12) -> List[Num]:
    v = _clean(values)
    out: List[Num] = [None] * len(v)
    for i in range(period, len(v)):
        if v[i - period]:
            out[i] = (v[i] - v[i - period]) / v[i - period] * 100
    return _r(out)


def momentum(values: Sequence[float], period: int = 10) -> List[Num]:
    v = _clean(values)
    out: List[Num] = [None] * len(v)
    for i in range(period, len(v)):
        out[i] = v[i] - v[i - period]
    return _r(out)


def williams_r(high: Sequence[float], low: Sequence[float], close: Sequence[float],
               period: int = 14) -> List[Num]:
    h, l, c = _clean(high), _clean(low), _clean(close)
    n = min(len(h), len(l), len(c))
    out: List[Num] = [None] * n
    for i in range(period - 1, n):
        hh = max(h[i - period + 1: i + 1])
        ll = min(l[i - period + 1: i + 1])
        out[i] = -100.0 * (hh - c[i]) / (hh - ll) if hh != ll else -50.0
    return _r(out)


def cci(high: Sequence[float], low: Sequence[float], close: Sequence[float],
        period: int = 20) -> List[Num]:
    h, l, c = _clean(high), _clean(low), _clean(close)
    n = min(len(h), len(l), len(c))
    tp = [(h[i] + l[i] + c[i]) / 3 for i in range(n)]
    out: List[Num] = [None] * n
    for i in range(period - 1, n):
        chunk = tp[i - period + 1: i + 1]
        m = sum(chunk) / period
        md = sum(abs(x - m) for x in chunk) / period
        out[i] = (tp[i] - m) / (0.015 * md) if md else None
    return _r(out)


def mfi(high: Sequence[float], low: Sequence[float], close: Sequence[float],
        volume: Sequence[float], period: int = 14) -> List[Num]:
    h, l, c, vol = _clean(high), _clean(low), _clean(close), _clean(volume)
    n = min(len(h), len(l), len(c), len(vol))
    if n < period + 1:
        return [None] * n
    tp = [(h[i] + l[i] + c[i]) / 3 for i in range(n)]
    raw: List[Num] = [None] * n
    pos = neg = 0.0
    for i in range(1, period + 1):
        flow = tp[i] * vol[i]
        if tp[i] > tp[i - 1]:
            pos += flow
        elif tp[i] < tp[i - 1]:
            neg += flow
    raw[period] = 100.0 if neg == 0 else 100 - 100 / (1 + pos / neg)
    for i in range(period + 1, n):
        flow = tp[i] * vol[i]
        leaving = tp[i - period] * vol[i - period]
        if tp[i] > tp[i - 1]:
            pos += flow
        else:
            pos -= leaving
        if tp[i] < tp[i - 1]:
            neg += flow
        else:
            neg -= leaving
        pos, neg = max(pos, 0.0), max(neg, 0.0)
        raw[i] = 100.0 if neg == 0 else 100 - 100 / (1 + pos / neg)
    return _r(raw)


def obv(close: Sequence[float], volume: Sequence[float]) -> List[float]:
    c, v = _clean(close), _clean(volume)
    n = min(len(c), len(v))
    out = [0.0]
    for i in range(1, n):
        out.append(out[-1] + (v[i] if c[i] > c[i - 1] else -v[i] if c[i] < c[i - 1] else 0.0))
    return [round(x, 2) for x in out]


def accumulation_distribution(high: Sequence[float], low: Sequence[float],
                              close: Sequence[float], volume: Sequence[float]) -> List[float]:
    h, l, c, v = _clean(high), _clean(low), _clean(close), _clean(volume)
    n = min(len(h), len(l), len(c), len(v))
    out, acc = [], 0.0
    for i in range(n):
        rng = h[i] - l[i]
        mfm = ((c[i] - l[i]) - (h[i] - c[i])) / rng if rng else 0.0
        acc += mfm * v[i]
        out.append(round(acc, 2))
    return out


def vwap(high: Sequence[float], low: Sequence[float], close: Sequence[float],
         volume: Sequence[float]) -> List[Num]:
    h, l, c, v = _clean(high), _clean(low), _clean(close), _clean(volume)
    n = min(len(h), len(l), len(c), len(v))
    out: List[Num] = []
    cum_pv = cum_v = 0.0
    for i in range(n):
        tp = (h[i] + l[i] + c[i]) / 3
        cum_pv += tp * v[i]
        cum_v += v[i]
        out.append(round(cum_pv / cum_v, 6) if cum_v else None)
    return out


def psar(high: Sequence[float], low: Sequence[float], af_step: float = 0.02,
         af_max: float = 0.2) -> Dict[str, Any]:
    """Parabolic SAR — also reports the current trend flip state."""
    h, l = _clean(high), _clean(low)
    n = min(len(h), len(l))
    if n < 3:
        return {"series": [], "trend": "unknown", "value": None, "flips": 0}
    bull = True
    af = af_step
    ep = h[0]
    sar = l[0]
    series: List[Num] = [None, None]
    flips = 0
    for i in range(2, n):
        sar = sar + af * (ep - sar)
        if bull:
            sar = min(sar, l[i - 1], l[i - 2])
            if h[i] > ep:
                ep = h[i]
                af = min(af + af_step, af_max)
            if l[i] < sar:
                bull, flips = False, flips + 1
                sar, ep, af = ep, l[i], af_step
        else:
            sar = max(sar, h[i - 1], h[i - 2])
            if l[i] < ep:
                ep = l[i]
                af = min(af + af_step, af_max)
            if h[i] > sar:
                bull, flips = True, flips + 1
                sar, ep, af = ep, h[i], af_step
        series.append(round(sar, 6))
    return {"series": series, "trend": "up" if bull else "down",
            "value": series[-1], "flips": flips}


def adx(high: Sequence[float], low: Sequence[float], close: Sequence[float],
        period: int = 14) -> Dict[str, List[Num]]:
    h, l, c = _clean(high), _clean(low), _clean(close)
    n = min(len(h), len(l), len(c))
    if n < period + 1:
        return {"adx": [], "plus_di": [], "minus_di": []}
    plus_dm, minus_dm, tr = [], [], []
    for i in range(1, n):
        up = h[i] - h[i - 1]
        down = l[i - 1] - l[i]
        plus_dm.append(up if (up > down and up > 0) else 0.0)
        minus_dm.append(down if (down > up and down > 0) else 0.0)
        tr.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))

    def wilder(series: List[float]) -> List[float]:
        acc = sum(series[:period])
        out = [acc]
        for x in series[period:]:
            acc = acc - acc / period + x
            out.append(acc)
        return out

    tr_s, plus_s, minus_s = wilder(tr), wilder(plus_dm), wilder(minus_dm)
    adx_vals: List[Num] = []
    dx: List[float] = []
    plus_di, minus_di = [], []
    for i in range(len(tr_s)):
        pdi = 100 * plus_s[i] / tr_s[i] if tr_s[i] else 0.0
        mdi = 100 * minus_s[i] / tr_s[i] if tr_s[i] else 0.0
        plus_di.append(pdi)
        minus_di.append(mdi)
        denom = pdi + mdi
        dx.append(100 * abs(pdi - mdi) / denom if denom else 0.0)
    if len(dx) >= period:
        acc = sum(dx[:period]) / period
        adx_vals = [acc]
        for x in dx[period:]:
            acc = (acc * (period - 1) + x) / period
            adx_vals.append(acc)
    pad = n - len(adx_vals)
    return {"adx": [None] * max(pad, 0) + [round(x, 4) for x in adx_vals],
            "plus_di": [None] * (n - len(plus_di)) + [round(x, 4) for x in plus_di],
            "minus_di": [None] * (n - len(minus_di)) + [round(x, 4) for x in minus_di]}


def ichimoku(high: Sequence[float], low: Sequence[float], close: Sequence[float]) -> Dict[str, Any]:
    h, l, c = _clean(high), _clean(low), _clean(close)
    n = min(len(h), len(l), len(c))
    if n < 52:
        return {"ok": False, "error": "Ichimoku needs at least 52 candles"}

    def midline(period: int, offset: int = 0) -> Num:
        end = n - offset
        if end < period:
            return None
        chunk_h = max(h[end - period:end])
        chunk_l = min(l[end - period:end])
        return round((chunk_h + chunk_l) / 2, 6)

    tenkan = midline(9)
    kijun = midline(26)
    senkou_a = round((tenkan + kijun) / 2, 6) if tenkan and kijun else None
    senkou_b = midline(52, 26)
    chikou = round(c[-1], 6)
    price = round(c[-1], 6)
    cloud_top = max(x for x in (senkou_a, senkou_b) if x)
    cloud_bottom = min(x for x in (senkou_a, senkou_b) if x)
    above = price > cloud_top
    below = price < cloud_bottom
    return {"ok": True, "tenkan_sen": tenkan, "kijun_sen": kijun, "senkou_span_a": senkou_a,
            "senkou_span_b": senkou_b, "chikou_span": chikou, "price": price,
            "cloud_top": cloud_top, "cloud_bottom": cloud_bottom,
            "position": "above cloud" if above else "below cloud" if below else "inside cloud",
            "bias": "bullish" if above and tenkan and kijun and tenkan > kijun else
                    "bearish" if below and tenkan and kijun and tenkan < kijun else "mixed",
            "signals": [s for s in [
                "price above the cloud" if above else "price below the cloud" if below else
                "price inside the cloud (indecision)",
                "Tenkan above Kijun (bullish cross)" if tenkan and kijun and tenkan > kijun else
                "Tenkan below Kijun (bearish cross)" if tenkan and kijun else "",
                "cloud expanding up" if senkou_a and senkou_b and senkou_a > senkou_b else
                "cloud expanding down" if senkou_a and senkou_b else "",
            ] if s]}


def historical_volatility(values: Sequence[float], period: int = 20,
                          annualise: int = 252) -> Dict[str, Any]:
    v = _clean(values)
    if len(v) < period + 1:
        return {"ok": False, "error": f"need at least {period + 1} closes for volatility"}
    rets = [math.log(v[i] / v[i - 1]) for i in range(len(v) - period, len(v)) if v[i - 1] > 0]
    if len(rets) < 2:
        return {"ok": False, "error": "not enough valid returns"}
    mean = sum(rets) / len(rets)
    var = sum((r - mean) ** 2 for r in rets) / (len(rets) - 1)
    sd = math.sqrt(var)
    return {"ok": True, "period": period, "returns_used": len(rets),
            "volatility_per_period_percent": round(sd * 100, 4),
            "annualised_volatility_percent": round(sd * math.sqrt(annualise) * 100, 3),
            "mean_return_percent": round(mean * 100, 4),
            "interpretation": ("high" if sd * math.sqrt(annualise) * 100 > 60 else
                               "elevated" if sd * math.sqrt(annualise) * 100 > 35 else
                               "normal" if sd * math.sqrt(annualise) * 100 > 15 else "low")}


def expected_move(price: float, volatility_percent: float, periods: float = 1) -> Dict[str, float]:
    """1-sigma expected move — what a binary-option expiry window really means."""
    sigma = price * (volatility_percent / 100) * math.sqrt(max(periods, 0))
    return {"price": round(price, 6), "one_sigma_up": round(price + sigma, 6),
            "one_sigma_down": round(price - sigma, 6), "sigma": round(sigma, 6),
            "sigma_percent": round(sigma / price * 100, 4) if price else None,
            "two_sigma_up": round(price + 2 * sigma, 6), "two_sigma_down": round(price - 2 * sigma, 6)}


# ---------------------------------------------------------------------------
# levels & structure
# ---------------------------------------------------------------------------
def pivot_points(high: Sequence[float], low: Sequence[float], close: Sequence[float],
                 kind: str = "classic") -> Dict[str, Any]:
    h, l, c = _clean(high)[-1], _clean(low)[-1], _clean(close)[-1]
    p = (h + l + c) / 3
    if kind == "fibonacci":
        rng = h - l
        return {"kind": "fibonacci", "pivot": round(p, 6),
                "r1": round(p + 0.382 * rng, 6), "r2": round(p + 0.618 * rng, 6),
                "r3": round(p + rng, 6), "s1": round(p - 0.382 * rng, 6),
                "s2": round(p - 0.618 * rng, 6), "s3": round(p - rng, 6)}
    if kind == "woodie":
        return {"kind": "woodie", "pivot": round((h + l + 2 * c) / 4, 6),
                "r1": round(2 * ((h + l + 2 * c) / 4) - l, 6),
                "s1": round(2 * ((h + l + 2 * c) / 4) - h, 6),
                "r2": round(((h + l + 2 * c) / 4) + (h - l), 6),
                "s2": round(((h + l + 2 * c) / 4) - (h - l), 6)}
    if kind == "camarilla":
        rng = h - l
        return {"kind": "camarilla", "pivot": round(p, 6),
                "r1": round(c + rng * 1.1 / 12, 6), "r2": round(c + rng * 1.1 / 6, 6),
                "r3": round(c + rng * 1.1 / 4, 6), "r4": round(c + rng * 1.1 / 2, 6),
                "s1": round(c - rng * 1.1 / 12, 6), "s2": round(c - rng * 1.1 / 6, 6),
                "s3": round(c - rng * 1.1 / 4, 6), "s4": round(c - rng * 1.1 / 2, 6)}
    r1, s1 = 2 * p - l, 2 * p - h
    return {"kind": "classic", "pivot": round(p, 6), "r1": round(r1, 6),
            "r2": round(p + (h - l), 6), "r3": round(h + 2 * (p - l), 6),
            "s1": round(s1, 6), "s2": round(p - (h - l), 6), "s3": round(l - 2 * (h - p), 6)}


def fibonacci(high: Sequence[float], low: Sequence[float], close: Sequence[float],
              lookback: int = 100) -> Dict[str, Any]:
    h, l, c = _clean(high), _clean(low), _clean(close)
    window_h, window_l = h[-lookback:], l[-lookback:]
    hi, lo = max(window_h), min(window_l)
    price = c[-1]
    up = c.index(hi) if hi in c else len(c) - 1
    trend = "up" if (len(c) > 1 and c[-1] >= c[0]) else "down"
    levels = [0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0]
    if trend == "up":
        values = {f"{int(x * 1000) / 10:g}%": round(hi - (hi - lo) * x, 6) for x in levels}
    else:
        values = {f"{int(x * 1000) / 10:g}%": round(lo + (hi - lo) * x, 6) for x in levels}
    nearest = min(values.items(), key=lambda kv: abs(kv[1] - price))
    return {"trend": trend, "swing_high": round(hi, 6), "swing_low": round(lo, 6),
            "price": round(price, 6), "levels": values,
            "nearest_level": {"level": nearest[0], "price": nearest[1],
                              "distance_percent": round((price - nearest[1]) / nearest[1] * 100, 4)},
            "golden_pocket": [values.get("61.8%"), values.get("78.6%")],
            "extensions": {f"{int(x * 1000) / 10:g}%":
                           round(hi + (hi - lo) * (x - 1), 6) for x in (1.272, 1.618, 2.0)}}


def support_resistance(high: Sequence[float], low: Sequence[float], close: Sequence[float],
                       lookback: int = 200, clusters: int = 6) -> Dict[str, Any]:
    """Swing-point clustering — no magic, just local extrema grouped by proximity."""
    h, l, c = _clean(high), _clean(low), _clean(close)
    n = min(len(h), len(l), len(c))
    if n < 10:
        return {"ok": False, "error": "need at least 10 candles to find levels"}
    window = n if lookback >= n else lookback
    hs, ls = h[-window:], l[-window:]
    price = c[-1]
    tol = (max(hs) - min(ls)) * 0.012 or price * 0.001

    pivots: List[Tuple[float, str]] = []
    for i in range(2, window - 2):
        if hs[i] == max(hs[i - 2:i + 3]):
            pivots.append((hs[i], "resistance"))
        if ls[i] == min(ls[i - 2:i + 3]):
            pivots.append((ls[i], "support"))

    grouped: List[Dict[str, Any]] = []
    for level, kind in sorted(pivots):
        hit = next((g for g in grouped if abs(g["price"] - level) <= tol), None)
        if hit:
            hit["touches"] += 1
            hit["price"] = round((hit["price"] * (hit["touches"] - 1) + level) / hit["touches"], 6)
            hit["kinds"].add(kind)
        else:
            grouped.append({"price": round(level, 6), "touches": 1, "kinds": {kind}})
    grouped.sort(key=lambda g: (-g["touches"], abs(g["price"] - price)))
    top = grouped[: clusters * 2]
    for g in top:
        g["kinds"] = sorted(g["kinds"])
        g["strength"] = "strong" if g["touches"] >= 4 else "moderate" if g["touches"] >= 2 else "weak"
        g["distance_percent"] = round((g["price"] - price) / price * 100, 4)
        g["type"] = "support" if g["price"] < price else "resistance"
    supports = sorted([g for g in top if g["price"] < price], key=lambda g: -g["price"])[:clusters]
    resistances = sorted([g for g in top if g["price"] >= price], key=lambda g: g["price"])[:clusters]
    return {"ok": True, "price": round(price, 6), "tolerance": round(tol, 6),
            "supports": supports, "resistances": resistances,
            "nearest_support": supports[0] if supports else None,
            "nearest_resistance": resistances[0] if resistances else None,
            "range_high": round(max(hs), 6), "range_low": round(min(ls), 6)}


def round_levels(price: float, step: Optional[float] = None, count: int = 3) -> Dict[str, Any]:
    """Psychological round numbers (1.1000, 1.1050, 150.00 …)."""
    if not price:
        return {"levels": []}
    magnitude = 10 ** math.floor(math.log10(abs(price)))
    step = step or magnitude / 2
    base = math.floor(price / step) * step
    levels = [round(base + i * step, 8) for i in range(-count, count + 1)]
    return {"price": round(price, 6), "step": step,
            "levels": [{"price": lv, "distance_percent": round((lv - price) / price * 100, 4),
                        "type": "below" if lv < price else "above"} for lv in levels if lv != price]}


def trend_state(close: Sequence[float], high: Sequence[float], low: Sequence[float],
                fast: int = 20, slow: int = 50) -> Dict[str, Any]:
    c = _clean(close)
    if len(c) < slow + 2:
        return {"trend": "unknown", "error": f"need ≥{slow + 2} candles"}
    e_fast, e_slow = ema(c, fast), ema(c, slow)
    s50, s200 = sma(c, min(slow, len(c))), sma(c, 200) if len(c) >= 200 else [None] * len(c)
    f, s = last(e_fast), last(e_slow)
    price = c[-1]
    slope = (c[-1] - c[-min(20, len(c))]) / c[-min(20, len(c))] * 100 if len(c) > 20 else 0.0
    a = adx(high, low, close, 14)
    adx_value = last(a["adx"])
    strength = ("strong" if (adx_value or 0) >= 40 else "moderate" if (adx_value or 0) >= 25
                else "weak" if (adx_value or 0) >= 20 else "no trend / ranging")
    trend = "up" if (f or 0) > (s or 0) and price > (f or 0) else \
            "down" if (f or 0) < (s or 0) and price < (f or 0) else "sideways"
    hh_hl = _higher_highs(high, low)
    return {"trend": trend, "strength": strength, "adx": adx_value,
            "plus_di": last(a["plus_di"]), "minus_di": last(a["minus_di"]),
            f"ema{fast}": f, f"ema{slow}": s, "sma200": last(s200), "price": round(price, 6),
            "slope_20_percent": round(slope, 4), "structure": hh_hl,
            "golden_cross": (last(s50) or 0) > (last(s200) or 0) if last(s200) else None,
            "interpretation": f"{strength} {trend} trend"
                              + (f", {hh_hl}" if hh_hl else "")
                              + (f", price {'above' if last(s200) and price > last(s200) else 'below'} SMA200"
                                 if last(s200) else "")}


def _higher_highs(high: Sequence[float], low: Sequence[float]) -> str:
    h, l = _clean(high), _clean(low)
    if len(h) < 20:
        return ""
    half = len(h) // 2
    hh = max(h[half:]) > max(h[:half])
    ll = min(l[half:]) > min(l[:half])
    lh = max(h[half:]) < max(h[:half])
    hl = min(l[half:]) < min(l[:half])
    if hh and ll:
        return "higher highs + higher lows"
    if lh and hl:
        return "lower highs + lower lows"
    return "no clear structure"


def squeeze(close: Sequence[float], high: Sequence[float], low: Sequence[float],
            bb_period: int = 20, kc_period: int = 20) -> Dict[str, Any]:
    """TTM Squeeze: Bollinger inside Keltner ⇒ low volatility, expansion likely."""
    bb = bollinger(close, bb_period)
    kc = keltner(high, low, close, kc_period)
    on = []
    for i in range(len(close)):
        if i < len(bb["upper"]) and i < len(kc["upper"]):
            u, l, ku, kl = bb["upper"][i], bb["lower"][i], kc["upper"][i], kc["lower"][i]
            on.append(bool(u is not None and l is not None and ku is not None
                           and kl is not None and u < ku and l > kl))
    recent = on[-10:] if on else []
    return {"squeeze_on": bool(on and on[-1]), "recent_squeeze_candles": sum(1 for x in recent if x),
            "fired_recently": bool(len(on) > 2 and on[-1] is False and any(on[-6:-1])),
            "history": on[-40:],
            "interpretation": ("volatility is compressed — expect an expansion move"
                               if on and on[-1] else
                               "squeeze just fired — volatility is expanding"
                               if len(on) > 2 and not on[-1] and any(on[-6:-1]) else
                               "normal volatility")}


def divergence(close: Sequence[float], indicator: Sequence[Num],
               lookback: int = 40) -> Dict[str, Any]:
    """Regular + hidden divergence between price swings and an oscillator."""
    c, ind = _clean(close), [x for x in indicator if x is not None]
    n = min(len(c), len(ind), lookback)
    if n < 12:
        return {"ok": False, "error": "not enough data for divergence"}
    c, ind = c[-n:], ind[-n:]

    def swings(series: List[float], compare) -> List[int]:
        return [i for i in range(1, len(series) - 1)
                if compare(series[i], series[i - 1]) and compare(series[i], series[i + 1])]

    price_highs = swings(c, lambda a, b: a >= b)
    price_lows = swings(c, lambda a, b: a <= b)
    ind_highs = swings(ind, lambda a, b: a >= b)
    ind_lows = swings(ind, lambda a, b: a <= b)
    out = {"ok": True, "regular_bullish": False, "regular_bearish": False,
           "hidden_bullish": False, "hidden_bearish": False, "notes": []}
    if len(price_lows) >= 2 and len(ind_lows) >= 2:
        p1, p2 = price_lows[-2], price_lows[-1]
        i1, i2 = ind_lows[-2], ind_lows[-1]
        if c[p2] < c[p1] and ind[i2] > ind[i1]:
            out["regular_bullish"] = True
            out["notes"].append("price made a lower low while the oscillator made a higher low "
                                "⇒ regular bullish divergence (possible reversal up)")
        if c[p2] > c[p1] and ind[i2] < ind[i1]:
            out["hidden_bullish"] = True
            out["notes"].append("price made a higher low while the oscillator made a lower low "
                                "⇒ hidden bullish divergence (trend continuation up)")
    if len(price_highs) >= 2 and len(ind_highs) >= 2:
        p1, p2 = price_highs[-2], price_highs[-1]
        i1, i2 = ind_highs[-2], ind_highs[-1]
        if c[p2] > c[p1] and ind[i2] < ind[i1]:
            out["regular_bearish"] = True
            out["notes"].append("price made a higher high while the oscillator made a lower high "
                                "⇒ regular bearish divergence (possible reversal down)")
        if c[p2] < c[p1] and ind[i2] > ind[i1]:
            out["hidden_bearish"] = True
            out["notes"].append("price made a lower high while the oscillator made a higher high "
                                "⇒ hidden bearish divergence (trend continuation down)")
    if not out["notes"]:
        out["notes"].append("no divergence detected in the last "
                            f"{n} candles")
    return out


# ---------------------------------------------------------------------------
# candlestick + chart patterns
# ---------------------------------------------------------------------------
def candle_patterns(candles: Sequence[Dict[str, Any]], count: int = 3) -> List[Dict[str, Any]]:
    """Detect the classic single/double/triple candle formations on recent bars."""
    found: List[Dict[str, Any]] = []
    cs = list(candles)[-max(count * 2, 8):]
    if len(cs) < 3:
        return found

    def body(c: Dict[str, Any]) -> float:
        return abs(c["close"] - c["open"])

    def rng(c: Dict[str, Any]) -> float:
        return max(c["high"] - c["low"], 1e-12)

    def bull(c: Dict[str, Any]) -> bool:
        return c["close"] > c["open"]

    for i in range(2, len(cs)):
        c, p, pp = cs[i], cs[i - 1], cs[i - 2]
        b, r = body(c), rng(c)
        upper = c["high"] - max(c["open"], c["close"])
        lower = min(c["open"], c["close"]) - c["low"]
        idx = len(cs) - 1 - i
        label = f"{idx} candle(s) ago" if idx else "latest candle"
        if r and b / r < 0.1:
            found.append({"pattern": "Doji", "bias": "indecision", "strength": "weak",
                          "when": label, "meaning": "open ≈ close — the market is undecided; "
                                                   "meaningful only after a strong move"})
        if lower > 2 * b and upper < b * 0.6 and b:
            found.append({"pattern": "Hammer" if bull(c) else "Hanging Man",
                          "bias": "bullish" if bull(c) else "bearish",
                          "strength": "moderate", "when": label,
                          "meaning": "long lower wick, small body — sellers pushed down and "
                                     "buyers took control"})
        if upper > 2 * b and lower < b * 0.6 and b:
            found.append({"pattern": "Shooting Star" if not bull(c) else "Inverted Hammer",
                          "bias": "bearish" if not bull(c) else "bullish",
                          "strength": "moderate", "when": label,
                          "meaning": "long upper wick, small body — the rally was rejected"})
        if body(p) and b > body(p) * 1.1 and bull(c) and not bull(p) and \
                c["close"] > p["open"] and c["open"] < p["close"]:
            found.append({"pattern": "Bullish Engulfing", "bias": "bullish", "strength": "strong",
                          "when": label,
                          "meaning": "a green body completely engulfs the previous red body"})
        if body(p) and b > body(p) * 1.1 and not bull(c) and bull(p) and \
                c["close"] < p["open"] and c["open"] > p["close"]:
            found.append({"pattern": "Bearish Engulfing", "bias": "bearish", "strength": "strong",
                          "when": label,
                          "meaning": "a red body completely engulfs the previous green body"})
        if not bull(pp) and body(p) / rng(p) < 0.35 and bull(c) and c["close"] > (pp["open"] + pp["close"]) / 2:
            found.append({"pattern": "Morning Star", "bias": "bullish", "strength": "strong",
                          "when": label, "meaning": "3-candle bottom reversal"})
        if bull(pp) and body(p) / rng(p) < 0.35 and not bull(c) and c["close"] < (pp["open"] + pp["close"]) / 2:
            found.append({"pattern": "Evening Star", "bias": "bearish", "strength": "strong",
                          "when": label, "meaning": "3-candle top reversal"})
        if body(p) and body(pp) and bull(c) and not bull(p) and not bull(pp) and \
                c["close"] > max(p["open"], pp["open"]):
            found.append({"pattern": "Three White Soldiers (partial)", "bias": "bullish",
                          "strength": "moderate", "when": label,
                          "meaning": "strong reversal candle after two down closes"})
    # dedupe keeping the strongest
    seen: Dict[str, Dict[str, Any]] = {}
    for f in found:
        key = f["pattern"]
        if key not in seen or ({"weak": 0, "moderate": 1, "strong": 2}[f["strength"]] >
                               {"weak": 0, "moderate": 1, "strong": 2}[seen[key]["strength"]]):
            seen[key] = f
    return sorted(seen.values(), key=lambda x: -{"weak": 0, "moderate": 1, "strong": 2}[x["strength"]])


def chart_patterns(candles: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Multi-candle structures: double top/bottom, head & shoulders, triangles, channels."""
    cs = list(candles)
    if len(cs) < 30:
        return [{"pattern": "insufficient data", "note": "need ≥30 candles for chart patterns"}]
    highs = [c["high"] for c in cs]
    lows = [c["low"] for c in cs]
    closes = [c["close"] for c in cs]
    out: List[Dict[str, Any]] = []
    n = len(cs)
    half = n // 2
    tol = (max(highs) - min(lows)) * 0.02

    def peaks(series: List[float]) -> List[int]:
        return [i for i in range(2, len(series) - 2)
                if series[i] == max(series[i - 2:i + 3])]

    hp, lp = peaks(highs), peaks(lows)
    if len(hp) >= 2 and abs(highs[hp[-1]] - highs[hp[-2]]) <= tol:
        out.append({"pattern": "Double Top", "bias": "bearish", "strength": "moderate",
                    "neckline": round(min(lows[hp[-2]:hp[-1]]), 6),
                    "meaning": "two highs at the same level — resistance confirmed"})
    if len(lp) >= 2 and abs(lows[lp[-1]] - lows[lp[-2]]) <= tol:
        out.append({"pattern": "Double Bottom", "bias": "bullish", "strength": "moderate",
                    "neckline": round(max(highs[lp[-2]:lp[-1]]), 6),
                    "meaning": "two lows at the same level — support confirmed"})
    if len(hp) >= 3 and highs[hp[-2]] > highs[hp[-3]] and highs[hp[-2]] > highs[hp[-1]]:
        out.append({"pattern": "Head and Shoulders", "bias": "bearish", "strength": "strong",
                    "head": round(highs[hp[-2]], 6),
                    "neckline": round((min(lows[hp[-3]:hp[-2]]) + min(lows[hp[-2]:hp[-1]])) / 2, 6),
                    "meaning": "higher high between two lower highs — classic reversal"})
    if len(lp) >= 3 and lows[lp[-2]] < lows[lp[-3]] and lows[lp[-2]] < lows[lp[-1]]:
        out.append({"pattern": "Inverse Head and Shoulders", "bias": "bullish", "strength": "strong",
                    "head": round(lows[lp[-2]], 6),
                    "meaning": "lower low between two higher lows — bullish reversal"})
    # trendline slopes on the last 30 bars
    recent_h, recent_l = highs[-30:], lows[-30:]
    hs_slope = _slope(list(range(len(recent_h))), [max(recent_h[:i + 1]) for i in range(len(recent_h))])
    ls_slope = _slope(list(range(len(recent_l))), [min(recent_l[i:]) for i in range(len(recent_l))])
    width_now = closes[-1] - min(recent_l)
    width_before = max(recent_h) - min(recent_l)
    if width_now < width_before * 0.55:
        out.append({"pattern": "Contracting range (triangle/wedge)", "bias": "neutral",
                    "strength": "moderate",
                    "meaning": f"range compressed to {round(width_now / width_before * 100)}% "
                               f"of its earlier width — breakouts from these tend to be decisive"})
    if hs_slope > 0 and ls_slope > 0:
        out.append({"pattern": "Ascending channel", "bias": "bullish", "strength": "moderate",
                    "meaning": "both highs and lows are rising"})
    elif hs_slope < 0 and ls_slope < 0:
        out.append({"pattern": "Descending channel", "bias": "bearish", "strength": "moderate",
                    "meaning": "both highs and lows are falling"})
    # breakout of the 20-bar range on the last candle
    hi20, lo20 = max(highs[-21:-1]), min(lows[-21:-1])
    if closes[-1] > hi20:
        out.append({"pattern": "20-bar range breakout (up)", "bias": "bullish", "strength": "strong",
                    "level": round(hi20, 6), "meaning": "close above the last 20 bars' high"})
    elif closes[-1] < lo20:
        out.append({"pattern": "20-bar range breakout (down)", "bias": "bearish", "strength": "strong",
                    "level": round(lo20, 6), "meaning": "close below the last 20 bars' low"})
    return out


def _slope(xs: List[float], ys: List[float]) -> float:
    n = len(xs)
    if n < 2:
        return 0.0
    mx, my = sum(xs) / n, sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den = sum((x - mx) ** 2 for x in xs)
    return num / den if den else 0.0


def correlation(a: Sequence[float], b: Sequence[float]) -> Optional[float]:
    x, y = _clean(a), _clean(b)
    n = min(len(x), len(y))
    if n < 3:
        return None
    x, y = x[-n:], y[-n:]
    rx = [math.log(x[i] / x[i - 1]) for i in range(1, n) if x[i - 1] > 0]
    ry = [math.log(y[i] / y[i - 1]) for i in range(1, n) if y[i - 1] > 0]
    m = min(len(rx), len(ry))
    if m < 3:
        return None
    rx, ry = rx[-m:], ry[-m:]
    mx, my = sum(rx) / m, sum(ry) / m
    num = sum((p - mx) * (q - my) for p, q in zip(rx, ry))
    den = math.sqrt(sum((p - mx) ** 2 for p in rx) * sum((q - my) ** 2 for q in ry))
    return round(num / den, 4) if den else None


def _r(series: Sequence[Num], places: int = 6) -> List[Num]:
    return [round(float(x), places) if x is not None else None for x in series]


# ---------------------------------------------------------------------------
# the "everything" snapshot
# ---------------------------------------------------------------------------
def full_snapshot(candles: Sequence[Dict[str, Any]], *, symbol: str = "",
                  interval: str = "") -> Dict[str, Any]:
    """
    Compute the whole indicator set for a candle series.

    This is what ``market.indicators`` and ``market.signal`` build on.
    """
    cs = list(candles)
    closes = [c["close"] for c in cs]
    highs = [c["high"] for c in cs]
    lows = [c["low"] for c in cs]
    vols = [c.get("volume") or 0 for c in cs]
    if len(closes) < 30:
        return {"ok": False, "symbol": symbol, "candles": len(closes),
                "error": f"only {len(closes)} candles — need at least 30 for a meaningful reading"}

    price = closes[-1]
    prev = closes[-2] if len(closes) > 1 else price
    change = price - prev
    change_pct = change / prev * 100 if prev else 0.0

    rsi_series = rsi(closes, 14)
    rsi7 = rsi(closes, 7)
    macd_data = macd(closes)
    bb = bollinger(closes, 20, 2)
    stoch = stochastic(highs, lows, closes)
    a = atr(highs, lows, closes, 14)
    adx_data = adx(highs, lows, closes, 14)
    trend = trend_state(closes, highs, lows)
    levels = support_resistance(highs, lows, closes)
    pivots = pivot_points(highs, lows, closes)
    fibs = fibonacci(highs, lows, closes)
    hv = historical_volatility(closes, 20)
    willr = williams_r(highs, lows, closes)
    cci_series = cci(highs, lows, closes)
    mfi_series = mfi(highs, lows, closes, vols) if any(vols) else [None]
    obv_series = obv(closes, vols) if any(vols) else []
    sq = squeeze(closes, highs, lows)
    div = divergence(closes, rsi_series)
    ich = ichimoku(highs, lows, closes) if len(closes) >= 52 else {"ok": False}
    sar = psar(highs, lows)
    patterns = candle_patterns(cs, 3)
    structures = chart_patterns(cs)

    rsi_now = last(rsi_series)
    macd_now, macd_sig, macd_hist = last(macd_data["macd"]), last(macd_data["signal"]), last(macd_data["histogram"])
    hist_prev = [x for x in macd_data["histogram"] if x is not None]

    summary = {
        "ok": True, "symbol": symbol, "interval": interval, "candles": len(cs),
        "price": round(price, 6), "change": round(change, 6),
        "change_percent": round(change_pct, 4),
        "session_high": round(max(highs[-min(24, len(highs)):]), 6),
        "session_low": round(min(lows[-min(24, len(lows)):]), 6),
        "period_high": round(max(highs), 6), "period_low": round(min(lows), 6),
        "trend": trend,
        "rsi14": rsi_now, "rsi7": last(rsi7),
        "rsi_state": ("overbought" if (rsi_now or 0) >= 70 else
                      "oversold" if (rsi_now or 0) <= 30 else
                      "bullish zone" if (rsi_now or 0) >= 55 else
                      "bearish zone" if (rsi_now or 0) <= 45 else "neutral"),
        "macd": {"macd": macd_now, "signal": macd_sig, "histogram": macd_hist,
                 "state": ("bullish" if (macd_now or 0) > (macd_sig or 0) else "bearish")
                          + (" + histogram growing" if len(hist_prev) > 2 and
                             abs(hist_prev[-1]) > abs(hist_prev[-2]) and
                             (hist_prev[-1] > 0) == (macd_now or 0) > (macd_sig or 0) else "")},
        "bollinger": {"upper": last(bb["upper"]), "middle": last(bb["middle"]),
                      "lower": last(bb["lower"]), "percent_b": last(bb["percent_b"]),
                      "bandwidth_percent": last(bb["bandwidth_percent"]),
                      "state": ("above upper band" if price > (last(bb["upper"]) or 1e18) else
                                "below lower band" if price < (last(bb["lower"]) or -1e18) else
                                "upper half of band" if price > (last(bb["middle"]) or price) else
                                "lower half of band")},
        "stochastic": {"k": last(stoch["k"]), "d": last(stoch["d"]),
                       "state": ("overbought" if (last(stoch["k"]) or 0) > 80 else
                                 "oversold" if (last(stoch["k"]) or 0) < 20 else "neutral")},
        "atr": a, "adx": {"value": last(adx_data["adx"]), "plus_di": last(adx_data["plus_di"]),
                          "minus_di": last(adx_data["minus_di"]),
                          "strength": trend.get("strength")},
        "williams_r": last(willr), "cci": last(cci_series), "mfi": last(mfi_series),
        "roc12": last(roc(closes, 12)),
        "volatility": hv, "expected_move_1_period":
            expected_move(price, hv.get("annualised_volatility_percent") or 0,
                          1 / 252) if hv.get("ok") else None,
        "vwap": last(vwap(highs, lows, closes, vols)) if any(vols) else None,
        "obv": obv_series[-1] if obv_series else None,
        "obv_trend": ("rising" if len(obv_series) > 5 and obv_series[-1] > obv_series[-5] else
                      "falling" if len(obv_series) > 5 else "flat"),
        "psar": {"value": sar.get("value"), "trend": sar.get("trend"), "flips": sar.get("flips")},
        "squeeze": sq, "divergence": div, "ichimoku": ich,
        "levels": levels, "pivots": pivots, "fibonacci": fibs,
        "round_levels": round_levels(price),
        "candle_patterns": patterns, "chart_patterns": structures,
        "volume": {"last": vols[-1] if vols else None,
                   "average_20": round(sum(vols[-20:]) / min(20, len(vols)), 2) if any(vols) else None,
                   "relative": round(vols[-1] / (sum(vols[-20:]) / min(20, len(vols))), 2)
                   if any(vols) and sum(vols[-20:]) else None},
        "series": {
            "sma20": _r(sma(closes, 20))[-60:], "sma50": _r(sma(closes, 50))[-60:],
            "sma200": _r(sma(closes, 200))[-60:], "ema9": _r(ema(closes, 9))[-60:],
            "ema21": _r(ema(closes, 21))[-60:], "rsi14": _r(rsi_series, 3)[-60:],
            "macd": _r(macd_data["macd"])[-60:], "macd_signal": _r(macd_data["signal"])[-60:],
            "macd_histogram": _r(macd_data["histogram"])[-60:],
            "bb_upper": _r(bb["upper"])[-60:], "bb_lower": _r(bb["lower"])[-60:],
            "atr14": _r(a["series"])[-60:],
        },
    }
    return summary
