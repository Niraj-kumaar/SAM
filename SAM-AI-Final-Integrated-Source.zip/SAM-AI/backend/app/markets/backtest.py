"""
backend.app.markets.backtest
============================

**Strategy backtester — the honest part of the Market Analyzer.**

A signal is an opinion; a backtest is evidence. This module replays historical
candles through a rule, applies commission and slippage, and reports the numbers
that decide whether the rule is worth trading:

    trades · win rate · profit factor · expectancy per trade · average win/loss
    total return · buy-and-hold comparison · max drawdown · Sharpe · Sortino
    longest losing streak · equity curve · every individual trade

Strategies
----------
``ma_cross``            EMA(fast) crossing EMA(slow), trend-following
``rsi_reversion``       buy RSI < oversold, exit RSI > 50 (range markets)
``rsi_trend``           long while RSI > 55 and price > EMA(slow) (trend markets)
``bollinger_breakout``  enter on a close outside the bands (expansion)
``bollinger_fade``      fade a close outside the bands back to the middle
``macd_cross``          MACD line crossing its signal line
``donchian``            N-bar high/low breakout (turtle style)
``psar_flip``           Parabolic SAR trend flips
``atr_trailing``        EMA trend with an ATR chandelier stop
``binary_direction``    for binary options: does the close N bars later finish
                        above/below the entry, filtered by RSI + EMA agreement?

The backtester is deliberately simple and *transparent*: no look-ahead, no
curve-fitting, fixed fractional sizing, and every trade is listed so you can
audit it. It is not a promise about the future.
"""

from __future__ import annotations

import math
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from backend.app.markets import indicators as ind

STRATEGIES = ["ma_cross", "rsi_reversion", "rsi_trend", "bollinger_breakout", "bollinger_fade",
              "macd_cross", "donchian", "psar_flip", "atr_trailing", "binary_direction"]


# ---------------------------------------------------------------------------
# position series per strategy: +1 long, -1 short, 0 flat, aligned to candles
# ---------------------------------------------------------------------------
def _position_series(strategy: str, candles: Sequence[Dict[str, Any]],
                     params: Dict[str, Any]) -> Tuple[List[int], List[str]]:
    closes = [c["close"] for c in candles]
    highs = [c["high"] for c in candles]
    lows = [c["low"] for c in candles]
    vols = [c.get("volume") or 0 for c in candles]
    n = len(closes)
    pos = [0] * n
    notes: List[str] = []

    if strategy == "ma_cross":
        fast, slow = int(params.get("fast", 9)), int(params.get("slow", 21))
        ef, es = ind.ema(closes, fast), ind.ema(closes, slow)
        direction = int(params.get("direction", 0))
        for i in range(n):
            if ef[i] is None or es[i] is None:
                continue
            if direction >= 0 and ef[i] > es[i]:
                pos[i] = 1
            elif direction <= 0 and ef[i] < es[i]:
                pos[i] = -1 if direction < 0 else 0
        notes.append(f"EMA{fast}/EMA{slow} cross, long-only" if direction >= 0
                     else "EMA cross, long and short")

    elif strategy in ("rsi_reversion", "rsi_trend"):
        period = int(params.get("period", 14))
        series = ind.rsi(closes, period)
        if strategy == "rsi_reversion":
            oversold, overbought, exit_level = (float(params.get("oversold", 30)),
                                                float(params.get("overbought", 70)),
                                                float(params.get("exit_level", 50)))
            state = 0
            for i in range(n):
                r = series[i]
                if r is None:
                    continue
                if state == 0 and r < oversold:
                    state = 1
                elif state == 1 and r > exit_level:
                    state = 0
                pos[i] = state
            notes.append(f"long when RSI{period} < {oversold}, exit when RSI > {exit_level}")
        else:
            slow = int(params.get("slow", 50))
            es = ind.ema(closes, slow)
            above = float(params.get("rsi_long", 55))
            below = float(params.get("rsi_short", 45))
            for i in range(n):
                r = series[i]
                if r is None or es[i] is None:
                    continue
                if r > above and closes[i] > es[i]:
                    pos[i] = 1
                elif r < below and closes[i] < es[i]:
                    pos[i] = -1 if params.get("allow_short", True) else 0
            notes.append(f"trend-follow: RSI{period} > {above} above EMA{slow} (long), "
                         f"RSI < {below} below EMA{slow} (short)")

    elif strategy in ("bollinger_breakout", "bollinger_fade"):
        period, mult = int(params.get("period", 20)), float(params.get("std", 2.0))
        bb = ind.bollinger(closes, period, mult)
        for i in range(n):
            u, l, m = bb["upper"][i], bb["lower"][i], bb["middle"][i]
            if u is None:
                continue
            if strategy == "bollinger_breakout":
                pos[i] = 1 if closes[i] > u else -1 if closes[i] < l else pos[i - 1] if i else 0
            else:
                pos[i] = 1 if closes[i] < l else -1 if closes[i] > u else 0
        notes.append(("close outside the bands, ride the expansion"
                      if strategy == "bollinger_breakout" else
                      f"fade closes outside BB({period},{mult}) back toward the mean"))

    elif strategy == "macd_cross":
        fast, slow, sig = (int(params.get("fast", 12)), int(params.get("slow", 26)),
                           int(params.get("signal", 9)))
        m = ind.macd(closes, fast, slow, sig)
        for i in range(n):
            if m["macd"][i] is None or m["signal"][i] is None:
                continue
            pos[i] = 1 if m["macd"][i] > m["signal"][i] else (
                -1 if params.get("allow_short", False) else 0)
        notes.append(f"MACD({fast},{slow},{sig}) above/below its signal line")

    elif strategy == "donchian":
        period = int(params.get("period", 20))
        exit_period = int(params.get("exit_period", max(2, period // 2)))
        state = 0
        for i in range(period, n):
            hh = max(highs[i - period:i])
            ll = min(lows[i - period:i])
            if closes[i] > hh:
                state = 1
            elif closes[i] < ll:
                state = -1 if params.get("allow_short", True) else 0
            elif state:
                eh = max(highs[i - exit_period:i])
                el = min(lows[i - exit_period:i])
                if state == 1 and closes[i] < min(lows[i - exit_period:i]):
                    state = 0
                elif state == -1 and closes[i] > eh:
                    state = 0
            pos[i] = state
        notes.append(f"{period}-bar breakout, {exit_period}-bar exit (turtle style)")

    elif strategy == "psar_flip":
        sar = ind.psar(highs, lows, float(params.get("af_step", 0.02)),
                       float(params.get("af_max", 0.2)))
        series = sar.get("series") or []
        state = 1 if sar.get("trend") == "up" else -1
        for i in range(n):
            if i < len(series) and series[i] is not None:
                state = 1 if closes[i] > series[i] else (-1 if params.get("allow_short", True) else 0)
            pos[i] = state
        notes.append(f"Parabolic SAR flips (stop {sar.get('value')}, {sar.get('flips')} flips in range)")

    elif strategy == "atr_trailing":
        ema_period = int(params.get("ema", 50))
        atr_period = int(params.get("atr_period", 14))
        mult = float(params.get("atr_mult", 3.0))
        e = ind.ema(closes, ema_period)
        a = ind.atr(highs, lows, closes, atr_period)["series"]
        state, trail = 0, None
        for i in range(n):
            if e[i] is None or i >= len(a) or a[i] is None:
                continue
            if state == 0 and closes[i] > e[i]:
                state, trail = 1, closes[i] - mult * a[i]
            elif state == 1:
                trail = max(trail or closes[i], closes[i] - mult * a[i])
                if closes[i] < trail:
                    state, trail = 0, None
            pos[i] = state
        notes.append(f"long above EMA{ema_period}, chandelier exit at {mult}×ATR{atr_period}")

    elif strategy == "binary_direction":
        rsi_period = int(params.get("period", 14))
        ema_period = int(params.get("ema", 21))
        series = ind.rsi(closes, rsi_period)
        e = ind.ema(closes, ema_period)
        side = str(params.get("side", "auto")).lower()
        for i in range(n):
            r = series[i]
            if r is None or e[i] is None:
                continue
            trend_up = closes[i] > e[i]
            if side == "up":
                pos[i] = 1 if (trend_up and r > 50) else 0
            elif side == "down":
                pos[i] = -1 if (not trend_up and r < 50) else 0
            else:
                pos[i] = 1 if (trend_up and r > 50) else -1 if (not trend_up and r < 50) else 0
        notes.append(f"binary filter: price vs EMA{ema_period} + RSI{rsi_period} vs 50")
    else:
        raise ValueError(f"unknown strategy '{strategy}'. Known: {', '.join(STRATEGIES)}")
    return pos, notes


# ---------------------------------------------------------------------------
# the backtester
# ---------------------------------------------------------------------------
def run(candles: Sequence[Dict[str, Any]], strategy: str = "ma_cross",
        *, params: Optional[Dict[str, Any]] = None, capital: float = 10_000.0,
        risk_percent: float = 100.0, commission_percent: float = 0.0,
        slippage_percent: float = 0.02, symbol: str = "", interval: str = "") -> Dict[str, Any]:
    """
    Replay a strategy over candles.

    ``risk_percent`` = share of the account deployed per trade (100 = fully
    invested, i.e. simple return-on-price backtest; 10 = 10% sizing).
    """
    cs = list(candles)
    if len(cs) < 40:
        return {"ok": False, "strategy": strategy, "candles": len(cs),
                "error": f"need at least 40 candles to backtest (got {len(cs)})"}
    params = params or {}
    try:
        pos, notes = _position_series(strategy, cs, params)
    except ValueError as exc:
        return {"ok": False, "strategy": strategy, "error": str(exc)}

    closes = [c["close"] for c in cs]
    trades: List[Dict[str, Any]] = []
    equity = capital
    curve = [capital]
    open_trade: Optional[Dict[str, Any]] = None
    slip = slippage_percent / 100
    comm = commission_percent / 100

    for i in range(len(cs) - 1):
        want = pos[i]
        have = open_trade["direction"] if open_trade else 0
        next_price = closes[i + 1]

        if have and want != have:
            exit_price = next_price * (1 - slip) if have == 1 else next_price * (1 + slip)
            entry = open_trade["entry"]
            units = open_trade["units"]
            gross = (exit_price - entry) * units * have
            cost = (entry * units + exit_price * units) * comm
            pnl = gross - cost
            equity += pnl
            trades.append({**open_trade, "exit_index": i + 1, "exit_ts": cs[i + 1].get("ts"),
                           "exit": round(exit_price, 6), "pnl": round(pnl, 4),
                           "return_percent": round(pnl / (entry * units) * 100, 4)
                           if entry * units else None,
                           "bars_held": i + 1 - open_trade["entry_index"],
                           "equity_after": round(equity, 2)})
            open_trade = None
            have = 0

        if want and not open_trade:
            entry_price = next_price * (1 + slip) if want == 1 else next_price * (1 - slip)
            units = (equity * risk_percent / 100) / entry_price if entry_price else 0
            open_trade = {"direction": want, "entry_index": i + 1, "entry_ts": cs[i + 1].get("ts"),
                          "entry": round(entry_price, 6), "units": round(units, 8),
                          "side": "long" if want == 1 else "short"}
        curve.append(round(equity + (
            ((next_price - open_trade["entry"]) * open_trade["units"] * open_trade["direction"])
            if open_trade else 0), 2))

    # close whatever is still open at the last candle
    if open_trade:
        exit_price = closes[-1] * (1 - slip) if open_trade["direction"] == 1 else closes[-1] * (1 + slip)
        pnl = (exit_price - open_trade["entry"]) * open_trade["units"] * open_trade["direction"]
        equity += pnl
        trades.append({**open_trade, "exit_index": len(cs) - 1, "exit_ts": cs[-1].get("ts"),
                       "exit": round(exit_price, 6), "pnl": round(pnl, 4), "bars_held":
                       len(cs) - 1 - open_trade["entry_index"], "equity_after": round(equity, 2),
                       "note": "still open at the end of data — closed at the last close"})

    return _metrics(trades, curve, capital, equity, closes, strategy, notes, params,
                    symbol, interval, commission_percent, slippage_percent, risk_percent,
                    len(cs))


def _metrics(trades: List[Dict[str, Any]], curve: List[float], capital: float,
             final_equity: float, closes: List[float], strategy: str, notes: List[str],
             params: Dict[str, Any], symbol: str, interval: str, commission: float,
             slippage: float, risk_percent: float, candle_count: int) -> Dict[str, Any]:
    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] <= 0]
    returns = [((curve[i] - curve[i - 1]) / curve[i - 1]) for i in range(1, len(curve))
               if curve[i - 1]]
    peak, max_dd, dd_at = capital, 0.0, 0
    for i, v in enumerate(curve):
        if v > peak:
            peak = v
        dd = (peak - v) / peak * 100 if peak else 0
        if dd > max_dd:
            max_dd, dd_at = dd, i
    mean_r = sum(returns) / len(returns) if returns else 0
    sd = math.sqrt(sum((r - mean_r) ** 2 for r in returns) / (len(returns) - 1)) \
        if len(returns) > 1 else 0
    downside = [r for r in returns if r < 0]
    downside_sd = math.sqrt(sum(r ** 2 for r in downside) / len(downside)) if downside else 0
    buy_hold = (closes[-1] / closes[0] - 1) * 100 if closes and closes[0] else 0
    total_return = (final_equity / capital - 1) * 100 if capital else 0
    streak = _longest_streak(trades)
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0
    avg_loss = sum(t["pnl"] for t in losses) / len(losses) if losses else 0
    gross_profit = sum(t["pnl"] for t in wins)
    gross_loss = abs(sum(t["pnl"] for t in losses))
    pf = gross_profit / gross_loss if gross_loss else (float("inf") if gross_profit else None)
    win_rate = len(wins) / len(trades) * 100 if trades else 0
    expectancy = (win_rate / 100 * avg_win) + ((1 - win_rate / 100) * avg_loss) if trades else 0
    periods_per_year = _annualisation(interval, candle_count)

    result = {
        "ok": True, "strategy": strategy, "params": params, "symbol": symbol,
        "interval": interval, "candles": candle_count, "notes": notes,
        "capital": capital, "final_equity": round(final_equity, 2),
        "net_profit": round(final_equity - capital, 2),
        "total_return_percent": round(total_return, 3),
        "buy_and_hold_percent": round(buy_hold, 3),
        "alpha_vs_buy_hold_percent": round(total_return - buy_hold, 3),
        "trades": len(trades), "wins": len(wins), "losses": len(losses),
        "win_rate_percent": round(win_rate, 2),
        "profit_factor": round(pf, 3) if pf not in (None, float("inf")) else pf,
        "expectancy_per_trade": round(expectancy, 4),
        "average_win": round(avg_win, 4), "average_loss": round(avg_loss, 4),
        "payoff_ratio": round(abs(avg_win / avg_loss), 3) if avg_loss else None,
        "best_trade": round(max((t["pnl"] for t in trades), default=0), 4),
        "worst_trade": round(min((t["pnl"] for t in trades), default=0), 4),
        "average_bars_held": round(sum(t.get("bars_held", 0) for t in trades) / len(trades), 2)
        if trades else 0,
        "longest_win_streak": streak[0], "longest_loss_streak": streak[1],
        "max_drawdown_percent": round(max_dd, 3), "max_drawdown_at_index": dd_at,
        "sharpe": round(mean_r / sd * math.sqrt(periods_per_year), 3) if sd else None,
        "sortino": round(mean_r / downside_sd * math.sqrt(periods_per_year), 3)
        if downside_sd else None,
        "calmar": round(total_return / max_dd, 3) if max_dd else None,
        "costs": {"commission_percent_per_side": commission, "slippage_percent_per_side": slippage,
                  "position_risk_percent": risk_percent},
        "equity_curve": curve[-400:], "trade_log": trades[-60:],
        "verdict": _verdict(win_rate, pf, max_dd, total_return, buy_hold, len(trades)),
        "disclaimer": ("Backtests are historical, use fixed rules, and cannot know future "
                       "spreads, slippage, requotes, gaps or your own behaviour. A good "
                       "backtest is a hypothesis to paper-trade — not a profit forecast."),
    }
    result["answer"] = _answer(result)
    return result


def _annualisation(interval: str, candle_count: int) -> float:
    minutes = {"1m": 1, "2m": 2, "5m": 5, "15m": 15, "30m": 30, "60m": 60, "1h": 60,
               "4h": 240, "1d": 1440, "1wk": 10080, "1mo": 43200}.get(interval.lower(), 60)
    bars_per_year = (365 * 24 * 60) / minutes if minutes < 1440 else 252
    return max(bars_per_year, 1)


def _longest_streak(trades: List[Dict[str, Any]]) -> Tuple[int, int]:
    win = loss = best_win = best_loss = 0
    for t in trades:
        if t["pnl"] > 0:
            win += 1
            loss = 0
            best_win = max(best_win, win)
        else:
            loss += 1
            win = 0
            best_loss = max(best_loss, loss)
    return best_win, best_loss


def _verdict(win_rate: float, pf: Optional[float], dd: float, ret: float,
             buy_hold: float, trades: int) -> str:
    if trades < 10:
        return f"only {trades} trades — far too few to conclude anything"
    if pf is None:
        return "no losing trades at all — suspicious, check the data and the rules"
    if pf >= 1.5 and dd < 20 and ret > buy_hold:
        return (f"promising: profit factor {pf}, {win_rate:.0f}% wins, drawdown {dd:.1f}%, "
                f"beats buy-and-hold by {ret - buy_hold:+.1f} points — worth paper trading")
    if pf >= 1.0:
        return (f"marginally positive (PF {pf}) — after real spreads and slippage this is "
                f"likely break-even or worse")
    return (f"losing system: profit factor {pf}, {win_rate:.0f}% win rate, "
            f"{dd:.1f}% max drawdown — do not trade this with money")


def _answer(r: Dict[str, Any]) -> str:
    return (f"{r['strategy']} on {r['symbol'] or 'the data'} ({r['interval']}, {r['candles']} bars): "
            f"{r['trades']} trades, {r['win_rate_percent']}% wins, PF {r['profit_factor']}, "
            f"return {r['total_return_percent']:+.2f}% vs buy-and-hold "
            f"{r['buy_and_hold_percent']:+.2f}%, max drawdown {r['max_drawdown_percent']:.2f}%, "
            f"Sharpe {r['sharpe']}. {r['verdict']}")


# ---------------------------------------------------------------------------
# binary-options specific backtest
# ---------------------------------------------------------------------------
def binary_backtest(candles: Sequence[Dict[str, Any]], *, expiry_candles: int = 5,
                    strategy: str = "binary_direction", params: Optional[Dict[str, Any]] = None,
                    payout_percent: float = 80.0, stake: float = 100.0,
                    symbol: str = "", interval: str = "") -> Dict[str, Any]:
    """
    Replays the binary question: *after this candle, is the close N bars later
    higher (UP) or lower (DOWN)?*

    Reports the win rate the rule actually achieves and, crucially, compares it
    to the break-even win rate implied by the payout.
    """
    cs = list(candles)
    params = dict(params or {})
    params.setdefault("expiry", expiry_candles)
    if len(cs) < expiry_candles + 40:
        return {"ok": False, "error": f"need at least {expiry_candles + 40} candles for a "
                                      f"{expiry_candles}-bar expiry test"}
    pos, notes = _position_series(strategy, cs, params)
    closes = [c["close"] for c in cs]

    results: List[Dict[str, Any]] = []
    for i in range(len(cs) - expiry_candles):
        side = pos[i]
        if not side:
            continue
        entry, exit_price = closes[i], closes[i + expiry_candles]
        won = (exit_price > entry) if side == 1 else (exit_price < entry)
        tie = exit_price == entry
        results.append({"index": i, "ts": cs[i].get("ts"), "side": "UP" if side == 1 else "DOWN",
                        "entry": round(entry, 6), "expiry_price": round(exit_price, 6),
                        "move_percent": round((exit_price - entry) / entry * 100, 5) if entry else None,
                        "result": "tie" if tie else "win" if won else "loss",
                        "pnl": round(stake * payout_percent / 100 if won else -stake, 2)})
    if not results:
        return {"ok": False, "strategy": strategy, "expiry_candles": expiry_candles,
                "error": "the rule never produced a signal on this data"}
    wins = [r for r in results if r["result"] == "win"]
    losses = [r for r in results if r["result"] == "loss"]
    ties = [r for r in results if r["result"] == "tie"]
    win_rate = len(wins) / (len(wins) + len(losses)) * 100 if (wins or losses) else 0
    # at an 80% payout you must win 100/1.8 = 55.56% just to break even
    breakeven = 10000.0 / (100.0 + max(payout_percent, 0.0))
    net = sum(r["pnl"] for r in results)
    equity, peak, max_dd, curve = 0.0, 0.0, 0.0, []
    for r in results:
        equity += r["pnl"]
        curve.append(round(equity, 2))
        peak = max(peak, equity)
        max_dd = max(max_dd, peak - equity)
    ups = [r for r in results if r["side"] == "UP"]
    downs = [r for r in results if r["side"] == "DOWN"]
    streak = _longest_streak([{"pnl": r["pnl"]} for r in results])
    return {
        "ok": True, "product": "binary option", "symbol": symbol, "interval": interval,
        "strategy": strategy, "notes": notes, "expiry_candles": expiry_candles,
        "payout_percent": payout_percent, "stake_per_trade": stake,
        "signals": len(results), "wins": len(wins), "losses": len(losses), "ties": len(ties),
        "win_rate_percent": round(win_rate, 2),
        "break_even_win_rate_percent": round(breakeven, 2),
        "edge_percent_points": round(win_rate - breakeven, 2),
        "up_trades": {"count": len(ups),
                      "win_rate_percent": round(sum(1 for r in ups if r["result"] == "win") /
                                                len(ups) * 100, 2) if ups else None},
        "down_trades": {"count": len(downs),
                        "win_rate_percent": round(sum(1 for r in downs if r["result"] == "win") /
                                                  len(downs) * 100, 2) if downs else None},
        "net_profit": round(net, 2), "return_on_staked_percent":
            round(net / (stake * len(results)) * 100, 2) if results else None,
        "max_drawdown_stake_units": round(max_dd, 2),
        "longest_win_streak": streak[0], "longest_loss_streak": streak[1],
        "average_move_percent": round(sum(abs(r["move_percent"] or 0) for r in results) /
                                      len(results), 5),
        "equity_curve": curve[-300:], "recent_trades": results[-40:],
        "verdict": (f"win rate {win_rate:.1f}% vs break-even {breakeven:.1f}% ⇒ "
                    + (f"positive edge of {win_rate - breakeven:+.1f} points — but verify on more "
                       f"data and with real spreads before believing it"
                       if win_rate > breakeven else
                       "NEGATIVE edge — this rule loses money at this payout")),
        "warning": ("Binary win rates are extremely sensitive to spread, payout and the exact "
                    "entry timestamp. Re-run with your broker's real payout, and treat any edge "
                    "smaller than 3 points as noise."),
    }


def walk_forward(candles: Sequence[Dict[str, Any]], strategy: str, *, folds: int = 4,
                 params: Optional[Dict[str, Any]] = None, capital: float = 10_000.0,
                 symbol: str = "", interval: str = "") -> Dict[str, Any]:
    """
    Split the data into N sequential folds and backtest each separately.

    A rule that only works in one fold is curve-fitted, not robust.
    """
    cs = list(candles)
    if len(cs) < folds * 60:
        return {"ok": False, "error": f"need at least {folds * 60} candles for {folds} folds"}
    size = len(cs) // folds
    rows = []
    for f in range(folds):
        chunk = cs[f * size: (f + 1) * size] if f < folds - 1 else cs[f * size:]
        res = run(chunk, strategy, params=params, capital=capital, symbol=symbol, interval=interval)
        rows.append({"fold": f + 1, "candles": len(chunk),
                     "from": chunk[0].get("ts"), "to": chunk[-1].get("ts"),
                     "trades": res.get("trades"), "win_rate_percent": res.get("win_rate_percent"),
                     "return_percent": res.get("total_return_percent"),
                     "profit_factor": res.get("profit_factor"),
                     "max_drawdown_percent": res.get("max_drawdown_percent"),
                     "ok": res.get("ok", False)})
    profitable = [r for r in rows if (r.get("return_percent") or 0) > 0]
    returns = [r.get("return_percent") or 0 for r in rows]
    return {"ok": True, "strategy": strategy, "folds": rows, "fold_count": folds,
            "profitable_folds": len(profitable),
            "consistency_percent": round(len(profitable) / len(rows) * 100, 1) if rows else 0,
            "average_return_percent": round(sum(returns) / len(returns), 3) if returns else None,
            "worst_fold_percent": round(min(returns), 3) if returns else None,
            "best_fold_percent": round(max(returns), 3) if returns else None,
            "verdict": (f"profitable in {len(profitable)}/{len(rows)} periods — "
                        + ("reasonably robust" if len(profitable) / len(rows) >= 0.75 else
                           "inconsistent: this rule depends on the period, which is the "
                           "signature of curve-fitting"))}
