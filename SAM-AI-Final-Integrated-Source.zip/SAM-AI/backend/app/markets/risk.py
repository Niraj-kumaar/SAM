"""
backend.app.markets.risk
========================

**The risk desk. This is the part of trading that is actually maths.**

Every function here is deterministic and depends only on the numbers you give
it — no model, no opinion:

``pip_value``        value of one pip for a lot size, per pair type
``position_size``    units/lots so that *stop distance* = *risk amount*
``risk_reward``      R multiple of a proposed trade
``kelly``            Kelly fraction with fractional-Kelly caps
``risk_of_ruin``     probability of blowing the account at a given win rate
``drawdown_math``    what a drawdown requires to recover
``margin_required``  leverage/margin and free-margin check
``portfolio_risk``   total open risk, correlation-adjusted exposure
``expectancy``       per-trade expectancy from a win rate + payoff
``stake_plan``       a session stake plan with a daily stop-loss
``martingale_check`` shows why martingale/doubling destroys accounts

SAM will always compute the *maximum* loss first and the position second.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Sequence

# standard lot sizes
LOT_UNITS = {"forex": 100_000, "mini": 10_000, "micro": 1_000}

# approximate quote-currency value of 1 pip per 1 standard lot (100k units)
PIP_TABLE = {
    "USD": 10.0, "EUR": 10.0, "GBP": 10.0, "CHF": 10.0, "CAD": 10.0,
    "AUD": 10.0, "NZD": 10.0, "JPY": 1000.0, "INR": 1000.0, "SGD": 10.0,
    "HKD": 10.0, "SEK": 100.0, "NOK": 100.0, "ZAR": 100.0, "MXN": 100.0,
    "TRY": 100.0, "PLN": 100.0, "CNY": 100.0,
}


def pip_size(pair: str) -> float:
    """JPY-quoted pairs move in 0.01 steps, everything else in 0.0001."""
    quote = (pair or "").replace("/", "")[-3:].upper()
    return 0.01 if quote == "JPY" else 0.0001


def pip_value(pair: str, lots: float = 1.0, quote_to_account: float = 1.0,
              units_per_lot: int = 100_000) -> Dict[str, Any]:
    """
    Value of one pip in the account currency.

    ``quote_to_account`` is how many units of the account currency one unit of
    the quote currency is worth (1.0 for a USD account trading EURUSD).
    """
    ps = pip_size(pair)
    value = ps * units_per_lot * lots * quote_to_account
    quote = (pair or "").replace("/", "")[-3:].upper()
    return {"pair": pair, "pip_size": ps, "lots": lots, "quote_currency": quote,
            "pip_value_quote_ccy": round(ps * units_per_lot * lots, 6),
            "pip_value_account_ccy": round(value, 6),
            "per_10_pips_account_ccy": round(value * 10, 4),
            "units_per_lot": units_per_lot}


def position_size(*, balance: float, risk_percent: float, entry: float, stop: float,
                  account_currency: str = "USD", pair_quote: str = "USD",
                  pair_type: str = "forex", quote_to_account: float = 1.0,
                  contract_size: float = 1.0, max_leverage: float = 0.0) -> Dict[str, Any]:
    """
    Size a position so that hitting the stop loses exactly ``risk_percent``.

    Works for forex (pip-based), CFDs/stocks/indices (contract-based) and crypto
    (fractional units).
    """
    risk_amount = balance * risk_percent / 100
    distance = abs(entry - stop)
    if distance <= 0:
        return {"ok": False, "error": "entry and stop are the same price — distance must be > 0"}
    if risk_amount <= 0:
        return {"ok": False, "error": "risk amount is zero — check balance and risk_percent"}

    if pair_type == "forex":
        ps = 0.01 if pair_quote.upper() == "JPY" else 0.0001
        pips = distance / ps
        value_per_unit = ps * quote_to_account
        units = risk_amount / (distance * quote_to_account)
        lots = units / LOT_UNITS["forex"]
        notional = units * entry
        out = {"ok": True, "risk_amount": round(risk_amount, 2), "stop_pips": round(pips, 1),
               "pip_size": ps, "units": round(units, 2), "lots": round(lots, 4),
               "micro_lots": round(units / LOT_UNITS["micro"], 2),
               "notional_account_ccy": round(notional * quote_to_account, 2),
               "pip_value_account_ccy": round(value_per_unit * units, 4),
               "loss_at_stop_account_ccy": round(risk_amount, 2),
               "risk_percent": risk_percent}
    else:
        units = risk_amount / distance
        lots = units * contract_size
        notional = units * entry
        out = {"ok": True, "risk_amount": round(risk_amount, 2), "stop_distance": round(distance, 6),
               "stop_distance_percent": round(distance / entry * 100, 4) if entry else None,
               "units": round(units, 6), "contracts": round(units / contract_size, 4),
               "lots": round(units / contract_size, 4),
               "notional_account_ccy": round(notional, 2),
               "loss_at_stop_account_ccy": round(risk_amount, 2),
               "risk_percent": risk_percent}

    if max_leverage:
        required_margin = out["notional_account_ccy"] / max_leverage
        out["max_leverage"] = max_leverage
        out["required_margin"] = round(required_margin, 2)
        out["margin_ok"] = required_margin <= balance
        if not out["margin_ok"]:
            out["warning"] = (f"needs {required_margin:,.2f} margin at {max_leverage}:1 but the "
                              f"account only has {balance:,.2f} — reduce size or risk")
    out["sanity"] = _sanity(balance, risk_percent, out["notional_account_ccy"], max_leverage)
    return out


def _sanity(balance: float, risk_percent: float, notional: float,
            max_leverage: float) -> List[str]:
    notes: List[str] = []
    if risk_percent > 2:
        notes.append(f"risking {risk_percent}% per trade is aggressive — 2% is the usual ceiling")
    if risk_percent > 5:
        notes.append("above 5% risk, a short losing streak mathematically ends the account")
    if max_leverage and notional / max_leverage > balance * 0.9:
        notes.append("this position uses almost all available margin — no room for a second trade")
    if notional > balance * 30:
        notes.append(f"notional {notional:,.0f} is {notional / balance:.0f}× the account — "
                     f"leverage that high makes the stop the only thing protecting you")
    return notes


def risk_reward(entry: float, stop: float, targets: Sequence[float]) -> Dict[str, Any]:
    distance = abs(entry - stop)
    if distance == 0:
        return {"ok": False, "error": "stop distance is zero"}
    direction = "long" if stop < entry else "short"
    rows = []
    for i, t in enumerate(targets, 1):
        reward = abs(t - entry)
        rows.append({"target_index": i, "price": round(float(t), 6),
                     "reward": round(reward, 6), "r_multiple": round(reward / distance, 2),
                     "break_even_win_rate_percent": round(100 / (1 + reward / distance), 2)})
    return {"ok": True, "direction": direction, "entry": entry, "stop": stop,
            "stop_distance": round(distance, 6), "targets": rows,
            "best_r": max((r["r_multiple"] for r in rows), default=None),
            "verdict": _rr_verdict(max((r["r_multiple"] for r in rows), default=0))}


def _rr_verdict(r: float) -> str:
    if r >= 3:
        return f"{r}:1 reward-to-risk — profitable even at a ~35% win rate"
    if r >= 2:
        return f"{r}:1 — needs roughly {round(100 / (1 + r))}% wins to break even"
    if r >= 1:
        return f"{r}:1 — thin; you need >{round(100 / (1 + r))}% wins, which is hard"
    return f"{r}:1 is negative expectancy territory — the stop is further than the target"


def kelly(win_rate: float, payoff: float, fraction: float = 0.25) -> Dict[str, Any]:
    """
    Kelly criterion with a fractional cap.

    ``payoff`` = average win ÷ average loss (b in the classic formula).
    """
    p = win_rate / 100 if win_rate > 1 else win_rate
    q = 1 - p
    if payoff <= 0:
        return {"ok": False, "error": "payoff (avg win / avg loss) must be > 0"}
    k = p - q / payoff
    capped = max(0.0, k * fraction)
    return {"ok": True, "win_rate_percent": round(p * 100, 2), "payoff": round(payoff, 3),
            "full_kelly_percent": round(k * 100, 3),
            "recommended_percent": round(capped * 100, 3),
            "fraction_used": fraction, "edge": round(k, 4),
            "interpretation": ("negative edge — bet nothing, no sizing fixes a losing system"
                               if k <= 0 else
                               f"quarter-Kelly {capped * 100:.2f}% of the account per trade "
                               f"(full Kelly {k * 100:.2f}% is too volatile to use in practice)")}


def risk_of_ruin(win_rate: float, risk_per_trade_percent: float, payoff: float = 1.0,
                 ruin_threshold_percent: float = 50.0) -> Dict[str, Any]:
    """
    Monte-Carlo-free closed-form approximation of ruin probability plus a
    simulation cross-check for small risk sizes.
    """
    p = win_rate / 100 if win_rate > 1 else win_rate
    q = 1 - p
    risk_fraction = risk_per_trade_percent / 100
    if p <= 0 or risk_fraction <= 0:
        return {"ok": False, "error": "need win_rate > 0 and risk_per_trade_percent > 0"}
    edge = p * payoff - q
    if edge <= 0:
        return {"ok": True, "win_rate_percent": round(p * 100, 2),
                "risk_per_trade_percent": risk_per_trade_percent, "payoff": payoff,
                "edge_per_trade_percent": round(edge * 100, 3),
                "risk_of_ruin_percent": 100.0,
                "verdict": "the system has no edge — ruin is certain given enough trades"}
    # classic approximation for symmetric bets
    try:
        ror = ((1 - edge) / (1 + edge)) ** (ruin_threshold_percent / risk_per_trade_percent)
    except OverflowError:
        ror = 1.0
    ror = min(1.0, max(0.0, ror))
    # how many consecutive losses to reach the threshold
    n_loss = math.log(1 - ruin_threshold_percent / 100) / math.log(1 - risk_fraction) \
        if risk_fraction < 1 else 1
    p_streak = (q ** n_loss) * 100
    return {"ok": True, "win_rate_percent": round(p * 100, 2), "payoff": payoff,
            "risk_per_trade_percent": risk_per_trade_percent,
            "edge_per_trade_percent": round(edge * 100, 3),
            "risk_of_ruin_percent": round(ror * 100, 4),
            "consecutive_losses_to_threshold": int(math.ceil(n_loss)),
            "probability_of_that_streak_percent": round(p_streak, 4),
            "verdict": ("ruin is likely" if ror > 0.5 else
                        "ruin is possible in a bad run" if ror > 0.1 else
                        "ruin is unlikely at this risk size" if ror > 0.01 else
                        "ruin is very unlikely — but the edge must be real")}


def drawdown_math(drawdown_percent: float) -> Dict[str, Any]:
    d = abs(drawdown_percent) / 100
    if d >= 1:
        return {"ok": False, "error": "a 100% drawdown is unrecoverable"}
    recovery = (1 / (1 - d) - 1) * 100
    return {"ok": True, "drawdown_percent": round(d * 100, 2),
            "required_gain_percent": round(recovery, 2),
            "equity_multiplier": round(1 / (1 - d), 4),
            "at_risk_1_percent": f"{math.ceil(recovery / 1)} trades at +1R",
            "at_risk_2_percent": f"{math.ceil(recovery / 2)} trades at +2R",
            "verdict": (f"losing {round(d * 100)}% requires +{recovery:.1f}% to get back to even — "
                        + ("this is why protecting capital beats chasing returns"
                           if recovery > d * 100 * 1.2 else "still recoverable"))}


def margin_required(notional: float, leverage: float) -> Dict[str, Any]:
    if leverage <= 0:
        return {"ok": False, "error": "leverage must be > 0"}
    margin = notional / leverage
    return {"ok": True, "notional": round(notional, 2), "leverage": leverage,
            "required_margin": round(margin, 2),
            "margin_percent": round(100 / leverage, 4),
            "max_notional_per_1000_equity": round(1000 * leverage, 2),
            "note": (f"at {leverage}:1, every 1% adverse move costs "
                     f"{leverage}% of the margin posted")}


def portfolio_risk(positions: Sequence[Dict[str, Any]], balance: float,
                   correlations: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
    """
    Total open risk, per-symbol concentration and correlation-adjusted exposure.

    Each position: ``{"symbol","direction","units","entry","stop"}``.
    """
    rows: List[Dict[str, Any]] = []
    total = 0.0
    for p in positions:
        try:
            units = float(p.get("units") or 0)
            entry = float(p.get("entry") or 0)
            stop = float(p.get("stop") or 0)
            distance = abs(entry - stop)
            risk = units * distance
            total += risk
            rows.append({"symbol": p.get("symbol"), "direction": p.get("direction", "long"),
                         "units": units, "entry": entry, "stop": stop,
                         "risk": round(risk, 2),
                         "risk_percent_of_balance": round(risk / balance * 100, 3) if balance else None,
                         "r_multiple_at_stop": -1.0})
        except (TypeError, ValueError):
            rows.append({"symbol": p.get("symbol"), "error": "could not parse units/entry/stop"})
    longs = sum(r["risk"] for r in rows if r.get("direction") == "long")
    shorts = sum(r["risk"] for r in rows if r.get("direction") == "short")
    net = longs - shorts
    corr_note = ""
    if correlations:
        pairs = [k for k, v in correlations.items() if v >= 0.8]
        if pairs:
            corr_note = (f"highly correlated exposure (ρ ≥ 0.8) on {', '.join(pairs)} — these "
                         f"positions are effectively one bigger trade")
    total_pct = total / balance * 100 if balance else 0
    return {"ok": True, "balance": balance, "positions": rows, "count": len(rows),
            "total_risk": round(total, 2), "total_risk_percent": round(total_pct, 3),
            "long_risk": round(longs, 2), "short_risk": round(shorts, 2),
            "net_exposure": round(net, 2),
            "largest_position": max(rows, key=lambda r: r.get("risk", 0))["symbol"] if rows else None,
            "concentration_percent": round(max((r.get("risk", 0) for r in rows), default=0) /
                                           total * 100, 1) if total else None,
            "correlation_note": corr_note,
            "verdict": ("total risk is above the 6% portfolio ceiling — reduce positions"
                        if total_pct > 6 else
                        "total risk above 3% is aggressive for one session" if total_pct > 3 else
                        "total open risk is within a conservative envelope" if rows else
                        "no open positions")}


def expectancy(win_rate_percent: float, average_win: float, average_loss: float,
               trades: int = 100) -> Dict[str, Any]:
    p = win_rate_percent / 100
    q = 1 - p
    exp = p * average_win - q * abs(average_loss)
    payoff = average_win / abs(average_loss) if average_loss else None
    return {"ok": True, "win_rate_percent": round(p * 100, 2), "payoff_ratio": round(payoff, 3)
            if payoff else None, "expectancy_per_trade": round(exp, 2),
            "expectancy_over_n_trades": round(exp * trades, 2), "trades": trades,
            "profit_factor": round((p * average_win) / (q * abs(average_loss)), 3)
            if q and average_loss else None,
            "break_even_win_rate_percent": round(100 / (1 + payoff), 2) if payoff else None,
            "verdict": ("positive expectancy — the system is worth trading at small size"
                        if exp > 0 else "negative expectancy — do not trade this with real money")}


def stake_plan(balance: float, risk_percent: float = 1.0, daily_loss_limit_percent: float = 3.0,
               max_trades: int = 5, payout_percent: float = 80.0) -> Dict[str, Any]:
    """A concrete session plan with hard stop rules."""
    stake = balance * risk_percent / 100
    daily_limit = balance * daily_loss_limit_percent / 100
    return {"ok": True, "balance": round(balance, 2), "risk_percent": risk_percent,
            "stake_per_trade": round(stake, 2), "max_trades": max_trades,
            "daily_loss_limit": round(daily_limit, 2),
            "consecutive_losses_to_daily_limit": max(1, int(daily_limit // stake)) if stake else None,
            "weekly_loss_limit": round(daily_limit * 5, 2),
            "binary_payout_percent": payout_percent,
            "binary_win_to_recover_one_loss": round(stake / (payout_percent / 100), 2)
            if payout_percent else None,
            "rules": [
                f"stake {round(stake, 2)} per trade ({risk_percent}% of {round(balance, 2)})",
                f"stop trading for the day after losing {round(daily_limit, 2)} "
                f"({daily_loss_limit_percent}%)",
                f"maximum {max_trades} trades per session — overtrading is a cost, not a strategy",
                "no revenge trades: a loss is data, not an insult",
                "review the journal at the end of every session",
            ]}


def martingale_check(balance: float, base_stake: float, payout_percent: float = 80.0,
                     steps: int = 8) -> Dict[str, Any]:
    """Show exactly how a doubling strategy ends — with real numbers."""
    rows, stake, total = [], base_stake, 0.0
    for i in range(1, max(1, steps) + 1):
        total += stake
        win = stake * payout_percent / 100
        rows.append({"step": i, "stake": round(stake, 2), "cumulative_risk": round(total, 2),
                     "profit_if_this_wins": round(win - (total - stake), 2),
                     "percent_of_balance": round(total / balance * 100, 2) if balance else None,
                     "busts_account": total > balance})
        stake *= 2
    bust_at = next((r["step"] for r in rows if r["busts_account"]), None)
    p_lose_n = (0.5 ** steps) * 100
    return {"ok": True, "base_stake": base_stake, "payout_percent": payout_percent,
            "balance": balance, "steps": rows,
            "total_risk_if_all_lose": round(total, 2),
            "account_busts_at_step": bust_at,
            "probability_of_that_many_losses_percent": round(p_lose_n, 4),
            "verdict": (f"martingale risks {round(total, 2)} ({round(total / balance * 100, 1)}% of "
                        f"the account) to win {base_stake * payout_percent / 100:.2f}. "
                        f"It converts many small wins into one certain ruin — "
                        f"and a {p_lose_n:.3f}% event happens regularly over thousands of trades."
                        if balance else "provide a balance to compute this")}
