"""
backend.app.markets.alerts
==========================

The background watcher for price / indicator alerts.

Started from ``main.py``'s lifespan when ``MARKET_ALERTS_ENABLED=true``. Every
``MARKET_ALERT_POLL_SECONDS`` it:

1. loads the enabled alerts,
2. groups them by symbol so each symbol is fetched **once**,
3. evaluates every condition with :func:`backend.app.markets.journal.evaluate_alert`,
4. on a hit: emits ``Topics.NOTIFICATION`` (desktop toast / phone / voice),
   writes an audit row, optionally disables a one-shot alert, and — if the user
   asked for it — creates a calendar/reminder entry.

It never trades. It only watches and tells you.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.markets import data_feed
from backend.app.markets import indicators as ind
from backend.app.markets.journal import alerts, evaluate_alert

log = get_logger("markets.alerts")


class AlertPoller:
    def __init__(self) -> None:
        self._task: Optional[asyncio.Task] = None
        self._stop = asyncio.Event()
        self.last_run: Optional[str] = None
        self.last_hits: List[Dict[str, Any]] = []
        self.runs = 0
        self.hits = 0
        self.errors = 0

    # ------------------------------------------------------------------ life
    def start(self) -> bool:
        if self._task and not self._task.done():
            return False
        if not getattr(settings, "market_enabled", True):
            log.info("market alerts disabled (MARKET_ENABLED=false)")
            return False
        if not getattr(settings, "market_alerts_enabled", True):
            log.info("market alerts disabled (MARKET_ALERTS_ENABLED=false)")
            return False
        self._stop.clear()
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:  # pragma: no cover
            return False
        self._task = loop.create_task(self._loop(), name="sam-market-alerts")
        log.info("market alert poller started (every %ss)", settings.market_alert_poll_seconds)
        return True

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        self._task = None

    # ------------------------------------------------------------------ loop
    async def _loop(self) -> None:
        interval = max(20, int(getattr(settings, "market_alert_poll_seconds", 120)))
        while not self._stop.is_set():
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=interval)
                break
            except asyncio.TimeoutError:
                pass
            try:
                await self.check_once()
            except Exception as exc:
                self.errors += 1
                log.warning("alert poll failed: %s", exc)

    # ------------------------------------------------------------------ check
    async def check_once(self) -> Dict[str, Any]:
        enabled = await alerts.list(enabled_only=True)
        self.runs += 1
        self.last_run = datetime.now(timezone.utc).isoformat(timespec="seconds")
        if not enabled:
            self.last_hits = []
            return {"ok": True, "alerts": 0, "hits": 0, "note": "no enabled alerts"}

        by_symbol: Dict[str, List[Dict[str, Any]]] = {}
        for a in enabled:
            cooldown = int(a.get("cooldown_minutes") or 0)
            if a.get("triggered_at") and cooldown:
                try:
                    last = datetime.fromisoformat(a["triggered_at"])
                    if last.tzinfo is None:
                        last = last.replace(tzinfo=timezone.utc)
                    if datetime.now(timezone.utc) - last < timedelta(minutes=cooldown):
                        continue
                except ValueError:
                    pass
            by_symbol.setdefault(a["symbol"], []).append(a)

        hits: List[Dict[str, Any]] = []
        for symbol, group in by_symbol.items():
            try:
                payload = await self._snapshot_for(symbol, group)
            except Exception as exc:
                self.errors += 1
                log.debug("alert snapshot failed for %s: %s", symbol, exc)
                continue
            price = payload.get("price")
            if price is None:
                continue
            for a in group:
                fired = evaluate_alert(a, price, **payload.get("context", {}))
                await alerts.mark(int(a["id"]), float(price), fired)
                if fired:
                    hit = {"alert_id": a["id"], "symbol": symbol, "price": price,
                           "condition": a["condition"], "threshold": a["threshold"],
                           "message": a.get("message") or f"{symbol} {a['condition']} {a['threshold']}",
                           "channel": a.get("channel", "desktop"),
                           "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
                    hits.append(hit)
                    self.hits += 1
                    emit(Topics.NOTIFICATION, kind="market_alert", **hit)
                    emit(Topics.AUDIT, action="market.alert.triggered", target=symbol,
                         detail={"condition": a["condition"], "threshold": a["threshold"],
                                 "price": price})
                    log.info("MARKET ALERT %s: %s @ %s", symbol, a["condition"], price)
        self.last_hits = hits
        return {"ok": True, "alerts": len(enabled), "symbols": len(by_symbol),
                "hits": len(hits), "triggered": hits, "checked_at": self.last_run}

    async def _snapshot_for(self, symbol: str, group: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Fetch just enough data for the conditions this symbol needs."""
        needs_indicator = any(a["condition"] in ("rsi_above", "rsi_below", "atr_spike",
                                                 "signal_flip", "percent_change", "cross_up",
                                                 "cross_down", "target_hit", "stop_hit")
                              for a in group)
        timeframe = max((a.get("timeframe") or "1h" for a in group),
                        key=lambda t: {"1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60,
                                       "4h": 240, "1d": 1440}.get(t, 60))
        q = await data_feed.quote(data_feed.resolve_symbol(symbol))
        price = q.get("price")
        context: Dict[str, Any] = {"change_percent": q.get("change_percent")}
        if needs_indicator and price:
            data = await data_feed.candles(symbol, timeframe, 120)
            candles = data.get("candles") or []
            if len(candles) >= 30:
                snap = ind.full_snapshot(candles, symbol=symbol, interval=timeframe)
                closes = [c["close"] for c in candles]
                context.update({
                    "prev_price": closes[-2] if len(closes) > 1 else price,
                    "rsi": snap.get("rsi14"),
                    "atr_percent": (snap.get("atr") or {}).get("percent"),
                    "signal_score": (snap.get("trend") or {}).get("slope_20_percent"),
                })
                levels = snap.get("levels") or {}
                ns, nr = levels.get("nearest_support"), levels.get("nearest_resistance")
                context["stop"] = ns.get("price") if ns else None
                context["target"] = nr.get("price") if nr else None
        return {"price": price, "context": context, "quote": q}

    # ---------------------------------------------------------------- status
    def status(self) -> Dict[str, Any]:
        return {"ok": True, "running": bool(self._task and not self._task.done()),
                "enabled": bool(getattr(settings, "market_alerts_enabled", True)),
                "poll_seconds": getattr(settings, "market_alert_poll_seconds", 120),
                "runs": self.runs, "hits": self.hits, "errors": self.errors,
                "last_run": self.last_run, "last_hits": self.last_hits}


alert_poller = AlertPoller()
