"""
backend.app.main
================

SAM's backend entry point.

Run it with::

    cd SAM-AI
    python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000

Startup order matters, so it is explicit in :func:`lifespan`:

1. logging + directories
2. database schema
3. tools (242 of them register themselves on import)
4. model router bootstrap (probe providers, list local models)
5. permission engine (seed defaults, load user overrides)
6. agents, memory, search indexes, orchestrator wiring
7. task store reload, scheduler start + job restore
8. device registry, phone bridge, sync engine
9. voice engine, wake word, proactive loop
10. market alert poller (only when MARKET_ENABLED and MARKET_ALERTS_ENABLED)
11. FastAPI routes + the built desktop UI

Shutdown is the mirror image and always reports what it stopped.
"""

from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from backend.app.config import PROJECT_ROOT, settings
from backend.app.core.database import close_db, init_db
from backend.app.core.event_bus import Topics, bus, emit
from backend.app.core.logging_config import get_logger, setup_logging
from backend.app.tools.registry import registry

log = get_logger("main")

DESKTOP_DIST = PROJECT_ROOT / "desktop" / "dist"
STARTED_AT = time.time()
STARTUP: Dict[str, Any] = {"steps": [], "ok": True, "errors": []}


def _step(name: str, detail: Any = None, ms: int = 0) -> None:
    STARTUP["steps"].append({"step": name, "detail": detail, "ms": ms,
                             "at": time.strftime("%H:%M:%S")})
    log.info("startup: %s (%s)", name, detail if detail is not None else f"{ms} ms")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    setup_logging(settings.sam_log_level)
    t_all = time.perf_counter()
    log.info("=" * 74)
    log.info("SAM — Fully Advanced AI Voice Assistant  ·  starting")
    log.info("mode=%s  port=%s  data=%s", settings.sam_mode, settings.sam_port,
             settings.sam_data_dir)
    log.info("=" * 74)

    settings.ensure_dirs()
    loop = asyncio.get_running_loop()
    bus.attach_loop(loop)
    _step("event bus attached", {"loop": True})

    # ---- 1. database ----------------------------------------------------
    t0 = time.perf_counter()
    await init_db()
    _step("database ready", settings.effective_database_url.split("///")[-1],
          int((time.perf_counter() - t0) * 1000))

    # ---- 2. tools -------------------------------------------------------
    t0 = time.perf_counter()
    from backend.app.agents.base import agents, load_tools

    tool_count = load_tools()
    _step("tools registered", tool_count, int((time.perf_counter() - t0) * 1000))
    if tool_count == 0:
        STARTUP["ok"] = False
        STARTUP["errors"].append("no tools registered — SAM cannot act")

    # ---- 3. model router ------------------------------------------------
    t0 = time.perf_counter()
    from backend.app.models.router import router as model_router

    await model_router.bootstrap()
    providers = [name for name, p in model_router.providers.items() if p.available()]
    _step("model router", {"providers": providers, "pins": model_router.pins()},
          int((time.perf_counter() - t0) * 1000))

    # ---- 4. permissions -------------------------------------------------
    t0 = time.perf_counter()
    from backend.app.security.permissions import permission_engine

    await permission_engine.load()
    granted = sum(1 for c in permission_engine.state() if c["granted"])
    _step("permissions loaded", f"{granted} granted", int((time.perf_counter() - t0) * 1000))

    # ---- 5. memory + indexes -------------------------------------------
    t0 = time.perf_counter()
    from backend.app.files.search_index import searcher
    from backend.app.files.semantic_index import semantic_index
    from backend.app.memory.store import memory_store

    memory_store.attach_router(model_router)
    searcher.attach_router(model_router)
    semantic_index.attach_router(model_router)
    chunks = await semantic_index.load()
    _step("memory + semantic index", {"chunks": chunks},
          int((time.perf_counter() - t0) * 1000))

    # ---- 6. orchestrator wiring ----------------------------------------
    from backend.app.core.orchestrator import orchestrator

    orchestrator.router = model_router
    orchestrator.attach(memory=memory_store, agents={a.name: a for a in agents.all()})
    _step("orchestrator wired", {"agents": len(agents.all())})

    # ---- 7. tasks + scheduler ------------------------------------------
    t0 = time.perf_counter()
    from backend.app.automation.scheduler import scheduler
    from backend.app.core.task_store import task_store

    restored_tasks = await task_store.load_from_db()

    async def run_scheduled(job_id: str, title: str, instruction: str, device: str = "pc",
                            priority: str = "normal", manual: bool = False) -> Dict[str, Any]:
        """A fired job becomes a real SAM task, with the full guard chain."""
        result = await orchestrator.handle_text(
            instruction, channel="scheduler", device=device, speak=False,
        )
        return {"ok": result.ok, "task_id": result.task.id if result.task else job_id,
                "reply": result.reply, "answer": result.reply,
                "actions": result.actions, "intent": result.intent}

    scheduler.attach_executor(run_scheduled)
    sched = await scheduler.start()
    _step("scheduler", {"tasks_restored": restored_tasks, **{k: sched.get(k) for k in
                                                             ("engine", "jobs_restored")}},
          int((time.perf_counter() - t0) * 1000))

    # ---- 8. devices -----------------------------------------------------
    t0 = time.perf_counter()
    from backend.app.devices.registry import device_registry
    from backend.app.devices.sync import sync_engine

    await device_registry.load()
    if settings.phone_enabled and not settings.privacy_phone_sync:
        sync_engine.start()
    _step("devices", device_registry.summary(), int((time.perf_counter() - t0) * 1000))

    # ---- 9. voice + proactive ------------------------------------------
    t0 = time.perf_counter()
    from backend.app.voice.engine import voice_engine, wire_wake_to_orchestrator
    from backend.app.voice.wake import wake_listener

    wire_wake_to_orchestrator()
    if settings.voice_wake_word_enabled:
        wake_listener.start()
    _step("voice", {"mode": voice_engine.state()["mode"]["mode"],
                    "tts_voice": voice_engine.state()["tts"]["voice_id"],
                    "wake_word": wake_listener.state()["engine"]},
          int((time.perf_counter() - t0) * 1000))

    # ---- 10. market alert poller ---------------------------------------
    t0 = time.perf_counter()
    market_poller_state: Dict[str, Any] = {"enabled": False}
    if settings.market_enabled and settings.market_alerts_enabled:
        try:
            from backend.app.markets.alerts import alert_poller

            alert_poller.start()          # sync: it spawns the asyncio task itself
            market_poller_state = alert_poller.status()
        except Exception as exc:                       # never block startup on markets
            log.warning("market alert poller did not start: %s", exc)
            market_poller_state = {"enabled": False, "error": f"{type(exc).__name__}: {exc}"}
    _step("markets", market_poller_state, int((time.perf_counter() - t0) * 1000))

    proactive = asyncio.create_task(_proactive_loop())

    total_ms = int((time.perf_counter() - t_all) * 1000)
    STARTUP["total_ms"] = total_ms
    emit(Topics.SYSTEM_STATUS, component="startup", state="ready", total_ms=total_ms,
         tools=tool_count, providers=providers)
    log.info("SAM ready in %d ms — %d tools, %d agents, %d providers",
             total_ms, tool_count, len(agents.all()), len(providers))
    if not settings.any_cloud_key and not providers:
        log.warning("no AI provider is configured: SAM is running on its offline rule engine. "
                    "Add a key to .env or start Ollama — see MODELS in the UI.")

    try:
        yield
    finally:
        log.info("SAM shutting down …")
        proactive.cancel()
        stopped: List[str] = []
        try:
            from backend.app.markets.alerts import alert_poller

            await alert_poller.stop()
            stopped.append("market-alerts")
        except Exception:
            pass
        try:
            await scheduler.stop()
            stopped.append("scheduler")
        except Exception:
            pass
        try:
            sync_engine.stop()
            stopped.append("sync")
        except Exception:
            pass
        try:
            from backend.app.browser.engine import browser_engine

            await browser_engine.stop()
            stopped.append("browser")
        except Exception:
            pass
        try:
            wake_listener.stop()
            stopped.append("wake-word")
        except Exception:
            pass
        try:
            await model_router.aclose()
            stopped.append("models")
        except Exception:
            pass
        try:
            await semantic_index.flush()
            stopped.append("semantic-index")
        except Exception:
            pass
        try:
            await close_db()
            stopped.append("database")
        except Exception:
            pass
        emit(Topics.SYSTEM_STATUS, component="shutdown", stopped=stopped)
        log.info("stopped: %s", ", ".join(stopped))


async def _proactive_loop() -> None:
    """
    Proactive mode: watch approved signals and speak up when something matters.

    It only ever *suggests* — the level (OFF / IMPORTANT ONLY / NORMAL /
    PROACTIVE) decides how much it says, and nothing is executed without the
    normal permission + confirmation chain.
    """
    import psutil

    from backend.app.automation.calendar_store import calendar_store
    from backend.app.voice.engine import voice_engine
    from backend.app.voice.modes import voice_modes

    cooldown: Dict[str, float] = {}
    while True:
        try:
            await asyncio.sleep(max(15, int(settings.proactive_check_interval_seconds)))
            level = voice_modes.proactive_level()
            if level == "off" or settings.proactive_level == "off":
                continue
            now = time.time()

            def cooled(key: str, seconds: float) -> bool:
                if now - cooldown.get(key, 0) < seconds:
                    return False
                cooldown[key] = now
                return True

            # 1. calendar: something starting soon
            upcoming = await calendar_store.upcoming(minutes=15)
            for event in upcoming:
                if cooled(f"cal-{event['id']}", 3600):
                    await voice_engine.announce(
                        f"{event['title']} starts soon",
                        f"at {(event.get('start') or '')[11:16]}"
                        + (f" in {event['location']}" if event.get("location") else ""),
                        level="important_only" if level == "important_only" else "info",
                    )

            # 2. battery
            batt = psutil.sensors_battery()
            if batt and not batt.power_plugged and batt.percent <= 15 and cooled("battery", 900):
                await voice_engine.announce("Battery is low", f"{round(batt.percent)}% remaining",
                                            level="warning")

            # 3. disk
            try:
                usage = psutil.disk_usage("/")
                free_pct = 100 * usage.free / max(usage.total, 1)
                if free_pct < 8 and cooled("disk", 3600):
                    await voice_engine.announce("Disk space is running low",
                                                f"{round(usage.free / (1024 ** 3), 1)} GB free "
                                                f"({round(free_pct)}%)", level="warning")
            except OSError:
                pass

            # 4. a long task finished while the user was away
            from backend.app.core.task_store import task_store

            done = [t for t in task_store.all() if t.finished_at and t.status.value == "COMPLETED"]
            if done and level in ("normal", "proactive"):
                from datetime import datetime, timezone

                latest = max(done, key=lambda t: t.finished_at)
                finished = latest.finished_at
                if finished.tzinfo is None:
                    finished = finished.replace(tzinfo=timezone.utc)
                age = (datetime.now(timezone.utc) - finished).total_seconds()
                if 0 <= age < 90 and cooled(f"task-{latest.id}", 900):
                    await voice_engine.announce("Task finished", latest.title or latest.id,
                                                level="info")
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # pragma: no cover
            log.debug("proactive loop: %s", exc)


# ===========================================================================
# Application
# ===========================================================================
app = FastAPI(
    title="SAM — Fully Advanced AI Voice Assistant",
    description=(
        "Professional multi-brain, multi-agent AI operating platform for PC + Android.\n\n"
        "**How a request flows:** UI → REST/WS → Orchestrator → Context Engine → Planner → "
        "17 specialised brains → Tool layer (162 tools) → Security guard "
        "(permission → risk → confirmation → audit) → Verification → response.\n\n"
        "**Safety:** every mutating endpoint goes through the same guard a chat request does. "
        "A blocked action returns `ok=false` with the reason and, when SAM needs approval, a "
        "`confirmation` object the UI must show. SAM never hides a failure."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs", redoc_url="/redoc", openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-SAM-Version"],
)


@app.middleware("http")
async def stamp_version(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-SAM-Version"] = "1.0.0"
    response.headers["X-SAM-Mode"] = settings.sam_mode
    return response


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception) -> JSONResponse:
    """Never hide a failure: report it plainly, log it fully."""
    log.exception("unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(status_code=500, content={
        "ok": False, "error": f"{type(exc).__name__}: {exc}"[:500],
        "path": request.url.path,
        "note": "SAM logs the full traceback to data/logs/sam.log",
    })


# ---- API v1 --------------------------------------------------------------
from backend.app.api.v1 import (  # noqa: E402  (import after app creation on purpose)
    agents as agents_api,
    automation as automation_api,
    browser as browser_api,
    chat as chat_api,
    coding as coding_api,
    creative as creative_api,
    devices as devices_api,
    files as files_api,
    markets as markets_api,
    memory as memory_api,
    models as models_api,
    phone as phone_api,
    research as research_api,
    security as security_api,
    settings as settings_api,
    system as system_api,
    tasks as tasks_api,
    voice as voice_api,
)
from backend.app.api import ws as ws_api  # noqa: E402

API_ROUTERS = [
    system_api.router, chat_api.router, tasks_api.router, agents_api.router, models_api.api,
    security_api.router, files_api.router, research_api.router, coding_api.router,
    creative_api.router, memory_api.router, automation_api.router, devices_api.router,
    phone_api.router, browser_api.router, voice_api.router, settings_api.router,
    markets_api.router,
]
for api_router in API_ROUTERS:
    app.include_router(api_router, prefix="/api/v1")

app.include_router(ws_api.router)


# ---- root + desktop UI ---------------------------------------------------
@app.get("/", include_in_schema=False)
async def root() -> Any:
    """Serve the built desktop UI, or a self-describing JSON page if unbuilt."""
    index = DESKTOP_DIST / "index.html"
    if index.exists():
        return FileResponse(str(index))
    return JSONResponse({
        "product": "SAM — Fully Advanced AI Voice Assistant",
        "version": "1.0.0",
        "status": "backend running, desktop UI not built yet",
        "mode": settings.sam_mode,
        "tools": len(registry.names()),
        "build_ui": ["cd desktop", "npm install", "npm run build"],
        "api_docs": "/docs",
        "health": "/health",
        "dashboard": "/api/v1/dashboard",
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(STARTED_AT)),
        "startup": STARTUP,
    })


@app.get("/health", include_in_schema=False)
@app.get("/api/health", include_in_schema=False)
async def health_root() -> Any:
    """Alias so ``/health`` works without the ``/api/v1`` prefix (scripts, uptime checks)."""
    return await system_api.health()


@app.get("/version", include_in_schema=False)
async def version() -> Dict[str, Any]:
    return {"product": "SAM", "version": "1.0.0", "mode": settings.sam_mode,
            "tools": len(registry.names()), "uptime_seconds": round(time.time() - STARTED_AT, 1)}


@app.get("/api/v1/integrations", include_in_schema=False)
async def integration_status() -> Dict[str, Any]:
    """Report source availability separately from active runtime connectivity."""
    from backend.app.integrations.openclaw import status as openclaw_status

    source_root = PROJECT_ROOT / "integrations" / "source"
    projects = {}
    for name in ("OpenJarvis", "MyAIHuman", "OpenClaw"):
        folder = source_root / name
        projects[name] = {
            "source_present": folder.is_dir(),
            "readme_present": folder.is_dir() and any(folder.glob("README*")),
            "runtime_adapter": name == "OpenClaw" and False,
            "note": ("Source included; upstream components are not automatically callable from SAM."
                     if name != "OpenClaw" else
                     "Source included; gateway transport/action adapter is not implemented."),
        }
    return {"ok": True, "projects": projects, "openclaw": openclaw_status()}


@app.get("/startup", include_in_schema=False)
async def startup_report() -> Dict[str, Any]:
    """Exactly what SAM did while booting — no mystery failures."""
    return {"ok": STARTUP["ok"], "total_ms": STARTUP.get("total_ms"),
            "errors": STARTUP["errors"], "steps": STARTUP["steps"],
            "uptime_seconds": round(time.time() - STARTED_AT, 1)}


if DESKTOP_DIST.exists():
    app.mount("/assets", StaticFiles(directory=str(DESKTOP_DIST / "assets")), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa(full_path: str) -> Any:
        """Client-side routing: unknown paths fall back to index.html."""
        candidate = (DESKTOP_DIST / full_path).resolve()
        if full_path and str(candidate).startswith(str(DESKTOP_DIST.resolve())) \
                and candidate.is_file():
            return FileResponse(str(candidate))
        index = DESKTOP_DIST / "index.html"
        if index.exists():
            return FileResponse(str(index))
        return JSONResponse({"ok": False, "error": f"not found: /{full_path}"}, status_code=404)
