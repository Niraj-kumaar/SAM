"""
backend.app.core.orchestrator
=============================

**SAM CORE** — the main AI orchestrator.

Responsibilities (from the spec, section 3):

* understand the user request
* identify intent and context
* maintain the conversation
* plan tasks and select models/agents
* coordinate agents and control tools
* monitor execution and handle errors
* verify results and return the final response

Public entry points
-------------------
``orchestrator.handle_text(text, ...)``   -> :class:`OrchestratorResult`
``orchestrator.handle_task(task_id)``     -> execute an already-planned task
``orchestrator.stream_text(text, ...)``   -> async generator of UI events
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.planner import Planner
from backend.app.core.schemas import (
    AgentName,
    ChatResponse,
    DeviceKind,
    RiskLevel,
    TaskModel,
    TaskStatus,
    TaskStepModel,
)
from backend.app.core.task_graph import GraphError, TaskGraph
from backend.app.core.task_store import task_store
from backend.app.models.router import ModelRouter
from backend.app.providers.heuristic import classify_intent, detect_language
from backend.app.tools.registry import ToolContext, ToolExecutionError, registry

log = get_logger("core.orchestrator")


@dataclass
class OrchestratorResult:
    conversation_id: str
    message_id: Optional[str]
    reply: str
    language: str = "en"
    model: str = ""
    agent: str = "core"
    task: Optional[TaskModel] = None
    intent: str = ""
    confidence: float = 0.0
    sources: List[Dict[str, Any]] = field(default_factory=list)
    actions: List[Dict[str, Any]] = field(default_factory=list)
    confirmations: List[Dict[str, Any]] = field(default_factory=list)
    took_ms: int = 0
    ok: bool = True

    def to_chat_response(self, spoken: bool = False) -> ChatResponse:
        return ChatResponse(
            conversation_id=self.conversation_id,
            message_id=self.message_id,
            reply=self.reply,
            language=self.language,
            model=self.model,
            agent=self.agent,
            task_id=self.task.id if self.task else None,
            task=self.task,
            sources=self.sources,
            actions=self.actions,
            confirmations=self.confirmations,
            took_ms=self.took_ms,
            spoken=spoken,
        )


class Orchestrator:
    """Coordinates every agent, model and tool call in SAM."""

    def __init__(self, router: Optional[ModelRouter] = None,
                 planner: Optional[Planner] = None) -> None:
        self.router = router or ModelRouter()
        self.planner = planner or Planner(self.router)
        self._memory: Any = None
        self._verifier: Any = None
        self._agents: Dict[str, Any] = {}
        self._history: Dict[str, List[Dict[str, str]]] = {}
        self._history_limit = 12
        self._started_at = time.time()

    # ------------------------------------------------------------------ wiring
    def attach(self, *, memory: Any = None, verifier: Any = None,
               agents: Optional[Dict[str, Any]] = None) -> None:
        """Late binding to avoid import cycles between core/ and the subsystems."""
        if memory is not None:
            self._memory = memory
        if verifier is not None:
            self._verifier = verifier
        if agents:
            self._agents.update(agents)

    @property
    def uptime(self) -> float:
        return round(time.time() - self._started_at, 1)

    # =========================================================== MAIN ENTRY
    async def handle_text(
        self,
        text: str,
        *,
        conversation_id: Optional[str] = None,
        language: Optional[str] = None,
        attachments: Optional[List[Dict[str, Any]]] = None,
        channel: str = "text",
        dry_run: bool = False,
        max_steps: int = 12,
        speak: bool = False,
        use_model: Optional[bool] = None,
        device: Optional[str] = None,
    ) -> OrchestratorResult:
        t0 = time.perf_counter()
        text = (text or "").strip()
        if not text:
            return OrchestratorResult(conversation_id=conversation_id or _new_conv(),
                                      message_id=None, reply="I didn't catch that — could you repeat it?",
                                      ok=False)

        conv_id = conversation_id or _new_conv()
        lang = language if language and language != "auto" else detect_language(text)
        intent, confidence = classify_intent(text)

        # ---- 1. conversation bookkeeping ---------------------------------
        await self._remember_turn(conv_id, "user", text, channel=channel,
                                  attachments=attachments, language=lang)
        emit(Topics.CHAT_USER, conversation_id=conv_id, text=text, language=lang,
             intent=intent, confidence=confidence, channel=channel)

        # ---- 2. memory context -------------------------------------------
        context = await self._gather_context(text, conv_id, lang)

        # ---- 3. attachments short-circuit (vision) ------------------------
        if attachments:
            images = [a.get("path") or a.get("data_url") for a in attachments
                      if str(a.get("type", "")).startswith("image") and (a.get("path") or a.get("data_url"))]
            if images:
                return await self._handle_vision(text, images, conv_id, lang, t0)

        # ---- 4. plan ------------------------------------------------------
        task, intent, confidence = await self.planner.plan(
            text, max_steps=max_steps, use_model=use_model, conversation_id=conv_id
        )
        task.kind = task.kind or intent.split(".")[0]
        if device:
            # cross-device handoff: force the whole task (and therefore every
            # step, since steps inherit the task device) onto that device.
            try:
                from backend.app.devices.registry import device_registry

                resolved = device_registry.resolve(device)
                kind = "phone" if device in ("phone", "mobile", "android") or resolved.startswith("phone") \
                    else ("cloud" if device == "cloud" else "pc")
                task.device = DeviceKind(kind)
                for step in task.steps:
                    if step.device == DeviceKind.PC and kind != "pc":
                        step.device = DeviceKind(kind)
                context = {**(context or {}), "device": resolved, "handoff": channel == "handoff"}
            except Exception as exc:  # pragma: no cover
                log.debug("device override failed: %s", exc)
        await task_store.create(task)

        if dry_run:
            await task_store.set_status(task.id, TaskStatus.WAITING, "dry run — plan only")
            reply = self._render_plan(task, intent, confidence)
            await self._remember_turn(conv_id, "assistant", reply, agent=task.agent.value,
                                      task_id=task.id, language=lang)
            return OrchestratorResult(
                conversation_id=conv_id, message_id=None, reply=reply, language=lang,
                agent=task.agent.value, task=task, intent=intent, confidence=confidence,
                took_ms=int((time.perf_counter() - t0) * 1000),
            )

        # ---- 5. execute ---------------------------------------------------
        outcome = await self.execute_task(task, context=context, language=lang)

        # ---- 6. verify ----------------------------------------------------
        verdict = await self._verify(task, outcome)

        # ---- 7. compose the reply -----------------------------------------
        reply, sources, actions, confirmations = await self._compose_reply(
            text, task, outcome, verdict, intent, confidence, lang, context
        )

        # ---- 8. persist + emit --------------------------------------------
        msg_id = await self._remember_turn(conv_id, "assistant", reply, agent=task.agent.value,
                                           task_id=task.id, language=lang,
                                           meta={"intent": intent, "confidence": confidence})
        emit(Topics.CHAT_ASSISTANT, conversation_id=conv_id, message_id=msg_id, text=reply,
             language=lang, agent=task.agent.value, task_id=task.id, model=outcome.get("model", ""))
        emit(Topics.CHAT_DONE, conversation_id=conv_id, task_id=task.id,
             status=task.status.value, took_ms=int((time.perf_counter() - t0) * 1000))

        await self._maybe_learn(text, task, outcome, lang)

        return OrchestratorResult(
            conversation_id=conv_id,
            message_id=msg_id,
            reply=reply,
            language=lang,
            model=outcome.get("model", ""),
            agent=task.agent.value,
            task=task,
            intent=intent,
            confidence=confidence,
            sources=sources,
            actions=actions,
            confirmations=confirmations,
            took_ms=int((time.perf_counter() - t0) * 1000),
            ok=task.status in (TaskStatus.COMPLETED, TaskStatus.WAITING),
        )

    # ------------------------------------------------------------- streaming
    async def stream_text(self, text: str, **kwargs: Any) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream UI events while handling a request.

        Yields dicts shaped like bus events, so the WebSocket layer can forward
        them verbatim and the REST layer can just await :meth:`handle_text`.
        """
        conv_id = kwargs.get("conversation_id") or _new_conv()
        kwargs["conversation_id"] = conv_id
        yield {"topic": "stream.start", "payload": {"conversation_id": conv_id, "text": text}}

        sub = None
        try:
            from backend.app.core.event_bus import bus

            sub = bus.subscribe("task.*", "chat.*", "agent.*", "security.*", "model.*", "voice.*")
            handler = asyncio.create_task(self.handle_text(text, **kwargs))

            while not handler.done():
                try:
                    ev = await asyncio.wait_for(sub.queue.get(), timeout=0.25)
                    yield {"topic": ev.topic, "payload": ev.payload}
                except asyncio.TimeoutError:
                    yield {"topic": "stream.tick", "payload": {"ts": time.time()}}

            result: OrchestratorResult = handler.result()
            yield {
                "topic": "stream.reply",
                "payload": {
                    "conversation_id": result.conversation_id,
                    "reply": result.reply,
                    "language": result.language,
                    "agent": result.agent,
                    "intent": result.intent,
                    "task_id": result.task.id if result.task else None,
                    "took_ms": result.took_ms,
                },
            }
        except Exception as exc:  # pragma: no cover
            log.exception("stream_text failed")
            yield {"topic": "stream.error", "payload": {"error": str(exc)}}
        finally:
            if sub is not None:
                from backend.app.core.event_bus import bus

                bus.unsubscribe(sub)
            yield {"topic": "stream.end", "payload": {"conversation_id": conv_id}}

    # ============================================================ EXECUTION
    async def execute_task(self, task: TaskModel, *, context: Optional[Dict[str, Any]] = None,
                           language: str = "en") -> Dict[str, Any]:
        """Run a planned task through the graph executor."""
        ctx_extra = context or {}
        await task_store.set_status(task.id, TaskStatus.RUNNING, "executing plan")

        graph = TaskGraph(task, self._make_executor(ctx_extra, language))
        try:
            result = await graph.run()
        except GraphError as exc:
            log.error("invalid task graph for %s: %s", task.id, exc)
            await task_store.finish(task.id, error=f"invalid plan: {exc}")
            return {"ok": False, "error": str(exc), "outputs": {}, "model": ""}
        except asyncio.CancelledError:
            await task_store.set_status(task.id, TaskStatus.CANCELLED, "cancelled")
            raise
        except Exception as exc:  # pragma: no cover
            log.exception("task %s crashed", task.id)
            await task_store.finish(task.id, error=f"{type(exc).__name__}: {exc}")
            return {"ok": False, "error": str(exc), "outputs": {}, "model": ""}

        if task_store.is_cancelled(task.id):
            return {"ok": False, "error": "cancelled", "outputs": result.outputs, "model": ""}

        if not result.ok:
            recovered = await self._recover(task, result.errors)
            if not recovered:
                await task_store.finish(
                    task.id,
                    result={"outputs": _jsonable(result.outputs)},
                    error="; ".join(e.get("error", "unknown") for e in result.errors[:3]),
                )
                return {"ok": False, "errors": result.errors, "outputs": result.outputs,
                        "graph": result.to_dict()}

        await task_store.finish(task.id, result={"outputs": _jsonable(result.outputs)})
        return {"ok": True, "outputs": result.outputs, "graph": result.to_dict()}

    def _make_executor(self, extra_context: Dict[str, Any], language: str):
        """Build the node executor closure used by :class:`TaskGraph`."""

        async def executor(task: TaskModel, step: TaskStepModel, graph_ctx: Dict[str, Any]) -> Any:
            await task_store.wait_if_paused(task.id)
            if task_store.is_cancelled(task.id):
                step.status = TaskStatus.CANCELLED
                return {"skipped": True, "reason": "cancelled"}

            ctx = ToolContext(
                task_id=task.id,
                step_id=step.id,
                agent=step.agent.value,
                device=step.device.value,
                conversation_id=task.conversation_id,
                user_text=task.request,
                params=dict(step.params),
                outputs={**graph_ctx.get("outputs", {}), **extra_context},
                language=language,
                meta={"step_name": step.name, "intent": task.kind},
            )

            tool_name = step.tool or self._tool_for(step)
            if tool_name is None:
                # No concrete tool: let the appropriate brain answer in prose.
                return await self._agent_fallback(task, step, ctx, graph_ctx)

            if registry.get(tool_name) is None:
                log.warning("tool %s is not registered — falling back to agent reasoning", tool_name)
                return await self._agent_fallback(task, step, ctx, graph_ctx)

            try:
                value = await registry.execute(tool_name, ctx, **self._resolve_params(step, graph_ctx))
                return {"ok": True, "tool": tool_name, "step_name": step.name, "value": _jsonable(value)}
            except ToolExecutionError as exc:
                # A user denial is not a crash — record it and continue.
                if exc.denied_by in ("confirmation", "permission", "risk"):
                    return {"ok": False, "tool": tool_name, "step_name": step.name,
                            "blocked": True, "denied_by": exc.denied_by, "reason": str(exc),
                            "confirmation_id": exc.confirmation_id}
                raise
            except KeyError:
                raise
            except Exception:
                raise

        return executor

    @staticmethod
    def _tool_for(step: TaskStepModel) -> Optional[str]:
        """Derive a tool name from the agent + step name when none was given."""
        guesses = {
            ("pc", "system"): "pc.system_info",
            ("files", "search"): "files.search",
            ("research", "search"): "research.search",
            ("browser", "navigate"): "browser.navigate",
            ("memory", "search"): "memory.search",
            ("memory", "write"): "memory.write",
            ("security", "report"): "security.report",
            ("core", "status"): "core.status",
        }
        name = step.name.lower()
        for (agent, key), tool_name in guesses.items():
            if step.agent.value == agent and key in name:
                return tool_name
        return None

    def _resolve_params(self, step: TaskStepModel, graph_ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Replace ``{{step:<id>.field}}`` placeholders with previous outputs."""
        params = dict(step.params or {})
        outputs = graph_ctx.get("outputs", {})
        resolved: Dict[str, Any] = {}
        for k, v in params.items():
            if isinstance(v, str) and v.startswith("{{") and v.endswith("}}"):
                resolved[k] = _resolve_ref(v[2:-2], outputs)
            else:
                resolved[k] = v
        # give every tool the raw request and the accumulated outputs
        resolved.setdefault("request", step.params.get("request") or "")
        return resolved

    async def _agent_fallback(self, task: TaskModel, step: TaskStepModel, ctx: ToolContext,
                              graph_ctx: Dict[str, Any]) -> Dict[str, Any]:
        """
        No tool matched — hand the step to the right *brain* and let a model
        produce the answer (writing, reasoning, research summary, etc.).
        """
        outputs = graph_ctx.get("outputs", {})
        role = {"reasoning": "reasoning", "writing": "primary", "research": "reasoning",
                "coding": "coding", "vision": "vision", "data": "reasoning",
                "creative": "primary", "communication": "fast", "core": "primary",
                "verification": "fast", "security": "fast", "planning": "reasoning",
                "memory": "fast"}.get(step.agent.value, "primary")

        prompt = self._agent_prompt(task, step, outputs)
        try:
            res = await self.router.ask(prompt, role=role, max_tokens=1500, temperature=0.35)
            return {"ok": True, "agent": step.agent.value, "step_name": step.name,
                    "text": res.text, "model": res.model, "provider": res.provider}
        except Exception as exc:  # pragma: no cover
            return {"ok": False, "agent": step.agent.value, "step_name": step.name, "error": str(exc)}

    @staticmethod
    def _agent_prompt(task: TaskModel, step: TaskStepModel, outputs: Dict[str, Any]) -> str:
        prior = json.dumps(_jsonable(outputs), indent=2, default=str)[:6000]
        return f"""You are SAM's {step.agent.value.upper()} brain executing one step of a larger plan.

USER REQUEST:
{task.request}

CURRENT STEP:
{step.name}

RESULTS FROM EARLIER STEPS:
{prior or "(none yet)"}

Do exactly this step and nothing else. Be concrete, accurate and useful.
If the step needs information you do not have, say precisely what is missing.
Plain text or Markdown. No preamble about being an AI."""

    # -------------------------------------------------------------- recovery
    async def _recover(self, task: TaskModel, errors: List[Dict[str, Any]]) -> bool:
        """
        Error recovery pipeline::

            detect -> understand -> check options -> apply allowed recovery
                   -> retry -> verify -> report
        """
        if not errors:
            return False
        await task_store.set_status(task.id, TaskStatus.RECOVERING, "analysing failure")
        emit(Topics.AGENT_ERROR, task_id=task.id, stage="recovery",
             errors=[e.get("error") for e in errors[:5]])

        summary = "; ".join(str(e.get("error", ""))[:200] for e in errors[:5])
        advice = ""
        try:
            res = await self.router.ask(
                f"A SAM task failed.\n\nTASK: {task.request}\nERRORS: {summary}\n\n"
                "In at most 3 short lines: (1) the likely cause, (2) one concrete recovery step "
                "SAM can attempt automatically, (3) what the user must do if it cannot.",
                role="fast", max_tokens=220, temperature=0.2,
            )
            advice = res.text.strip()
        except Exception:  # pragma: no cover
            advice = "No model available to analyse the failure."

        # a "blocked by user" outcome is a valid terminal state, not an error
        blocked_only = all(
            isinstance(e.get("error"), str) and "denied" in e.get("error", "").lower()
            for e in errors
        )
        task.error = summary
        task.result = json.dumps({"recovery_advice": advice, "blocked": blocked_only}, indent=2)
        await task_store.set_status(
            task.id, TaskStatus.WAITING if blocked_only else TaskStatus.FAILED,
            "awaiting user" if blocked_only else "recovery attempted",
        )
        return blocked_only

    # ------------------------------------------------------------ verification
    async def _verify(self, task: TaskModel, outcome: Dict[str, Any]) -> Dict[str, Any]:
        """Ask the Verification Brain whether the operation actually succeeded."""
        if self._verifier is not None:
            try:
                return await self._verifier.verify_task(task, outcome)
            except Exception as exc:  # pragma: no cover
                log.debug("verifier failed: %s", exc)

        outputs = outcome.get("outputs") or {}
        blocked = [k for k, v in outputs.items()
                   if isinstance(v, dict) and v.get("blocked")]
        failed = [k for k, v in outputs.items()
                  if isinstance(v, dict) and v.get("ok") is False and not v.get("blocked")]
        verdict = "success" if outcome.get("ok") and not blocked and not failed else (
            "blocked" if blocked else "failed"
        )
        return {
            "verdict": verdict,
            "task_id": task.id,
            "steps_ok": sum(1 for v in outputs.values() if isinstance(v, dict) and v.get("ok")),
            "steps_blocked": len(blocked),
            "steps_failed": len(failed),
            "notes": [],
        }

    # ----------------------------------------------------------------- reply
    async def _compose_reply(
        self, text: str, task: TaskModel, outcome: Dict[str, Any], verdict: Dict[str, Any],
        intent: str, confidence: float, lang: str, context: Dict[str, Any],
    ) -> Tuple[str, List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Turn the execution result into the final user-facing answer."""
        outputs = outcome.get("outputs") or {}
        sources: List[Dict[str, Any]] = []
        actions: List[Dict[str, Any]] = []
        confirmations: List[Dict[str, Any]] = []

        for step in task.steps:
            out = outputs.get(step.id)
            if not isinstance(out, dict):
                continue
            value = out.get("value")
            if isinstance(value, dict):
                if value.get("sources"):
                    sources.extend(value["sources"])
                if value.get("confirmation_id"):
                    confirmations.append(value)
            actions.append(
                {
                    "step": step.name,
                    "agent": step.agent.value,
                    "device": step.device.value,
                    "tool": step.tool,
                    "status": step.status.value,
                    "ok": bool(out.get("ok")),
                    "blocked": bool(out.get("blocked")),
                    "reason": out.get("reason"),
                    "error": out.get("error"),
                }
            )

        # --- collect textual results produced by model-backed steps --------
        texts: List[str] = []
        for step in task.steps:
            out = outputs.get(step.id)
            if isinstance(out, dict):
                if isinstance(out.get("text"), str) and out["text"].strip():
                    texts.append(out["text"].strip())
                value = out.get("value")
                if isinstance(value, dict):
                    for key in ("summary", "answer", "text", "markdown", "reply", "report"):
                        if isinstance(value.get(key), str) and value[key].strip():
                            texts.append(value[key].strip())
                            break
                    if value.get("sources"):
                        sources.extend(value["sources"])

        # --- blocked / denied ----------------------------------------------
        blocked = [a for a in actions if a.get("blocked")]
        if blocked and not texts:
            reasons = "\n".join(f"- {b['step']}: {b.get('reason', 'blocked')}" for b in blocked[:6])
            reply = (
                f"I stopped before running {len(blocked)} action(s).\n\n{reasons}\n\n"
                "Approve them in the confirmation panel (or enable the capability in the "
                "Security Center) and I'll carry on from where I left off."
            )
            return reply, sources, actions, confirmations

        # --- nothing produced text: describe what happened -----------------
        if not texts:
            reply = self._describe_outcome(task, actions, verdict)
            return reply, sources, actions, confirmations

        # --- merge multiple step texts into one coherent answer ------------
        if len(texts) == 1:
            reply = texts[0]
        else:
            try:
                merged = await self.router.ask(
                    "You are SAM. Combine these step outputs into one clear, well-structured "
                    f"answer to the user's request. Keep every fact. Use Markdown.\n\n"
                    f"REQUEST: {text}\n\nSTEP OUTPUTS:\n" + "\n\n---\n\n".join(texts)[:8000],
                    role="primary", max_tokens=1600, temperature=0.3,
                )
                reply = merged.text.strip() or "\n\n".join(texts)
            except Exception:  # pragma: no cover
                reply = "\n\n".join(texts)

        if sources:
            reply += "\n\n**Sources**\n" + "\n".join(
                f"- [{s.get('title') or s.get('url')}]({s.get('url')})" for s in sources[:8] if s.get("url")
            )
        return reply, sources, actions, confirmations

    @staticmethod
    def _describe_outcome(task: TaskModel, actions: List[Dict[str, Any]], verdict: Dict[str, Any]) -> str:
        done = [a for a in actions if a.get("ok")]
        failed = [a for a in actions if a.get("error")]
        lines = [f"**{task.title}** — {task.status.value.lower()}"]
        if done:
            lines.append("\nCompleted:")
            lines += [f"- {a['step']} ({a['agent']} on {a['device']})" for a in done[:8]]
        if failed:
            lines.append("\nFailed:")
            lines += [f"- {a['step']}: {a['error']}" for a in failed[:5]]
        if verdict.get("notes"):
            lines.append("\nVerification: " + "; ".join(str(n) for n in verdict["notes"][:4]))
        if not done and not failed:
            lines.append("\nNo action was executed.")
        return "\n".join(lines)

    def _render_plan(self, task: TaskModel, intent: str, confidence: float) -> str:
        rows = []
        for s in task.steps:
            dep = f" after {','.join(s.depends_on)}" if s.depends_on else " (parallel)"
            flag = " [needs confirmation]" if s.requires_confirmation else ""
            rows.append(f"{s.index + 1}. **{s.name}** — agent `{s.agent.value}` on `{s.device.value}`"
                        f"{dep} risk {s.risk.value}{flag}")
        return (
            f"**Plan (dry run)** for “{task.request[:120]}”\n\n"
            f"Intent `{intent}` (confidence {confidence:.2f}) · primary agent `{task.agent.value}` · "
            f"device `{task.device.value}` · {len(task.steps)} step(s)\n\n"
            + "\n".join(rows)
            + "\n\nNothing was executed. Send the same request without `dry_run` to run it."
        )

    # ----------------------------------------------------------------- vision
    async def _handle_vision(self, text: str, images: List[str], conv_id: str, lang: str,
                             t0: float) -> OrchestratorResult:
        prompt = text or "Describe what you see in detail, including any readable text."
        res = await self.router.vision(prompt, images)
        reply = res.text or "I could not analyse that image with the models available."
        msg_id = await self._remember_turn(conv_id, "assistant", reply, agent="vision",
                                           language=lang, meta={"images": len(images)})
        emit(Topics.CHAT_ASSISTANT, conversation_id=conv_id, message_id=msg_id, text=reply,
             agent="vision", language=lang)
        task = TaskModel(title="Image understanding", request=text, kind="vision",
                         status=TaskStatus.COMPLETED, agent=AgentName.VISION,
                         device=DeviceKind.PC, progress=100.0, result=reply)
        await task_store.create(task)
        await task_store.finish(task.id, reply)
        return OrchestratorResult(
            conversation_id=conv_id, message_id=msg_id, reply=reply, language=lang,
            model=res.model, agent="vision", task=task, intent="vision.analyse",
            confidence=0.9, took_ms=int((time.perf_counter() - t0) * 1000),
        )

    # ---------------------------------------------------------------- context
    async def _gather_context(self, text: str, conv_id: str, lang: str) -> Dict[str, Any]:
        ctx: Dict[str, Any] = {"language": lang, "history": self._history.get(conv_id, [])[-6:]}
        if self._memory is not None:
            try:
                recalled = await self._memory.recall(text, limit=6)
                ctx["memory"] = recalled
                if recalled:
                    emit(Topics.MEMORY_UPDATED, event="recall", count=len(recalled))
            except Exception as exc:  # pragma: no cover
                log.debug("memory recall failed: %s", exc)
        return ctx

    async def _maybe_learn(self, text: str, task: TaskModel, outcome: Dict[str, Any], lang: str) -> None:
        """Store obviously memorable statements (explicit 'remember ...')."""
        if self._memory is None:
            return
        low = text.lower()
        if not any(k in low for k in ("remember", "note that", "my name is", "i prefer", "i like",
                                      "i always", "never ", "yaad rakho", "ನೆನಪಿಟ್ಟುಕೋ")):
            return
        try:
            await self._memory.store_from_text(text, source="conversation", language=lang)
        except Exception as exc:  # pragma: no cover
            log.debug("memory store failed: %s", exc)

    # -------------------------------------------------------------- history
    async def _remember_turn(self, conv_id: str, role: str, content: str, *, agent: str = "core",
                             task_id: Optional[str] = None, channel: str = "text",
                             attachments: Optional[List[Dict[str, Any]]] = None,
                             language: str = "en", model: str = "",
                             meta: Optional[Dict[str, Any]] = None) -> Optional[str]:
        hist = self._history.setdefault(conv_id, [])
        hist.append({"role": role, "content": content})
        if len(hist) > self._history_limit * 2:
            self._history[conv_id] = hist[-self._history_limit * 2 :]

        msg_id: Optional[str] = None
        try:
            from backend.app.memory.store import memory_store

            msg_id = await memory_store.add_message(
                conv_id, role, content, agent=agent, task_id=task_id, channel=channel,
                attachments=attachments or [], language=language, model=model, meta=meta or {},
            )
        except Exception as exc:  # pragma: no cover
            log.debug("message persist failed: %s", exc)
        return msg_id

    def recent_history(self, conv_id: str, limit: int = 10) -> List[Dict[str, str]]:
        return self._history.get(conv_id, [])[-limit:]

    # ---------------------------------------------------------------- status
    def status(self) -> Dict[str, Any]:
        return {
            "product": settings.sam_name,
            "version": "1.0.0",
            "mode": settings.sam_mode,
            "uptime_seconds": self.uptime,
            "agents_registered": sorted(self._agents),
            "tools_registered": registry.stats(),
            "tasks": task_store.counts(),
            "active_tasks": len(task_store.active()),
            "risk_mode": settings.security_risk_mode,
            "proactive_level": settings.proactive_level,
            "cloud_enabled": settings.cloud_enabled,
            "privacy": {
                "cloud_ai": settings.privacy_cloud_ai,
                "external_web": settings.privacy_external_web,
                "phone_sync": settings.privacy_phone_sync,
                "telemetry": settings.privacy_telemetry,
                "local_models": settings.privacy_local_models,
                "local_memory": settings.privacy_local_memory,
            },
        }


# ---------------------------------------------------------------------------
def _new_conv() -> str:
    return f"conv_{uuid.uuid4().hex[:12]}"


def _jsonable(value: Any) -> Any:
    """Make anything safe for JSON serialisation and the event bus."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except Exception:
            pass
    if hasattr(value, "to_dict"):
        try:
            return _jsonable(value.to_dict())
        except Exception:
            pass
    return str(value)


def _resolve_ref(ref: str, outputs: Dict[str, Any]) -> Any:
    """``{{step:<id>.value.summary}}`` -> nested lookup."""
    parts = ref.split(".")
    if parts and parts[0] in ("step", "steps", "outputs"):
        parts = parts[1:]
    cur: Any = outputs
    for p in parts:
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return None
    return cur


orchestrator = Orchestrator()
