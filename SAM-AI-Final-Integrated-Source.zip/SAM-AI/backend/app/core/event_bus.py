"""
backend.app.core.event_bus
==========================

In-process publish/subscribe bus. This is the nervous system of SAM:

* Agents publish progress + results.
* The Verification Engine publishes verdicts.
* The Security Engine publishes confirmations.
* The WebSocket layer subscribes to ``*`` and streams everything to the UI.

Design notes
------------
* ``asyncio.Queue`` per subscriber with a bounded size so a slow client can
  never block an agent (old events are dropped and counted).
* Topics support a trailing wildcard: subscribing to ``task.*`` receives
  ``task.created``, ``task.progress`` etc. ``*`` receives everything.
* A ring buffer keeps the last N events so a reconnecting UI can catch up.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable, Deque, Dict, Iterable, List, Optional

from backend.app.core.logging_config import get_logger

log = get_logger("event_bus")

REPLAY_BUFFER_SIZE = 500
QUEUE_SIZE = 1000


@dataclass
class Event:
    """One SAM event."""

    topic: str
    payload: Dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    ts: float = field(default_factory=time.time)
    source: str = "sam"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "topic": self.topic,
            "ts": self.ts,
            "source": self.source,
            "payload": self.payload,
        }


class Subscription:
    """A single subscriber's queue + the topic filters it wants."""

    def __init__(self, topics: Iterable[str], queue_size: int = QUEUE_SIZE) -> None:
        self.id = uuid.uuid4().hex[:10]
        self.topics: List[str] = list(topics) or ["*"]
        self.queue: asyncio.Queue[Event] = asyncio.Queue(maxsize=queue_size)
        self.dropped = 0
        self.received = 0

    def wants(self, topic: str) -> bool:
        for t in self.topics:
            if t == "*" or t == topic:
                return True
            if t.endswith(".*") and topic.startswith(t[:-1]):
                return True
        return False

    async def __aiter__(self) -> AsyncIterator[Event]:  # pragma: no cover - convenience
        while True:
            yield await self.queue.get()


class EventBus:
    """Central async event bus with wildcard topics and a replay buffer."""

    def __init__(self) -> None:
        self._subs: Dict[str, Subscription] = {}
        self._buffer: Deque[Event] = deque(maxlen=REPLAY_BUFFER_SIZE)
        self._hooks: Dict[str, List[Callable[[Event], Any]]] = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self.stats = {"published": 0, "delivered": 0, "dropped": 0}

    # ------------------------------------------------------------------ pub
    def publish(self, topic: str, payload: Optional[Dict[str, Any]] = None, source: str = "sam") -> Event:
        """Thread-safe / loop-safe publish. Never raises."""
        ev = Event(topic=topic, payload=payload or {}, source=source)
        self._buffer.append(ev)
        self.stats["published"] += 1

        for hook in self._hooks.get(topic, []) + self._hooks.get("*", []):
            try:
                hook(ev)
            except Exception as exc:  # pragma: no cover
                log.warning("event hook failed for %s: %s", topic, exc)

        try:
            loop = self._loop or asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        for sub in list(self._subs.values()):
            if not sub.wants(topic):
                continue
            try:
                if loop is not None and loop.is_running():
                    loop.call_soon_threadsafe(self._enqueue_nowait, sub, ev)
                else:
                    self._enqueue_nowait(sub, ev)
            except Exception as exc:  # pragma: no cover
                log.debug("publish failed to %s: %s", sub.id, exc)
        return ev

    def _enqueue_nowait(self, sub: Subscription, ev: Event) -> None:
        try:
            sub.queue.put_nowait(ev)
            sub.received += 1
            self.stats["delivered"] += 1
        except asyncio.QueueFull:
            try:
                sub.queue.get_nowait()          # drop oldest
                sub.queue.put_nowait(ev)
            except Exception:
                pass
            sub.dropped += 1
            self.stats["dropped"] += 1

    async def publish_async(
        self, topic: str, payload: Optional[Dict[str, Any]] = None, source: str = "sam"
    ) -> Event:
        return self.publish(topic, payload, source)

    # ------------------------------------------------------------------ sub
    def subscribe(self, *topics: str) -> Subscription:
        sub = Subscription(topics or ("*",))
        self._subs[sub.id] = sub
        log.debug("subscriber %s joined topics=%s", sub.id, sub.topics)
        return sub

    def unsubscribe(self, sub: Subscription) -> None:
        self._subs.pop(sub.id, None)

    def on(self, topic: str, handler: Callable[[Event], Any]) -> None:
        """Register a synchronous in-process hook (not a queue subscriber)."""
        self._hooks.setdefault(topic, []).append(handler)

    # --------------------------------------------------------------- replay
    def replay(self, since_ts: float = 0.0, topics: Optional[Iterable[str]] = None) -> List[Event]:
        wanted = set(topics) if topics else None
        out: List[Event] = []
        for ev in self._buffer:
            if ev.ts <= since_ts:
                continue
            if wanted and ev.topic not in wanted:
                continue
            out.append(ev)
        return out

    def attach_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def snapshot(self) -> Dict[str, Any]:
        return {
            "subscribers": len(self._subs),
            "buffered": len(self._buffer),
            **self.stats,
        }


# ---------------------------------------------------------------- singleton
bus = EventBus()


# ------------------------------------------------------------ topic helpers
class Topics:
    """Canonical topic names — always publish/subscribe through these."""

    # lifecycle
    SYSTEM_STATUS = "system.status"
    SYSTEM_LOG = "system.log"

    # conversation
    CHAT_USER = "chat.user"
    CHAT_ASSISTANT = "chat.assistant"
    CHAT_STREAM = "chat.stream"
    CHAT_DONE = "chat.done"

    # voice
    VOICE_LISTENING = "voice.listening"
    VOICE_TRANSCRIPT = "voice.transcript"
    VOICE_SPEAKING = "voice.speaking"
    VOICE_STOPPED = "voice.stopped"
    VOICE_WAKE = "voice.wake"

    # tasks / orchestration
    TASK_CREATED = "task.created"
    TASK_PLAN = "task.plan"
    TASK_PROGRESS = "task.progress"
    TASK_STEP = "task.step"
    TASK_STATUS = "task.status"
    TASK_COMPLETED = "task.completed"
    TASK_FAILED = "task.failed"
    TASK_CANCELLED = "task.cancelled"

    # agents
    AGENT_STARTED = "agent.started"
    AGENT_FINISHED = "agent.finished"
    AGENT_ERROR = "agent.error"

    # models
    MODEL_SELECTED = "model.selected"
    MODEL_USAGE = "model.usage"

    # security
    RISK_ASSESSED = "security.risk"
    CONFIRMATION_REQUIRED = "security.confirmation_required"
    CONFIRMATION_RESOLVED = "security.confirmation_resolved"
    PERMISSION_DENIED = "security.permission_denied"
    AUDIT = "security.audit"

    # devices
    DEVICE_ONLINE = "device.online"
    DEVICE_OFFLINE = "device.offline"
    DEVICE_STATE = "device.state"
    PHONE_EVENT = "phone.event"

    # memory
    MEMORY_STORED = "memory.stored"
    MEMORY_UPDATED = "memory.updated"

    # automation
    AUTOMATION_TRIGGERED = "automation.triggered"
    AUTOMATION_FINISHED = "automation.finished"
    PROACTIVE_SUGGESTION = "proactive.suggestion"

    # notifications
    NOTIFICATION = "notification.new"


def emit(topic: str, **payload: Any) -> Event:
    """Shorthand: ``emit(Topics.TASK_PROGRESS, task_id='t1', percent=42)``."""
    return bus.publish(topic, payload)
