"""
backend.app.core.guard
======================

**The single choke point every SAM action passes through.**

``guard()`` implements the security pipeline from the spec::

    USER -> SAM -> RISK ANALYZER -> PERMISSION ENGINE -> ACTION -> VERIFICATION

Nothing in ``backend/app/tools`` or ``backend/app/agents`` is allowed to touch
the operating system, the network or the phone without going through here.

Example::

    result = await guard(
        capability="pc.apps.launch",
        action="launch",
        target="notepad.exe",
        device="pc",
        run=lambda: pc_agent.launch_app("notepad.exe"),
    )
    if result.allowed:
        print(result.value)
    else:
        print(result.reason)
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, Optional

from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import RiskLevel
from backend.app.security.audit import audit_trail
from backend.app.security.confirmation_engine import confirmation_engine
from backend.app.security.permissions import Decision, permission_engine
from backend.app.security.risk_engine import risk_engine

log = get_logger("guard")

Runner = Callable[[], Awaitable[Any]]


@dataclass
class GuardResult:
    allowed: bool
    value: Any = None
    error: Optional[str] = None
    reason: str = ""
    risk: RiskLevel = RiskLevel.LOW
    risk_score: int = 0
    confirmation_id: Optional[str] = None
    capability: str = ""
    action: str = ""
    target: str = ""
    device: str = "pc"
    agent: str = "core"
    duration_ms: int = 0
    denied_by: str = ""          # permission | risk | confirmation | error | timeout
    verified: Optional[bool] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "allowed": self.allowed,
            "value": self.value,
            "error": self.error,
            "reason": self.reason,
            "risk": self.risk.value,
            "risk_score": self.risk_score,
            "confirmation_id": self.confirmation_id,
            "capability": self.capability,
            "action": self.action,
            "target": self.target,
            "device": self.device,
            "agent": self.agent,
            "duration_ms": self.duration_ms,
            "denied_by": self.denied_by,
            "verified": self.verified,
        }


async def guard(
    *,
    capability: str,
    action: str,
    target: str = "",
    run: Runner,
    device: str = "pc",
    agent: str = "core",
    task_id: Optional[str] = None,
    params: Optional[Dict[str, Any]] = None,
    batch_size: int = 1,
    verify: Optional[Callable[[Any], Awaitable[bool]]] = None,
    timeout: int = 300,
    auto_deny_critical: bool = False,
) -> GuardResult:
    """
    Evaluate permission + risk, ask for confirmation if needed, run the action,
    verify the outcome and write an audit entry. Never raises.
    """
    t0 = time.time()
    result = GuardResult(
        allowed=False, capability=capability, action=action, target=target,
        device=device, agent=agent,
    )

    # ------------------------------------------------- 1. permission check
    perm = permission_engine.check(capability, context=params, path=target if _looks_like_path(target) else None)

    # ------------------------------------------------------- 2. risk check
    assessment = risk_engine.assess(
        capability=capability,
        action=action,
        target=target,
        params=params,
        permission_requires_confirmation=perm.requires_confirmation,
        batch_size=batch_size,
    )
    result.risk = assessment.level
    result.risk_score = assessment.score

    if perm.decision == Decision.DENY:
        result.denied_by = "permission"
        result.reason = perm.reason
        audit_trail.denied(action=action, target=target, reason=perm.reason, risk=assessment.level.value,
                           agent=agent, device=device, task_id=task_id)
        emit(Topics.NOTIFICATION, kind="denied", title="SAM blocked an action",
             body=f"{action}: {perm.reason}", risk=assessment.level.value)
        result.duration_ms = int((time.time() - t0) * 1000)
        return result

    # -------------------------------------------------- 3. confirmation
    needs_confirm = assessment.requires_confirmation or perm.decision == Decision.CONFIRM
    if needs_confirm:
        if assessment.level == RiskLevel.CRITICAL and auto_deny_critical:
            result.denied_by = "risk"
            result.reason = "CRITICAL actions are never executed automatically"
            audit_trail.record(action=action, target=target, result="denied",
                               risk="CRITICAL", confirmation="auto_denied",
                               agent=agent, device=device, task_id=task_id)
            return result

        pc = await confirmation_engine.request(
            capability=capability,
            action=action,
            target=target,
            risk=assessment.level,
            reasons=assessment.reasons,
            style=assessment.confirmation_style,
            task_id=task_id,
            device=device,
            auto_deny_critical=auto_deny_critical,
        )
        result.confirmation_id = pc.id
        if not pc.decision:
            result.denied_by = "confirmation"
            result.reason = pc.note or "user denied the action"
            audit_trail.record(action=action, target=target, result="denied",
                               risk=assessment.level.value, confirmation="denied",
                               agent=agent, device=device, task_id=task_id,
                               detail={"reasons": assessment.reasons})
            result.duration_ms = int((time.time() - t0) * 1000)
            return result
        confirmation_state = "approved"
    else:
        confirmation_state = "not_required"

    # --------------------------------------------------------- 4. execute
    try:
        value = await asyncio.wait_for(run(), timeout=timeout)
    except asyncio.TimeoutError:
        result.denied_by = "timeout"
        result.error = f"action timed out after {timeout}s"
        result.reason = result.error
        audit_trail.failed(action=action, target=target, error=result.error,
                           risk=assessment.level.value, confirmation=confirmation_state,
                           agent=agent, device=device, task_id=task_id)
        result.duration_ms = int((time.time() - t0) * 1000)
        return result
    except asyncio.CancelledError:
        result.denied_by = "cancelled"
        result.error = "cancelled"
        audit_trail.record(action=action, target=target, result="skipped",
                           risk=assessment.level.value, confirmation=confirmation_state,
                           agent=agent, device=device, task_id=task_id)
        raise
    except Exception as exc:
        result.denied_by = "error"
        result.error = f"{type(exc).__name__}: {exc}"
        result.reason = result.error
        audit_trail.failed(action=action, target=target, error=result.error,
                           risk=assessment.level.value, confirmation=confirmation_state,
                           agent=agent, device=device, task_id=task_id)
        result.duration_ms = int((time.time() - t0) * 1000)
        return result

    # --------------------------------------------------------- 5. verify
    if verify is not None:
        try:
            ok = bool(await verify(value))
        except Exception as exc:
            ok = False
            result.error = f"verification error: {exc}"
        result.verified = ok
        if not ok:
            result.allowed = False
            result.denied_by = "verification"
            result.reason = result.reason or "verification reported the action did not take effect"
            audit_trail.record(action=action, target=target, result="failed",
                               risk=assessment.level.value, confirmation=confirmation_state,
                               agent=agent, device=device, task_id=task_id,
                               detail={"verification": False, "error": result.error})
            result.duration_ms = int((time.time() - t0) * 1000)
            return result

    # ---------------------------------------------------------- 6. success
    result.allowed = True
    result.value = value
    result.reason = "ok"
    result.duration_ms = int((time.time() - t0) * 1000)
    audit_trail.record(
        action=action, target=target, result="ok", risk=assessment.level.value,
        confirmation=confirmation_state, agent=agent, device=device, task_id=task_id,
        detail={
            "capability": capability,
            "duration_ms": result.duration_ms,
            "reversible": assessment.reversible,
            "reasons": assessment.reasons[:6],
        },
    )
    emit(Topics.AUDIT, action=action, target=target, result="ok", risk=assessment.level.value,
         device=device, agent=agent, task_id=task_id)
    return result


def _looks_like_path(value: str) -> bool:
    if not value:
        return False
    v = value.strip()
    return (
        v.startswith(("/", "~/", "\\\\"))
        or (len(v) > 2 and v[1] == ":" and v[2] in "/\\")   # C:\ or C:/
        or "/" in v
        or "\\" in v
    )
