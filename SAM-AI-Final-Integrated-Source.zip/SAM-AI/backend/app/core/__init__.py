"""SAM backend package: ``backend.app.core``."""
