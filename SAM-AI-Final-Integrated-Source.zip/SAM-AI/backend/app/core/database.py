"""
backend.app.core.database
=========================

Async SQLAlchemy engine + session factory.

SQLite by default (zero-setup, file lives in ``data/db/sam.db``) and swappable
to PostgreSQL for production by setting ``DATABASE_URL`` in ``.env``::

    DATABASE_URL=postgresql+asyncpg://sam:sam@localhost:5432/sam
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from sqlalchemy import event
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from backend.app.config import settings


class Base(DeclarativeBase):
    """Declarative base class for every SAM ORM model."""


def _make_engine() -> AsyncEngine:
    url = settings.effective_database_url
    kwargs: dict = {"echo": False, "future": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}
    else:
        kwargs.update({"pool_size": 10, "max_overflow": 20, "pool_pre_ping": True})
    return create_async_engine(url, **kwargs)


engine: AsyncEngine = _make_engine()
SessionLocal: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=engine, expire_on_commit=False, class_=AsyncSession
)


@event.listens_for(engine.sync_engine, "connect")
def _sqlite_pragmas(dbapi_connection, _record):  # pragma: no cover - driver hook
    """Enable WAL + foreign keys on SQLite for concurrent reads/writes."""
    try:
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL;")
        cursor.execute("PRAGMA synchronous=NORMAL;")
        cursor.execute("PRAGMA foreign_keys=ON;")
        cursor.close()
    except Exception:
        pass


async def init_db() -> None:
    """Create all tables. Idempotent — safe to call on every startup."""
    settings.ensure_dirs()
    # Import models so they register on Base.metadata before create_all()
    from backend.app.core import models as _orm_models  # noqa: F401

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db() -> None:
    await engine.dispose()


@asynccontextmanager
async def session_scope() -> AsyncIterator[AsyncSession]:
    """Transactional scope: commits on success, rolls back on exception."""
    async with SessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_session() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency — ``Depends(get_session)``."""
    async with SessionLocal() as session:
        yield session
