"""
backend.app.core.task_graph
===========================

Turns a flat list of :class:`TaskStepModel` into an executable DAG.

``USER REQUEST -> PLANNER -> TASK GRAPH -> [A B C] -> COMBINE -> VERIFY -> COMPLETE``

Capabilities required by the spec:

* **Sequential** execution (``depends_on`` chains)
* **Parallel** execution (independent nodes run with ``asyncio.gather``)
* **Conditional** execution (``condition`` is a tiny safe expression evaluated
  against the outputs of previous steps)
* **Retry** and **error recovery**
* **Cancellation** and **pause** honoured between nodes
* Cycle detection, orphan dependency detection and topological wave ordering
"""

from __future__ import annotations

import ast
import asyncio
import operator
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set

from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import TaskModel, TaskStatus, TaskStepModel

log = get_logger("task_graph")

# A node executor receives (task, step, context) and returns any JSON-able value.
NodeExecutor = Callable[[TaskModel, TaskStepModel, Dict[str, Any]], Awaitable[Any]]


class GraphError(Exception):
    """Raised when the plan itself is invalid (cycle, missing dependency)."""


@dataclass
class GraphResult:
    ok: bool
    outputs: Dict[str, Any] = field(default_factory=dict)
    errors: List[Dict[str, Any]] = field(default_factory=list)
    duration_ms: int = 0
    nodes_run: int = 0
    nodes_skipped: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "outputs": self.outputs,
            "errors": self.errors,
            "duration_ms": self.duration_ms,
            "nodes_run": self.nodes_run,
            "nodes_skipped": self.nodes_skipped,
        }


# ---------------------------------------------------------------------------
# Safe condition evaluation (no eval, no exec)
# ---------------------------------------------------------------------------
_ALLOWED_OPS = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.And: lambda a, b: a and b,
    ast.Or: lambda a, b: a or b,
}


def safe_eval(expr: str, ctx: Dict[str, Any]) -> Any:
    """
    Evaluate a small boolean/arithmetic expression against ``ctx``.

    Only literals, names, attribute-free subscripts, comparisons, boolean
    operators and basic arithmetic are permitted — no calls, no imports, no
    attribute access. Anything else evaluates to ``False`` instead of raising.

    Example expressions::

        steps.search.ok == true
        outputs.fetch.status in ['ok', 'cached']
        battery.percent < 20
    """
    if not expr or not expr.strip():
        return True
    expr = expr.strip().replace("true", "True").replace("false", "False")
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError:
        log.warning("condition is not parseable, treating as False: %r", expr)
        return False

    def ev(node: ast.AST) -> Any:
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return ctx.get(node.id)
        if isinstance(node, ast.Subscript):
            base = ev(node.value)
            key = ev(node.slice)
            try:
                return base[key]
            except Exception:
                return None
        if isinstance(node, ast.BoolOp):
            vals = [ev(v) for v in node.values]
            if isinstance(node.op, ast.And):
                return all(vals)
            return any(vals)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            return not ev(node.operand)
        if isinstance(node, ast.Compare):
            left = ev(node.left)
            for op, right_node in zip(node.ops, node.comparators):
                right = ev(right_node)
                fn = _ALLOWED_OPS.get(type(op))
                if fn is None:
                    return False
                if not fn(left, right):
                    return False
                left = right
            return True
        if isinstance(node, ast.BinOp):
            fn = _ALLOWED_OPS.get(type(node.op))
            if fn is None:
                return False
            return fn(ev(node.left), ev(node.right))
        if isinstance(node, ast.List):
            return [ev(e) for e in node.elts]
        if isinstance(node, ast.Tuple):
            return tuple(ev(e) for e in node.elts)
        return None

    try:
        return ev(tree)
    except Exception as exc:
        log.debug("condition %r failed: %s", expr, exc)
        return False


# ---------------------------------------------------------------------------
# Graph
# ---------------------------------------------------------------------------
class TaskGraph:
    """Executable DAG over :class:`TaskStepModel` nodes."""

    def __init__(self, task: TaskModel, executor: NodeExecutor) -> None:
        self.task = task
        self.executor = executor
        self.nodes: Dict[str, TaskStepModel] = {s.id: s for s in task.steps}
        self.outputs: Dict[str, Any] = {}
        self._validate()

    # ----------------------------------------------------------------- prep
    def _validate(self) -> None:
        unknown: Set[str] = set()
        for s in self.task.steps:
            for d in s.depends_on:
                if d not in self.nodes:
                    unknown.add(d)
        if unknown:
            raise GraphError(f"steps depend on unknown step ids: {sorted(unknown)}")
        if self._cycle():
            raise GraphError("task graph contains a dependency cycle")

    def _cycle(self) -> bool:
        WHITE, GREY, BLACK = 0, 1, 2
        colour: Dict[str, int] = {k: WHITE for k in self.nodes}

        def visit(n: str) -> bool:
            colour[n] = GREY
            for dep in self.nodes[n].depends_on:
                if colour.get(dep) == GREY:
                    return True
                if colour.get(dep) == WHITE and visit(dep):
                    return True
            colour[n] = BLACK
            return False

        return any(colour[k] == WHITE and visit(k) for k in list(colour))

    def waves(self) -> List[List[TaskStepModel]]:
        """Topological 'waves' — each wave can run fully in parallel."""
        done: Set[str] = set()
        remaining = list(self.task.steps)
        out: List[List[TaskStepModel]] = []
        guard = 0
        while remaining and guard < 1000:
            guard += 1
            ready = [s for s in remaining if all(d in done for d in s.depends_on)]
            if not ready:  # pragma: no cover - unreachable after _cycle()
                raise GraphError("cannot resolve execution order")
            # group explicitly tagged parallel groups together
            out.append(ready)
            for s in ready:
                done.add(s.id)
            remaining = [s for s in remaining if s.id not in done]
        return out

    def context(self) -> Dict[str, Any]:
        return {
            "outputs": self.outputs,
            "steps": self.outputs,
            "task": self.task.id,
            "request": self.task.request,
        }

    # ------------------------------------------------------------------ run
    async def run(self, on_progress: Optional[Callable[[float, str], Awaitable[None]]] = None) -> GraphResult:
        t0 = time.time()
        result = GraphResult(ok=True)
        waves = self.waves()
        total = max(1, len(self.task.steps))
        completed = 0

        emit(Topics.TASK_PLAN, task_id=self.task.id, waves=[[s.id for s in w] for w in waves])

        for wave_no, wave in enumerate(waves, start=1):
            from backend.app.core.task_store import task_store

            if task_store.is_cancelled(self.task.id):
                for s in wave:
                    s.status = TaskStatus.CANCELLED
                result.ok = False
                result.errors.append({"stage": "graph", "error": "cancelled"})
                break

            await task_store.wait_if_paused(self.task.id)

            results = await asyncio.gather(
                *[self._run_node(s, wave_no) for s in wave], return_exceptions=True
            )

            for step, res in zip(wave, results):
                completed += 1
                if isinstance(res, BaseException):
                    result.ok = False
                    result.errors.append({"step": step.id, "name": step.name, "error": str(res)})
                    step.error = str(res)
                    step.status = TaskStatus.FAILED
                elif step.status == TaskStatus.CANCELLED:
                    result.nodes_skipped += 1
                else:
                    result.nodes_run += 1
                    if step.error:
                        result.ok = False
                        result.errors.append({"step": step.id, "name": step.name, "error": step.error})

                pct = round(completed / total * 100, 1)
                if on_progress:
                    await on_progress(pct, f"wave {wave_no}: {step.name}")
                else:
                    await task_store.set_progress(self.task.id, pct, f"{step.name}")

        result.outputs = self.outputs
        result.duration_ms = int((time.time() - t0) * 1000)
        return result

    # ----------------------------------------------------------------- node
    async def _run_node(self, step: TaskStepModel, wave_no: int) -> Any:
        from backend.app.core.task_store import task_store

        if task_store.is_cancelled(self.task.id):
            step.status = TaskStatus.CANCELLED
            return None

        # conditional node -------------------------------------------------
        if step.condition and not safe_eval(step.condition, self.context()):
            step.status = TaskStatus.CANCELLED
            step.output = {"skipped": True, "reason": f"condition false: {step.condition}"}
            self.outputs[step.id] = step.output
            emit(
                Topics.TASK_STEP,
                task_id=self.task.id,
                step_id=step.id,
                status="SKIPPED",
                reason=step.condition,
            )
            return None

        step.status = TaskStatus.RUNNING
        # a datetime, not a float: the ORM column is DateTime and SQLite rejects
        # anything else (this silently broke task persistence)
        step.started_at = datetime.now(timezone.utc)
        await task_store.set_step_status(self.task.id, step.id, TaskStatus.RUNNING)
        log.info("task=%s wave=%d step=%s agent=%s", self.task.id, wave_no, step.name, step.agent.value)

        attempts = max(1, step.retries + 1)
        last_error: Optional[str] = None

        for attempt in range(1, attempts + 1):
            if task_store.is_cancelled(self.task.id):
                step.status = TaskStatus.CANCELLED
                return None
            await task_store.wait_if_paused(self.task.id)
            try:
                output = await asyncio.wait_for(
                    self.executor(self.task, step, self.context()), timeout=step.timeout_seconds
                )
                step.output = output
                step.error = None
                step.status = TaskStatus.COMPLETED
                self.outputs[step.id] = output
                await task_store.set_step_status(self.task.id, step.id, TaskStatus.COMPLETED, output=output)
                return output
            except asyncio.CancelledError:
                step.status = TaskStatus.CANCELLED
                await task_store.set_step_status(self.task.id, step.id, TaskStatus.CANCELLED, error="cancelled")
                raise
            except asyncio.TimeoutError as exc:
                last_error = f"timeout after {step.timeout_seconds}s"
                log.warning("step %s %s", step.name, last_error)
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                log.warning("step %s attempt %d failed: %s", step.name, attempt, last_error)

            if attempt < attempts:
                emit(
                    Topics.AGENT_ERROR,
                    task_id=self.task.id,
                    step=step.name,
                    attempt=attempt,
                    error=last_error,
                    retrying=True,
                )
                await asyncio.sleep(min(2 ** attempt * 0.4, 5.0))

        step.error = last_error
        step.status = TaskStatus.FAILED
        self.outputs[step.id] = {"ok": False, "error": last_error}
        await task_store.set_step_status(self.task.id, step.id, TaskStatus.FAILED, error=last_error or "")
        return None


# ---------------------------------------------------------------------------
# Helpers used by the planner
# ---------------------------------------------------------------------------
def linear_graph(steps: List[TaskStepModel]) -> List[TaskStepModel]:
    """Chain steps sequentially: each depends on the previous one."""
    prev: Optional[str] = None
    for i, s in enumerate(steps):
        s.index = i
        s.depends_on = [prev] if prev else []
        prev = s.id
    return steps


def fan_out(steps: List[TaskStepModel], join: Optional[TaskStepModel] = None) -> List[TaskStepModel]:
    """Run all ``steps`` in parallel, then optionally a ``join`` step."""
    for i, s in enumerate(steps):
        s.index = i
        s.depends_on = []
    out = list(steps)
    if join is not None:
        join.depends_on = [s.id for s in steps]
        join.index = len(steps)
        out.append(join)
    return out
