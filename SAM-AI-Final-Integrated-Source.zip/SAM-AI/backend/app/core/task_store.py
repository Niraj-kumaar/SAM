"""
backend.app.core.task_store
===========================

Authoritative registry of every SAM task.

* Hot path: an in-memory dict keyed by task id (fast, no DB round-trip while a
  task graph is executing).
* Cold path: SQLAlchemy persistence so history survives restarts.
* Control surface used by the Task Control Center UI:
  start / pause / resume / cancel / restart / prioritise / inspect / stream logs.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import delete, select

from backend.app.core.database import SessionLocal
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import Task as TaskRow
from backend.app.core.models import TaskStep as StepRow
from backend.app.core.schemas import TaskModel, TaskStatus

log = get_logger("task_store")


def _now() -> datetime:
    return datetime.now(timezone.utc)


class TaskStore:
    """Thread/async-safe task registry with DB persistence."""

    def __init__(self) -> None:
        self._tasks: Dict[str, TaskModel] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._cancel: Dict[str, asyncio.Event] = {}
        self._pause: Dict[str, asyncio.Event] = {}   # set => paused
        self._futures: Dict[str, asyncio.Future] = {}
        self._mutex = asyncio.Lock()

    # ---------------------------------------------------------------- create
    async def create(self, task: TaskModel, persist: bool = True) -> TaskModel:
        async with self._mutex:
            self._tasks[task.id] = task
            self._cancel[task.id] = asyncio.Event()
            self._pause[task.id] = asyncio.Event()
            self._locks[task.id] = asyncio.Lock()
        if persist:
            await self._persist(task)
        emit(
            Topics.TASK_CREATED,
            task_id=task.id,
            title=task.title,
            status=task.status.value,
            agent=task.agent.value,
            device=task.device.value,
            steps=len(task.steps),
        )
        return task

    # ----------------------------------------------------------------- read
    def get(self, task_id: str) -> Optional[TaskModel]:
        return self._tasks.get(task_id)

    def all(self) -> List[TaskModel]:
        return sorted(self._tasks.values(), key=lambda t: t.created_at, reverse=True)

    def active(self) -> List[TaskModel]:
        live = {
            TaskStatus.QUEUED,
            TaskStatus.PLANNING,
            TaskStatus.RUNNING,
            TaskStatus.WAITING,
            TaskStatus.CONFIRMATION,
            TaskStatus.PAUSED,
            TaskStatus.RECOVERING,
        }
        return [t for t in self.all() if t.status in live]

    def by_status(self, status: TaskStatus) -> List[TaskModel]:
        return [t for t in self.all() if t.status == status]

    def counts(self) -> Dict[str, int]:
        out: Dict[str, int] = {s.value: 0 for s in TaskStatus}
        for t in self._tasks.values():
            out[t.status.value] = out.get(t.status.value, 0) + 1
        return out

    # --------------------------------------------------------------- update
    async def set_status(
        self, task_id: str, status: TaskStatus, action: str = "", persist: bool = True
    ) -> Optional[TaskModel]:
        task = self._tasks.get(task_id)
        if not task:
            return None
        task.status = status
        if action:
            task.current_action = action
        if status == TaskStatus.RUNNING and task.started_at is None:
            task.started_at = _now()
        if status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED):
            task.finished_at = _now()
            if status == TaskStatus.COMPLETED:
                task.progress = 100.0
        if persist:
            await self._persist(task)
        emit(
            Topics.TASK_STATUS,
            task_id=task_id,
            status=status.value,
            action=task.current_action,
            progress=task.progress,
        )
        return task

    async def set_progress(
        self, task_id: str, percent: float, action: str = "", persist: bool = False
    ) -> None:
        task = self._tasks.get(task_id)
        if not task:
            return
        task.progress = max(0.0, min(100.0, float(percent)))
        if action:
            task.current_action = action
        if persist:
            await self._persist(task)
        emit(
            Topics.TASK_PROGRESS,
            task_id=task_id,
            progress=task.progress,
            action=task.current_action,
            status=task.status.value,
        )

    async def finish(
        self, task_id: str, result: Any = None, error: Optional[str] = None
    ) -> Optional[TaskModel]:
        task = self._tasks.get(task_id)
        if not task:
            return None
        if error:
            task.error = error
            task.result = result if isinstance(result, str) else json.dumps(result, default=str)
            await self.set_status(task_id, TaskStatus.FAILED, "failed")
            emit(Topics.TASK_FAILED, task_id=task_id, error=error)
        else:
            task.result = result if isinstance(result, str) else json.dumps(result, default=str, indent=2)
            await self.set_status(task_id, TaskStatus.COMPLETED, "completed")
            emit(Topics.TASK_COMPLETED, task_id=task_id, result_preview=str(task.result)[:2000])
        return task

    async def set_step_status(
        self, task_id: str, step_id: str, status: TaskStatus, output: Any = None, error: str = ""
    ) -> None:
        task = self._tasks.get(task_id)
        if not task:
            return
        for s in task.steps:
            if s.id == step_id:
                s.status = status
                if status == TaskStatus.RUNNING and s.started_at is None:
                    s.started_at = _now()
                if status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED):
                    s.finished_at = _now()
                if output is not None:
                    s.output = output
                if error:
                    s.error = error
                break
        emit(
            Topics.TASK_STEP,
            task_id=task_id,
            step_id=step_id,
            status=status.value,
            error=error,
            output_preview=(str(output)[:500] if output is not None else None),
        )

    # ------------------------------------------------------- control verbs
    async def pause(self, task_id: str) -> bool:
        ev = self._pause.get(task_id)
        if ev is None:
            return False
        ev.set()
        await self.set_status(task_id, TaskStatus.PAUSED, "paused by user")
        return True

    async def resume(self, task_id: str) -> bool:
        ev = self._pause.get(task_id)
        if ev is None:
            return False
        ev.clear()
        await self.set_status(task_id, TaskStatus.RUNNING, "resumed")
        return True

    async def cancel(self, task_id: str) -> bool:
        ev = self._cancel.get(task_id)
        if ev is None:
            return False
        ev.set()
        self._pause.get(task_id, asyncio.Event()).clear()
        fut = self._futures.get(task_id)
        if fut and not fut.done():
            fut.cancel()
        await self.set_status(task_id, TaskStatus.CANCELLED, "cancelled by user")
        emit(Topics.TASK_CANCELLED, task_id=task_id)
        return True

    async def reprioritise(self, task_id: str, priority: int) -> bool:
        task = self._tasks.get(task_id)
        if not task:
            return False
        task.priority = max(1, min(10, int(priority)))
        await self._persist(task)
        emit(Topics.TASK_STATUS, task_id=task_id, status=task.status.value, priority=task.priority)
        return True

    def is_cancelled(self, task_id: str) -> bool:
        return self._cancel.get(task_id, asyncio.Event()).is_set()

    def is_paused(self, task_id: str) -> bool:
        return self._pause.get(task_id, asyncio.Event()).is_set()

    async def wait_if_paused(self, task_id: str, poll: float = 0.25) -> None:
        """Block while the task is paused; return immediately if cancelled."""
        ev = self._pause.get(task_id)
        while ev is not None and ev.is_set():
            if self.is_cancelled(task_id):
                return
            await asyncio.sleep(poll)

    def register_future(self, task_id: str, fut: asyncio.Future) -> None:
        self._futures[task_id] = fut

    # ------------------------------------------------------------ discard
    def discard(self, task_id: str) -> bool:
        """Forget a finished task (memory only — the DB row stays for the audit trail)."""
        if task_id not in self._tasks:
            return False
        task = self._tasks[task_id]
        if task.status in (TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.PLANNING):
            return False
        self._tasks.pop(task_id, None)
        self._cancel.pop(task_id, None)
        self._pause.pop(task_id, None)
        self._futures.pop(task_id, None)
        emit(Topics.TASK_STATUS, task_id=task_id, status="DISCARDED")
        return True

    # ------------------------------------------------------------ restart
    async def restart(self, task_id: str) -> Optional[TaskModel]:
        task = self._tasks.get(task_id)
        if not task:
            return None
        clone = task.model_copy(deep=True)
        clone.status = TaskStatus.QUEUED
        clone.progress = 0.0
        clone.error = None
        clone.result = None
        clone.started_at = None
        clone.finished_at = None
        clone.current_action = "restarted"
        for s in clone.steps:
            s.status = TaskStatus.QUEUED
            s.output = None
            s.error = None
            s.started_at = None
            s.finished_at = None
        self._cancel[task_id] = asyncio.Event()
        self._pause[task_id] = asyncio.Event()
        await self._persist(clone)
        emit(Topics.TASK_STATUS, task_id=task_id, status="QUEUED", action="restarted")
        return clone

    # ---------------------------------------------------------- persistence
    async def _persist(self, task: TaskModel) -> None:
        try:
            async with SessionLocal() as db:
                row = await db.get(TaskRow, task.id)
                if row is None:
                    row = TaskRow(id=task.id)
                    db.add(row)
                row.title = task.title
                row.request = task.request
                row.status = task.status.value
                row.priority = task.priority
                row.kind = task.kind
                row.agent = task.agent.value
                row.device = task.device.value
                row.progress = task.progress
                row.current_action = task.current_action
                row.result = task.result
                row.error = task.error
                row.risk_level = task.risk_level.value
                row.requires_confirmation = task.requires_confirmation
                row.plan_json = json.dumps([s.model_dump(mode="json") for s in task.steps], default=str)
                row.created_at = task.created_at
                row.started_at = task.started_at
                row.finished_at = task.finished_at

                await db.execute(delete(StepRow).where(StepRow.task_id == task.id))
                for s in task.steps:
                    db.add(
                        StepRow(
                            task_id=task.id,
                            index=s.index,
                            name=s.name,
                            agent=s.agent.value,
                            device=s.device.value,
                            status=s.status.value,
                            depends_on=json.dumps(s.depends_on),
                            input_json=json.dumps(s.params, default=str),
                            output_json=json.dumps(s.output, default=str) if s.output is not None else "{}",
                            error=s.error,
                            started_at=s.started_at,
                            finished_at=s.finished_at,
                        )
                    )
                await db.commit()
        except Exception as exc:  # pragma: no cover
            log.warning("task persist failed for %s: %s", task.id, exc)

    async def load_from_db(self, limit: int = 200) -> int:
        """Hydrate recent tasks into memory on startup."""
        loaded = 0
        try:
            async with SessionLocal() as db:
                rows = (
                    await db.execute(select(TaskRow).order_by(TaskRow.created_at.desc()).limit(limit))
                ).scalars().all()
                for r in rows:
                    if r.id in self._tasks:
                        continue
                    try:
                        plan = json.loads(r.plan_json or "[]")
                    except Exception:
                        plan = []
                    task = TaskModel(
                        id=r.id,
                        title=r.title,
                        request=r.request,
                        kind=r.kind,
                        status=TaskStatus(r.status) if r.status in TaskStatus._value2member_map_ else TaskStatus.QUEUED,
                        priority=r.priority,
                        agent=r.agent,
                        device=r.device,
                        progress=r.progress,
                        current_action=r.current_action or "",
                        result=r.result,
                        error=r.error,
                        risk_level=r.risk_level,
                        requires_confirmation=r.requires_confirmation,
                        created_at=r.created_at or _now(),
                        started_at=r.started_at,
                        finished_at=r.finished_at,
                        steps=plan,
                    )
                    # anything still 'RUNNING' when we booted is actually dead
                    if task.status in (TaskStatus.RUNNING, TaskStatus.PLANNING, TaskStatus.WAITING):
                        task.status = TaskStatus.FAILED
                        task.error = task.error or "interrupted by restart"
                    self._tasks[task.id] = task
                    self._cancel[task.id] = asyncio.Event()
                    self._pause[task.id] = asyncio.Event()
                    loaded += 1
        except Exception as exc:  # pragma: no cover
            log.warning("task history load failed: %s", exc)
        return loaded

    async def purge(self, keep_days: int = 30) -> int:
        """Delete finished tasks older than ``keep_days`` from memory + DB."""
        cutoff = _now().timestamp() - keep_days * 86400
        removed = 0
        terminal = {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED}
        for tid, t in list(self._tasks.items()):
            if t.status in terminal and t.created_at.timestamp() < cutoff:
                del self._tasks[tid]
                removed += 1
        try:
            async with SessionLocal() as db:
                await db.execute(delete(TaskRow).where(TaskRow.created_at < datetime.fromtimestamp(cutoff, tz=timezone.utc)))
                await db.commit()
        except Exception:
            pass
        return removed


task_store = TaskStore()
