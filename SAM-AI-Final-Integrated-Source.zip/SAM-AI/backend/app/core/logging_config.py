"""
backend.app.core.logging_config
===============================

Console + rotating file logging for the whole SAM platform.

* Console: colourised (``rich``) when available, plain otherwise.
* File:    ``data/logs/sam.log`` — rolling, 5 MB x 5 backups.
* Audit:   separate logger ``sam.audit`` fed by the Security Engine.
"""

from __future__ import annotations

import logging
import logging.handlers
import sys
import time
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional

from backend.app.config import settings

_CONFIGURED = False

_FMT = "%(asctime)s | %(levelname)-7s | %(name)-28s | %(message)s"
_DATEFMT = "%H:%M:%S"


def setup_logging(level: str | None = None) -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return

    lvl = (level or settings.sam_log_level).upper()
    root = logging.getLogger()
    root.setLevel(lvl)
    for h in list(root.handlers):
        root.removeHandler(h)

    # ---- console -------------------------------------------------------
    stream = logging.StreamHandler(sys.stdout)
    stream.setLevel(lvl)
    try:
        from rich.logging import RichHandler

        console_handler: logging.Handler = RichHandler(
            rich_tracebacks=True, show_path=False, markup=False, omit_repeated_times=False
        )
        console_handler.setLevel(lvl)
        root.addHandler(console_handler)
    except Exception:  # rich not installed -> plain formatter
        stream.setFormatter(logging.Formatter(_FMT, _DATEFMT))
        root.addHandler(stream)

    # ---- file ----------------------------------------------------------
    log_dir: Path = settings.sam_data_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    file_handler = logging.handlers.RotatingFileHandler(
        log_dir / "sam.log", maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setLevel(lvl)
    file_handler.setFormatter(logging.Formatter(_FMT, _DATEFMT))
    root.addHandler(file_handler)

    # ---- audit (JSON lines, separate file) -----------------------------
    audit = logging.getLogger("sam.audit")
    audit.setLevel(logging.INFO)
    audit.propagate = False
    audit_handler = logging.handlers.RotatingFileHandler(
        log_dir / "audit.log", maxBytes=5 * 1024 * 1024, backupCount=10, encoding="utf-8"
    )
    audit_handler.setFormatter(logging.Formatter("%(message)s"))
    audit.addHandler(audit_handler)

    # ---- quiet noisy third-party loggers -------------------------------
    for noisy in ("httpx", "httpcore", "watchfiles", "asyncio", "urllib3", "PIL"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    _install_ring()
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced logger, e.g. ``get_logger('agents.pc')``."""
    setup_logging()
    return logging.getLogger(f"sam.{name}")


# ---------------------------------------------------------------------------
# In-memory ring buffer so the UI can show live logs without tailing a file
# ---------------------------------------------------------------------------
class _RingHandler(logging.Handler):
    """Keeps the last N records in memory for ``GET /api/v1/logs``."""

    def __init__(self, capacity: int = 1000) -> None:
        super().__init__()
        self.capacity = capacity
        self.records: deque = deque(maxlen=capacity)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.records.append({
                "ts": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(record.created)),
                "level": record.levelname,
                "logger": record.name.replace("sam.", ""),
                "message": record.getMessage()[:800],
            })
        except Exception:  # pragma: no cover - logging must never raise
            pass


_ring: Optional[_RingHandler] = None


def _install_ring() -> _RingHandler:
    global _ring
    if _ring is None:
        _ring = _RingHandler()
        _ring.setLevel(logging.INFO)
        logging.getLogger("sam").addHandler(_ring)
    return _ring


def recent_logs(limit: int = 200, level: Optional[str] = None) -> List[Dict[str, Any]]:
    """Most recent log lines, newest last (ready to render in a console view)."""
    ring = _install_ring()
    rows = list(ring.records)
    if level:
        wanted = level.upper()
        order = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40, "CRITICAL": 50}
        threshold = order.get(wanted, 20)
        rows = [r for r in rows if order.get(r["level"], 20) >= threshold]
    return rows[-max(1, min(int(limit), ring.capacity)):]
