"""
backend.app.core.models
=======================

Persistent ORM tables. Everything the UI can inspect later (tasks, audit log,
memory, automations, devices) is stored here.

Table map
---------
==========================  ===============================================
``tasks``                   Every task SAM has ever planned/executed
``task_steps``              Nodes of the task graph (agent, device, result)
``audit_events``            Immutable security/activity log
``memory_items``            Long-term, project, device, semantic memory
``conversations``           Chat/voice session headers
``messages``                Individual turns inside a conversation
``automations``             WHEN -> IF -> DO -> VERIFY rules
``scheduled_jobs``          Materialised scheduler entries
``devices``                 Registered PC / phone / browser endpoints
``permissions``             Per-capability user grants and overrides
``model_usage``             Token + latency accounting per model call
``calendar_events``         SAM's own calendar (phone events sync in here)
``market_trades``           Trade journal: planned / open / closed positions
``price_alerts``            Price & indicator alerts watched by the poller
``paper_positions``         Virtual (paper) trading portfolio
``paper_account``           Single-row virtual balance and realised P&L
==========================  ===============================================
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.app.core.database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Task(Base):
    __tablename__ = "tasks"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(255), default="")
    request: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(32), default="QUEUED", index=True)
    priority: Mapped[int] = mapped_column(Integer, default=5)
    kind: Mapped[str] = mapped_column(String(32), default="general")
    agent: Mapped[str] = mapped_column(String(64), default="core")
    device: Mapped[str] = mapped_column(String(32), default="pc")
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    current_action: Mapped[str] = mapped_column(String(255), default="")
    result: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    risk_level: Mapped[str] = mapped_column(String(16), default="LOW")
    requires_confirmation: Mapped[bool] = mapped_column(Boolean, default=False)
    plan_json: Mapped[str] = mapped_column(Text, default="[]")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    steps: Mapped[list["TaskStep"]] = relationship(
        back_populates="task", cascade="all, delete-orphan", lazy="selectin"
    )

    __table_args__ = (Index("ix_tasks_created", "created_at"),)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "request": self.request,
            "status": self.status,
            "priority": self.priority,
            "kind": self.kind,
            "agent": self.agent,
            "device": self.device,
            "progress": self.progress,
            "current_action": self.current_action,
            "result": self.result,
            "error": self.error,
            "risk_level": self.risk_level,
            "requires_confirmation": self.requires_confirmation,
            "plan": _loads(self.plan_json),
            "created_at": _iso(self.created_at),
            "started_at": _iso(self.started_at),
            "finished_at": _iso(self.finished_at),
            "steps": [s.to_dict() for s in (self.steps or [])],
        }


class TaskStep(Base):
    __tablename__ = "task_steps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    task_id: Mapped[str] = mapped_column(ForeignKey("tasks.id", ondelete="CASCADE"), index=True)
    index: Mapped[int] = mapped_column(Integer, default=0)
    name: Mapped[str] = mapped_column(String(128), default="")
    agent: Mapped[str] = mapped_column(String(64), default="core")
    device: Mapped[str] = mapped_column(String(32), default="pc")
    status: Mapped[str] = mapped_column(String(32), default="QUEUED")
    depends_on: Mapped[str] = mapped_column(Text, default="[]")
    input_json: Mapped[str] = mapped_column(Text, default="{}")
    output_json: Mapped[str] = mapped_column(Text, default="{}")
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    task: Mapped["Task"] = relationship(back_populates="steps")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "index": self.index,
            "name": self.name,
            "agent": self.agent,
            "device": self.device,
            "status": self.status,
            "depends_on": _loads(self.depends_on),
            "input": _loads(self.input_json),
            "output": _loads(self.output_json),
            "error": self.error,
            "started_at": _iso(self.started_at),
            "finished_at": _iso(self.finished_at),
        }


class AuditEvent(Base):
    """Append-only security / activity log. Never updated, only appended."""

    __tablename__ = "audit_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    device: Mapped[str] = mapped_column(String(32), default="pc")
    agent: Mapped[str] = mapped_column(String(64), default="core")
    action: Mapped[str] = mapped_column(String(128), default="")
    target: Mapped[str] = mapped_column(Text, default="")
    result: Mapped[str] = mapped_column(String(32), default="ok")
    risk: Mapped[str] = mapped_column(String(16), default="LOW")
    confirmation: Mapped[str] = mapped_column(String(32), default="not_required")
    task_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    detail_json: Mapped[str] = mapped_column(Text, default="{}")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "ts": _iso(self.ts),
            "device": self.device,
            "agent": self.agent,
            "action": self.action,
            "target": self.target,
            "result": self.result,
            "risk": self.risk,
            "confirmation": self.confirmation,
            "task_id": self.task_id,
            "detail": _loads(self.detail_json),
        }


class MemoryItem(Base):
    __tablename__ = "memory_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kind: Mapped[str] = mapped_column(String(32), default="long_term", index=True)
    key: Mapped[str] = mapped_column(String(255), default="", index=True)
    content: Mapped[str] = mapped_column(Text, default="")
    source: Mapped[str] = mapped_column(String(64), default="user")
    scope: Mapped[str] = mapped_column(String(128), default="global")
    importance: Mapped[float] = mapped_column(Float, default=0.5)
    tags: Mapped[str] = mapped_column(Text, default="[]")
    embedding_json: Mapped[str] = mapped_column(Text, default="[]")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (Index("ix_memory_kind_key", "kind", "key"),)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "kind": self.kind,
            "key": self.key,
            "content": self.content,
            "source": self.source,
            "scope": self.scope,
            "importance": self.importance,
            "tags": _loads(self.tags),
            "enabled": self.enabled,
            "created_at": _iso(self.created_at),
            "updated_at": _iso(self.updated_at),
        }


class Conversation(Base):
    __tablename__ = "conversations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(255), default="New conversation")
    channel: Mapped[str] = mapped_column(String(16), default="text")  # text | voice
    language: Mapped[str] = mapped_column(String(16), default="auto")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    messages: Mapped[list["Message"]] = relationship(
        back_populates="conversation", cascade="all, delete-orphan", lazy="selectin"
    )

    def to_dict(self, with_messages: bool = False) -> dict:
        d = {
            "id": self.id,
            "title": self.title,
            "channel": self.channel,
            "language": self.language,
            "created_at": _iso(self.created_at),
            "updated_at": _iso(self.updated_at),
            "message_count": len(self.messages or []),
        }
        if with_messages:
            d["messages"] = [m.to_dict() for m in (self.messages or [])]
        return d


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    conversation_id: Mapped[str] = mapped_column(
        ForeignKey("conversations.id", ondelete="CASCADE"), index=True
    )
    role: Mapped[str] = mapped_column(String(16), default="user")  # user | assistant | system | tool
    content: Mapped[str] = mapped_column(Text, default="")
    model: Mapped[str] = mapped_column(String(128), default="")
    agent: Mapped[str] = mapped_column(String(64), default="core")
    task_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    attachments_json: Mapped[str] = mapped_column(Text, default="[]")
    meta_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    conversation: Mapped["Conversation"] = relationship(back_populates="messages")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "model": self.model,
            "agent": self.agent,
            "task_id": self.task_id,
            "attachments": _loads(self.attachments_json),
            "meta": _loads(self.meta_json),
            "created_at": _iso(self.created_at),
        }


class Automation(Base):
    __tablename__ = "automations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), default="Automation")
    description: Mapped[str] = mapped_column(Text, default="")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    trigger_type: Mapped[str] = mapped_column(String(32), default="time")
    trigger_clause: Mapped[str] = mapped_column(String(255), default="")
    trigger_json: Mapped[str] = mapped_column(Text, default="{}")
    condition_clause: Mapped[str] = mapped_column(Text, default="")
    condition_json: Mapped[str] = mapped_column(Text, default="{}")
    actions_json: Mapped[str] = mapped_column(Text, default="[]")
    verify_clause: Mapped[str] = mapped_column(Text, default="")
    verify_json: Mapped[str] = mapped_column(Text, default="{}")
    device: Mapped[str] = mapped_column(String(32), default="pc")
    priority: Mapped[str] = mapped_column(String(16), default="normal")
    confirmation: Mapped[str] = mapped_column(String(16), default="required")
    source: Mapped[str] = mapped_column(String(32), default="user")
    last_run_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_result: Mapped[str] = mapped_column(Text, default="")
    run_count: Mapped[int] = mapped_column(Integer, default=0)
    failure_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "enabled": self.enabled,
            "trigger_type": self.trigger_type,
            "when": self.trigger_clause,
            "trigger": _loads(self.trigger_json),
            "condition": self.condition_clause,
            "condition_data": _loads(self.condition_json),
            "actions": _loads(self.actions_json) or [],
            "verify": self.verify_clause,
            "verify_data": _loads(self.verify_json),
            "device": self.device,
            "priority": self.priority,
            "confirmation": self.confirmation,
            "source": self.source,
            "last_run_at": _iso(self.last_run_at),
            "last_result": self.last_result,
            "run_count": self.run_count,
            "failure_count": self.failure_count,
            "created_at": _iso(self.created_at),
        }


class ScheduledJob(Base):
    __tablename__ = "scheduled_jobs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    automation_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    name: Mapped[str] = mapped_column(String(255), default="Job")
    instruction: Mapped[str] = mapped_column(Text, default="")
    kind: Mapped[str] = mapped_column(String(32), default="once")  # once | interval | cron | date | event
    expression: Mapped[str] = mapped_column(String(255), default="")
    payload_json: Mapped[str] = mapped_column(Text, default="{}")
    device: Mapped[str] = mapped_column(String(32), default="pc")
    priority: Mapped[str] = mapped_column(String(16), default="normal")
    source: Mapped[str] = mapped_column(String(32), default="user")
    timezone: Mapped[str] = mapped_column(String(64), default="Asia/Kolkata")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    next_run_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_run_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_result: Mapped[str] = mapped_column(Text, default="")
    run_count: Mapped[int] = mapped_column(Integer, default=0)
    failure_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "automation_id": self.automation_id,
            "name": self.name,
            "title": self.name,
            "instruction": self.instruction,
            "kind": self.kind,
            "expression": self.expression,
            "payload": _loads(self.payload_json) or {},
            "device": self.device,
            "priority": self.priority,
            "source": self.source,
            "timezone": self.timezone,
            "enabled": self.enabled,
            "next_run_at": _iso(self.next_run_at),
            "next_run": _iso(self.next_run_at),
            "last_run_at": _iso(self.last_run_at),
            "last_run": _iso(self.last_run_at),
            "last_result": self.last_result,
            "runs": self.run_count,
            "failures": self.failure_count,
            "created_at": _iso(self.created_at),
        }


class Device(Base):
    __tablename__ = "devices"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(128), default="")
    kind: Mapped[str] = mapped_column(String(32), default="pc")  # pc | phone | browser | external
    online: Mapped[bool] = mapped_column(Boolean, default=False)
    platform: Mapped[str] = mapped_column(String(64), default="")
    address: Mapped[str] = mapped_column(String(255), default="")
    capabilities_json: Mapped[str] = mapped_column(Text, default="[]")
    state_json: Mapped[str] = mapped_column(Text, default="{}")
    last_seen_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    paired_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "kind": self.kind,
            "online": self.online,
            "platform": self.platform,
            "address": self.address,
            "capabilities": _loads(self.capabilities_json),
            "state": _loads(self.state_json),
            "last_seen_at": _iso(self.last_seen_at),
            "paired_at": _iso(self.paired_at),
        }


class PermissionGrant(Base):
    __tablename__ = "permissions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    capability: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    category: Mapped[str] = mapped_column(String(32), default="SYSTEM")
    granted: Mapped[bool] = mapped_column(Boolean, default=False)
    requires_confirmation: Mapped[bool] = mapped_column(Boolean, default=True)
    scope_json: Mapped[str] = mapped_column(Text, default="{}")
    note: Mapped[str] = mapped_column(String(255), default="")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    def to_dict(self) -> dict:
        return {
            "capability": self.capability,
            "category": self.category,
            "granted": self.granted,
            "requires_confirmation": self.requires_confirmation,
            "scope": _loads(self.scope_json),
            "note": self.note,
            "updated_at": _iso(self.updated_at),
        }


class ModelUsage(Base):
    __tablename__ = "model_usage"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    role: Mapped[str] = mapped_column(String(32), default="primary")
    provider: Mapped[str] = mapped_column(String(32), default="")
    model: Mapped[str] = mapped_column(String(128), default="")
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)
    ok: Mapped[bool] = mapped_column(Boolean, default=True)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    def to_dict(self) -> dict:
        return {
            "ts": _iso(self.ts),
            "role": self.role,
            "provider": self.provider,
            "model": self.model,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "latency_ms": self.latency_ms,
            "ok": self.ok,
            "error": self.error,
        }


class CalendarEvent(Base):
    """SAM's own calendar. Phone calendar events are synced into this table."""

    __tablename__ = "calendar_events"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(255), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    location: Mapped[str] = mapped_column(String(255), default="")
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    end_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    all_day: Mapped[bool] = mapped_column(Boolean, default=False)
    reminder_minutes: Mapped[int] = mapped_column(Integer, default=15)
    device: Mapped[str] = mapped_column(String(32), default="pc")
    source: Mapped[str] = mapped_column(String(32), default="sam")   # sam | google | phone | import
    external_id: Mapped[str] = mapped_column(String(255), default="")
    reminder_job_id: Mapped[str] = mapped_column(String(64), default="")
    status: Mapped[str] = mapped_column(String(32), default="scheduled")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "notes": self.description,
            "location": self.location,
            "start": _iso(self.start_at),
            "end": _iso(self.end_at),
            "all_day": self.all_day,
            "reminder_minutes": self.reminder_minutes,
            "device": self.device,
            "source": self.source,
            "external_id": self.external_id,
            "reminder_job_id": self.reminder_job_id,
            "status": self.status,
            "created_at": _iso(self.created_at),
        }


# ---------------------------------------------------------------------------
# Market Analyzer brain
# ---------------------------------------------------------------------------
class MarketTrade(Base):
    """
    One row per trade idea, from *planned* to *closed*.

    SAM writes a journal entry whenever the Market Analyzer produces a plan, so
    the user can review whether the analysis was any good — win rate, expectancy
    and mistakes over time, instead of memory.
    """

    __tablename__ = "market_trades"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(32), default="", index=True)
    asset_class: Mapped[str] = mapped_column(String(16), default="forex")
    product: Mapped[str] = mapped_column(String(16), default="spot")   # spot|binary|cfd|option|paper
    direction: Mapped[str] = mapped_column(String(8), default="long")  # long|short|up|down
    status: Mapped[str] = mapped_column(String(16), default="planned", index=True)
    account: Mapped[str] = mapped_column(String(16), default="paper")  # paper|live|journal
    timeframe: Mapped[str] = mapped_column(String(8), default="1h")
    strategy: Mapped[str] = mapped_column(String(64), default="")
    entry: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    exit: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    stop: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    units: Mapped[float] = mapped_column(Float, default=0.0)
    stake: Mapped[float] = mapped_column(Float, default=0.0)
    targets_json: Mapped[str] = mapped_column(Text, default="[]")
    pnl: Mapped[float] = mapped_column(Float, default=0.0)
    pnl_percent: Mapped[float] = mapped_column(Float, default=0.0)
    fees: Mapped[float] = mapped_column(Float, default=0.0)
    result: Mapped[str] = mapped_column(String(16), default="")        # win|loss|tie|open
    r_multiple: Mapped[float] = mapped_column(Float, default=0.0)
    signal_score: Mapped[float] = mapped_column(Float, default=0.0)
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    expiry_minutes: Mapped[int] = mapped_column(Integer, default=0)
    payout_percent: Mapped[float] = mapped_column(Float, default=0.0)
    reasons_json: Mapped[str] = mapped_column(Text, default="[]")
    notes: Mapped[str] = mapped_column(Text, default="")
    review: Mapped[str] = mapped_column(Text, default="")
    tags: Mapped[str] = mapped_column(String(255), default="")
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    def to_dict(self) -> dict:
        return {
            "id": self.id, "symbol": self.symbol, "asset_class": self.asset_class,
            "product": self.product, "direction": self.direction, "status": self.status,
            "account": self.account, "timeframe": self.timeframe, "strategy": self.strategy,
            "entry": self.entry, "exit": self.exit, "stop": self.stop, "units": self.units,
            "stake": self.stake, "targets": _loads(self.targets_json) or [],
            "pnl": round(self.pnl, 4), "pnl_percent": round(self.pnl_percent, 4),
            "fees": self.fees, "result": self.result, "r_multiple": round(self.r_multiple, 3),
            "signal_score": self.signal_score, "confidence": self.confidence,
            "expiry_minutes": self.expiry_minutes, "payout_percent": self.payout_percent,
            "reasons": _loads(self.reasons_json) or [], "notes": self.notes,
            "review": self.review, "tags": [t for t in (self.tags or "").split(",") if t],
            "opened_at": _iso(self.opened_at), "closed_at": _iso(self.closed_at),
        }


class PriceAlert(Base):
    """A watched condition. The markets poller checks it and emits an event."""

    __tablename__ = "price_alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(32), default="", index=True)
    condition: Mapped[str] = mapped_column(String(24), default="above")
    # above | below | cross_up | cross_down | percent_change | rsi_above | rsi_below
    # | atr_spike | signal_flip
    threshold: Mapped[float] = mapped_column(Float, default=0.0)
    timeframe: Mapped[str] = mapped_column(String(8), default="1h")
    window_minutes: Mapped[int] = mapped_column(Integer, default=60)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    message: Mapped[str] = mapped_column(String(255), default="")
    channel: Mapped[str] = mapped_column(String(32), default="desktop")  # desktop|phone|voice|all
    once: Mapped[bool] = mapped_column(Boolean, default=True)
    cooldown_minutes: Mapped[int] = mapped_column(Integer, default=60)
    triggered_count: Mapped[int] = mapped_column(Integer, default=0)
    triggered_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    trigger_price: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_checked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_price: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id, "symbol": self.symbol, "condition": self.condition,
            "threshold": self.threshold, "timeframe": self.timeframe,
            "window_minutes": self.window_minutes, "enabled": self.enabled,
            "message": self.message, "channel": self.channel, "once": self.once,
            "cooldown_minutes": self.cooldown_minutes, "triggered_count": self.triggered_count,
            "triggered_at": _iso(self.triggered_at), "trigger_price": self.trigger_price,
            "last_checked_at": _iso(self.last_checked_at), "last_price": self.last_price,
            "created_at": _iso(self.created_at),
        }


class PaperPosition(Base):
    """An open virtual (paper) trade. No real money is ever involved."""

    __tablename__ = "paper_positions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(32), default="", index=True)
    asset_class: Mapped[str] = mapped_column(String(16), default="forex")
    direction: Mapped[str] = mapped_column(String(8), default="long")
    units: Mapped[float] = mapped_column(Float, default=0.0)
    entry: Mapped[float] = mapped_column(Float, default=0.0)
    stop: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    targets_json: Mapped[str] = mapped_column(Text, default="[]")
    status: Mapped[str] = mapped_column(String(16), default="open", index=True)
    exit: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    pnl: Mapped[float] = mapped_column(Float, default=0.0)
    risk_amount: Mapped[float] = mapped_column(Float, default=0.0)
    notes: Mapped[str] = mapped_column(Text, default="")
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    def to_dict(self) -> dict:
        return {
            "id": self.id, "symbol": self.symbol, "asset_class": self.asset_class,
            "direction": self.direction, "units": self.units, "entry": self.entry,
            "stop": self.stop, "targets": _loads(self.targets_json) or [],
            "status": self.status, "exit": self.exit, "pnl": round(self.pnl, 4),
            "risk_amount": self.risk_amount, "notes": self.notes,
            "opened_at": _iso(self.opened_at), "closed_at": _iso(self.closed_at),
        }


class PaperAccount(Base):
    """Single-row virtual trading account."""

    __tablename__ = "paper_account"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default="default")
    currency: Mapped[str] = mapped_column(String(8), default="USD")
    starting_balance: Mapped[float] = mapped_column(Float, default=10000.0)
    balance: Mapped[float] = mapped_column(Float, default=10000.0)
    realised_pnl: Mapped[float] = mapped_column(Float, default=0.0)
    trades_closed: Mapped[int] = mapped_column(Integer, default=0)
    wins: Mapped[int] = mapped_column(Integer, default=0)
    losses: Mapped[int] = mapped_column(Integer, default=0)
    risk_per_trade_percent: Mapped[float] = mapped_column(Float, default=1.0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id, "currency": self.currency,
            "starting_balance": round(self.starting_balance, 2),
            "balance": round(self.balance, 2), "realised_pnl": round(self.realised_pnl, 2),
            "return_percent": round((self.balance / self.starting_balance - 1) * 100, 3)
            if self.starting_balance else 0.0,
            "trades_closed": self.trades_closed, "wins": self.wins, "losses": self.losses,
            "win_rate_percent": round(self.wins / self.trades_closed * 100, 2)
            if self.trades_closed else 0.0,
            "risk_per_trade_percent": self.risk_per_trade_percent,
            "updated_at": _iso(self.updated_at),
        }


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _iso(dt: Optional[datetime]) -> Optional[str]:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _loads(raw: Optional[str]) -> object:
    import json

    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return raw
