"""
backend.app.core.schemas
========================

Pydantic models shared by the API, the orchestrator and the desktop UI.
These mirror ``shared/schemas/*.json`` so Python, TypeScript and Kotlin can
all agree on the wire format.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


def _id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------
class TaskStatus(str, Enum):
    QUEUED = "QUEUED"
    PLANNING = "PLANNING"
    RUNNING = "RUNNING"
    WAITING = "WAITING"
    CONFIRMATION = "CONFIRMATION"
    PAUSED = "PAUSED"
    FAILED = "FAILED"
    RECOVERING = "RECOVERING"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class DeviceKind(str, Enum):
    PC = "pc"
    PHONE = "phone"
    BROWSER = "browser"
    CLOUD = "cloud"
    BOTH = "both"


class AgentName(str, Enum):
    CORE = "core"
    REASONING = "reasoning"
    CODING = "coding"
    RESEARCH = "research"
    WRITING = "writing"
    VISION = "vision"
    PC = "pc"
    PHONE = "phone"
    BROWSER = "browser"
    FILES = "files"
    CREATIVE = "creative"
    DATA = "data"
    MEMORY = "memory"
    SECURITY = "security"
    PLANNING = "planning"
    COMMUNICATION = "communication"
    VERIFICATION = "verification"
    MARKETS = "markets"


class ModelRole(str, Enum):
    PRIMARY = "primary"
    REASONING = "reasoning"
    FAST = "fast"
    CODING = "coding"
    VISION = "vision"
    STT = "stt"
    TTS = "tts"
    TRANSLATION = "translation"
    EMBEDDING = "embedding"
    IMAGE = "image"
    LOCAL = "local"
    FALLBACK = "fallback"


class PermissionCategory(str, Enum):
    READ = "READ"
    WRITE = "WRITE"
    EXECUTE = "EXECUTE"
    COMMUNICATE = "COMMUNICATE"
    FINANCIAL = "FINANCIAL"
    SYSTEM = "SYSTEM"
    PRIVACY = "PRIVACY"
    DEVICE = "DEVICE"


class ProactiveLevel(str, Enum):
    OFF = "off"
    IMPORTANT_ONLY = "important_only"
    NORMAL = "normal"
    PROACTIVE = "proactive"


class VoiceMode(str, Enum):
    STANDARD = "standard"
    CONVERSATIONAL = "conversational"
    PROFESSIONAL = "professional"
    FAST = "fast"
    QUIET = "quiet"
    STUDY = "study"
    CODING = "coding"
    COMPANION = "companion"


# ---------------------------------------------------------------------------
# Task graph
# ---------------------------------------------------------------------------
class TaskStepModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str = Field(default_factory=lambda: _id("st"))
    index: int = 0
    name: str = ""
    agent: AgentName = AgentName.CORE
    device: DeviceKind = DeviceKind.PC
    tool: Optional[str] = None
    params: Dict[str, Any] = Field(default_factory=dict)
    depends_on: List[str] = Field(default_factory=list)
    parallel_group: Optional[str] = None
    condition: Optional[str] = None
    retries: int = 1
    timeout_seconds: int = 120
    requires_confirmation: bool = False
    risk: RiskLevel = RiskLevel.LOW
    status: TaskStatus = TaskStatus.QUEUED
    output: Optional[Any] = None
    error: Optional[str] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None


class TaskModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str = Field(default_factory=lambda: _id("task"))
    title: str = ""
    request: str = ""
    kind: str = "general"
    status: TaskStatus = TaskStatus.QUEUED
    priority: int = 5
    agent: AgentName = AgentName.CORE
    device: DeviceKind = DeviceKind.PC
    progress: float = 0.0
    current_action: str = ""
    result: Optional[str] = None
    error: Optional[str] = None
    risk_level: RiskLevel = RiskLevel.LOW
    requires_confirmation: bool = False
    conversation_id: Optional[str] = None
    steps: List[TaskStepModel] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=_now)
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None

    @field_validator("steps")
    @classmethod
    def _index_steps(cls, v: List[TaskStepModel]) -> List[TaskStepModel]:
        for i, s in enumerate(v):
            s.index = i
        return v


# ---------------------------------------------------------------------------
# API request / response bodies
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, description="User text or transcribed voice")
    conversation_id: Optional[str] = None
    language: Optional[str] = "auto"
    attachments: List[Dict[str, Any]] = Field(default_factory=list)
    mode: Optional[str] = None           # voice | text
    voice_mode: VoiceMode = VoiceMode.STANDARD
    stream: bool = True
    dry_run: bool = False                # plan only, do not execute
    max_steps: int = 12


class ChatResponse(BaseModel):
    conversation_id: str
    message_id: Optional[str] = None
    reply: str
    language: str = "en"
    model: str = ""
    agent: str = "core"
    task_id: Optional[str] = None
    task: Optional[TaskModel] = None
    sources: List[Dict[str, Any]] = Field(default_factory=list)
    actions: List[Dict[str, Any]] = Field(default_factory=list)
    confirmations: List[Dict[str, Any]] = Field(default_factory=list)
    took_ms: int = 0
    spoken: bool = False


class ConfirmationRequest(BaseModel):
    confirmation_id: str
    approved: bool
    remember: bool = False
    note: Optional[str] = None


class MemoryWrite(BaseModel):
    kind: Literal["short_term", "long_term", "project", "device", "task", "semantic"] = "long_term"
    key: str
    content: str
    scope: str = "global"
    tags: List[str] = Field(default_factory=list)
    importance: float = Field(0.5, ge=0.0, le=1.0)
    source: str = "user"


class MemoryQuery(BaseModel):
    text: str = ""
    kind: Optional[str] = None
    scope: Optional[str] = None
    limit: int = 12


class AutomationAction(BaseModel):
    agent: AgentName = AgentName.CORE
    tool: Optional[str] = None
    params: Dict[str, Any] = Field(default_factory=dict)
    device: DeviceKind = DeviceKind.PC


class AutomationModel(BaseModel):
    id: str = Field(default_factory=lambda: _id("auto"))
    name: str = "Automation"
    enabled: bool = True
    trigger_type: Literal["time", "interval", "cron", "event", "condition"] = "time"
    trigger: Dict[str, Any] = Field(default_factory=dict)
    condition: Dict[str, Any] = Field(default_factory=dict)
    actions: List[AutomationAction] = Field(default_factory=list)
    verify: Dict[str, Any] = Field(default_factory=dict)
    device: DeviceKind = DeviceKind.PC
    confirmation: Literal["none", "required", "high_risk_only"] = "required"


class ScheduleModel(BaseModel):
    id: str = Field(default_factory=lambda: _id("job"))
    name: str = "Job"
    kind: Literal["once", "interval", "cron", "date"] = "once"
    expression: str = ""
    payload: Dict[str, Any] = Field(default_factory=dict)
    timezone: str = "Asia/Kolkata"
    enabled: bool = True
    automation_id: Optional[str] = None
    next_run_at: Optional[datetime] = None
    last_run_at: Optional[datetime] = None


class PermissionModel(BaseModel):
    capability: str
    category: PermissionCategory = PermissionCategory.SYSTEM
    granted: bool = False
    requires_confirmation: bool = True
    scope: Dict[str, Any] = Field(default_factory=dict)
    note: str = ""


class DeviceState(BaseModel):
    id: str
    name: str
    kind: DeviceKind = DeviceKind.PC
    online: bool = False
    platform: str = ""
    battery: Optional[Dict[str, Any]] = None
    cpu: Optional[float] = None
    ram: Optional[float] = None
    disk: Optional[Dict[str, Any]] = None
    network: Optional[Dict[str, Any]] = None
    storage: Optional[Dict[str, Any]] = None
    display: Optional[Dict[str, Any]] = None
    extra: Dict[str, Any] = Field(default_factory=dict)
    last_seen_at: Optional[datetime] = None


class VoiceConfig(BaseModel):
    input_device: Optional[str] = None
    output_device: Optional[str] = None
    voice_gender: Literal["male", "female", "neutral"] = "female"
    voice_id: Optional[str] = None
    language: str = "auto"
    speed: float = Field(1.0, ge=0.5, le=2.0)
    wake_word: str = "hey sam"
    wake_word_enabled: bool = False
    interruptions: bool = True
    mode: VoiceMode = VoiceMode.STANDARD


class PersonalityConfig(BaseModel):
    friendliness: float = Field(0.6, ge=0, le=1)
    professionalism: float = Field(0.7, ge=0, le=1)
    humor: float = Field(0.3, ge=0, le=1)
    verbosity: float = Field(0.4, ge=0, le=1)
    proactivity: float = Field(0.5, ge=0, le=1)
    response_style: Literal["adaptive", "concise", "detailed", "technical", "friendly"] = "adaptive"


class ResearchRequest(BaseModel):
    question: str
    depth: Literal["quick", "standard", "deep"] = "standard"
    max_sources: int = 8
    language: str = "auto"
    include_citations: bool = True


class CodingRequest(BaseModel):
    goal: str
    language: Optional[str] = None
    project_path: Optional[str] = None
    run_tests: bool = True
    explain: bool = True


class HealthResponse(BaseModel):
    status: str = "ok"
    product: str = "SAM"
    version: str = "1.0.0"
    mode: str = "hybrid"
    uptime_seconds: float = 0.0
    time: datetime = Field(default_factory=_now)
    components: Dict[str, str] = Field(default_factory=dict)
