"""
backend.app.core.planner
========================

The **Planner + Router**. Turns one natural-language request into an executable
task graph::

    USER REQUEST -> PLANNER -> TASK GRAPH -> [A B C] -> COMBINE -> VERIFY -> COMPLETE

Two-stage planning
------------------
1. **Fast path (always runs).** Deterministic intent classification from the
   offline engine produces a reliable, zero-latency plan. This is what makes SAM
   feel instant for "open notepad", "find my invoices", "lock the PC".
2. **Deep path (runs when the fast path is unsure or the request is complex).**
   The Reasoning model is asked for a JSON plan. If the model is unavailable or
   returns something unparseable, the fast path plan is kept — SAM never stalls.

The router also decides **which device** owns each step (PC / phone / browser /
cloud / both), which is what the Cross-Device Command Execution section needs.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple

from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import (
    AgentName,
    DeviceKind,
    RiskLevel,
    TaskModel,
    TaskStatus,
    TaskStepModel,
)
from backend.app.providers.heuristic import classify_intent, detect_language, intent_to_agent, intent_to_device

log = get_logger("planner")

# How confident the deterministic classifier must be before we skip the model.
FAST_PATH_CONFIDENCE = 0.60

# ---------------------------------------------------------------------------
# Intent -> concrete plan template
# ---------------------------------------------------------------------------
# Each template returns a list of steps given the raw request + extracted slots.
StepFactory = Any


def _step(name: str, agent: str, device: str = "pc", tool: Optional[str] = None,
          params: Optional[Dict[str, Any]] = None, depends_on: Optional[List[str]] = None,
          risk: str = "LOW", confirm: bool = False, retries: int = 1, timeout: int = 120) -> TaskStepModel:
    """
    Build one task step.

    The owning **agent** and **device** are taken from the tool's own
    registration when the tool is known, so the dashboard always attributes a
    step to the brain that really runs it (a plan can never mislabel a step,
    and renaming a tool's agent cannot silently desynchronise the planner).
    """
    agent_name, device_name = agent, device
    if tool:
        registered = None
        try:
            from backend.app.tools.registry import registry
            registered = registry.get(tool)
        except Exception:                              # pragma: no cover - tools not loaded yet
            registered = None
        if registered is not None:
            a = getattr(registered.agent, "value", str(registered.agent))
            d = getattr(registered.device, "value", str(registered.device))
            if a in {x.value for x in AgentName}:
                agent_name = a
            if d in {x.value for x in DeviceKind} and d != "both":
                device_name = d
            if getattr(registered.risk, "value", str(registered.risk)) == "HIGH" and risk != "HIGH":
                risk = "HIGH"                          # never downgrade a tool's own risk
            confirm = confirm or bool(registered.confirm)
    return TaskStepModel(
        name=name,
        agent=AgentName(agent_name),
        device=DeviceKind(device_name),
        tool=tool,
        params=params or {},
        depends_on=depends_on or [],
        risk=RiskLevel(risk),
        requires_confirmation=confirm,
        retries=retries,
        timeout_seconds=timeout,
    )


APP_ALIASES: Dict[str, List[str]] = {
    "chrome": ["chrome", "google chrome", "browser"],
    "firefox": ["firefox"],
    "edge": ["edge", "microsoft edge"],
    "notepad": ["notepad", "text editor"],
    "vscode": ["vs code", "vscode", "visual studio code", "code"],
    "explorer": ["explorer", "file explorer", "files", "my computer"],
    "terminal": ["terminal", "cmd", "command prompt", "powershell", "shell"],
    "word": ["word", "ms word", "microsoft word"],
    "excel": ["excel", "ms excel", "microsoft excel", "spreadsheet"],
    "powerpoint": ["powerpoint", "power point", "slides"],
    "calculator": ["calculator", "calc"],
    "paint": ["paint"],
    "taskmgr": ["task manager", "taskmgr"],
    "spotify": ["spotify"],
    "settings": ["settings", "control panel"],
    "outlook": ["outlook", "mail"],
}


def _extract_app(text: str) -> Optional[str]:
    low = text.lower()
    best: Optional[Tuple[int, str]] = None
    for canonical, aliases in APP_ALIASES.items():
        for a in aliases:
            idx = low.find(a)
            if idx != -1:
                score = len(a)
                if best is None or score > best[0]:
                    best = (score, canonical)
    return best[1] if best else None


def _extract_url(text: str) -> Optional[str]:
    m = re.search(r"(https?://\S+|www\.\S+|\b[\w-]+\.(?:com|org|net|io|in|dev|co|ai|gov|edu)\b(?:/\S*)?)",
                  text, re.IGNORECASE)
    return m.group(1) if m else None


def _extract_duration(text: str) -> Optional[int]:
    """Return minutes from 'in 20 minutes', 'in 2 hours', 'at 9am'."""
    low = text.lower()
    m = re.search(r"in\s+(\d+)\s*(second|sec|minute|min|hour|hr|day)s?", low)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        return {"second": 0, "sec": 0, "minute": 1, "min": 1, "hour": 60, "hr": 60, "day": 1440}[unit] * n or 1
    m = re.search(r"at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", low)
    if m:
        return -1  # sentinel: absolute clock time, scheduler resolves it
    return None




# ---------------------------------------------------------------------------
# Market / web / math slot extraction
# ---------------------------------------------------------------------------
_TIMEFRAMES = {
    "1m": ("1 minute", "1min", "1m", "one minute"),
    "5m": ("5 minute", "5min", "5m", "five minute"),
    "15m": ("15 minute", "15min", "15m", "fifteen minute"),
    "30m": ("30 minute", "30min", "30m", "half hour", "half-hour"),
    "1h": ("1h", "1 hour", "hourly", "one hour", "60 minute"),
    "4h": ("4h", "4 hour", "four hour"),
    "1d": ("daily", "1d", "day chart", "1 day", "daily chart", "end of day", "eod"),
    "1wk": ("weekly", "1wk", "week chart", "1 week"),
    "1mo": ("monthly", "1mo", "month chart", "1 month"),
}

_STRATEGIES = {
    "ma_cross": ("ma cross", "moving average cross", "ema cross", "crossover", "ma_cross",
                 "golden cross", "death cross"),
    "rsi_reversion": ("rsi reversion", "rsi mean reversion", "oversold", "overbought",
                      "rsi_reversion", "buy the dip"),
    "rsi_trend": ("rsi trend", "rsi_trend"),
    "bollinger_breakout": ("bollinger breakout", "band breakout", "bollinger_breakout"),
    "bollinger_fade": ("bollinger fade", "band fade", "mean reversion band", "bollinger_fade"),
    "macd_cross": ("macd", "macd cross", "macd_cross"),
    "donchian": ("donchian", "channel breakout", "turtle", "20 day high"),
    "psar_flip": ("psar", "parabolic sar", "sar flip", "psar_flip"),
    "atr_trailing": ("atr trailing", "trailing stop", "chandelier", "atr_trailing"),
    "binary_direction": ("binary", "expiry", "up or down", "60 second", "binary_direction"),
}

_RISK_OPS = {
    "position_size": ("lot size", "position size", "how many lots", "how much to buy",
                      "units to trade", "sizing"),
    "pip_value": ("pip value", "value of a pip", "pip worth"),
    "risk_reward": ("risk reward", "risk:reward", "r:r", "risk to reward"),
    "kelly": ("kelly",),
    "risk_of_ruin": ("risk of ruin", "blow up", "blow the account", "ruin"),
    "drawdown_math": ("drawdown", "recover", "get back to even"),
    "margin_required": ("margin required", "margin needed", "how much margin"),
    "portfolio_risk": ("portfolio risk", "total risk", "correlated risk"),
    "expectancy": ("expectancy", "expected value", "edge per trade"),
    "stake_plan": ("stake plan", "how much to stake", "binary stake", "session plan"),
    "martingale_check": ("martingale", "double after", "doubling down"),
}

_ALERT_CONDITIONS = {
    "above": ("above", "over", "reaches", "hits", "touches", "goes up to", "crosses above",
              "higher than", "breaks above"),
    "below": ("below", "under", "drops to", "falls to", "goes down to", "crosses below",
              "lower than", "breaks below"),
    "percent_change": ("percent change", "% change", "moves by", "changes by", "swings"),
    "rsi_above": ("rsi above", "rsi over", "rsi higher"),
    "rsi_below": ("rsi below", "rsi under", "rsi lower"),
    "atr_spike": ("volatility spike", "atr spike", "atr jumps"),
    "signal_flip": ("signal flips", "flips bullish", "flips bearish", "reverses"),
}


# symbol baskets the screener scans when the user does not name symbols
_UNIVERSES: Dict[str, List[str]] = {
    "forex": ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD", "EURJPY"],
    "crypto": ["bitcoin", "ethereum", "solana", "xrp", "doge", "cardano", "litecoin", "chainlink"],
    "indices": ["nifty", "sensex", "bank nifty", "sp500", "nasdaq", "dow", "vix", "dax"],
    "commodities": ["gold", "silver", "crude oil", "copper", "platinum"],
    "stocks": ["AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "TSLA", "RELIANCE.NS", "TCS.NS"],
}


def _extract_timeframe(text: str) -> str:
    low = (text or "").lower()
    for tf, words in _TIMEFRAMES.items():
        if any(w in low for w in words):
            return tf
    return ""


def _first_match(text: str, table: Dict[str, Tuple[str, ...]], default: str = "") -> str:
    low = (text or "").lower()
    for key, words in table.items():
        if any(w in low for w in words):
            return key
    return default


def _extract_number(text: str, *, after: Tuple[str, ...] = (), default: Optional[float] = None,
                    maximum: Optional[float] = None) -> Optional[float]:
    """Pull a number out of free text, optionally only after one of ``after``."""
    low = (text or "").lower()
    if after:
        for word in after:
            m = re.search(re.escape(word) + r"\s*[:=]?\s*([\d.,]+)", low)
            if m:
                try:
                    val = float(m.group(1).replace(",", ""))
                    return min(val, maximum) if maximum else val
                except ValueError:
                    continue
    m = re.search(r"(-?[\d,]+(?:\.\d+)?)", low)
    if m:
        try:
            val = float(m.group(1).replace(",", ""))
            return min(val, maximum) if maximum else val
        except ValueError:
            return default
    return default


def _extract_symbols(text: str) -> List[str]:
    """Symbols named in a comparison / correlation request."""
    from backend.app.markets.data_feed import CRYPTO_ALIASES, FOREX_CCY, INDICES, COMMODITIES

    low = (text or "").lower()
    found: List[str] = []
    for m in re.finditer(r"\b([a-z]{3,6})\s*/?\s*(usd|usdt|inr|eur|gbp|jpy)\b", low):
        found.append(m.group(0).replace(" ", ""))
    for m in re.finditer(r"\b([a-z]{6})\b", low):                     # eurusd, gbpjpy ...
        if m.group(1)[:3] in FOREX_CCY and m.group(1)[3:] in FOREX_CCY:
            found.append(m.group(1))
    for word in re.findall(r"[a-z]+", low):
        if word in CRYPTO_ALIASES and word not in ("usd", "usdt", "usdc", "eur", "gbp"):
            found.append(word)
        elif word in INDICES or word in COMMODITIES:
            found.append(word)
    out: List[str] = []
    for f in found:
        if f not in out:
            out.append(f)
    return out[:6]


def _numbers(text: str) -> List[float]:
    out: List[float] = []
    for n in re.findall(r"-?[\d,]+(?:\.\d+)?", text or ""):
        try:
            out.append(float(n.replace(",", "")))
        except ValueError:
            continue
    return out


_SHAPE_DIMS = {
    "circle": ["radius"], "sphere": ["radius"], "square": ["side"], "cube": ["side"],
    "rectangle": ["length", "width"], "triangle": ["base", "height"],
    "cylinder": ["radius", "height"], "cone": ["radius", "height"],
    "ellipse": ["a", "b"], "trapezoid": ["a", "b", "height"],
    "parallelogram": ["base", "height"], "hexagon": ["side"], "polygon": ["sides", "side"],
}


def _math_payload(text: str, tool: str) -> Dict[str, Any]:
    """Turn a maths sentence into the parameters that specific math tool takes."""
    raw = (text or "").strip()
    low = raw.lower()
    nums = _numbers(raw)

    if tool == "math.solve":
        m = re.search(r"([0-9a-z\(\)\s\+\-\*/\^\.\,]{3,80}=[0-9a-z\(\)\s\+\-\*/\^\.\,]{1,60})", low)
        return {"equation": (m.group(1).strip() if m else raw), "request": raw}

    if tool == "math.calculus":
        expr = re.sub(r"^.*?\b(?:of|for)\s+", "", low, count=1).strip() or low
        op = ("integrate" if any(w in low for w in ("integral", "integrate", "integration"))
              else "limit" if "limit" in low else "differentiate")
        out: Dict[str, Any] = {"operation": op, "expression": expr, "variable": "x", "request": raw}
        if op == "integrate" and len(nums) >= 2:
            out["lower"], out["upper"] = nums[0], nums[1]     # definite integral
        if op == "limit" and nums:
            out["point"] = nums[0]
        return out

    if tool == "math.statistics":
        vals = nums
        if not vals:
            m = re.search(r"\[([^\]]+)\]", raw)
            vals = _numbers(m.group(1)) if m else []
        return {"values": vals, "request": raw}

    if tool == "math.regression":
        xs = list(range(1, len(nums) + 1))
        return {"x": xs, "y": nums, "forecast_x": float(len(nums) + 1) if nums else None,
                "request": raw}

    if tool == "math.unit_convert":
        m = re.search(r"(-?[\d.,]+)\s*([a-z°/%]{1,12})\s*(?:to|in|into)\s*([a-z°/%]{1,12})", low)
        if m:
            return {"value": float(m.group(1).replace(",", "")),
                    "from_unit": m.group(2).strip(), "to_unit": m.group(3).strip(), "request": raw}
        return {"value": nums[0] if nums else 0.0, "request": raw}

    if tool == "math.finance":
        op = ("sip" if "sip" in low else "gst" if "gst" in low else "cagr" if "cagr" in low else
              "compound_interest" if "compound" in low else
              "simple_interest" if "simple interest" in low else
              "npv" if "npv" in low else "irr" if "irr" in low else
              "emi" if "emi" in low or "loan" in low else "compound_interest")
        payload: Dict[str, Any] = {"operation": op, "request": raw}
        if op == "sip":
            if nums:
                payload["monthly_investment"] = nums[0]
            if len(nums) > 1:
                payload["rate"] = nums[1]
            if len(nums) > 2:
                payload["years"] = nums[2]
        else:
            if nums:
                payload["principal"] = nums[0]
            if len(nums) > 1:
                payload["rate"] = nums[1]
            if len(nums) > 2:
                payload["years"] = nums[2]
            if len(nums) > 3:
                payload["future_value"] = nums[3]
        return payload

    if tool == "math.geometry":
        m = re.search(r"\b(circle|square|rectangle|triangle|sphere|cylinder|cone|cube|ellipse|"
                      r"trapezoid|parallelogram|hexagon|polygon)\b", low)
        shape = m.group(1) if m else ""
        names = _SHAPE_DIMS.get(shape, ["a", "b", "c"])
        return {"shape": shape,
                "dimensions": {n: v for n, v in zip(names, nums[:len(names)])}, "request": raw}

    if tool == "math.matrix":
        op = ("determinant" if "determinant" in low else "inverse" if "inverse" in low else
              "transpose" if "transpose" in low else "eigen" if "eigen" in low else
              "identity" if "identity" in low else "multiply")
        m = re.findall(r"(\[\[.*?\]\]|\[[^\[\]]*\])", raw)
        payload = {"operation": op, "request": raw}
        if m:
            payload["a"] = m[0]
            if len(m) > 1:
                payload["b"] = m[1]
        elif nums:
            payload["size"] = int(nums[0]) if op == "identity" else 3
        return payload

    if tool == "math.prime_factor":
        op = ("prime" if "prime" in low else "gcd" if "gcd" in low or "hcf" in low else
              "lcm" if "lcm" in low else "factorial" if "factorial" in low else
              "fibonacci" if "fibonacci" in low else "divisors" if "divisor" in low else "factor")
        payload = {"operation": op, "request": raw}
        if nums:
            payload["value"] = int(nums[0])
        if len(nums) > 1:
            payload["other"] = int(nums[1])
        return payload

    if tool == "math.date_calc":
        op = ("difference" if any(w in low for w in ("between", "difference", "how many days"))
              else "age" if "old" in low or "age" in low else
              "weekday" if "weekday" in low or "day of the week" in low else
              "add" if re.search(r"\b(add|plus|after)\b", low) else
              "subtract" if re.search(r"\b(subtract|minus|before)\b", low) else "difference")
        dates = re.findall(r"\b(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}|\d{4}-\d{2}-\d{2}|"
                           r"\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*"
                           r"(?:\s+\d{2,4})?)\b", low)
        payload: Dict[str, Any] = {"operation": op, "request": raw}
        if dates:
            payload["date"] = dates[0]
            if len(dates) > 1:
                payload["other_date"] = dates[1]
        days = _extract_number(text, after=("days", "day", "add", "minus"), maximum=100000)
        if days is not None and op in ("add", "subtract"):
            payload["days"] = int(days)
        return payload

    if tool == "math.percent":
        op = ("of" if re.search(r"\d+\s*%\s*of", low) else
              "change" if any(w in low for w in ("change", "increase", "decrease", "difference",
                                                "from", "growth")) else "of")
        payload = {"operation": op, "request": raw}
        if len(nums) >= 2:
            payload["a"], payload["b"] = nums[0], nums[1]
        return payload

    # math.evaluate and anything else
    expr = re.sub(r"^(?:please\s+)?(?:calculate|compute|work\s*out|evaluate|what\s+is|"
                  r"how\s+much\s+is)\s*", "", low, flags=re.I).strip()
    return {"expression": expr or raw, "request": raw}


_MATH_TOOL_FOR_INTENT = {
    "math.finance": "math.finance",
    "math.algebra": "math.solve",
    "math.calculus": "math.calculus",
    "math.statistics": "math.statistics",
    "math.matrix": "math.matrix",
    "math.geometry": "math.geometry",
    "math.number": "math.prime_factor",
    "math.date": "math.date_calc",
    "math.convert": "math.unit_convert",
    "math.calculate": "math.evaluate",
}


def _math_plan(intent: str, text: str) -> List[TaskStepModel]:
    tool = _MATH_TOOL_FOR_INTENT.get(intent, "math.evaluate")
    params = _math_payload(text, tool)
    steps = [_step(f"compute: {tool}", "reasoning", "pc", tool, params, risk="LOW", timeout=60)]
    low = text.lower()
    if tool == "math.evaluate" and "%" in text:
        steps.append(_step("show the percentage breakdown", "reasoning", "pc", "math.percent",
                           _math_payload(text, "math.percent"), depends_on=[], risk="LOW"))
    if tool in ("math.statistics", "math.evaluate") and any(
            w in low for w in ("forecast", "predict", "trend", "regression", "next")):
        steps.append(_step("fit a regression and forecast", "data", "pc", "math.regression",
                           _math_payload(text, "math.regression"), depends_on=[], risk="LOW"))
    if tool == "math.evaluate" and any(w in low for w in ("simplify", "expand", "factor")):
        steps.append(_step("simplify symbolically", "reasoning", "pc", "math.simplify",
                           {"expression": params.get("expression", text), "request": text},
                           depends_on=[], risk="LOW"))
    return steps

# ---------------------------------------------------------------------------
# text.* / code.* plan helpers
# ---------------------------------------------------------------------------
_TONES = ("professional", "casual", "friendly", "persuasive", "formal", "empathetic",
          "confident", "neutral", "witty", "apologetic")


def _payload(text: str, slots: Dict[str, Any]) -> str:
    """The text a writing tool should operate on: a quoted span wins."""
    quoted = slots.get("quoted") or []
    return quoted[0] if quoted else text


def _second_payload(text: str, slots: Dict[str, Any]) -> str:
    """The comparison text, when the user supplied two."""
    quoted = slots.get("quoted") or []
    if len(quoted) >= 2:
        return quoted[1]
    for sep in ("\n---\n", " ||| ", " vs ", " compared to "):
        if sep in text:
            return text.split(sep, 1)[1].strip()
    return ""


def _word_after(text: str, words: Sequence[str], default: str = "") -> str:
    low = text.lower()
    for w in words:
        if w in low:
            return w
    return default


def _text_params(intent: str, text: str, slots: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    """Return ``(tool, params)`` for every ``text.*`` intent."""
    body = _payload(text, slots)
    other = _second_payload(text, slots)
    low = text.lower()
    if intent == "text.count":
        return "text.count", {"text": body}
    if intent == "text.readability":
        return "text.readability", {"text": body}
    if intent == "text.sentiment":
        return "text.sentiment", {"text": body}
    if intent == "text.keywords":
        return "text.keywords", {"text": body, "limit": 12, "phrases": True,
                                 "meta_description": ("seo" in low or "meta" in low)}
    if intent == "text.similarity":
        return "text.similarity", {"text_a": body, "text_b": other}
    if intent == "text.diff":
        mode = "words" if "word" in low else "side_by_side" if "side" in low else "unified"
        return "text.diff", {"text_a": body, "text_b": other, "mode": mode}
    if intent == "text.grammar":
        report_only = any(w in low for w in ("only report", "don't change", "do not change",
                                             "just check"))
        return "text.grammar", {"text": body, "apply": not report_only, "strict": "strict" in low}
    if intent == "text.rewrite":
        tone = _word_after(low, _TONES, "professional")
        length = ("shorter" if any(w in low for w in ("shorter", "concise", "brief", "tighten"))
                  else "longer" if any(w in low for w in ("longer", "expand", "more detail"))
                  else "one_sentence" if ("one sentence" in low or "single sentence" in low)
                  else "same")
        audience = ""
        m = re.search(r"\bfor\s+(?:a\s+|an\s+|the\s+)?([a-z][\w\s]{2,30}?)(?:\s*[.,;]|\s*$)", low)
        if m and m.group(1).strip() not in ("me", "you", "now", "later"):
            audience = m.group(1).strip()
        return "text.rewrite", {"text": body, "tone": tone, "length": length,
                                "audience": audience, "keep_numbers": True}
    if intent == "text.summarise":
        style = ("bullets" if any(w in low for w in ("bullet", "points", "list")) else
                 "executive" if any(w in low for w in ("executive", "manager", "brief")) else
                 "simple" if any(w in low for w in ("simple", "child", "plain")) else
                 "technical" if "technical" in low else "neutral")
        n = int(_extract_number(text, after=("sentences", "sentence", "points", "bullets"),
                                maximum=20) or 5)
        return "text.summarise", {"text": body, "max_sentences": n, "method": "auto",
                                  "style": style}
    if intent == "text.bullets":
        direction = ("to_prose" if any(w in low for w in ("to prose", "into prose", "paragraph",
                                                          "prose")) else "to_bullets")
        n = int(_extract_number(text, after=("bullets", "points"), maximum=25) or 8)
        return "text.bullets", {"text": body, "direction": direction, "max_bullets": n}
    if intent == "text.extract":
        kinds = [k for k in ("email", "url", "phone", "date", "time", "money", "hashtag",
                             "mention", "ip", "number", "percent", "file_path") if k in low]
        return "text.extract", {"text": body, "kinds": ",".join(kinds)}
    if intent == "text.redact":
        return "text.redact", {"text": body, "mask_char": "*", "keep_edges": 2, "names": ""}
    if intent == "text.template":
        return "text.template", {"template": body, "values": None, "values_json": ""}
    if intent == "text.table":
        fmt = _word_after(low, ("markdown", "csv", "html", "json", "text"), "markdown")
        delim = "\\t" if "tab" in low else "|" if "pipe" in low else ","
        return "text.table", {"text": body, "delimiter": delim, "format": fmt, "has_header": True}
    if intent == "text.lines":
        op = ("sort_desc" if any(w in low for w in ("descending", "reverse sort", "z to a")) else
              "sort" if "sort" in low else
              "reverse" if "reverse" in low else
              "number" if "number" in low else
              "trim" if "trim" in low else
              "remove_empty" if "empty" in low else
              "filter_in" if any(w in low for w in ("only lines", "keep lines", "filter")) else
              "dedupe")
        params: Dict[str, Any] = {"text": body, "operation": op}
        if op in ("filter_in", "filter_out"):
            m = re.search(r"(?:matching|containing|with)\s+[\"']?([^\"']+)[\"']?", low)
            params["pattern"] = re.escape(m.group(1).strip()) if m else ""
        return "text.lines", params
    if intent == "text.slug":
        return "text.slug", {"text": body, "max_length": 80}
    if intent == "text.title":
        return "text.title", {"text": body, "style": "chicago" if "chicago" in low else "apa"}
    if intent == "text.case":
        target = ("snake" if "snake" in low else "camel" if "camel" in low else
                  "pascal" if "pascal" in low else "kebab" if "kebab" in low else
                  "constant" if "constant" in low else "sentence" if "sentence" in low else
                  "upper" if any(w in low for w in ("upper", "caps", "uppercase")) else
                  "lower" if "lower" in low else "title" if "title" in low else "snake")
        return "text.case", {"text": body, "to": target}
    if intent == "text.markdown":
        direction = ("html_to_markdown" if ("to markdown" in low or "2 markdown" in low) else
                     "html_to_text" if ("html" in low and "text" in low and "markdown" not in low)
                     else "md_to_html")
        return "text.markdown", {"text": body, "direction": direction,
                                 "standalone": ("page" in low or "document" in low)}
    if intent == "text.lorem":
        unit = "words" if "word" in low else "sentences" if "sentence" in low else "paragraphs"
        n = int(_extract_number(text, after=(unit.rstrip("s"),), maximum=100) or 3)
        return "text.lorem", {"count": n, "unit": unit}
    return "text.count", {"text": body}


def _code_params(intent: str, text: str, slots: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    """Return ``(tool, params)`` for every ``code.*`` intent."""
    low = text.lower()
    quoted = slots.get("quoted") or []
    body = quoted[0] if quoted else text
    nums = _numbers(text)

    if intent == "code.regex":
        m = re.search(r"(?:regex|pattern|expression)\s*[:=]?\s*[\"'`/]?(.+?)[\"'`/]?\s*$", text,
                      re.IGNORECASE)
        pattern = m.group(1).strip() if m else (quoted[0] if quoted else "")
        sample = quoted[1] if len(quoted) > 1 else ""
        return "code.regex", {"pattern": pattern, "text": sample or text,
                              "flags": "i" if "case insensitive" in low else ""}
    if intent == "code.json":
        op = ("minify" if any(w in low for w in ("minify", "compress", "one line")) else
              "query" if any(w in low for w in ("query", "get the", "extract", "path")) else
              "flatten" if "flatten" in low else
              "keys" if ("keys" in low or "structure" in low) else
              "stats" if "stats" in low else
              "to_csv" if "csv" in low else
              "to_yaml" if "yaml" in low else
              "validate" if "valid" in low else "format")
        return "code.json", {"text": body, "operation": op, "indent": 2}
    if intent == "code.format_convert":
        target = _word_after(low, ("yaml", "csv", "tsv", "toml", "ini", "xml", "markdown",
                                   "python", "json"), "json")
        return "code.format_convert", {"text": body, "to_format": target}
    if intent == "code.hash":
        algs = [a for a in ("md5", "sha1", "sha224", "sha256", "sha384", "sha512", "blake2b")
                if a in low] or ["sha256"]
        return "code.hash", {"text": body, "algorithms": ",".join(algs)}
    if intent == "code.encode":
        codec = ("base64url" if ("url" in low and "base64" in low) else
                 "base32" if "base32" in low else
                 "hex" if ("hex" in low or "base16" in low) else
                 "url" if ("url" in low or "percent" in low) else
                 "binary" if ("binary" in low or "bits" in low) else
                 "rot13" if "rot13" in low else "base64")
        op = ("decode" if any(w in low for w in ("decode", "decrypt", "from base64", "unread"))
              else "encode")
        return "code.encode", {"text": body, "operation": op, "codec": codec}
    if intent == "code.jwt":
        m = re.search(r"(eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*)", text)
        return "code.jwt", {"token": m.group(1) if m else body}
    if intent == "code.uuid":
        version = (5 if ("v5" in low or "deterministic" in low or "name" in low) else
                   1 if "v1" in low else 3 if "v3" in low else 4)
        op = ("parse" if any(w in low for w in ("parse", "decode", "inspect", "what is this uuid"))
              else "generate")
        n = int(_extract_number(text, after=("uuids", "of them", "generate"), maximum=100) or 1)
        params: Dict[str, Any] = {"operation": op, "version": version, "count": max(1, n)}
        if op == "parse":
            m = re.search(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
                          r"[0-9a-fA-F]{12}", text)
            params["value"] = m.group(1) if m else body
        if version in (3, 5):
            m = re.search(r"(?:for|named?|name)\s+[\"']?([^\"']+)", text, re.IGNORECASE)
            params["hash_name"] = (m.group(1).strip() if m else body)[:120]
        return "code.uuid", params
    if intent == "code.color":
        m = re.search(r"(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|\b[a-z]{3,14}\b)", text)
        colour = m.group(1) if m else body
        op = ("contrast" if any(w in low for w in ("contrast", "wcag", "accessib", "readable on"))
              else "palette" if "palette" in low else
              "tints" if "tint" in low else "shades" if "shade" in low else
              "invert" if "invert" in low else
              "grayscale" if ("grey" in low or "gray" in low) else
              "nearest" if ("name" in low or "closest" in low) else "convert")
        params = {"color": colour, "operation": op}
        if op == "contrast":
            m2 = re.search(r"\b(?:on|with|against|vs)\s+(#[0-9a-fA-F]{3,8}|white|black|"
                           r"[a-z]{3,12})", low)
            params["other"] = m2.group(1) if m2 else "white"
        return "code.color", params
    if intent == "code.cron":
        m = re.search(r"([0-9*/,\-]+\s+[0-9*/,\-]+\s+[0-9*/,\-]+\s+[0-9*/,\-]+\s+[0-9*/,\-]+)",
                      text)
        return "code.cron", {"expression": m.group(1) if m else body, "count": 5}
    if intent == "code.timestamp":
        m = re.search(r"(-?\d{9,13})", text)
        value = m.group(1) if m else ("now" if "now" in low else body)
        tz = ""
        m2 = re.search(r"\b(?:in|to|for)\s+([A-Z][a-z]+/[A-Z][a-z]+|UTC|IST|GMT|EST|PST|CET|"
                       r"Asia/\w+|Europe/\w+|America/\w+)", text)
        if m2:
            tz = m2.group(1)
        return "code.timestamp", {"value": value, "to_timezone": tz}
    if intent == "code.sql":
        m = re.search(r"((?:select|with|insert|update|delete|create|pragma)\b.+)", text,
                      re.IGNORECASE | re.DOTALL)
        query = (quoted[0] if quoted else (m.group(1).strip().rstrip(";") if m else body))
        write = bool(re.search(r"\b(insert|update|delete|drop|alter|create)\b", query, re.I))
        return "code.sql", {"query": query, "allow_write": write, "limit": 200}
    if intent == "code.number_base":
        op = ("bitwise" if any(w in low for w in ("bitwise", "xor", "shift")) else
              "float_bits" if ("float" in low or "ieee" in low or "double" in low) else "convert")
        value = str(int(nums[0])) if nums else body
        params = {"value": value, "operation": op}
        if op == "bitwise":
            params["other"] = str(int(nums[1])) if len(nums) > 1 else ""
            params["op"] = _word_after(low, ("xor", "shift_left", "shift_right", "or", "and",
                                             "not"), "and")
        return "code.number_base", params
    if intent == "code.secret_scan":
        m = re.search(r"(?:file|in|scan)\s+[\"']?([^\s\"']+\.[A-Za-z0-9]{1,6})", text)
        return "code.secret_scan", {"text": "" if m else body, "path": m.group(1) if m else "",
                                    "show_values": False}
    if intent in ("code.review", "code.complexity"):
        tool = "code.review" if intent == "code.review" else "code.complexity"
        m = re.search(r"(?:file|in)\s+[\"']?([^\s\"']+\.[A-Za-z0-9]{1,6})", text)
        lang = _word_after(low, ("python", "javascript", "typescript", "java", "go", "rust",
                                 "bash", "sql", "html", "css"), "python")
        params = {"code": "" if m else body, "path": m.group(1) if m else "", "language": lang}
        if tool == "code.review":
            params["strict"] = True
        return tool, params
    if intent == "code.snippet":
        lang = _word_after(low, ("python", "javascript", "typescript", "java", "go", "rust",
                                 "bash", "sql", "html", "css", "php"), "python")
        style = ("quick" if any(w in low for w in ("quick", "one liner", "short")) else
                 "teaching" if any(w in low for w in ("teach", "explain", "learn", "beginner"))
                 else "production")
        return "code.snippet", {"task": body, "language": lang, "style": style,
                                "save": ("save" in low or "file" in low)}
    if intent == "code.random_data":
        kind = _word_after(low, ("users", "orders", "events", "logs", "products", "transactions",
                                 "ips"), "users")
        fmt = _word_after(low, ("csv", "sql", "markdown", "json"), "json")
        n = int(_extract_number(text, after=("rows", "records", "of them", "generate"),
                                maximum=1000) or 10)
        return "code.random_data", {"kind": kind, "count": n, "format": fmt, "table": kind}
    if intent == "code.qrcode":
        m = re.search(r"(https?://\S+)", text)
        return "code.qrcode", {"text": m.group(1) if m else body, "file_name": "qrcode.png",
                               "wifi": ("wifi" in low or "wi-fi" in low)}
    if intent == "code.artifact":
        name_m = re.search(r"(?:as|to|named?)\s+[\"']?([\w.\-]+\.\w{1,6})", text)
        return "code.artifact", {"content": body,
                                 "file_name": name_m.group(1) if name_m else "artifact.md",
                                 "category": "code"}
    return "code.json", {"text": body, "operation": "format"}


def _text_code_plan(intent: str, text: str, slots: Dict[str, Any]) -> List[TaskStepModel]:
    """Build the step list for a ``text.*`` or ``code.*`` intent."""
    if intent.startswith("text."):
        tool, params = _text_params(intent, text, slots)
        agent, device, title = "writing", "both", f"{tool.split('.', 1)[1]} the text"
    else:
        tool, params = _code_params(intent, text, slots)
        agent, device, title = "coding", "both", tool.split(".", 1)[1]
    steps = [_step(title, agent, device, tool, params, risk="LOW", timeout=120)]
    if tool == "text.rewrite":
        # a rewrite is only useful if the writer can see what changed
        steps.append(_step("show what changed", "writing", "both", "text.diff",
                           {"text_a": params["text"], "text_b": "", "mode": "words"},
                           depends_on=[], risk="LOW", timeout=60))
    return steps


def plan_for_intent(intent: str, text: str, slots: Dict[str, Any]) -> List[TaskStepModel]:
    """
    Deterministic plan for a classified intent.

    Every step names a **real registered tool** and only passes parameters that
    tool's signature accepts — ``tests/backend/test_plans.py`` asserts exactly
    that, so a rename in a tool module cannot silently break planning.
    """
    # market.*, web.* and math.* intents have their own template block
    routed = _plan_body(intent, text, slots)
    if routed:
        return routed

    app = slots.get("app")
    url = slots.get("url")
    low = text.lower()
    quoted = slots.get("quoted") or []
    pct = _extract_number(text, after=("to", "percent", "%"), maximum=100)

    # --------------------------------------------------------------- pc ----
    if intent == "pc.screen":
        return [_step("look at the screen", "vision", "pc", "pc.screenshot",
                      {"analyze": True, "question": text}, risk="MEDIUM", confirm=True, timeout=90)]

    if intent == "pc.app.launch":
        return [_step(f"launch {app or 'application'}", "pc", "pc", "pc.launch_app",
                      {"app": app or text, "request": text}, risk="MEDIUM", confirm=True)]

    if intent == "pc.app.close":
        return [_step(f"close {app or 'application'}", "pc", "pc", "pc.close_app",
                      {"app": app or text, "request": text}, risk="MEDIUM", confirm=True)]

    if intent == "pc.power":
        delay = int(_extract_number(text, after=("in", "after"), maximum=3600) or 0)
        if "restart" in low or "reboot" in low:
            tool, risk = "pc.power_restart", "HIGH"
        elif "shutdown" in low or "shut down" in low or "power off" in low or "turn off" in low:
            tool, risk = "pc.power_shutdown", "HIGH"
        elif "sign out" in low or "signout" in low or "log out" in low or "logout" in low:
            tool, risk = "pc.power_signout", "HIGH"
        elif "sleep" in low:
            tool, risk = "pc.power_sleep", "MEDIUM"
        else:
            tool, risk = "pc.power_lock", "MEDIUM"
        return [_step(tool.replace("pc.power_", "") + " the PC", "pc", "pc", tool,
                      {"delay_seconds": delay}, risk=risk, confirm=True)]

    if intent == "pc.system.info":
        section = ("processes" if any(w in low for w in ("process", "running", "task")) else
                   "all" if any(w in low for w in ("everything", "full", "all")) else "summary")
        steps = [_step("read system state", "pc", "pc", "pc.system_info", {"section": section},
                       risk="LOW")]
        if section == "processes":
            steps.append(_step("list the heavy processes", "pc", "pc", "pc.processes.list",
                               {"limit": 12, "sort_by": "cpu"}, depends_on=[], risk="LOW"))
        return steps

    if intent == "pc.window.manage":
        action = ("minimize" if "minimi" in low or "minimize" in low else
                  "maximize" if "maximi" in low or "maximize" in low else
                  "close" if "close" in low else
                  "restore" if "restore" in low else
                  "move" if "move" in low else
                  "resize" if "resize" in low or "size" in low else
                  "focus" if any(w in low for w in ("focus", "bring", "front", "switch")) else
                  "list")
        params: Dict[str, Any] = {"action": action, "request": text}
        if app:
            params["app"] = app
        if action in ("move", "resize"):
            params.update({"x": 100, "y": 100, "width": 1280, "height": 800})
        if action == "list":
            return [_step("list open windows", "pc", "pc", "pc.windows.list", {"search": app or ""},
                          risk="LOW")]
        return [_step(f"{action} window", "pc", "pc", "pc.window_action", params,
                      risk="MEDIUM", confirm=True)]

    if intent == "pc.volume":
        mute = any(w in low for w in ("mute", "silent", "unmute"))
        params = {"request": text}
        if mute:
            params["mute"] = "unmute" not in low
        elif pct is not None:
            params["percent"] = int(pct)
        elif "up" in low:
            params["percent"] = 70
        elif "down" in low:
            params["percent"] = 30
        return [_step("set the volume", "pc", "pc", "pc.volume", params, risk="LOW")]

    if intent == "pc.brightness":
        params = {"request": text}
        if pct is not None:
            params["percent"] = int(pct)
        else:
            params["percent"] = 40 if any(w in low for w in ("down", "dim", "lower")) else 80
        return [_step("set the brightness", "pc", "pc", "pc.brightness", params, risk="LOW")]

    # ------------------------------------------------------------ files ----
    if intent == "files.search":
        ext = ""
        m = re.search(r"\b(pdf|docx?|xlsx?|pptx?|csv|txt|png|jpe?g|zip|mp3|mp4|json|py|md)\b", low)
        if m:
            ext = m.group(1)
        query = quoted[0] if quoted else re.sub(
            r"\b(find|search|look|for|the|my|all|any|files?|documents?|please|on|in)\b", "",
            text, flags=re.I).strip()
        return [_step("search the files", "files", "pc", "files.search",
                      {"query": query or text, "ext": ext, "limit": 25,
                       "folder": (app if app and app not in ("chrome",) else "")},
                      risk="LOW", timeout=90)]

    if intent == "files.organise":
        folder = quoted[0] if quoted else (app or "")
        strategy = ("extension" if any(w in low for w in ("type", "extension", "kind")) else
                    "date" if any(w in low for w in ("date", "month", "year")) else
                    "size" if "size" in low else "extension")
        return [
            _step("plan the moves (dry run)", "reasoning", "pc", "files.plan_organise",
                  {"folder": folder, "strategy": strategy, "query": text}, risk="LOW", timeout=90),
            _step("organise the folder", "files", "pc", "files.organise",
                  {"folder": folder, "strategy": strategy, "dry_run": False, "max_moves": 500},
                  risk="MEDIUM", confirm=True, timeout=180),
        ]

    if intent == "files.convert":
        m = re.search(r"\bto\s+(pdf|docx?|xlsx?|pptx?|csv|txt|png|jpe?g|md|json|zip)\b", low)
        return [_step("convert the file", "files", "pc", "files.convert",
                      {"path": (quoted[0] if quoted else text), "to": (m.group(1) if m else "pdf"),
                       "query": text}, risk="MEDIUM", confirm=True, timeout=180)]

    if intent == "files.backup":
        return [_step("back up", "files", "pc", "files.backup",
                      {"path": (quoted[0] if quoted else text), "label": "manual", "keep": 10,
                       "request": text}, risk="MEDIUM", confirm=True, timeout=600)]

    # ---------------------------------------------------------- terminal ----
    if intent == "terminal.run":
        command = slots.get("command") or (quoted[0] if quoted else text)
        return [_step("run the command", "pc", "pc", "pc.terminal",
                      {"command": command, "timeout": 120}, risk="HIGH", confirm=True, timeout=300)]

    # ----------------------------------------------------------- browser ----
    if intent == "browser.open":
        steps = [
            _step("open the page", "browser", "browser", "browser.navigate",
                  {"url": url or text, "request": text, "wait": 3}, risk="MEDIUM", timeout=120),
            _step("read what is on the page", "browser", "browser", "browser.read_page",
                  {"screenshot": False, "max_text": 12000}, depends_on=[], risk="LOW", timeout=90),
        ]
        if any(w in low for w in ("summar", "what does it say", "read it", "tell me")):
            steps.append(_step("summarise the page", "writing", "cloud", "research.summarise",
                               {"question": text, "request": text, "citations": True,
                                "max_words": 400}, depends_on=[], risk="LOW", timeout=120))
        return steps

    if intent == "browser.scrape":
        kind = ("table" if any(w in low for w in ("table", "prices", "list of")) else
                "links" if "link" in low else "text")
        return [
            _step("open the page", "browser", "browser", "browser.navigate",
                  {"url": url or text, "request": text, "wait": 3}, risk="MEDIUM", timeout=120),
            _step("extract structured data", "browser", "browser", "browser.extract",
                  {"query": text, "kind": kind, "limit": 60}, depends_on=[], risk="LOW",
                  timeout=120),
        ]

    # ---------------------------------------------------------- research ----
    if intent == "research.deep":
        return [
            _step("search sources", "research", "cloud", "research.search",
                  {"query": text, "limit": 8}, risk="LOW", timeout=90),
            _step("read top sources", "research", "cloud", "research.read",
                  {"max_chars": 20000}, depends_on=[], risk="LOW", timeout=120),
            _step("cross-check and compare", "reasoning", "cloud", "research.compare",
                  {"claim": text, "request": text}, depends_on=[], risk="LOW", timeout=120),
            _step("write cited summary", "writing", "cloud", "research.summarise",
                  {"question": text, "request": text, "citations": True, "max_words": 700},
                  depends_on=[], risk="LOW", timeout=150),
        ]

    # ------------------------------------------------------------ coding ----
    if intent == "coding.test":
        return [
            _step("detect the toolchain", "coding", "pc", "pc.dev.detect", {}, risk="LOW"),
            _step("run the tests", "coding", "pc", "coding.run_tests",
                  {"project_path": (quoted[0] if quoted else ""), "command": "",
                   "language": ""}, depends_on=[], risk="HIGH", confirm=True, timeout=600),
        ]

    if intent == "coding.write":
        goal = quoted[0] if quoted else text
        return [
            _step("analyse requirements", "coding", "pc", "coding.analyse",
                  {"goal": goal, "language": "", "project_path": "", "request": text},
                  risk="LOW", timeout=120),
            _step("plan the architecture", "reasoning", "pc", "coding.architecture",
                  {"goal": goal, "language": "", "project_path": ""}, depends_on=[],
                  risk="LOW", timeout=120),
            _step("generate the code", "coding", "pc", "coding.generate",
                  {"goal": goal, "language": "", "files": None}, depends_on=[],
                  risk="MEDIUM", timeout=300),
            _step("write the files", "coding", "pc", "coding.write_files",
                  {"project_path": "", "files": None, "overwrite": False}, depends_on=[],
                  risk="MEDIUM", confirm=True, timeout=120),
            _step("run the tests", "coding", "pc", "coding.run_tests",
                  {"project_path": "", "command": "", "language": ""}, depends_on=[],
                  risk="HIGH", confirm=True, timeout=600),
        ]

    if intent == "coding.debug":
        return [
            _step("diagnose the error", "reasoning", "pc", "coding.analyse_error",
                  {"error": (quoted[0] if quoted else text), "problem": text,
                   "project_path": ""}, risk="LOW", timeout=150),
            _step("propose and apply the fix", "coding", "pc", "coding.repair",
                  {"project_path": "", "fix": True, "files": None}, depends_on=[],
                  risk="MEDIUM", confirm=True, timeout=300),
            _step("re-run the tests", "coding", "pc", "coding.run_tests",
                  {"project_path": "", "command": "", "language": ""}, depends_on=[],
                  risk="HIGH", confirm=True, timeout=600),
        ]

    if intent == "coding.explain":
        return [_step("explain the code", "coding", "pc", "coding.explain",
                      {"path": (quoted[0] if quoted else ""), "code": text, "target": "",
                       "depth": "detailed"}, risk="LOW", timeout=180)]

    # --------------------------------------------------------- documents ----
    if intent == "document.create":
        fmt = ("docx" if any(w in low for w in ("word", "docx", "letter", "resume", "cv",
                                                "report", "essay", "article")) else
               "pptx" if any(w in low for w in ("slide", "presentation", "ppt", "deck")) else
               "xlsx" if any(w in low for w in ("spreadsheet", "excel", "xlsx", "invoice",
                                                "budget", "table")) else
               "pdf" if "pdf" in low else "md")
        return [
            _step("outline the document", "writing", "cloud", "documents.outline",
                  {"request": text, "format": fmt, "sections": 0}, risk="LOW", timeout=120),
            _step("write the content", "writing", "cloud", "documents.write",
                  {"request": text, "outline": "", "word_target": 800, "tone": "professional"},
                  depends_on=[], risk="LOW", timeout=300),
            _step(f"render the {fmt.upper()} file", "files", "pc", "documents.render",
                  {"format": fmt, "markdown": "", "title": "", "output": ""}, depends_on=[],
                  risk="MEDIUM", confirm=True, timeout=180),
            _step("verify the file", "verification", "pc", "documents.verify",
                  {"path": ""}, depends_on=[], risk="LOW", timeout=90),
        ]

    # -------------------------------------------------------------- data ----
    if intent == "data.analyse":
        path = quoted[0] if quoted else ""
        return [
            _step("load the dataset", "data", "pc", "data.load", {"path": path, "sheet": "",
                                                                  "query": text},
                  risk="LOW", timeout=120),
            _step("analyse it", "data", "pc", "data.analyse",
                  {"group_by": "", "metric": "", "agg": "mean", "top": 10, "path": path,
                   "query": text}, depends_on=[], risk="LOW", timeout=180),
            _step("chart the result", "data", "pc", "data.chart",
                  {"chart": "bar", "x": "", "y": "", "title": text, "output": "",
                   "path": path, "group_by": "", "agg": "mean", "limit": 20},
                  depends_on=[], risk="LOW", timeout=180),
            _step("write the report", "data", "pc", "data.report",
                  {"format": "md", "output": "", "title": text, "path": path}, depends_on=[],
                  risk="MEDIUM", confirm=True, timeout=180),
        ]

    # ------------------------------------------------------------ images ----
    if intent == "image.generate":
        prompt = quoted[0] if quoted else re.sub(
            r"\b(generate|create|draw|design|make|me|an?|the|image|picture|of|please)\b", "",
            text, flags=re.I).strip() or text
        return [_step("generate the image", "creative", "cloud", "creative.image_generate",
                      {"prompt": prompt, "request": text, "negative": "", "aspect": "1:1",
                       "style": "", "count": 1, "pack": False}, risk="LOW", timeout=240)]

    if intent == "image.edit":
        action = ("resize" if "resize" in low else "crop" if "crop" in low else
                  "rotate" if "rotate" in low else "text" if "text" in low else
                  "enhance" if any(w in low for w in ("enhance", "improve", "upscale")) else
                  "filter" if "filter" in low else "enhance")
        return [_step(f"{action} the image", "creative", "pc", "creative.image_edit",
                      {"path": (quoted[0] if quoted else ""), "action": action, "width": 0,
                       "height": 0, "degrees": 0, "quality": 90, "text": "", "output": "",
                       "request": text}, risk="MEDIUM", confirm=True, timeout=180)]

    # ------------------------------------------------------------- email ----
    if intent == "email.read":
        return [_step("read the inbox", "communication", "pc", "email.read",
                      {"limit": 15, "unread_only": "unread" in low, "search": "",
                       "folder": "inbox", "include_body": True}, risk="MEDIUM", confirm=True,
                      timeout=120)]

    if intent == "email.send":
        m = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", text)
        return [
            _step("draft the email", "communication", "pc", "email.draft",
                  {"to": (m.group(0) if m else ""), "cc": "", "subject": "", "body": "",
                   "tone": "professional", "language": slots.get("language") or "en",
                   "instruction": text, "attachments": None, "request": text},
                  risk="LOW", timeout=180),
            _step("preview the draft", "communication", "pc", "email.preview",
                  {"draft_id": ""}, depends_on=[], risk="LOW", timeout=60),
            _step("send after confirmation", "communication", "pc", "email.send",
                  {"draft_id": "", "to": (m.group(0) if m else ""), "subject": "", "body": "",
                   "cc": "", "attachments": None, "request": text}, depends_on=[],
                  risk="HIGH", confirm=True, timeout=120),
        ]

    # ------------------------------------------------- calendar / timers ----
    if intent == "calendar.manage":
        if any(w in low for w in ("list", "show", "what", "schedule for", "agenda", "today",
                                  "tomorrow", "this week")):
            days = int(_extract_number(text, after=("next", "days"), maximum=90) or 7)
            return [_step("read the calendar", "planning", "pc", "calendar.list",
                          {"days": days, "date": "", "include_past": False, "search": ""},
                          risk="LOW", timeout=60)]
        if any(w in low for w in ("remove", "delete", "cancel")):
            return [_step("remove the event", "planning", "pc", "calendar.remove",
                          {"event_id": "", "title": text, "request": text},
                          risk="MEDIUM", confirm=True, timeout=60)]
        return [_step("create the event", "planning", "pc", "calendar.upsert",
                      {"title": text, "start": "", "end": "", "when": text, "at": "",
                       "duration_minutes": 60, "location": "", "notes": "",
                       "reminder_minutes": 15, "all_day": False, "event_id": "",
                       "request": text}, risk="MEDIUM", confirm=True, timeout=90)]

    if intent == "timer.set":
        minutes = slots.get("minutes") or 5
        when = "" if minutes and minutes > 0 else "now"
        return [_step("schedule the reminder", "planning", "pc", "scheduler.create",
                      {"instruction": text, "when": "", "at": "", "every": "", "on": "",
                       "priority": "normal", "device": "pc", "name": "", "enabled": True,
                       "request": text}, risk="MEDIUM", confirm=True, timeout=60)]

    # ------------------------------------------------------------- phone ----
    if intent == "phone.control":
        return [_step("run it on the phone", "phone", "phone", "phone.dispatch",
                      {"request": text, "device_id": ""}, risk="MEDIUM", confirm=True,
                      timeout=120)]

    if intent == "phone.notify":
        return [_step("notify the phone", "phone", "phone", "phone.notify",
                      {"title": "SAM", "body": text, "request": text, "device_id": ""},
                      risk="LOW", timeout=60)]

    # ------------------------------------------------------------ memory ----
    if intent == "memory.store":
        return [_step("store the memory", "memory", "pc", "memory.write",
                      {"content": text, "kind": "fact", "key": "", "scope": "user",
                       "tags": "", "importance": 0.6, "request": text}, risk="LOW", timeout=45)]

    if intent == "memory.recall":
        return [
            _step("search the memory", "memory", "pc", "memory.search",
                  {"query": text, "kind": "", "scope": "", "limit": 8, "request": text},
                  risk="LOW", timeout=60),
            _step("semantic recall", "memory", "pc", "memory.semantic_search",
                  {"query": text, "limit": 5}, depends_on=[], risk="LOW", timeout=90),
        ]

    # -------------------------------------------------------- automation ----
    if intent == "automation.create":
        return [_step("create the automation", "planning", "pc", "automation.create",
                      {"instruction": text, "name": "", "when": "", "condition": "",
                       "action": "", "verify": "", "enabled": True, "priority": "normal",
                       "request": text}, risk="MEDIUM", confirm=True, timeout=90)]

    # ---------------------------------------------------------- security ----
    if intent == "security.status":
        return [
            _step("security report", "security", "pc", "security.report", {}, risk="LOW"),
            _step("permission table", "security", "pc", "security.permissions",
                  {"category": "", "search": ""}, depends_on=[], risk="LOW"),
            _step("recent audit trail", "security", "pc", "security.audit",
                  {"limit": 20, "device": "", "agent": "", "result": "", "risk": "",
                   "since_hours": 24, "search": ""}, depends_on=[], risk="LOW"),
        ]

    if intent == "sam.status":
        return [_step("report SAM's status", "core", "pc", "core.status", {}, risk="LOW")]

    if intent == "translate":
        m = re.search(r"\b(?:in|to|into)\s+(hindi|kannada|tamil|telugu|marathi|bengali|french|"
                      r"german|spanish|japanese|chinese|arabic|portuguese|russian|italian|"
                      r"korean|english)\b", low)
        return [_step("translate the text", "communication", "cloud", "core.translate",
                      {"text": (quoted[0] if quoted else text), "target": (m.group(1) if m else ""),
                       "request": text}, risk="LOW", timeout=90)]

    if intent == "core.help":
        return [_step("explain what SAM can do", "core", "pc", "core.help",
                      {"topic": text, "request": text}, risk="LOW")]

    # ---- conversation / everything else --------------------------------
    style = "brief" if intent in ("greeting", "farewell") else "normal"
    params: Dict[str, Any] = {"question": text, "request": text, "use_memory": True,
                              "language": slots.get("language") or "en", "style": style,
                              "max_words": 0}
    # an arithmetic question is answered by the maths engine, not by prose
    if re.fullmatch(r"\s*-?[\d.,\s\+\-\*/x×÷%^()]+\s*", text or "") or (
            intent == "chat.general" and re.search(r"\d\s*(?:\+|-|\*|/|%|plus|minus|times)\s*\d", low)):
        return _math_plan("math.calculate", text)
    return [_step("understand and answer", "core", "both", "core.answer", params, risk="LOW")]


def _plan_body(intent: str, text: str, slots: Dict[str, Any]) -> Optional[List[TaskStepModel]]:
    """
    Plan templates for the market, web, maths, writing and developer toolboxes
    (called from :func:`plan_for_intent`, which owns the PC / files / browser /
    coding / communication intents).
    """
    low = text.lower()
    if intent.startswith(("text.", "code.")):
        return _text_code_plan(intent, text, slots)

    # =====================================================================
    # Market Analyzer plans
    # =====================================================================
    if intent.startswith("market."):
        tf = _extract_timeframe(text) or "1h"
        low = text.lower()
        syms = _extract_symbols(text)

        if intent == "market.quote":
            return [_step("fetch the live quote", "markets", "cloud", "market.quote",
                          {"symbol": text}, risk="LOW", timeout=60)]

        if intent == "market.signal":
            return [
                _step("score the setup", "markets", "cloud", "market.signal",
                      {"symbol": text, "interval": tf}, risk="LOW", timeout=90),
                _step("map the key levels", "markets", "cloud", "market.levels",
                      {"symbol": text, "interval": "1d"}, depends_on=[], risk="LOW", timeout=90),
            ]

        if intent == "market.analysis":
            frames = [tf] + [f for f in ("15m", "1h", "4h", "1d") if f != tf][:2]
            return [_step("build the technical report", "markets", "cloud", "market.technical_report",
                          {"symbol": text, "timeframes": frames, "style": "standard", "save": False},
                          risk="LOW", timeout=180)]

        if intent == "market.forex_plan":
            params: Dict[str, Any] = {"symbol": text, "interval": tf}
            bal = _extract_number(text, after=("balance", "account", "capital", "with"), maximum=1e9)
            if bal and bal > 100:
                params["balance"] = bal
            rp = _extract_number(text, after=("risk", "risking"), maximum=100)
            if rp and 0 < rp <= 100:
                params["risk_percent"] = min(rp, 5)
            rr = _extract_number(text, after=("rr", "reward", "r:r"), maximum=20)
            if rr and 0.5 <= rr <= 20:
                params["rr"] = rr
            if tf in ("15m", "30m", "1h"):
                params["htf"] = "4h"
            return [_step("build the trade plan", "markets", "cloud", "market.forex_plan",
                          params, risk="LOW", timeout=150)]

        if intent == "market.binary":
            expiry = _extract_number(text, after=("expiry", "minute", "minutes", "second"),
                                     maximum=1440) or 5
            if "second" in low:
                expiry = 1
            payout = _extract_number(text, after=("payout",), maximum=200) or 80
            chart = "1m" if expiry <= 5 else "5m" if expiry <= 30 else "15m"
            return [_step("analyse the binary setup", "markets", "cloud", "market.binary_analysis",
                          {"symbol": text, "interval": _extract_timeframe(text) or chart,
                           "expiry_minutes": int(expiry), "payout_percent": float(payout)},
                          risk="LOW", timeout=150)]

        if intent == "market.backtest":
            strategy = _first_match(text, _STRATEGIES, "ma_cross")
            payout = _extract_number(text, after=("payout",), maximum=200) or 80.0
            expiry = int(_extract_number(text, after=("expiry", "bars", "candles"), maximum=48) or 5)
            return [
                _step(f"backtest {strategy}", "markets", "cloud", "market.backtest",
                      {"symbol": text, "strategy": strategy,
                       "interval": _extract_timeframe(text) or "1d", "limit": 600,
                       "walk_forward": True, "expiry_candles": expiry, "payout_percent": payout},
                      risk="LOW", timeout=240),
                _step("explain what the numbers mean", "markets", "cloud", "market.explain",
                      {"topic": "backtest", "level": "intermediate", "with_example": True},
                      depends_on=[], risk="LOW", timeout=90),
            ]

        if intent == "market.journal":
            if any(w in low for w in ("stats", "statistic", "how am i", "how have i", "performance",
                                      "win rate", "summary")):
                days = _extract_number(text, after=("last", "past"), maximum=3650)
                return [_step("journal statistics", "markets", "pc", "market.journal.stats",
                              {"days": int(days) if days else None}, risk="LOW", timeout=60)]
            if "close" in low:
                tid = _extract_number(text, after=("trade", "id", "#"), maximum=100000)
                exit_price = _extract_number(text, after=("at", "exit", "price"), maximum=1e7)
                return [_step("close the journal trade", "markets", "pc", "market.journal.close",
                              {"trade_id": int(tid) if tid else None,
                               "exit_price": float(exit_price) if exit_price else 0.0,
                               "symbol": text}, risk="LOW", timeout=60)]
            if "review" in low:
                tid = _extract_number(text, after=("trade", "id", "#"), maximum=100000)
                return [_step("attach a review", "markets", "pc", "market.journal.review",
                              {"trade_id": int(tid) if tid else None, "review": text},
                              risk="LOW", timeout=60)]
            if any(w in low for w in ("show", "list", "recent", "open trades", "history")):
                return [_step("list journal trades", "markets", "pc", "market.journal.list",
                              {"limit": 15, "symbol": (syms[0] if syms else "")},
                              risk="LOW", timeout=60)]
            direction = "short" if any(w in low for w in ("short", "sold", "sell", "down", "put")) else "long"
            add: Dict[str, Any] = {
                "symbol": (syms[0] if syms else text), "direction": direction,
                "product": "binary" if "binary" in low else "spot",
                "timeframe": _extract_timeframe(text) or "1h", "notes": text,
                "strategy": _first_match(text, _STRATEGIES, ""),
            }
            for kw, key in ((("entry", "bought at", "sold at", "at"), "entry"),
                            (("stop", "sl"), "stop"), (("size", "units", "lots"), "units"),
                            (("stake",), "stake")):
                val = _extract_number(text, after=kw, maximum=1e9)
                if val:
                    add[key] = float(val)
            tps = re.findall(r"(?:target|tp)\D{0,6}([\d.]+)", low)
            if tps:
                add["targets"] = [float(t) for t in tps[:3]]
            exp = _extract_number(text, after=("expiry",), maximum=1440)
            if exp:
                add["expiry_minutes"] = int(exp)
            pay = _extract_number(text, after=("payout",), maximum=200)
            if pay:
                add["payout_percent"] = float(pay)
            return [_step("add the trade to the journal", "markets", "pc", "market.journal.add",
                          add, risk="LOW", timeout=60)]

        if intent == "market.paper":
            if any(w in low for w in ("portfolio", "balance", "position", "how am i doing", "equity")):
                return [_step("paper portfolio", "markets", "pc", "market.paper.portfolio",
                              {"status": "open"}, risk="LOW", timeout=60)]
            if "close" in low:
                pid = _extract_number(text, after=("position", "id", "#"), maximum=100000)
                exit_price = _extract_number(text, after=("at", "exit", "price"), maximum=1e7)
                return [_step("close the paper position", "markets", "pc", "market.paper.close",
                              {"position_id": int(pid) if pid else None,
                               "exit_price": float(exit_price) if exit_price else None,
                               "symbol": (syms[0] if syms else text), "notes": text},
                              risk="MEDIUM", confirm=True, timeout=60)]
            if "reset" in low:
                return [_step("reset the paper account", "markets", "pc", "market.paper.reset",
                              {"starting_balance": float(getattr(
                                  __import__("backend.app.config", fromlist=["settings"]).settings,
                                  "market_paper_balance", 10000) or 10000)},
                              risk="MEDIUM", confirm=True, timeout=60)]
            direction = "short" if any(w in low for w in ("short", "sell", "down", "put", "bearish")) else "long"
            trade: Dict[str, Any] = {"symbol": (syms[0] if syms else text), "direction": direction,
                                     "notes": text}
            entry = _extract_number(text, after=("entry", "at"), maximum=1e7)
            stop = _extract_number(text, after=("stop", "sl"), maximum=1e7)
            risk_pct = _extract_number(text, after=("risk",), maximum=100)
            if entry:
                trade["entry"] = float(entry)
            if stop and stop != entry:
                trade["stop"] = float(stop)
            if risk_pct and 0 < risk_pct <= 100:
                trade["risk_percent"] = min(float(risk_pct), 5.0)
            tps = re.findall(r"(?:target|tp)\D{0,6}([\d.]+)", low)
            if tps:
                trade["targets"] = [float(t) for t in tps[:3]]
            return [_step(f"open a PAPER {direction} position", "markets", "pc", "market.paper.trade",
                          trade, risk="MEDIUM", confirm=True, timeout=90)]

        if intent == "market.alert":
            if any(w in low for w in ("list", "show", "my alerts", "what am i watching")):
                return [_step("list price alerts", "markets", "pc", "market.alert.list",
                              {"enabled_only": True}, risk="LOW", timeout=45)]
            if any(w in low for w in ("remove", "delete", "cancel", "stop watching")):
                aid = _extract_number(text, after=("alert", "id", "#"), maximum=100000)
                return [_step("remove a price alert", "markets", "pc", "market.alert.remove",
                              {"alert_id": int(aid) if aid else None,
                               "disable_only": aid is None},
                              risk="LOW", confirm=True, timeout=45)]
            if "check" in low:
                return [_step("check the alerts now", "markets", "cloud", "market.alert.check",
                              {}, risk="LOW", timeout=90)]
            condition = _first_match(text, _ALERT_CONDITIONS, "above")
            threshold = _extract_number(text, after=("above", "below", "at", "reaches", "hits",
                                                     "crosses", "="), maximum=1e8)
            params = {"symbol": (syms[0] if syms else text), "condition": condition,
                      "timeframe": _extract_timeframe(text) or "1h",
                      "message": text, "once": True, "cooldown_minutes": 60}
            if threshold is not None:
                params["threshold"] = float(threshold)
            return [_step("set the price alert", "markets", "pc", "market.alert.set",
                          params, risk="LOW", timeout=60)]

        if intent == "market.screener":
            universe = ("crypto" if any(w in low for w in ("crypto", "coin", "bitcoin")) else
                        "stocks" if any(w in low for w in ("stock", "share", "equity")) else
                        "indices" if any(w in low for w in ("index", "indices", "nifty", "sensex")) else
                        "commodities" if any(w in low for w in ("commodity", "gold", "oil", "silver")) else
                        "forex")
            return [_step(f"scan the {universe} universe", "markets", "cloud", "market.screener",
                          {"symbols": syms or _UNIVERSES.get(universe, _UNIVERSES["forex"]),
                           "interval": tf, "min_confidence": 0.35, "direction": "any"},
                          risk="LOW", timeout=240)]

        if intent == "market.watchlist":
            return [_step("scan the watchlist", "markets", "cloud", "market.watchlist",
                          {"symbols": syms or None, "interval": tf, "with_signal": True},
                          risk="LOW", timeout=180)]

        if intent == "market.sentiment":
            topic = (syms[0] if syms else text)
            return [
                _step("read the headlines", "markets", "cloud", "market.sentiment",
                      {"symbol": topic, "limit": 8}, risk="LOW", timeout=120),
                _step("build the risk calendar", "markets", "cloud", "market.calendar",
                      {"topic": topic, "limit": 6}, depends_on=[], risk="LOW", timeout=120),
            ]

        if intent == "market.compare":
            tool = "market.correlation" if "correlat" in low else "market.compare"
            return [_step("compare the markets", "markets", "cloud", tool,
                          {"symbols": syms or None, "interval": "1d", "lookback": 90},
                          risk="LOW", timeout=180)]

        if intent == "market.risk":
            op = _first_match(text, _RISK_OPS, "position_size")
            nums = [float(n.replace(",", "")) for n in re.findall(r"-?[\d,]+(?:\.\d+)?", text)]
            inner: Dict[str, Any] = {}
            if op == "position_size" and len(nums) >= 3:
                inner = {"balance": nums[0], "risk_percent": nums[1], "entry": nums[2],
                         "stop": nums[3] if len(nums) > 3 else None}
            elif op == "kelly" and len(nums) >= 2:
                inner = {"win_rate": nums[0], "payoff": nums[1]}
            elif op == "risk_of_ruin" and nums:
                inner = {"win_rate": nums[0], "risk_per_trade": nums[1] if len(nums) > 1 else 1.0}
            elif op == "drawdown_math" and nums:
                inner = {"drawdown_percent": nums[0]}
            elif op == "stake_plan" and nums:
                inner = {"balance": nums[0], "risk_percent": nums[1] if len(nums) > 1 else 1.0}
            elif op == "expectancy" and len(nums) >= 2:
                inner = {"win_rate": nums[0], "payoff": nums[1]}
            elif op == "martingale_check" and len(nums) >= 2:
                inner = {"balance": nums[0], "base_stake": nums[1]}
            elif op == "margin_required" and len(nums) >= 2:
                inner = {"price": nums[0], "units": nums[1],
                         "leverage": nums[2] if len(nums) > 2 else 100}
            elif op == "pip_value" and nums:
                inner = {"pair": (syms[0] if syms else "EURUSD"), "lots": nums[0]}
            return [_step("run the risk maths", "markets", "pc", "market.risk",
                          {"operation": op, "params": inner or None}, risk="LOW", timeout=60)]

        if intent == "market.explain":
            topic = re.sub(r"\b(what|is|are|does|do|explain|define|tell|me|about|how|the|a|an|"
                           r"mean|means|in|trading|please)\b", "", low).strip()
            level = ("advanced" if any(w in low for w in ("advanced", "deep", "maths", "formula"))
                     else "beginner" if any(w in low for w in ("simple", "beginner", "basic", "eli5"))
                     else "intermediate")
            return [_step(f"explain '{topic or text}'", "markets", "cloud", "market.explain",
                          {"topic": topic or text, "level": level, "with_example": True},
                          risk="LOW", timeout=90)]

        # any other market.* intent: let the brain report its own status
        return [_step("market analyzer status", "markets", "pc", "market.status",
                      {"deep": True}, risk="LOW", timeout=60)]

    # =====================================================================
    # General web / knowledge plans
    # =====================================================================
    if intent.startswith("web."):
        if intent == "web.define":
            word = re.sub(r"\b(definition|define|meaning|of|the|what|does|mean|please)\b", "",
                          text, flags=re.I).strip() or text
            return [
                _step(f"look up '{word}'", "research", "cloud", "web.define",
                      {"word": word}, risk="LOW", timeout=60),
                _step("find related words", "research", "cloud", "web.thesaurus",
                      {"word": word, "kind": "syn", "limit": 10}, depends_on=[],
                      risk="LOW", timeout=60),
            ]
        if intent == "web.weather":
            place = re.sub(r"\b(weather|forecast|temperature|in|at|for|the|tomorrow|today|"
                           r"how\s+is|will\s+it\s+rain|please|of|next)\b", "", text,
                           flags=re.I).strip() or text
            days = int(_extract_number(text, after=("days", "day", "next"), maximum=14) or 3)
            return [_step(f"weather for {place or 'your area'}", "research", "cloud", "web.weather",
                          {"place": place, "days": days}, risk="LOW", timeout=60)]
        if intent == "web.time":
            zone = re.sub(r"\b(time|current|local|present|in|at|the|what|is|it|please|convert|to|"
                          r"zone|right|now)\b", "", text, flags=re.I).strip() or text
            return [_step(f"time in {zone}", "research", "cloud", "web.time",
                          {"timezone": zone}, risk="LOW", timeout=45)]
        if intent == "web.exchange":
            amount = _extract_number(text, maximum=1e12) or 1.0
            return [
                _step("fetch the live exchange rates", "research", "cloud", "web.currency",
                      {"amount": float(amount), "request": text}, risk="LOW", timeout=60),
                _step("show the conversion maths", "reasoning", "pc", "math.unit_convert",
                      {"value": float(amount), "from_unit": "", "to_unit": "", "request": text},
                      depends_on=[], risk="LOW", timeout=30),
            ]
        if intent == "web.news":
            topic = re.sub(r"\b(latest|news|headlines|breaking|on|about|for|today'?s|please|the)\b",
                           "", text, flags=re.I).strip() or text
            return [_step(f"news on '{topic}'", "research", "cloud", "web.news",
                          {"topic": topic, "limit": 8}, risk="LOW", timeout=90)]
        if intent == "web.wiki":
            topic = re.sub(r"\b(who|what|is|was|are|the|a|an|tell|me|about|wikipedia|history|of|"
                           r"biography|please)\b", "", text, flags=re.I).strip() or text
            return [
                _step(f"read up on '{topic}'", "research", "cloud", "web.wiki",
                      {"topic": topic, "lang": "en"}, risk="LOW", timeout=90),
                _step("check the latest news", "research", "cloud", "web.news",
                      {"topic": topic, "limit": 5}, depends_on=[], risk="LOW", timeout=90),
            ]
        if intent == "web.arxiv":
            query = re.sub(r"\b(research|papers?|academic|on|about|for|arxiv|scientific|please)\b",
                           "", text, flags=re.I).strip() or text
            return [_step("search arXiv", "research", "cloud", "web.arxiv",
                          {"query": query, "limit": 6}, risk="LOW", timeout=90)]
        if intent == "web.github":
            query = re.sub(r"\b(github|repos?|repository|for|on|find|search|please|of|about)\b",
                           "", text, flags=re.I).strip() or text
            kind = ("code" if "code" in text.lower() else
                    "issues" if "issue" in text.lower() else
                    "users" if "user" in text.lower() or "developer" in text.lower() else "repos")
            return [_step("search GitHub", "research", "cloud", "web.github",
                          {"query": query, "kind": kind, "limit": 8}, risk="LOW", timeout=90)]
        if intent == "web.image":
            query = re.sub(r"\b(find|show|search|get|download|need|images?|photos?|pictures?|"
                           r"of|for|please|some|wallpapers?)\b", "", text, flags=re.I).strip() or text
            return [_step(f"find images of '{query}'", "creative", "cloud", "web.images",
                          {"query": query, "limit": 6}, risk="LOW", timeout=90)]
        # web.search (and anything else): search, then answer with citations
        query = re.sub(r"\b(search|google|look|up|find|for|the|please|on|web|internet|online)\b",
                       "", text, flags=re.I).strip() or text
        return [
            _step("search the web", "research", "cloud", "web.search",
                  {"query": query, "limit": 8}, risk="LOW", timeout=90),
            _step("answer with citations", "reasoning", "cloud", "web.ask",
                  {"question": text, "sources": 4, "style": "detailed"}, depends_on=[],
                  risk="LOW", timeout=150),
        ]

    # =====================================================================
    # Math plans
    # =====================================================================
    if intent.startswith("math."):
        return _math_plan(intent, text)

    return None        # not a market / web / maths intent: plan_for_intent continues


def chain(steps: List[TaskStepModel]) -> List[TaskStepModel]:
    """Wire a list of steps into a sequential chain (each depends on the last)."""
    prev: Optional[str] = None
    for i, s in enumerate(steps):
        s.index = i
        if prev:
            s.depends_on = [prev]
        prev = s.id
    return steps


# ---------------------------------------------------------------------------
# Planner
# ---------------------------------------------------------------------------
class Planner:
    """Builds :class:`TaskModel` objects from user requests."""

    def __init__(self, router: Any = None) -> None:
        self.router = router

    # ------------------------------------------------------------------ slots
    @staticmethod
    def extract_slots(text: str, intent: str) -> Dict[str, Any]:
        slots: Dict[str, Any] = {
            "app": _extract_app(text),
            "url": _extract_url(text),
            "minutes": _extract_duration(text),
            "language": detect_language(text),
        }
        m = re.search(r"\b(?:run|execute)\s+(?:this\s+)?(?:command\s+)?[`\"']?(.+?)[`\"']?\s*$",
                      text, re.IGNORECASE)
        if m and intent == "terminal.run":
            slots["command"] = m.group(1).strip()
        # quoted strings are usually the important payload
        quoted = re.findall(r"[\"'“”‘’]([^\"'“”‘’]{3,200})[\"'“”‘’]", text)
        if quoted:
            slots["quoted"] = quoted
        return slots

    # ------------------------------------------------------------- fast path
    def fast_plan(self, text: str) -> Tuple[TaskModel, str, float]:
        intent, confidence = classify_intent(text)
        slots = self.extract_slots(text, intent)
        agent = intent_to_agent(intent)
        device = intent_to_device(intent)
        steps = plan_for_intent(intent, text, slots)

        # multi-step plans run sequentially; parallel plans declare depends_on=[]
        if all(not s.depends_on for s in steps) and len(steps) > 1:
            pass  # keep the fan-out shape the template produced
        else:
            chain(steps)

        kind = intent.split(".")[0]
        title = _title_for(intent, slots, text)
        task = TaskModel(
            title=title,
            request=text,
            kind=kind,
            status=TaskStatus.PLANNING,
            agent=AgentName(agent),
            device=DeviceKind(device),
            risk_level=max((s.risk for s in steps), default=RiskLevel.LOW),
            requires_confirmation=any(s.requires_confirmation for s in steps),
            steps=steps,
        )
        return task, intent, confidence

    # ------------------------------------------------------------- deep path
    async def deep_plan(self, text: str, base: TaskModel, max_steps: int = 12) -> TaskModel:
        """
        Ask the Reasoning model to refine/replace the fast plan.

        Never fails: on any error the deterministic plan is returned unchanged.
        """
        if self.router is None:
            return base
        prompt = self._planning_prompt(text, base)
        try:
            data = await self.router.ask_json(
                prompt, role="reasoning", temperature=0.1, default=None
            )
        except Exception as exc:  # pragma: no cover
            log.debug("deep plan failed: %s", exc)
            return base

        if not isinstance(data, dict) or "steps" not in data:
            return base

        steps = self._parse_model_steps(data.get("steps", []), max_steps)
        if not steps:
            return base

        base.steps = steps
        base.title = str(data.get("title") or base.title)[:200]
        base.kind = str(data.get("kind") or base.kind)
        if data.get("agent") in {a.value for a in AgentName}:
            base.agent = AgentName(data["agent"])
        if data.get("device") in {d.value for d in DeviceKind}:
            base.device = DeviceKind(data["device"])
        base.risk_level = max((s.risk for s in steps), default=RiskLevel.LOW)
        base.requires_confirmation = any(s.requires_confirmation for s in steps)
        log.info("deep plan replaced fast plan with %d steps", len(steps))
        return base

    @staticmethod
    def _planning_prompt(text: str, base: TaskModel) -> str:
        agents = ", ".join(a.value for a in AgentName)
        devices = ", ".join(d.value for d in DeviceKind)
        draft = json.dumps(
            [{"name": s.name, "agent": s.agent.value, "device": s.device.value, "tool": s.tool}
             for s in base.steps],
            indent=2,
        )
        return f"""You are SAM's Planning Brain. Convert the user's request into an executable task graph.

USER REQUEST:
{text}

DETERMINISTIC DRAFT PLAN (may be incomplete or wrong):
{draft}

VALID AGENTS: {agents}
VALID DEVICES: {devices}
VALID TOOLS: pc.launch_app, pc.close_app, pc.window_action, pc.system_info, pc.terminal,
  pc.power_lock, pc.power_sleep, pc.power_restart, pc.power_shutdown, pc.power_signout,
  pc.volume, pc.brightness, files.search, files.scan, files.organise, files.convert,
  files.archive, files.write, files.read, browser.navigate, browser.read_page,
  browser.extract, browser.form_fill, research.search, research.read, research.compare,
  research.summarise, coding.analyse, coding.architecture, coding.generate,
  coding.write_files, coding.run_tests, coding.repair, coding.explain, coding.document,
  documents.outline, documents.write, documents.render, documents.verify, data.load,
  data.clean, data.analyse, data.report, creative.prompt, creative.image_generate,
  creative.image_edit, creative.save, email.draft, email.preview, email.send, email.read,
  calendar.upsert, scheduler.timer, automation.create, memory.write, memory.search,
  phone.dispatch, phone.notify, security.report, core.status, core.answer, core.translate

RULES:
1. Use 1-8 steps. Fewer is better. Do not invent steps that cannot be executed.
2. Steps with an empty "depends_on" array run in parallel; list step indexes to
   sequence them (e.g. "depends_on": [0]).
3. Every step that changes state on a device must have "requires_confirmation": true
   when it is destructive, sends communication, spends money, or touches system config.
4. Choose the smallest sufficient "risk": LOW for reads, MEDIUM for reversible writes,
   HIGH for destructive/system changes, CRITICAL for irreversible or financial actions.
5. Prefer local execution ("pc"/"phone") over "cloud" when privacy matters.

Respond with ONLY this JSON shape:
{{
  "title": "short human title",
  "kind": "pc|files|browser|research|coding|creative|phone|planning|communication|general",
  "agent": "primary agent",
  "device": "pc|phone|browser|cloud|both",
  "steps": [
    {{"name": "...", "agent": "...", "device": "...", "tool": "...",
      "params": {{}}, "depends_on": [], "risk": "LOW|MEDIUM|HIGH|CRITICAL",
      "requires_confirmation": false, "retries": 1, "timeout_seconds": 120}}
  ]
}}"""

    @staticmethod
    def _parse_model_steps(raw: List[Any], max_steps: int) -> List[TaskStepModel]:
        if not isinstance(raw, list) or not raw:
            return []
        valid_agents = {a.value for a in AgentName}
        valid_devices = {d.value for d in DeviceKind}
        valid_risks = {r.value for r in RiskLevel}
        steps: List[TaskStepModel] = []
        for i, item in enumerate(raw[:max_steps]):
            if not isinstance(item, dict):
                continue
            agent = item.get("agent", "core")
            device = item.get("device", "pc")
            risk = str(item.get("risk", "LOW")).upper()
            try:
                deps = [str(d) for d in (item.get("depends_on") or [])]
            except Exception:
                deps = []
            steps.append(
                TaskStepModel(
                    index=i,
                    name=str(item.get("name") or f"step {i + 1}")[:120],
                    agent=AgentName(agent if agent in valid_agents else "core"),
                    device=DeviceKind(device if device in valid_devices else "pc"),
                    tool=item.get("tool") if isinstance(item.get("tool"), str) else None,
                    params=item.get("params") if isinstance(item.get("params"), dict) else {},
                    risk=RiskLevel(risk if risk in valid_risks else "LOW"),
                    requires_confirmation=bool(item.get("requires_confirmation", False)),
                    retries=int(item.get("retries", 1) or 1),
                    timeout_seconds=int(item.get("timeout_seconds", 120) or 120),
                )
            )
        # resolve numeric depends_on -> real step ids
        for s in steps:
            resolved: List[str] = []
            for d in s.depends_on:
                if d.isdigit() and 0 <= int(d) < len(steps):
                    resolved.append(steps[int(d)].id)
                elif any(x.id == d for x in steps):
                    resolved.append(d)
            s.depends_on = resolved
        if steps:
            steps[0].depends_on = []
        return steps

    # ------------------------------------------------------------------ main
    async def plan(self, text: str, *, max_steps: int = 12, use_model: Optional[bool] = None,
                   conversation_id: Optional[str] = None) -> Tuple[TaskModel, str, float]:
        """
        Produce a task plan for ``text``.

        Returns ``(task, intent, confidence)``.
        """
        base, intent, confidence = self.fast_plan(text)
        base.conversation_id = conversation_id

        want_model = use_model
        if want_model is None:
            complex_signals = (
                confidence < FAST_PATH_CONFIDENCE
                or len(text) > 220
                or any(k in text.lower() for k in ("and then", "after that", "first", "finally", "then"))
                or intent in ("research.deep", "coding.write", "coding.debug", "document.create", "data.analyse")
            )
            want_model = complex_signals

        if want_model and self.router is not None:
            base = await self.deep_plan(text, base, max_steps=max_steps)

        if len(base.steps) > max_steps:
            base.steps = base.steps[:max_steps]
        for i, s in enumerate(base.steps):
            s.index = i

        log.info("planned %r -> intent=%s conf=%.2f steps=%d agent=%s device=%s",
                 text[:60], intent, confidence, len(base.steps), base.agent.value, base.device.value)
        return base, intent, confidence


def _title_for(intent: str, slots: Dict[str, Any], text: str) -> str:
    if slots.get("app") and intent.startswith("pc.app"):
        verb = "Close" if intent.endswith("close") else "Launch"
        return f"{verb} {slots['app'].replace('vscode', 'VS Code').title()}"
    if intent == "pc.power":
        return "Power control"
    if intent.startswith("files."):
        return "File operation"
    if intent.startswith("browser."):
        return f"Browse {slots.get('url') or 'the web'}"[:80]
    if intent.startswith("research."):
        return f"Research: {text[:60]}"
    if intent.startswith("coding."):
        return f"Coding: {text[:60]}"
    if intent == "document.create":
        return f"Document: {text[:60]}"
    if intent.startswith("image."):
        return "Creative: image"
    if intent.startswith("email."):
        return "Email"
    if intent.startswith("phone."):
        return "Phone action"
    if intent.startswith("memory."):
        return "Memory"
    if intent == "automation.create":
        return "Automation"
    return text[:70] or "SAM task"


planner = Planner()
