"""
backend.app.devices.registry
============================

The unified device registry — one place that knows every device SAM can act on:
this PC, paired Android phones, browser sessions and any external endpoint.

Responsibilities:

* track online/offline state and last-seen timestamps (persisted in the DB)
* expose the capabilities each device actually reported (never assumed)
* answer **cross-device routing** questions: PC / PHONE / CLOUD / BOTH
* publish ``device.online`` / ``device.offline`` / ``device.state`` events so the
  DEVICES dashboard and the scheduler's event triggers react immediately
"""

from __future__ import annotations

import platform
import re
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import Device
from backend.app.core.database import session_scope
from sqlalchemy import select

log = get_logger("devices")

PC_ID = "pc-local"

KINDS = ("pc", "phone", "browser", "external", "cloud")

# what a device kind can do at all — the device's own report narrows this
KIND_CAPABILITIES: Dict[str, List[str]] = {
    "pc": ["apps", "windows", "keyboard", "mouse", "screen", "files", "terminal", "system",
           "power", "clipboard", "audio", "browser"],
    "phone": ["apps", "notifications", "calls", "sms", "contacts", "calendar", "media",
              "files", "camera", "screen", "settings", "sensors", "accessibility"],
    "browser": ["navigate", "read", "extract", "click", "forms", "tabs", "download",
                "screenshot", "bookmarks"],
    "cloud": ["ai", "search", "translate", "tts", "stt", "image"],
    "external": [],
}


class DeviceRegistry:
    def __init__(self) -> None:
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._loaded = False

    # ------------------------------------------------------------------- load
    async def load(self) -> int:
        """Load persisted devices and always make sure this PC is registered."""
        async with session_scope() as db:
            rows = (await db.execute(select(Device))).scalars().all()
            self._cache = {r.id: r.to_dict() for r in rows}
        self._loaded = True
        await self.register_local_pc()
        return len(self._cache)

    async def _upsert(self, device_id: str, **fields: Any) -> Dict[str, Any]:
        now = datetime.utcnow()
        async with session_scope() as db:
            row = await db.get(Device, device_id)
            if row is None:
                row = Device(id=device_id, **{k: v for k, v in fields.items()
                                              if k in ("name", "kind", "platform", "address")})
                db.add(row)
            for key, value in fields.items():
                if key == "capabilities" and isinstance(value, (list, tuple)):
                    import json
                    row.capabilities_json = json.dumps(list(value))
                elif key == "state" and isinstance(value, dict):
                    import json
                    row.state_json = json.dumps(value, default=str)
                elif key == "online":
                    row.online = bool(value)
                elif key == "last_seen":
                    row.last_seen_at = now
                elif key == "paired":
                    row.paired_at = now
                elif hasattr(row, key):
                    setattr(row, key, value)
            row.last_seen_at = now
            await db.flush()
            data = row.to_dict()
        self._cache[device_id] = data
        return data

    # ------------------------------------------------------------------ local
    async def register_local_pc(self) -> Dict[str, Any]:
        import psutil

        state = {
            "os": f"{platform.system()} {platform.release()}",
            "python": platform.python_version(),
            "cpu_percent": psutil.cpu_percent(interval=0.1),
            "cpu_cores": psutil.cpu_count(),
            "ram_percent": psutil.virtual_memory().percent,
            "ram_total_gb": round(psutil.virtual_memory().total / (1024 ** 3), 1),
            "hostname": platform.node(),
            "user": _current_user(),
            "sam_version": "1.0.0",
            "mode": settings.sam_mode,
        }
        try:
            usage = psutil.disk_usage("/")
            state["disk_free_gb"] = round(usage.free / (1024 ** 3), 1)
        except OSError:
            pass
        batt = psutil.sensors_battery()
        if batt:
            state["battery"] = {"percent": round(batt.percent), "plugged": batt.power_plugged}

        previous = self._cache.get(PC_ID)
        data = await self._upsert(
            PC_ID, name=platform.node() or "This PC", kind="pc",
            platform=f"{platform.system()} {platform.release()}",
            address=_lan_ip(), capabilities=KIND_CAPABILITIES["pc"], state=state, online=True,
        )
        if previous is None:
            emit(Topics.DEVICE_ONLINE, device_id=PC_ID, kind="pc", name=data["name"])
        emit(Topics.DEVICE_STATE, device_id=PC_ID, kind="pc", state=state)
        return data

    # ------------------------------------------------------------------ CRUD
    async def register(self, device_id: str, name: str, kind: str = "phone",
                       platform_name: str = "", address: str = "",
                       capabilities: Optional[List[str]] = None,
                       state: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if kind not in KINDS:
            kind = "external"
        caps = capabilities if capabilities is not None else KIND_CAPABILITIES.get(kind, [])
        previous = self._cache.get(device_id)
        data = await self._upsert(device_id, name=name or device_id, kind=kind,
                                  platform=platform_name, address=address,
                                  capabilities=caps, state=state or {}, online=True)
        if previous is None or not previous.get("online"):
            emit(Topics.DEVICE_ONLINE, device_id=device_id, kind=kind, name=data["name"],
                 platform=platform_name)
        return data

    async def set_online(self, device_id: str, online: bool,
                         state: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        known = self._cache.get(device_id)
        if known is None and not online:
            return None
        fields: Dict[str, Any] = {"online": online, "last_seen": True}
        if state:
            fields["state"] = state
        data = await self._upsert(device_id, **fields)
        emit(Topics.DEVICE_OFFLINE if not online else Topics.DEVICE_ONLINE,
             device_id=device_id, kind=data.get("kind"), name=data.get("name"))
        return data

    async def update_state(self, device_id: str, state: Dict[str, Any],
                           online: bool = True) -> Optional[Dict[str, Any]]:
        if device_id not in self._cache:
            return None
        merged = {**(self._cache[device_id].get("state") or {}), **state}
        data = await self._upsert(device_id, state=merged, online=online, last_seen=True)
        emit(Topics.DEVICE_STATE, device_id=device_id, kind=data.get("kind"), state=merged)
        return data

    async def remove(self, device_id: str) -> bool:
        if device_id == PC_ID:
            return False
        async with session_scope() as db:
            row = await db.get(Device, device_id)
            if row is None:
                return False
            await db.delete(row)
        self._cache.pop(device_id, None)
        emit(Topics.DEVICE_OFFLINE, device_id=device_id, reason="unpaired")
        return True

    def get(self, device_id: str) -> Optional[Dict[str, Any]]:
        return self._cache.get(device_id)

    def all(self, kind: str = "", online_only: bool = False) -> List[Dict[str, Any]]:
        items = list(self._cache.values())
        if kind:
            items = [d for d in items if d.get("kind") == kind]
        if online_only:
            items = [d for d in items if d.get("online")]
        return sorted(items, key=lambda d: (d.get("kind") != "pc", not d.get("online"),
                                            d.get("name") or ""))

    def summary(self) -> Dict[str, Any]:
        items = self.all()
        by_kind: Dict[str, Dict[str, int]] = {}
        for d in items:
            bucket = by_kind.setdefault(d.get("kind", "external"), {"total": 0, "online": 0})
            bucket["total"] += 1
            if d.get("online"):
                bucket["online"] += 1
        return {
            "total": len(items),
            "online": sum(1 for d in items if d.get("online")),
            "offline": sum(1 for d in items if not d.get("online")),
            "by_kind": by_kind,
            "ids": {d["id"]: ("ONLINE" if d.get("online") else "OFFLINE") for d in items},
        }

    # --------------------------------------------------------------- routing
    def route(self, request: str, needs: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Decide PC / PHONE / CLOUD / BOTH for a request.

        ``needs`` is the list of device capabilities the plan requires. Text
        evidence is used first (the user usually says where), then capabilities,
        then the default: PC for local actions, CLOUD for pure AI work.
        """
        text = (request or "").lower()
        explicit: Optional[str] = None
        if re.search(r"\b(on|from|my) (the )?(phone|mobile|android|device)\b", text) or \
                "phone pe" in text or "ಮೊಬೈಲ್" in text or "फ़ोन" in text:
            explicit = "PHONE"
        elif re.search(r"\b(on|in) (the )?(pc|computer|laptop|desktop|windows|this machine)\b", text):
            explicit = "PC"
        elif re.search(r"\b(both|every device|all devices|everywhere)\b", text):
            explicit = "BOTH"
        elif re.search(r"\b(in the cloud|online|from the internet)\b", text):
            explicit = "CLOUD"

        wants = set(needs or [])
        phone_only = {"calls", "sms", "contacts", "notifications", "accessibility", "sensors"}
        pc_only = {"terminal", "windows", "power", "keyboard", "mouse", "clipboard"}

        target = explicit
        if target is None:
            if wants & phone_only:
                target = "PHONE"
            elif wants & pc_only:
                target = "PC"
            elif wants & {"apps", "files", "screen", "media", "camera"}:
                target = "BOTH" if wants & {"notifications", "calls"} else "PC"
            else:
                target = "CLOUD"

        available = self._availability(target)
        return {
            "target": target,
            "explicit": explicit is not None,
            "available": available["available"],
            "devices": available["devices"],
            "fallback": available["fallback"],
            "reason": available["reason"],
            "needs": sorted(wants),
        }

    def _availability(self, target: str) -> Dict[str, Any]:
        pc = self._cache.get(PC_ID, {})
        phones = [d for d in self.all(kind="phone", online_only=True)]
        if target == "PC":
            return {"available": bool(pc.get("online")), "devices": [PC_ID] if pc else [],
                    "fallback": "PHONE" if phones else "CLOUD",
                    "reason": "runs on this computer"}
        if target == "PHONE":
            if phones:
                return {"available": True, "devices": [p["id"] for p in phones],
                        "fallback": "PC", "reason": "a companion phone is connected"}
            return {"available": False, "devices": [], "fallback": "PC",
                    "reason": "no phone is paired — install the SAM Companion app and pair it, "
                              "or connect a device with `adb devices` visible"}
        if target == "BOTH":
            devices = ([PC_ID] if pc.get("online") else []) + [p["id"] for p in phones]
            return {"available": len(devices) > 1, "devices": devices,
                    "fallback": "PC", "reason": "runs on every connected device"}
        return {"available": True, "devices": ["cloud"], "fallback": "PC",
                "reason": "pure model work — no device control needed"}

    def resolve(self, device: str = "") -> str:
        """Map a loose device reference to a registry id."""
        if not device or device in ("auto", "any"):
            return PC_ID
        low = device.lower()
        if low in ("pc", "computer", "laptop", "desktop", "local", "this"):
            return PC_ID
        if low in ("cloud", "ai"):
            return "cloud"
        if low in ("phone", "mobile", "android"):
            phones = self.all(kind="phone", online_only=True)
            return phones[0]["id"] if phones else "phone-none"
        for device_id, data in self._cache.items():
            if low == device_id.lower() or low == (data.get("name") or "").lower():
                return device_id
        return device

    async def snapshot(self) -> Dict[str, Any]:
        """Live state for the DEVICES dashboard."""
        await self.register_local_pc()
        try:
            from backend.app.devices.phone_bridge import phone_bridge

            phone_status = phone_bridge.status()
        except Exception as exc:  # pragma: no cover
            phone_status = {"ok": False, "error": str(exc)[:200]}
        try:
            from backend.app.browser.engine import browser_engine

            browser_status = browser_engine.status()
        except Exception as exc:  # pragma: no cover
            browser_status = {"ok": False, "error": str(exc)[:200]}
        return {
            "ok": True,
            "summary": self.summary(),
            "devices": self.all(),
            "phone": phone_status,
            "browser": browser_status,
            "routing": {t: self._availability(t) for t in ("PC", "PHONE", "CLOUD", "BOTH")},
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }


def _current_user() -> str:
    import getpass

    try:
        return getpass.getuser()
    except Exception:
        return ""


def _lan_ip() -> str:
    import socket

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.4)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


device_registry = DeviceRegistry()
