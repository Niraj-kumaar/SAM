"""
backend.app.devices.sync
========================

The PC ⇄ Phone sync engine.

What it actually does:

* **state mirror** — keeps one live picture of every device (battery, Wi-Fi,
  storage, focus mode, notifications count) so dashboards and automations can
  read a single source instead of polling each device.
* **clipboard bridge** — copy on the PC, paste on the phone (and back). Only
  when the user enables it, and never for content that looks like a password.
* **file bridge** — send a file PC → phone or phone → PC, through the companion
  app's own storage permission (SAM never reaches into phone storage itself).
* **notification mirror** — phone notifications can surface on the PC, and PC
  notifications can surface on the phone.
* **handoff** — "continue on my phone": SAM re-issues the same task targeted at
  the other device.

Android's permission model stays in charge: every phone-side operation is a
request to the companion app, which answers ``permission_denied`` when the user
has not granted it, and SAM reports that honestly instead of working around it.
"""

from __future__ import annotations

import asyncio
import base64
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.files.file_ops import FileSecurityError, assert_allowed

log = get_logger("devices.sync")

SYNC_INTERVAL_SECONDS = 45
MAX_CLIPBOARD_BYTES = 512 * 1024
MAX_FILE_BYTES = 50 * 1024 * 1024
TRANSFER_DIR = settings.sam_data_dir / "transfers"


@dataclass
class SyncState:
    enabled: bool = False
    clipboard_bridge: bool = False
    notification_mirror: bool = False
    file_bridge: bool = True
    auto_state_sync: bool = True
    last_sync: Optional[float] = None
    last_error: str = ""
    cycles: int = 0
    mirrored: Dict[str, Any] = field(default_factory=dict)
    history: Deque[Dict[str, Any]] = field(default_factory=lambda: deque(maxlen=200))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "enabled": self.enabled, "clipboard_bridge": self.clipboard_bridge,
            "notification_mirror": self.notification_mirror, "file_bridge": self.file_bridge,
            "auto_state_sync": self.auto_state_sync,
            "last_sync": self.last_sync, "last_error": self.last_error,
            "cycles": self.cycles, "mirrored": self.mirrored,
            "history": list(self.history)[-30:],
            "interval_seconds": SYNC_INTERVAL_SECONDS,
            "privacy_phone_sync": settings.privacy_phone_sync,
        }


class SyncEngine:
    def __init__(self) -> None:
        self.state = SyncState(enabled=settings.privacy_phone_sync is False and
                               settings.phone_enabled)
        self._task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------------ control
    def configure(self, **values: Any) -> Dict[str, Any]:
        for key in ("enabled", "clipboard_bridge", "notification_mirror", "file_bridge",
                    "auto_state_sync"):
            if key in values and values[key] is not None:
                setattr(self.state, key, bool(values[key]))
        if self.state.enabled and self._task is None:
            self.start()
        elif not self.state.enabled and self._task is not None:
            self.stop()
        return self.state.to_dict()

    def start(self) -> Dict[str, Any]:
        if settings.privacy_phone_sync:
            return {"ok": False, "error": "Privacy Mode: phone sync is switched off",
                    **self.state.to_dict()}
        if not settings.phone_enabled:
            return {"ok": False, "error": "phone support is disabled (PHONE_ENABLED=false)",
                    **self.state.to_dict()}
        self.state.enabled = True
        if self._task is None:
            try:
                self._task = asyncio.get_running_loop().create_task(self._loop())
            except RuntimeError:
                self._task = None
                return {"ok": False, "error": "no event loop running — SAM is still starting",
                        **self.state.to_dict()}
        log.info("device sync engine started")
        emit(Topics.DEVICE_STATE, component="sync", running=True)
        return {"ok": True, **self.state.to_dict()}

    def stop(self) -> Dict[str, Any]:
        self.state.enabled = False
        if self._task:
            self._task.cancel()
            self._task = None
        emit(Topics.DEVICE_STATE, component="sync", running=False)
        return {"ok": True, **self.state.to_dict()}

    async def _loop(self) -> None:
        while self.state.enabled:
            try:
                await self.sync_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover
                self.state.last_error = str(exc)[:300]
                log.debug("sync cycle failed: %s", exc)
            await asyncio.sleep(SYNC_INTERVAL_SECONDS)

    # --------------------------------------------------------------------- sync
    async def sync_once(self, device_id: str = "") -> Dict[str, Any]:
        """One mirror cycle: pull phone state, publish it, update the registry."""
        from backend.app.devices.phone_bridge import phone_bridge
        from backend.app.devices.registry import device_registry

        t0 = time.perf_counter()
        status = phone_bridge.status()
        connected = status.get("connected") or status.get("transport") == "adb"
        if not connected:
            self.state.cycles += 1
            self.state.last_error = "no phone is connected"
            return {"ok": False, "reason": "no phone connected", "status": status,
                    "took_ms": int((time.perf_counter() - t0) * 1000)}

        phone_id = device_id or _primary_phone(phone_bridge) or "phone"
        snapshot: Dict[str, Any] = {"at": time.time(), "transport": status.get("transport"),
                                    "device_id": phone_id}
        for key, method in (("battery", "battery.get"), ("wifi_state", "wifi.state"),
                            ("storage", "storage.get")):
            try:
                snapshot[key] = await _phone_send(phone_bridge, phone_id, method, {})
            except Exception as exc:
                snapshot[key] = {"ok": False, "error": str(exc)[:160]}

        # flatten into the registry state
        flat: Dict[str, Any] = {}
        battery = snapshot.get("battery") or {}
        if isinstance(battery, dict) and battery.get("ok"):
            flat["battery_percent"] = battery.get("level", battery.get("percent"))
            flat["charging"] = battery.get("charging")
            flat["battery_saver"] = battery.get("battery_saver")
        wifi = snapshot.get("wifi_state") or {}
        if isinstance(wifi, dict) and wifi.get("ok"):
            flat["wifi"] = wifi.get("enabled")
            flat["ssid"] = wifi.get("ssid")
        storage = snapshot.get("storage") or {}
        if isinstance(storage, dict) and storage.get("ok"):
            flat["storage_free_gb"] = storage.get("free_gb", storage.get("free"))
        if snapshot.get("notifications_count"):
            flat["notifications"] = snapshot["notifications_count"]

        await device_registry.update_state(phone_id, flat, online=True)
        self.state.mirrored = flat
        self.state.last_sync = time.time()
        self.state.cycles += 1
        self.state.last_error = ""
        self.state.history.append({"at": self.state.last_sync, "state": flat,
                                   "took_ms": int((time.perf_counter() - t0) * 1000)})

        # automations that watch battery / device state fire from here
        emit(Topics.PHONE_EVENT, event="state_synced", device_id=phone_id, state=flat)
        try:
            from backend.app.automation.scheduler import scheduler

            percent = flat.get("battery_percent")
            if isinstance(percent, (int, float)):
                if percent <= 20:
                    await scheduler.trigger_event("battery low", flat)
                if percent >= 95:
                    await scheduler.trigger_event("battery full", flat)
                if flat.get("charging"):
                    await scheduler.trigger_event("battery charging", flat)
        except Exception as exc:
            log.debug("event trigger failed: %s", exc)

        return {"ok": True, "device_id": phone_id, "state": flat, "snapshot": snapshot,
                "took_ms": int((time.perf_counter() - t0) * 1000)}

    # -------------------------------------------------------- clipboard bridge
    async def push_clipboard(self, text: str, direction: str = "pc_to_phone") -> Dict[str, Any]:
        if not self.state.enabled or not self.state.clipboard_bridge:
            return {"ok": False, "error": "the clipboard bridge is off",
                    "hint": "enable it in DEVICES → Sync (it is off by default for privacy)"}
        if not text:
            return {"ok": False, "error": "nothing on the clipboard"}
        if _looks_secret(text):
            emit(Topics.NOTIFICATION, level="warning", title="Clipboard not shared",
                 body="The clipboard looks like a password, key or OTP, so SAM did not sync it.")
            return {"ok": False, "blocked": True,
                    "error": "refused: the clipboard content looks like a secret"}
        if len(text.encode("utf-8")) > MAX_CLIPBOARD_BYTES:
            return {"ok": False, "error": f"clipboard is larger than {MAX_CLIPBOARD_BYTES // 1024} KB"}

        if direction == "pc_to_phone":
            from backend.app.devices.phone_bridge import phone_bridge

            result = await _phone_send(phone_bridge, _primary_phone(phone_bridge) or "",
                                       "clipboard.set", {"text": text})
        else:
            from backend.app.tools.registry import registry

            clip = registry.get("pc.clipboard.write")
            if clip is None:
                return {"ok": False, "error": "pc.clipboard.write is not registered"}
            result = await clip.fn(_ctx(), text=text)
        ok = bool(isinstance(result, dict) and result.get("ok"))
        self.state.history.append({"at": time.time(), "op": f"clipboard:{direction}",
                                   "ok": ok, "chars": len(text)})
        return {"ok": ok, "direction": direction, "chars": len(text), "result": result}

    async def pull_clipboard(self, direction: str = "phone_to_pc") -> Dict[str, Any]:
        if not self.state.enabled or not self.state.clipboard_bridge:
            return {"ok": False, "error": "the clipboard bridge is off"}
        if direction == "phone_to_pc":
            from backend.app.devices.phone_bridge import phone_bridge

            result = await _phone_send(phone_bridge, _primary_phone(phone_bridge) or "",
                                       "clipboard.get", {})
            text = (result or {}).get("text", "") if isinstance(result, dict) else ""
            if not result.get("ok"):
                return {"ok": False, "error": result.get("error", "phone refused"),
                        "permission": result.get("permission_denied")}
            if _looks_secret(text):
                return {"ok": False, "blocked": True,
                        "error": "refused: the phone clipboard looks like a secret"}
            return await self.push_clipboard(text, direction="pc_local")
        from backend.app.tools.registry import registry

        clip = registry.get("pc.clipboard.read")
        if clip is None:
            return {"ok": False, "error": "pc.clipboard.read is not registered"}
        return await clip.fn(_ctx())

    # ------------------------------------------------------------ file bridge
    async def send_file(self, path: str, direction: str = "pc_to_phone",
                        device_id: str = "") -> Dict[str, Any]:
        if not self.state.enabled or not self.state.file_bridge:
            return {"ok": False, "error": "the file bridge is off"}
        try:
            source = assert_allowed(path)
        except FileSecurityError as exc:
            return {"ok": False, "error": str(exc), "blocked": True}
        if not source.exists():
            return {"ok": False, "error": f"not found: {source}"}
        size = source.stat().st_size
        if size > MAX_FILE_BYTES:
            return {"ok": False,
                    "error": f"{source.name} is {size // (1024 * 1024)} MB — the bridge limit "
                             f"is {MAX_FILE_BYTES // (1024 * 1024)} MB"}
        if size == 0:
            return {"ok": False, "error": f"{source.name} is empty"}

        from backend.app.devices.phone_bridge import phone_bridge

        payload = base64.b64encode(source.read_bytes()).decode()
        result = await phone_bridge.send(
            device_id or _primary_phone(phone_bridge) or "", "file.receive",
            {"name": source.name, "bytes": size, "data": payload,
             "destination": "Download/SAM"}, timeout=180.0)
        ok = bool(isinstance(result, dict) and result.get("ok"))
        self.state.history.append({"at": time.time(), "op": f"file:{direction}",
                                   "name": source.name, "bytes": size, "ok": ok})
        if not ok and isinstance(result, dict) and result.get("permission_denied"):
            return {"ok": False, "error": "Android refused the transfer — the companion app needs "
                                          "the storage permission (SAM will not bypass it)",
                    "permission_denied": True}
        return {"ok": ok, "file": source.name, "bytes": size, "direction": direction,
                "result": result}

    async def receive_file(self, name: str, data_b64: str, folder: str = "") -> Dict[str, Any]:
        """Called by the companion bridge when the phone pushes a file to the PC."""
        if not self.state.enabled or not self.state.file_bridge:
            return {"ok": False, "error": "the file bridge is off"}
        try:
            raw = base64.b64decode(data_b64)
        except Exception as exc:
            return {"ok": False, "error": f"could not decode the payload: {exc}"}
        if len(raw) > MAX_FILE_BYTES:
            return {"ok": False, "error": "payload exceeds the 50 MB bridge limit"}
        base = Path(folder) if folder else \
            (settings.allowed_roots[0] if settings.allowed_roots else TRANSFER_DIR)
        try:
            base = assert_allowed(base, for_write=True)
        except FileSecurityError as exc:
            return {"ok": False, "error": str(exc), "blocked": True}
        base.mkdir(parents=True, exist_ok=True)
        safe_name = Path(name or "sam-transfer.bin").name
        target = base / safe_name
        counter = 1
        while target.exists():
            target = base / f"{Path(safe_name).stem}_{counter}{Path(safe_name).suffix}"
            counter += 1
        try:
            target.write_bytes(raw)
        except OSError as exc:
            return {"ok": False, "error": f"could not write {target}: {exc}"}
        self.state.history.append({"at": time.time(), "op": "file:phone_to_pc",
                                   "name": target.name, "bytes": len(raw), "ok": True})
        emit(Topics.NOTIFICATION, title="File received from your phone",
             body=f"{target.name} ({len(raw) // 1024} KB) → {target}", level="info",
             source="sync")
        return {"ok": True, "path": str(target), "name": target.name, "bytes": len(raw),
                "verified": target.exists()}

    # ---------------------------------------------------- notification mirror
    async def mirror_notifications(self, limit: int = 20) -> Dict[str, Any]:
        if not self.state.enabled or not self.state.notification_mirror:
            return {"ok": False, "error": "notification mirroring is off"}
        from backend.app.devices.phone_bridge import phone_bridge

        result = await _phone_send(phone_bridge, _primary_phone(phone_bridge) or "",
                                   "notifications.list", {"limit": int(limit)})
        if not isinstance(result, dict) or not result.get("ok"):
            return {"ok": False, "error": (result or {}).get("error", "phone refused"),
                    "permission_denied": bool((result or {}).get("permission_denied"))}
        items = result.get("notifications") or result.get("items") or []
        for item in items[:5]:
            emit(Topics.NOTIFICATION, title=f"📱 {item.get('app', 'Phone')}: "
                                            f"{item.get('title', '')}",
                 body=str(item.get("text", ""))[:200], level="info", source="phone")
        return {"ok": True, "count": len(items), "notifications": items}

    # --------------------------------------------------------------- handoff
    async def handoff(self, instruction: str, to_device: str = "phone") -> Dict[str, Any]:
        """Continue the same request on another device."""
        from backend.app.core.orchestrator import orchestrator
        from backend.app.devices.registry import device_registry

        device_id = device_registry.resolve(to_device)
        routing = device_registry.route(instruction)
        if to_device.lower() == "phone" and not routing["available"] and routing["target"] == "PHONE":
            return {"ok": False, "error": routing["reason"], "target": "PHONE"}
        result = await orchestrator.handle_text(
            instruction, device=device_id, channel="handoff", speak=False,
        )
        return {"ok": result.ok, "device": device_id, "reply": result.reply,
                "task_id": result.task.id if result.task else None,
                "actions": result.actions, "error": "" if result.ok else "the task reported a failure"}

    async def status(self) -> Dict[str, Any]:
        from backend.app.devices.phone_bridge import phone_bridge
        from backend.app.devices.registry import device_registry

        phone = phone_bridge.status()
        return {"ok": True, "sync": self.state.to_dict(), "phone": phone,
                "devices": device_registry.summary(),
                "running": self._task is not None and not self._task.done()}


def _primary_phone(bridge: Any) -> Optional[str]:
    try:
        return bridge.first_device_id()
    except Exception:
        return None


async def _phone_send(bridge: Any, device_id: str, method: str,
                      params: Dict[str, Any]) -> Dict[str, Any]:
    if not device_id:
        return {"ok": False, "error": "no companion phone is connected"}
    result = await bridge.send(device_id, method, params)
    return result if isinstance(result, dict) else {"ok": False, "error": "unexpected reply"}


def _looks_secret(text: str) -> bool:
    import re

    t = text.strip()
    if len(t) <= 1:
        return False
    patterns = [
        r"(?i)\b(password|passwd|pwd|passphrase|secret|api[_-]?key|token|private[_-]?key)\b",
        r"\b\d{4,8}\b(?=.{0,4}$)",                       # short all-digit strings (OTP / PIN)
        r"(?i)\botp\b|\bcvv\b|\bpin\b",
        r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
        r"\b[A-Za-z0-9_\-]{32,}\b",                       # long opaque tokens
        r"\b\d{12,19}\b",                                 # card numbers
        r"(?i)aws_access_key|sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{20,}",
    ]
    return any(re.search(p, t) for p in patterns)


def _ctx() -> Any:
    from backend.app.tools.registry import ToolContext

    return ToolContext(agent="pc", device="pc", user_text="device sync")


sync_engine = SyncEngine()
