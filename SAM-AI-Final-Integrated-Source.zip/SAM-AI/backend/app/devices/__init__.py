"""SAM backend package: ``backend.app.devices``."""
