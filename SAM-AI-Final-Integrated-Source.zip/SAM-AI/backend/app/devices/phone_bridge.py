"""
backend.app.devices.phone_bridge
================================

The PC side of the **SAM Phone** link.

Two transports, both optional:

``websocket``  the SAM Companion Android app connects to ``/ws/phone`` on the
               PC after QR/pairing-code approval. Every command is a JSON-RPC
               style message; every reply is verified. This is the default and
               the only transport that works without a USB cable.

``adb``        SAM shells out to ``adb`` for the subset of things ADB can do
               without root (battery, wifi state, storage, notifications via
               ``dumpsys``, launching apps via intents, input taps/keys). Useful
               when the phone app is not installed yet.

Android's own permission model stays in charge: SAM asks the companion app to
do something, and the companion app only does it if the user granted that
Android runtime permission. SAM never bypasses Android security.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import re
import secrets
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger

log = get_logger("devices.phone")

PROTOCOL_VERSION = "1.0"
REQUEST_TIMEOUT = 30.0


@dataclass
class PhoneSession:
    """One connected Android companion."""

    device_id: str
    ws: Any = None
    name: str = "Android"
    model: str = ""
    android_version: str = ""
    paired_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    capabilities: List[str] = field(default_factory=list)
    permissions: Dict[str, bool] = field(default_factory=dict)
    state: Dict[str, Any] = field(default_factory=dict)
    pending: Dict[str, asyncio.Future] = field(default_factory=dict)
    online: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.device_id, "name": self.name, "model": self.model,
            "android_version": self.android_version, "online": self.online,
            "paired_at": datetime.fromtimestamp(self.paired_at, tz=timezone.utc).isoformat(),
            "last_seen": datetime.fromtimestamp(self.last_seen, tz=timezone.utc).isoformat(),
            "seconds_ago": int(time.time() - self.last_seen),
            "capabilities": self.capabilities, "permissions": self.permissions,
            "state": self.state, "transport": "websocket",
        }


@dataclass
class PairingOffer:
    code: str
    created_at: float
    expires_at: float
    device_hint: str = ""
    fingerprint: str = ""
    accepted: bool = False


class PhoneBridge:
    """Registry of connected phones + command dispatcher."""

    def __init__(self) -> None:
        self.sessions: Dict[str, PhoneSession] = {}
        self.pairing_offers: Dict[str, PairingOffer] = {}
        self.history: List[Dict[str, Any]] = []
        self.adb_available: Optional[bool] = None
        self._lock = asyncio.Lock()

    # ======================================================================
    # Pairing
    # ======================================================================
    def create_pairing_code(self, device_hint: str = "", ttl: int = 300) -> PairingOffer:
        code = "-".join(secrets.choice("ABCDEFGHJKMNPQRSTUVWXYZ23456789") for _ in range(8))
        offer = PairingOffer(
            code=code, created_at=time.time(), expires_at=time.time() + ttl,
            device_hint=device_hint, fingerprint=_fingerprint(code),
        )
        self.pairing_offers[code] = offer
        self._prune_offers()
        log.info("pairing code created: %s", code)
        return offer

    def _prune_offers(self) -> None:
        now = time.time()
        for code in [c for c, o in self.pairing_offers.items() if o.expires_at < now]:
            del self.pairing_offers[code]

    async def accept_pairing(self, code: str, device_id: str, device_name: str = "",
                             shared_secret: str = "") -> bool:
        """Called by the user (via API/UI) to approve a phone's pairing request."""
        code = (code or "").upper().strip()
        offer = self.pairing_offers.get(code)
        if offer is None or offer.expires_at < time.time():
            return False
        offer.accepted = True
        async with self._lock:
            session = self.sessions.get(device_id)
            if session:
                session.name = device_name or session.name
                session.online = True
        emit(Topics.DEVICE_ONLINE, device="phone", device_id=device_id, name=device_name,
             method="paired")
        return True

    def pairing_qr_payload(self, offer: PairingOffer, host: str = "") -> Dict[str, Any]:
        """Payload the UI renders as a QR code for the phone to scan."""
        port = settings.sam_port
        addr = host or _lan_ip()
        return {
            "type": "sam-phone-pairing",
            "protocol": PROTOCOL_VERSION,
            "code": offer.code,
            "host": addr,
            "port": port,
            "ws_path": "/ws/phone",
            "url": f"ws://{addr}:{port}/ws/phone",
            "expires_in": int(offer.expires_at - time.time()),
            "fingerprint": offer.fingerprint,
        }

    def verify_handshake(self, code: str, signature: str, shared_secret: str = "") -> bool:
        """Validate the phone's HMAC signature over the pairing code."""
        secret = shared_secret or settings.phone_pairing_secret
        if not secret:
            # no secret configured -> accept the code alone (development mode)
            return code.upper().strip() in self.pairing_offers
        expected = hmac.new(secret.encode(), code.upper().strip().encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature or "")

    # ======================================================================
    # Session management (called from the WebSocket route)
    # ======================================================================
    async def register(self, device_id: str, ws: Any, hello: Dict[str, Any]) -> PhoneSession:
        async with self._lock:
            session = self.sessions.get(device_id) or PhoneSession(device_id=device_id)
            session.ws = ws
            session.online = True
            session.last_seen = time.time()
            session.name = hello.get("name") or session.name or "Android"
            session.model = hello.get("model") or session.model
            session.android_version = str(hello.get("android_version") or session.android_version)
            session.capabilities = list(hello.get("capabilities") or session.capabilities)
            session.permissions = dict(hello.get("permissions") or session.permissions)
            session.state = dict(hello.get("state") or session.state)
            self.sessions[device_id] = session
        emit(Topics.DEVICE_ONLINE, device="phone", device_id=device_id,
             name=session.name, model=session.model, capabilities=session.capabilities)
        log.info("phone connected: %s (%s)", session.name, device_id)
        return session

    async def unregister(self, device_id: str) -> None:
        async with self._lock:
            session = self.sessions.get(device_id)
            if session:
                session.online = False
                session.ws = None
                for fut in session.pending.values():
                    if not fut.done():
                        fut.cancel()
                session.pending.clear()
        emit(Topics.DEVICE_OFFLINE, device="phone", device_id=device_id)
        log.info("phone disconnected: %s", device_id)

    def touch(self, device_id: str) -> None:
        session = self.sessions.get(device_id)
        if session:
            session.last_seen = time.time()

    def update_state(self, device_id: str, state: Dict[str, Any]) -> None:
        session = self.sessions.get(device_id)
        if not session:
            return
        session.state.update(state)
        session.last_seen = time.time()
        emit(Topics.DEVICE_STATE, device="phone", device_id=device_id, **state)

    # ======================================================================
    # Commands
    # ======================================================================
    async def send(self, device_id: str, method: str, params: Optional[Dict[str, Any]] = None,
                   timeout: float = REQUEST_TIMEOUT) -> Dict[str, Any]:
        """Send an RPC to the companion app and await its verified reply."""
        session = self.sessions.get(device_id)
        if session is None or not session.online or session.ws is None:
            return await self._fallback_adb(method, params or {})

        request_id = f"r_{secrets.token_hex(6)}"
        loop = asyncio.get_running_loop()
        fut: asyncio.Future = loop.create_future()
        session.pending[request_id] = fut

        payload = {
            "jsonrpc": "2.0", "id": request_id, "method": method,
            "params": params or {}, "protocol": PROTOCOL_VERSION,
            "ts": time.time(),
        }
        try:
            await session.ws.send_text(json.dumps(payload))
        except Exception as exc:
            session.pending.pop(request_id, None)
            return {"ok": False, "error": f"could not reach the phone: {exc}"}

        self._record("send", method, device_id, params)
        try:
            result = await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            result = {"ok": False, "error": f"phone did not answer '{method}' within {timeout}s",
                      "timed_out": True}
        except asyncio.CancelledError:
            result = {"ok": False, "error": "cancelled"}
        finally:
            session.pending.pop(request_id, None)
        self._record("reply", method, device_id, {"ok": result.get("ok")})
        return result

    def resolve(self, device_id: str, request_id: str, result: Dict[str, Any]) -> bool:
        """Called by the WebSocket route when the phone answers."""
        session = self.sessions.get(device_id)
        if not session:
            return False
        fut = session.pending.get(request_id)
        if fut is None or fut.done():
            return False
        fut.set_result(result)
        return True

    async def broadcast(self, method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Send to every connected phone (used for notifications)."""
        out: Dict[str, Any] = {}
        for device_id in list(self.sessions):
            out[device_id] = await self.send(device_id, method, params)
        return out

    # ---------------------------------------------------------------- ADB
    async def _fallback_adb(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """When no companion app is connected, try ADB (if PHONE_TRANSPORT allows)."""
        if settings.phone_transport not in ("adb", "websocket"):
            return {"ok": False, "error": "no phone connected and ADB transport is disabled"}
        adb = await self._adb_path()
        if not adb:
            return {"ok": False, "error": "no phone is connected and adb was not found on PATH",
                    "hint": "install the SAM Companion app, or install Android Platform Tools"}

        devices = await self.adb_devices()
        serials = [d["serial"] for d in devices.get("devices", []) if d.get("state") == "device"]
        if not serials:
            return {"ok": False, "error": "adb found no authorised device",
                    "hint": "enable USB debugging on the phone and accept the RSA prompt"}

        serial = serials[0]
        mapping = {
            "system.state": ["shell", "dumpsys battery"],
            "battery.get": ["shell", "dumpsys battery"],
            "wifi.state": ["shell", "dumpsys wifi | grep 'mWifiInfo' | head -n 1"],
            "storage.get": ["shell", "df -h /data"],
            "device.info": ["shell", "getprop ro.product.model"],
            "apps.list": ["shell", "pm list packages -3"],
            "apps.launch": None,       # built below
            "notifications.list": ["shell", "dumpsys notification --noredact | head -n 200"],
            "display.info": ["shell", "dumpsys display | grep -E 'mBaseDisplayInfo|DisplayDeviceInfo' | head -n 5"],
            "media.volume": None,
        }

        if method == "apps.launch":
            package = str(params.get("package") or "")
            if not re.fullmatch(r"[A-Za-z0-9_.]{3,120}", package):
                return {"ok": False, "error": f"invalid package name: {package}"}
            cmd = ["shell", f"monkey -p {package} -c android.intent.category.LAUNCHER 1"]
        elif method == "media.volume":
            index = max(0, min(15, int(params.get("index", 8))))
            cmd = ["shell", f"cmd media_session volume --set {index}"]
        elif method in mapping and mapping[method]:
            cmd = mapping[method]
        else:
            return {"ok": False, "error": f"method '{method}' needs the SAM Companion app",
                    "supported_via_adb": sorted(k for k, v in mapping.items() if v is not None) +
                                         ["apps.launch", "media.volume"],
                    "transport": "adb"}

        argv = [adb, "-s", serial] + cmd
        proc = await asyncio.create_subprocess_exec(
            *argv, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            out_b, err_b = await asyncio.wait_for(proc.communicate(), timeout=25)
        except asyncio.TimeoutError:
            return {"ok": False, "error": "adb command timed out", "transport": "adb"}
        out = (out_b or b"").decode(errors="replace").strip()
        err = (err_b or b"").decode(errors="replace").strip()
        self._record("adb", method, serial, {"cmd": " ".join(cmd)[:120]})
        return {"ok": proc.returncode == 0, "transport": "adb", "serial": serial,
                "method": method, "output": _parse_adb(method, out), "raw": out[:4000],
                "error": err[:400] or None}

    async def _adb_path(self) -> Optional[str]:
        import shutil

        if self.adb_available is False:
            return None
        path = shutil.which(settings.adb_path) or shutil.which("adb")
        self.adb_available = bool(path)
        return path

    async def adb_devices(self) -> Dict[str, Any]:
        adb = await self._adb_path()
        if not adb:
            return {"ok": False, "devices": [], "error": "adb not found on PATH"}
        proc = await asyncio.create_subprocess_exec(
            adb, "devices", "-l", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            out_b, _ = await asyncio.wait_for(proc.communicate(), timeout=15)
        except asyncio.TimeoutError:
            return {"ok": False, "devices": [], "error": "adb timed out"}
        devices = []
        for line in out_b.decode(errors="replace").splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 2:
                info = {"serial": parts[0], "state": parts[1]}
                for kv in parts[2:]:
                    if ":" in kv:
                        k, v = kv.split(":", 1)
                        info[k] = v
                devices.append(info)
        return {"ok": True, "devices": devices, "count": len(devices)}

    # -------------------------------------------------------------- helpers
    def connected(self) -> List[PhoneSession]:
        return [s for s in self.sessions.values() if s.online and s.ws is not None]

    def any_connected(self) -> bool:
        return bool(self.connected())

    def first_device_id(self) -> Optional[str]:
        sessions = self.connected()
        return sessions[0].device_id if sessions else None

    def status(self) -> Dict[str, Any]:
        return {
            "enabled": settings.phone_enabled,
            "transport": settings.phone_transport,
            "connected": len(self.connected()),
            "devices": [s.to_dict() for s in self.sessions.values()],
            "adb_available": self.adb_available,
            "protocol": PROTOCOL_VERSION,
            "history": self.history[-20:],
            "permissions_required_on_phone": [
                "INTERNET", "ACCESS_NETWORK_STATE", "ACCESS_WIFI_STATE", "POST_NOTIFICATIONS",
                "READ_PHONE_STATE (optional)", "RECEIVE_BOOT_COMPLETED (optional)",
                "READ/WRITE_EXTERNAL_STORAGE or MANAGE_EXTERNAL_STORAGE (optional)",
                "SET_ALARM", "READ_CALENDAR/WRITE_CALENDAR (optional)",
                "SEND_SMS / CALL_PHONE (optional, off by default)",
                "BIND_NOTIFICATION_LISTENER_SERVICE (optional)",
                "BIND_ACCESSIBILITY_SERVICE (optional, off by default)",
            ],
        }

    def _record(self, direction: str, method: str, device_id: str,
                detail: Optional[Dict[str, Any]] = None) -> None:
        entry = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "direction": direction,
                 "method": method, "device_id": device_id,
                 "detail": _json_safe(detail or {})}
        self.history.append(entry)
        if len(self.history) > 300:
            self.history = self.history[-300:]
        emit(Topics.PHONE_EVENT, device_id=device_id, direction=direction, method=method)


def _parse_adb(method: str, raw: str) -> Dict[str, Any]:
    """Turn common ``dumpsys`` output into structured data."""
    if not raw:
        return {}
    if method in ("system.state", "battery.get"):
        out: Dict[str, Any] = {}
        for line in raw.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                k, v = k.strip(), v.strip()
                if v.isdigit():
                    out[k] = int(v)
                elif v.lower() in ("true", "false"):
                    out[k] = v.lower() == "true"
                else:
                    out[k] = v
        if "level" in out:
            out["percent"] = out["level"]
        return out
    if method == "apps.list":
        pkgs = [l.replace("package:", "").strip() for l in raw.splitlines() if l.startswith("package:")]
        return {"count": len(pkgs), "packages": pkgs[:500]}
    if method == "device.info":
        return {"model": raw.strip()}
    if method == "storage.get":
        lines = [l for l in raw.splitlines() if l.strip()]
        if len(lines) >= 2:
            cols = lines[1].split()
            if len(cols) >= 5:
                return {"filesystem": cols[0], "size": cols[1], "used": cols[2],
                        "available": cols[3], "use_percent": cols[4]}
    return {"raw": raw[:1000]}


def _json_safe(obj: Any) -> Any:
    try:
        json.dumps(obj)
        return obj
    except Exception:
        return str(obj)


def _fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()[:16].upper()


def _lan_ip() -> str:
    import socket

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"
    finally:
        s.close()


phone_bridge = PhoneBridge()
