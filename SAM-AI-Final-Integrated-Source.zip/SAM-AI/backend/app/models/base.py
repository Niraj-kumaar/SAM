"""
backend.app.models.base
=======================

Provider-agnostic model interface.

Every backend (OpenAI-compatible, Anthropic, Ollama, local runtime, mock)
implements :class:`ModelProvider`. The Model Router only ever talks to this
interface, so adding a new AI vendor is a single new file in
``backend/app/providers/``.
"""

from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Literal, Optional

Role = Literal["system", "user", "assistant", "tool"]


@dataclass
class ChatMessage:
    role: Role
    content: str
    name: Optional[str] = None
    images: List[str] = field(default_factory=list)   # data URLs or file paths

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"role": self.role, "content": self.content}
        if self.name:
            d["name"] = self.name
        if self.images:
            d["images"] = self.images
        return d


@dataclass
class ModelRequest:
    messages: List[ChatMessage]
    role: str = "primary"                 # router role: primary|reasoning|fast|coding|vision|...
    model: Optional[str] = None           # explicit override
    temperature: float = 0.4
    max_tokens: int = 2048
    top_p: float = 1.0
    stop: Optional[List[str]] = None
    json_mode: bool = False
    tools: Optional[List[Dict[str, Any]]] = None
    stream: bool = False
    system: Optional[str] = None
    timeout: float = 120.0
    meta: Dict[str, Any] = field(default_factory=dict)

    def copy_with(self, **overrides: Any) -> "ModelRequest":
        """Return a shallow copy with some fields replaced (used by the router)."""
        from dataclasses import replace
        return replace(self, **overrides)

    @classmethod
    def simple(cls, prompt: str, role: str = "primary", system: Optional[str] = None, **kw: Any) -> "ModelRequest":
        return cls(messages=[ChatMessage("user", prompt)], role=role, system=system, **kw)


@dataclass
class ModelResponse:
    text: str
    provider: str = ""
    model: str = ""
    role: str = "primary"
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    latency_ms: int = 0
    finish_reason: str = "stop"
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    raw: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    local: bool = False

    @property
    def ok(self) -> bool:
        return self.error is None

    def json(self) -> Optional[Any]:
        """Best-effort JSON parse of the response text."""
        import json
        import re

        text = (self.text or "").strip()
        if not text:
            return None
        # strip markdown fences
        fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
        if fence:
            text = fence.group(1).strip()
        # grab the outermost {...} or [...]
        for opener, closer in (("{", "}"), ("[", "]")):
            start = text.find(opener)
            end = text.rfind(closer)
            if start != -1 and end > start:
                try:
                    return json.loads(text[start : end + 1])
                except Exception:
                    continue
        try:
            return json.loads(text)
        except Exception:
            return None


@dataclass
class ModelInfo:
    """What a provider advertises about one of its models."""

    provider: str
    model: str
    roles: List[str] = field(default_factory=lambda: ["primary", "fast"])
    context_window: int = 8192
    vision: bool = False
    streaming: bool = True
    tools: bool = False
    local: bool = False
    languages: List[str] = field(default_factory=list)
    cost_per_1k_in: float = 0.0
    cost_per_1k_out: float = 0.0
    quality: int = 3          # 1 (fast/cheap) .. 5 (best reasoning)
    speed: int = 3            # 1 (slow) .. 5 (very fast)
    privacy: int = 3          # 1 (data leaves machine) .. 5 (fully local)
    enabled: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "provider": self.provider,
            "model": self.model,
            "roles": self.roles,
            "context_window": self.context_window,
            "vision": self.vision,
            "streaming": self.streaming,
            "tools": self.tools,
            "local": self.local,
            "languages": self.languages,
            "quality": self.quality,
            "speed": self.speed,
            "privacy": self.privacy,
            "enabled": self.enabled,
        }


class ModelProvider(abc.ABC):
    """Base class for every AI backend SAM can talk to."""

    name: str = "base"
    is_local: bool = False
    priority: int = 50          # lower = preferred when everything else ties

    def __init__(self) -> None:
        self._healthy = True
        self._last_error: Optional[str] = None
        self._fail_count = 0

    # ------------------------------------------------------------- contract
    @abc.abstractmethod
    async def complete(self, req: ModelRequest) -> ModelResponse: ...

    async def stream(self, req: ModelRequest) -> AsyncIterator[str]:
        """Default: emit the whole completion as one chunk."""
        res = await self.complete(req)
        if res.ok and res.text:
            yield res.text

    @abc.abstractmethod
    def available(self) -> bool:
        """Cheap check: is this provider usable right now (keys, binaries)?"""

    async def health(self) -> Dict[str, Any]:
        return {"provider": self.name, "healthy": self._healthy, "last_error": self._last_error,
                "available": self.available(), "local": self.is_local}

    def models(self) -> List[ModelInfo]:
        return []

    # ------------------------------------------------------------- helpers
    def mark_failure(self, error: str) -> None:
        self._last_error = error
        self._fail_count += 1
        if self._fail_count >= 3:
            self._healthy = False

    def mark_success(self) -> None:
        self._healthy = True
        self._fail_count = 0
        self._last_error = None

    @staticmethod
    def merge_system(req: ModelRequest) -> List[ChatMessage]:
        msgs = list(req.messages)
        if req.system and not (msgs and msgs[0].role == "system"):
            msgs.insert(0, ChatMessage("system", req.system))
        return msgs


def timed() -> float:
    return time.perf_counter()
