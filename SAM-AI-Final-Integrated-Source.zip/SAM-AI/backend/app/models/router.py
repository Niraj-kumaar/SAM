"""
backend.app.models.router
=========================

The **Model Router**. SAM is never locked to one AI vendor.

                    SAM MODEL ROUTER
                           |
        +------------------+------------------+
        v                  v                  v
   FAST MODEL        REASONING MODEL      VISION MODEL

Selection inputs (per the spec):

* task type / role           (primary, reasoning, fast, coding, vision, stt, tts, ...)
* complexity                 (estimated from prompt size + intent)
* latency requirement        (voice wants fast, documents want quality)
* available hardware         (is Ollama up? how much RAM?)
* privacy requirement        (Privacy Mode / Local Mode forces local providers)
* user preference            (explicit role -> model mapping in ``.env``)
* model availability         (health, keys, pulled local models)

Every call is recorded in ``model_usage`` so the Models dashboard can show cost
and latency per role.
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple

from sqlalchemy import func, select

from backend.app.config import settings
from backend.app.core.database import SessionLocal
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import ModelUsage
from backend.app.models.base import (
    ChatMessage,
    ModelInfo,
    ModelProvider,
    ModelRequest,
    ModelResponse,
)
from backend.app.providers.anthropic_provider import AnthropicProvider
from backend.app.providers.heuristic import HeuristicProvider, classify_intent, detect_language
from backend.app.providers.ollama_provider import OllamaProvider
from backend.app.providers.openai_compat import build_openai_compat_providers

log = get_logger("models.router")

ROLE_TO_SETTING = {
    "primary": "model_primary",
    "reasoning": "model_reasoning",
    "fast": "model_fast",
    "coding": "model_coding",
    "vision": "model_vision",
    "stt": "model_voice_stt",
    "tts": "model_voice_tts",
    "translation": "model_translation",
    "embedding": "model_embedding",
    "image": "model_image",
    "local": "model_local",
    "fallback": "model_fallback",
}


@dataclass
class RoutingDecision:
    role: str
    provider: str
    model: str
    reason: str
    chain: List[Tuple[str, str]] = field(default_factory=list)
    forced_local: bool = False
    complexity: str = "medium"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role,
            "provider": self.provider,
            "model": self.model,
            "reason": self.reason,
            "chain": [{"provider": p, "model": m} for p, m in self.chain],
            "forced_local": self.forced_local,
            "complexity": self.complexity,
        }


class ModelRouter:
    """Chooses, calls and failover-routes every model request in SAM."""

    def __init__(self) -> None:
        self.providers: Dict[str, ModelProvider] = {}
        self._ollama = OllamaProvider()
        self._heuristic = HeuristicProvider()
        self._anthropic = AnthropicProvider()
        self._lock = asyncio.Lock()
        self._bootstrapped = False
        self.usage: List[Dict[str, Any]] = []
        self._pins: Dict[str, str] = {}      # runtime role -> model overrides

    # ------------------------------------------------------------------ boot
    async def bootstrap(self) -> None:
        async with self._lock:
            if self._bootstrapped:
                return
            self.providers = {}
            for p in build_openai_compat_providers():
                if p.available():
                    self.providers[p.name] = p
                    log.info("provider online: %s", p.name)
            if self._anthropic.available():
                self.providers["anthropic"] = self._anthropic
                log.info("provider online: anthropic")
            if self._ollama.available():
                self.providers["ollama"] = self._ollama
                try:
                    found = await self._ollama.discover()
                    log.info("provider online: ollama (%d models)", len(found))
                except Exception as exc:  # pragma: no cover
                    log.info("ollama configured but not reachable yet: %s", exc)
            self.providers["heuristic"] = self._heuristic
            self._bootstrapped = True
            emit(Topics.MODEL_SELECTED, event="bootstrap",
                 providers=list(self.providers.keys()))

    async def refresh(self) -> Dict[str, Any]:
        """Re-scan providers (after the user edits .env or starts Ollama)."""
        self._bootstrapped = False
        self._ollama._tags_cache = None
        await self.bootstrap()
        return self.status()

    # ------------------------------------------------------------- catalogue
    def catalogue(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for name, p in self.providers.items():
            try:
                for m in p.models():
                    d = m.to_dict()
                    d["available"] = p.available()
                    out.append(d)
            except Exception as exc:  # pragma: no cover
                log.debug("catalogue error for %s: %s", name, exc)
        return out

    def status(self) -> Dict[str, Any]:
        roles: Dict[str, Optional[Dict[str, Any]]] = {}
        for role in ROLE_TO_SETTING:
            if role in ("stt", "tts", "image"):
                roles[role] = {"provider": "voice/image service", "model": getattr(settings, ROLE_TO_SETTING[role], "auto")}
                continue
            try:
                decision = self.plan(role)
                roles[role] = {"provider": decision.provider, "model": decision.model,
                               "forced_local": decision.forced_local}
            except Exception:
                roles[role] = None
        return {
            "pins": dict(self._pins),
            "auto_routing": settings.model_auto_routing,
            "mode": settings.sam_mode,
            "cloud_enabled": settings.cloud_enabled,
            "providers": {
                name: {
                    "available": p.available(),
                    "local": p.is_local,
                    "priority": p.priority,
                    "models": len(p.models()),
                }
                for name, p in self.providers.items()
            },
            "roles": roles,
        }

    # --------------------------------------------------------------- planning
    def plan(self, role: str = "primary", *, complexity: str = "medium",
             prefer_local: Optional[bool] = None, model_hint: Optional[str] = None) -> RoutingDecision:
        """Decide *which* provider/model would be used — without calling it."""
        forced_local = bool(prefer_local)
        if settings.sam_mode == "local" or settings.privacy_cloud_ai or not settings.any_cloud_key:
            forced_local = True

        chain: List[Tuple[str, str]] = []
        chosen: Optional[Tuple[str, str, str]] = None

        # 0. runtime pin set from the MODELS dashboard (session only)
        pinned = self._pins.get(role)
        if pinned and pinned != "auto":
            provider, model = self._resolve_explicit(pinned, forced_local)
            if provider:
                chain.append((provider, model))
                chosen = (provider, model, f"pinned from the UI: {role}={pinned}")

        # 1. explicit user mapping from .env
        if chosen is None:
            explicit = getattr(settings, ROLE_TO_SETTING.get(role, "model_primary"), "auto")
            if explicit and explicit != "auto":
                provider, model = self._resolve_explicit(explicit, forced_local)
                if provider:
                    chain.append((provider, model))
                    chosen = (provider, model,
                              f"explicit .env mapping {ROLE_TO_SETTING.get(role)}={explicit}")

        # 2. score the catalogue for this role
        if chosen is None:
            candidates = self._candidates(role, complexity, forced_local)
            chain = [(p, m) for p, m, *_ in candidates[:6]]
            if candidates:
                p, m, score, why = candidates[0]
                chosen = (p, m, why)

        # 3. last resort
        if chosen is None:
            chosen = ("heuristic", "sam-rules-v1", "no other provider available — offline rule engine")
            chain.append(chosen[:2])

        decision = RoutingDecision(
            role=role, provider=chosen[0], model=chosen[1], reason=chosen[2],
            chain=chain, forced_local=forced_local, complexity=complexity,
        )
        return decision

    # ------------------------------------------------------------------- pins
    def pin(self, role: str, model: str) -> Dict[str, str]:
        """Pin a role to a model for this session ("auto" clears the pin)."""
        role = role.lower()
        if not model or model == "auto":
            self._pins.pop(role, None)
        else:
            self._pins[role] = model
        emit(Topics.MODEL_SELECTED, event="pin", role=role, model=model or "auto")
        return dict(self._pins)

    def pins(self) -> Dict[str, str]:
        return dict(self._pins)

    def _resolve_explicit(self, explicit: str, forced_local: bool) -> Tuple[Optional[str], str]:
        """``provider/model`` or a bare model id."""
        if "/" in explicit and explicit.split("/")[0] in self.providers:
            prov, model = explicit.split("/", 1)
        else:
            prov, model = None, explicit
            for name, p in self.providers.items():
                if any(m.model == explicit for m in p.models()):
                    prov = name
                    break
            if prov is None:
                prov = "ollama" if (forced_local and self._ollama.available()) else None
        if prov and prov in self.providers:
            if forced_local and not self.providers[prov].is_local and prov != "heuristic":
                return (None, model)
            return (prov, model)
        return (None, model)

    def _candidates(self, role: str, complexity: str, forced_local: bool) -> List[Tuple[str, str, float, str]]:
        """Score every model in the catalogue for ``role``."""
        scored: List[Tuple[str, str, float, str]] = []
        want_quality = complexity in ("high", "very_high")
        want_speed = complexity in ("low", "voice") or role in ("fast", "stt", "tts")

        for pname, provider in self.providers.items():
            if not provider.available():
                continue
            if forced_local and not provider.is_local and pname != "heuristic":
                continue
            for m in provider.models():
                if not m.enabled:
                    continue
                if role not in m.roles and "fallback" not in m.roles and pname != "heuristic":
                    continue
                score = 0.0
                reasons: List[str] = []

                if role in m.roles:
                    score += 30
                    reasons.append(f"role match ({role})")
                else:
                    score += 5

                # provider priority (lower number = better)
                score += max(0, (100 - provider.priority) / 6)
                reasons.append(f"provider priority {provider.priority}")

                if want_quality:
                    score += m.quality * 4
                    reasons.append(f"quality {m.quality}")
                if want_speed:
                    score += m.speed * 4
                    reasons.append(f"speed {m.speed}")
                if not want_quality and not want_speed:
                    score += m.quality * 2 + m.speed * 2

                if forced_local and m.local:
                    score += 25
                    reasons.append("local (privacy preserved)")
                if m.privacy >= 5:
                    score += 8

                if provider.name == "heuristic":
                    score -= 60      # only if literally nothing else exists
                    reasons.append("offline rule engine (last resort)")

                if not provider._healthy:
                    score -= 25
                    reasons.append("provider recently unhealthy")

                scored.append((pname, m.model, round(score, 2), "; ".join(reasons)))

        scored.sort(key=lambda x: x[2], reverse=True)
        return scored

    # ------------------------------------------------------------------ calls
    async def complete(self, req: ModelRequest, *, prefer_local: Optional[bool] = None,
                       complexity: Optional[str] = None) -> ModelResponse:
        """Run a completion with automatic failover across the whole chain."""
        await self.bootstrap()
        cx = complexity or estimate_complexity(req)
        decision = self.plan(req.role, complexity=cx, prefer_local=prefer_local, model_hint=req.model)

        order: List[Tuple[str, str]] = []
        if req.model:
            prov = req.model.split("/")[0] if "/" in req.model and req.model.split("/")[0] in self.providers else decision.provider
            model = req.model.split("/")[-1]
            order.append((prov, model))
        order.append((decision.provider, decision.model))
        for item in decision.chain:
            if item not in order:
                order.append(item)
        order.append(("heuristic", "sam-rules-v1"))

        emit(Topics.MODEL_SELECTED, **decision.to_dict(), order=[f"{p}/{m}" for p, m in order])

        last_error = ""
        for provider_name, model_name in order:
            provider = self.providers.get(provider_name)
            if provider is None or not provider.available():
                continue
            probe = req.copy_with(model=model_name, stream=False)
            t0 = time.perf_counter()
            res = await provider.complete(probe)
            latency = int((time.perf_counter() - t0) * 1000)
            await self._record_usage(req.role, provider_name, res.model or model_name, res, latency, res.ok)

            if res.ok and (res.text or res.tool_calls):
                res.role = req.role
                res.latency_ms = latency
                return res
            last_error = res.error or "empty response"
            log.warning("router: %s/%s failed (%s) — trying next", provider_name, model_name, last_error)

        # absolute fallback: offline rule engine
        res = await self._heuristic.complete(req)
        res.error = None
        res.text = res.text or "SAM is offline and could not reach any model."
        await self._record_usage(req.role, "heuristic", res.model, res, res.latency_ms, True)
        return res

    async def stream(self, req: ModelRequest, *, prefer_local: Optional[bool] = None) -> AsyncIterator[str]:
        """Token streaming with one-shot failover: if the stream dies before any
        token arrives, the router retries the next provider in the chain."""
        await self.bootstrap()
        cx = estimate_complexity(req)
        decision = self.plan(req.role, complexity=cx, prefer_local=prefer_local)
        order = [(decision.provider, decision.model)] + [c for c in decision.chain if c != (decision.provider, decision.model)]
        order.append(("heuristic", "sam-rules-v1"))

        for provider_name, model_name in order:
            provider = self.providers.get(provider_name)
            if provider is None or not provider.available():
                continue
            produced = False
            try:
                probe = req.copy_with(model=model_name, stream=True)
                async for piece in provider.stream(probe):
                    if piece:
                        produced = True
                        yield piece
                if produced:
                    return
            except Exception as exc:
                log.warning("stream failed on %s/%s: %s", provider_name, model_name, exc)
                if produced:
                    return
            if produced:
                return

    # ------------------------------------------------------------ convenience
    async def ask(self, prompt: str, role: str = "primary", system: Optional[str] = None,
                  temperature: float = 0.4, max_tokens: int = 1024, json_mode: bool = False,
                  prefer_local: Optional[bool] = None) -> ModelResponse:
        req = ModelRequest(
            messages=[ChatMessage("user", prompt)], role=role, system=system,
            temperature=temperature, max_tokens=max_tokens, json_mode=json_mode,
        )
        return await self.complete(req, prefer_local=prefer_local)

    async def ask_json(self, prompt: str, role: str = "reasoning", system: Optional[str] = None,
                       default: Any = None) -> Any:
        """Ask for JSON and parse it defensively."""
        sys_prompt = (system or "") + "\nRespond with ONLY valid JSON. No prose, no markdown fences."
        res = await self.ask(prompt, role=role, system=sys_prompt.strip(), json_mode=True, temperature=0.15)
        parsed = res.json()
        if parsed is None:
            log.debug("ask_json could not parse: %.200s", res.text)
            return default
        return parsed

    async def vision(self, prompt: str, images: List[str], role: str = "vision") -> ModelResponse:
        req = ModelRequest(
            messages=[ChatMessage("user", prompt, images=images)], role=role, max_tokens=1500
        )
        return await self.complete(req, prefer_local=False if settings.sam_mode == "online" else None)

    async def embed(self, texts: List[str]) -> List[List[float]]:
        await self.bootstrap()
        if self._ollama.available():
            vecs = await self._ollama.embed(texts)
            if vecs and any(any(v) for v in vecs):
                return vecs
        return [_hash_embedding(t) for t in texts]

    async def translate(self, text: str, target: str) -> str:
        src = detect_language(text)
        if src == target:
            return text
        res = await self.ask(
            f"Translate the following text into {target}. Keep the meaning, tone and any code/formatting "
            f"intact. Output ONLY the translation.\n\n{text}",
            role="translation", temperature=0.1, max_tokens=1024,
        )
        return res.text.strip() or text

    # ------------------------------------------------------------------ usage
    async def _record_usage(self, role: str, provider: str, model: str, res: ModelResponse,
                            latency_ms: int, ok: bool) -> None:
        row = {
            "ts": time.time(), "role": role, "provider": provider, "model": model,
            "prompt_tokens": res.prompt_tokens, "completion_tokens": res.completion_tokens,
            "latency_ms": latency_ms, "ok": ok, "error": res.error,
        }
        self.usage.append(row)
        if len(self.usage) > 500:
            self.usage = self.usage[-500:]
        emit(Topics.MODEL_USAGE, **{k: v for k, v in row.items() if k != "ts"})
        try:
            async with SessionLocal() as db:
                db.add(ModelUsage(role=role, provider=provider, model=model,
                                  prompt_tokens=res.prompt_tokens,
                                  completion_tokens=res.completion_tokens,
                                  latency_ms=latency_ms, ok=ok, error=res.error))
                await db.commit()
        except Exception as exc:  # pragma: no cover
            log.debug("model usage persist failed: %s", exc)

    async def usage_stats(self, hours: int = 24) -> Dict[str, Any]:
        async with SessionLocal() as db:
            rows = (
                await db.execute(
                    select(
                        ModelUsage.role,
                        ModelUsage.provider,
                        func.count(ModelUsage.id),
                        func.sum(ModelUsage.prompt_tokens),
                        func.sum(ModelUsage.completion_tokens),
                        func.avg(ModelUsage.latency_ms),
                    ).group_by(ModelUsage.role, ModelUsage.provider)
                )
            ).all()
        return {
            "by_role": [
                {
                    "role": r[0], "provider": r[1], "calls": r[2],
                    "prompt_tokens": int(r[3] or 0), "completion_tokens": int(r[4] or 0),
                    "avg_latency_ms": round(float(r[5] or 0), 1),
                }
                for r in rows
            ],
            "recent": self.usage[-25:][::-1],
        }

    async def health(self) -> List[Dict[str, Any]]:
        out = []
        for name, p in self.providers.items():
            try:
                out.append(await p.health())
            except Exception as exc:  # pragma: no cover
                out.append({"provider": name, "healthy": False, "error": str(exc)})
        return out

    async def aclose(self) -> None:
        for p in self.providers.values():
            closer = getattr(p, "aclose", None)
            if closer:
                try:
                    await closer()
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def estimate_complexity(req: ModelRequest) -> str:
    """Cheap complexity estimate used to pick fast vs reasoning models."""
    text = " ".join(m.content for m in req.messages)
    length = len(text)
    intent, _ = classify_intent(text[-1500:])

    if req.role in ("reasoning", "coding"):
        return "high"
    if req.role == "fast" or req.meta.get("voice"):
        return "voice" if req.meta.get("voice") else "low"
    if length > 6000 or intent in ("research.deep", "coding.write", "coding.debug"):
        return "high"
    if length > 1500:
        return "medium"
    return "low"


def _hash_embedding(text: str, dim: int = 256) -> List[float]:
    """Deterministic bag-of-words embedding used when no embedding model exists."""
    import hashlib
    import math
    import re

    vec = [0.0] * dim
    tokens = re.findall(r"[a-zA-Z\u0900-\u097F\u0C80-\u0CFF]+", (text or "").lower())
    for tok in tokens:
        h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
        vec[h % dim] += 1.0
        vec[(h // dim) % dim] += 0.5
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [round(v / norm, 6) for v in vec]


router = ModelRouter()
