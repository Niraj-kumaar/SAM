"""
backend.app.agents.base
=======================

The agent abstraction.

An **agent** is one of SAM's specialised brains. It owns:

* a name and a human description (shown in the Agent Dashboard)
* the set of tools it is allowed to invoke
* a system prompt that shapes its behaviour
* its own health, configuration and statistics
* an optional ``run()`` for when the orchestrator delegates a whole step to it

The 18 brains (the 17 from the specification + the Market Analyzer) are declared here, plus a registry the
UI reads to render the AGENTS dashboard.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional

from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import AgentName, DeviceKind, TaskModel, TaskStepModel
from backend.app.tools.registry import ToolContext, registry

log = get_logger("agents")


@dataclass
class AgentSpec:
    """Declarative description of one brain."""

    name: AgentName
    title: str
    description: str
    tools: List[str] = field(default_factory=list)
    devices: List[DeviceKind] = field(default_factory=lambda: [DeviceKind.PC])
    model_role: str = "primary"
    system_prompt: str = ""
    default_enabled: bool = True
    requires: List[str] = field(default_factory=list)   # capability names it needs
    tags: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# The 18 brains
# ---------------------------------------------------------------------------
AGENT_SPECS: List[AgentSpec] = [
    AgentSpec(
        AgentName.CORE, "Core Brain",
        "Main reasoning and decision-making. Owns the conversation, intent "
        "understanding and final answer composition.",
        tools=["core.status", "core.answer", "core.translate"],
        devices=[DeviceKind.PC, DeviceKind.CLOUD],
        model_role="primary",
        system_prompt=(
            "You are SAM, a personal AI operating platform. You are precise, calm and "
            "concrete. You act on the user's PC, phone and browser only through approved "
            "tools, and you always say what you did, what failed and what needs approval. "
            "Never invent facts, file paths, command output or tool results."
        ),
        tags=["conversation", "reasoning", "orchestration"],
    ),
    AgentSpec(
        AgentName.REASONING, "Reasoning Brain",
        "Complex reasoning, planning and problem solving. Produces task graphs and "
        "cross-checks evidence.",
        tools=["research.compare"],
        devices=[DeviceKind.CLOUD],
        model_role="reasoning",
        system_prompt=(
            "You decompose problems into the smallest number of verifiable steps. You state "
            "assumptions, flag uncertainty, and prefer evidence over intuition."
        ),
        tags=["planning", "analysis"],
    ),
    AgentSpec(
        AgentName.CODING, "Coding Brain",
        "Programming, debugging, refactoring, testing and software development.",
        tools=["coding.analyse", "coding.architecture", "coding.generate", "coding.write_files",
               "coding.run_tests", "coding.repair", "coding.explain", "coding.document",
               "coding.execute", "coding.git", "pc.dev.detect", "pc.terminal"],
        devices=[DeviceKind.PC],
        model_role="coding",
        system_prompt=(
            "You write production-quality code. You read the existing project before changing "
            "it, you run the tests, and you fix what you broke. You explain trade-offs briefly."
        ),
        tags=["development", "automation"],
    ),
    AgentSpec(
        AgentName.RESEARCH, "Research Brain",
        "Internet research, source gathering, cross-checking and citation.",
        tools=["research.search", "research.read", "research.compare", "research.summarise",
               "research.deep", "research.fetch"],
        devices=[DeviceKind.CLOUD],
        model_role="reasoning",
        system_prompt=(
            "You gather from several independent sources, prefer primary and authoritative "
            "ones, and you always separate what is verified from what is uncertain, "
            "conflicting or outdated. Every claim carries a citation."
        ),
        requires=["research.web_search"],
        tags=["search", "citations"],
    ),
    AgentSpec(
        AgentName.WRITING, "Writing Brain",
        "Documents, reports, emails, scripts and long-form content.",
        tools=["documents.outline", "documents.write", "documents.render", "email.draft"],
        devices=[DeviceKind.CLOUD, DeviceKind.PC],
        model_role="primary",
        system_prompt=(
            "You write clearly and structure content for the reader, not for yourself. You "
            "match the requested tone and length exactly, and you output clean Markdown that "
            "renders correctly into DOCX, PDF or slides."
        ),
        tags=["writing", "documents"],
    ),
    AgentSpec(
        AgentName.VISION, "Vision Brain",
        "Images, screenshots, scanned documents, UI understanding and OCR.",
        tools=["pc.screenshot", "pc.screen.understand", "vision.analyse", "vision.ocr"],
        devices=[DeviceKind.PC, DeviceKind.CLOUD],
        model_role="vision",
        system_prompt=(
            "You describe what is actually visible. You report UI elements with their labels "
            "and positions, transcribe text exactly, and you never guess at content you "
            "cannot see."
        ),
        requires=["vision.image_analysis"],
        tags=["vision", "ocr", "ui"],
    ),
    AgentSpec(
        AgentName.PC, "Computer Brain",
        "Windows interaction: applications, windows, keyboard, mouse, system state, power.",
        tools=["pc.launch_app", "pc.close_app", "pc.apps.running", "pc.installed_apps",
               "pc.windows.list", "pc.window_action", "pc.keyboard", "pc.mouse",
               "pc.clipboard.read", "pc.clipboard.write", "pc.clipboard.paste",
               "pc.system_info", "pc.processes.list", "pc.processes.kill", "pc.services.list",
               "pc.volume", "pc.brightness", "pc.notify", "pc.env.read", "pc.ui.elements",
               "pc.power_lock", "pc.power_sleep", "pc.power_restart", "pc.power_shutdown",
               "pc.power_signout", "pc.terminal", "pc.terminal.script"],
        devices=[DeviceKind.PC],
        model_role="fast",
        system_prompt=(
            "You control this computer carefully. You verify that an action actually took "
            "effect before reporting success, and you stop and ask whenever an action is "
            "destructive or irreversible."
        ),
        requires=["pc.apps.launch"],
        tags=["windows", "automation", "input"],
    ),
    AgentSpec(
        AgentName.PHONE, "Phone Brain",
        "Android device interaction through the SAM Companion app or ADB.",
        tools=["phone.status", "phone.system_state", "phone.battery", "phone.dispatch",
               "phone.apps.list", "phone.apps.launch", "phone.wifi", "phone.bluetooth",
               "phone.volume", "phone.brightness", "phone.notifications.list", "phone.notify",
               "phone.alarm", "phone.message.prepare", "phone.message.send", "phone.call",
               "phone.contacts", "phone.calendar", "phone.media", "phone.files.list",
               "phone.screen.capture", "phone.accessibility.tap"],
        devices=[DeviceKind.PHONE],
        model_role="fast",
        system_prompt=(
            "Android's permission model is in charge, not you. If a permission is missing you "
            "report exactly which one, and you never attempt to bypass app security, "
            "authentication or payment protection."
        ),
        requires=["phone.connect"],
        tags=["android", "mobile"],
    ),
    AgentSpec(
        AgentName.BROWSER, "Browser Brain",
        "Web browsing and browser automation inside the user's own session.",
        tools=["browser.navigate", "browser.read_page", "browser.extract", "browser.click",
               "browser.form_fill", "browser.tabs", "browser.screenshot", "browser.download",
               "browser.bookmarks", "browser.page_info", "browser.status", "browser.scroll",
               "browser.wait", "browser.stop"],
        devices=[DeviceKind.BROWSER],
        model_role="fast",
        system_prompt=(
            "You stay inside the user's authenticated session and never type credentials, OTPs "
            "or card details. You read before you act, and you confirm the page state after "
            "every interaction."
        ),
        requires=["browser.open"],
        tags=["web", "automation"],
    ),
    AgentSpec(
        AgentName.FILES, "File Brain",
        "Files, folders, archives, search, conversion and organisation.",
        tools=["files.search", "files.scan", "files.read", "files.write", "files.copy",
               "files.move", "files.rename", "files.delete", "files.archive",
               "files.duplicates", "files.plan_organise", "files.organise", "files.convert",
               "files.info", "files.index", "memory.semantic_search", "documents.verify"],
        devices=[DeviceKind.PC],
        model_role="fast",
        system_prompt=(
            "You only touch paths inside the configured allowed roots. You propose a plan "
            "before bulk changes, you prefer the recycle bin over permanent deletion, and you "
            "report exactly what moved where."
        ),
        requires=["files.read"],
        tags=["files", "documents"],
    ),
    AgentSpec(
        AgentName.CREATIVE, "Creative Brain",
        "Image generation and editing, design, social content and video planning.",
        tools=["creative.prompt", "creative.image_generate", "creative.image_edit",
               "creative.social_pack", "creative.script", "creative.save"],
        devices=[DeviceKind.CLOUD, DeviceKind.PC],
        model_role="image",
        system_prompt=(
            "You think like an art director: concept first, then a precise prompt, palette and "
            "composition. You offer alternatives rather than one guess."
        ),
        requires=["creative.image.generate"],
        tags=["design", "media"],
    ),
    AgentSpec(
        AgentName.DATA, "Data Brain",
        "Tables, spreadsheets, statistics, charts and analysis reports.",
        tools=["data.load", "data.clean", "data.analyse", "data.chart", "data.report"],
        devices=[DeviceKind.PC],
        model_role="reasoning",
        system_prompt=(
            "You compute, you do not estimate. Every number you report comes from the actual "
            "data, and you state the row count and any rows you excluded."
        ),
        tags=["analysis", "spreadsheets"],
    ),
    AgentSpec(
        AgentName.MEMORY, "Memory Brain",
        "Long-term context, preferences, project knowledge and semantic file memory.",
        tools=["memory.write", "memory.search", "memory.list", "memory.forget",
               "memory.semantic_search"],
        devices=[DeviceKind.PC],
        model_role="fast",
        system_prompt=(
            "You store only what the user approved. You never store passwords, keys, card "
            "numbers or other secrets, and you can always show, correct or erase what you know."
        ),
        tags=["memory", "personalisation"],
    ),
    AgentSpec(
        AgentName.SECURITY, "Security Brain",
        "Permission, risk, confirmation and audit management.",
        tools=["security.report", "security.permissions", "security.set_permission",
               "security.audit", "security.risk_check"],
        devices=[DeviceKind.PC],
        model_role="fast",
        system_prompt=(
            "You are the brake, not the accelerator. You explain risk in plain language and "
            "you never soften a CRITICAL classification."
        ),
        tags=["security", "audit"],
    ),
    AgentSpec(
        AgentName.PLANNING, "Planning Brain",
        "Schedules, projects, reminders and long-running tasks.",
        tools=["scheduler.create", "scheduler.list", "scheduler.remove", "automation.create",
               "automation.list", "automation.toggle", "calendar.upsert"],
        devices=[DeviceKind.PC],
        model_role="fast",
        system_prompt=(
            "You turn vague intentions into concrete, timed, verifiable plans with an owner "
            "and a definition of done."
        ),
        tags=["scheduling", "automation"],
    ),
    AgentSpec(
        AgentName.COMMUNICATION, "Communication Brain",
        "Natural conversation, tone matching, translation and multilingual replies.",
        tools=["core.answer", "core.translate", "email.draft", "email.read", "email.send"],
        devices=[DeviceKind.CLOUD],
        model_role="fast",
        system_prompt=(
            "You match the user's language and register, including code-mixed speech. You are "
            "warm but never sycophantic, and you are transparent that you are an AI."
        ),
        tags=["conversation", "language"],
    ),
    AgentSpec(
        AgentName.VERIFICATION, "Verification Brain",
        "Checks whether an operation actually succeeded, and reports honestly when it did not.",
        tools=["documents.verify", "core.status", "verification.check"],
        devices=[DeviceKind.PC],
        model_role="fast",
        system_prompt=(
            "You verify by observation, not by assumption: check the process list, the file on "
            "disk, the page state, the returned JSON. 'It should have worked' is not a result."
        ),
        tags=["quality", "reliability"],
    ),
    AgentSpec(
        AgentName.MARKETS, "Market Analyzer Brain",
        "Financial market analysis: forex, binary options, crypto, stocks, indices and "
        "commodities. Pulls live keyless market data, computes 30+ technical indicators, "
        "scores a direction with explicit reasons, sizes positions from the user's risk "
        "percentage, backtests rules with costs, keeps a trade journal and runs a virtual "
        "(paper) account. It analyses and simulates \u2014 it never places a real order.",
        tools=["market.quote", "market.candles", "market.forex_rates", "market.crypto_screener",
               "market.watchlist", "market.feed_status", "market.indicators", "market.signal",
               "market.technical_report", "market.forex_plan", "market.binary_analysis",
               "market.regime", "market.screener", "market.multi_timeframe", "market.levels",
               "market.patterns", "market.volatility", "market.correlation", "market.sentiment",
               "market.compare", "market.calendar", "market.risk", "market.backtest",
               "market.journal.add", "market.journal.list", "market.journal.close",
               "market.journal.stats", "market.journal.review", "market.alert.set",
               "market.alert.list", "market.alert.remove", "market.alert.check",
               "market.paper.trade", "market.paper.close", "market.paper.portfolio",
               "market.paper.reset", "market.explain", "market.broker.status", "market.status"],
        devices=[DeviceKind.PC, DeviceKind.CLOUD, DeviceKind.PHONE],
        model_role="reasoning",
        system_prompt=(
            "You are SAM's Market Analyzer. You are numeric, calm and brutally honest about "
            "uncertainty. Every claim carries the number behind it. You always state the "
            "invalidation level, the risk, and the indicators that disagree with you. "
            "You never promise or imply a profit, never invent a price, and you size every "
            "position from the user's stated risk percentage. You remind the user that binary "
            "options are banned for retail in the EU/UK and flagged as illegal for Indian "
            "residents, and that leveraged trading loses money for most retail accounts. "
            "You are an AI analyst, not a licensed financial advisor."
        ),
        requires=["market.data.read", "market.analysis"],
        tags=["forex", "binary-options", "crypto", "stocks", "technical-analysis", "risk"],
    ),
]

SPECS_BY_NAME: Dict[str, AgentSpec] = {s.name.value: s for s in AGENT_SPECS}


# ---------------------------------------------------------------------------
# Runtime agent
# ---------------------------------------------------------------------------
class Agent:
    """A live brain: spec + runtime state + optional custom handler."""

    def __init__(self, spec: AgentSpec, handler: Optional[Callable[..., Awaitable[Any]]] = None) -> None:
        self.spec = spec
        self.handler = handler
        self.enabled = spec.default_enabled
        self.online = True
        self.config: Dict[str, Any] = {
            "model_role": spec.model_role,
            "temperature": 0.4,
            "max_tokens": 2048,
            "auto_confirm_low_risk": True,
        }
        self.stats = {"calls": 0, "errors": 0, "total_ms": 0, "last_run": None}
        self.last_error: str = ""

    # ------------------------------------------------------------------ api
    @property
    def name(self) -> str:
        return self.spec.name.value

    def to_dict(self) -> Dict[str, Any]:
        tools = [registry.get(t) for t in self.spec.tools]
        return {
            "name": self.name,
            "title": self.spec.title,
            "description": self.spec.description,
            "status": "ONLINE" if (self.online and self.enabled) else
                      ("DISABLED" if not self.enabled else "OFFLINE"),
            "enabled": self.enabled,
            "online": self.online,
            "devices": [d.value for d in self.spec.devices],
            "model_role": self.config.get("model_role"),
            "tools": [t.name for t in tools if t],
            "tools_available": [t.name for t in tools if t and t.is_available()],
            "requires": self.spec.requires,
            "tags": self.spec.tags,
            "config": self.config,
            "stats": {**self.stats,
                      "avg_ms": round(self.stats["total_ms"] / self.stats["calls"], 1)
                      if self.stats["calls"] else 0},
            "last_error": self.last_error,
        }

    def set_config(self, **values: Any) -> Dict[str, Any]:
        for key, value in values.items():
            if key == "enabled":
                self.enabled = bool(value)
            elif key in self.config:
                self.config[key] = value
        emit(Topics.AGENT_FINISHED, agent=self.name, event="config", config=self.config,
             enabled=self.enabled)
        return self.to_dict()

    def can(self, tool_name: str) -> bool:
        return tool_name in self.spec.tools

    async def run(self, task: TaskModel, step: TaskStepModel, ctx: ToolContext) -> Any:
        """Execute one step, preferring the registered tool."""
        if not self.enabled:
            return {"ok": False, "error": f"agent '{self.name}' is disabled"}
        t0 = time.perf_counter()
        self.stats["calls"] += 1
        emit(Topics.AGENT_STARTED, agent=self.name, task_id=task.id, step=step.name)
        try:
            tool_name = step.tool
            if tool_name and registry.get(tool_name) is not None:
                if not self.can(tool_name):
                    log.warning("agent %s asked for tool %s which is not in its set",
                                self.name, tool_name)
                value = await registry.execute(tool_name, ctx, **step.params)
            elif self.handler is not None:
                value = await self.handler(task, step, ctx)
            else:
                value = {"ok": False, "error": f"agent '{self.name}' has no handler for '{step.name}'"}
            self.stats["total_ms"] += int((time.perf_counter() - t0) * 1000)
            self.stats["last_run"] = time.time()
            self.last_error = ""
            emit(Topics.AGENT_FINISHED, agent=self.name, task_id=task.id, step=step.name, ok=True)
            return value
        except Exception as exc:
            self.stats["errors"] += 1
            self.stats["total_ms"] += int((time.perf_counter() - t0) * 1000)
            self.last_error = str(exc)[:400]
            emit(Topics.AGENT_ERROR, agent=self.name, task_id=task.id, step=step.name,
                 error=self.last_error)
            raise


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------
class AgentRegistry:
    def __init__(self) -> None:
        self.agents: Dict[str, Agent] = {s.name.value: Agent(s) for s in AGENT_SPECS}

    def get(self, name: str) -> Optional[Agent]:
        return self.agents.get(name)

    def all(self) -> List[Agent]:
        return list(self.agents.values())

    def enabled(self) -> List[Agent]:
        return [a for a in self.agents.values() if a.enabled]

    def names(self) -> List[str]:
        return list(self.agents)

    def register_handler(self, name: str, handler: Callable[..., Awaitable[Any]]) -> None:
        agent = self.agents.get(name)
        if agent:
            agent.handler = handler

    def set_status(self, name: str, online: bool) -> None:
        agent = self.agents.get(name)
        if agent:
            agent.online = online

    def snapshot(self) -> List[Dict[str, Any]]:
        return [a.to_dict() for a in self.agents.values()]

    def summary(self) -> Dict[str, Any]:
        agents = self.all()
        return {
            "total": len(agents),
            "online": sum(1 for a in agents if a.online and a.enabled),
            "disabled": sum(1 for a in agents if not a.enabled),
            "calls": sum(a.stats["calls"] for a in agents),
            "errors": sum(a.stats["errors"] for a in agents),
            "by_name": {a.name: ("ONLINE" if a.online and a.enabled else "OFFLINE") for a in agents},
        }


agents = AgentRegistry()


def load_tools() -> int:
    """
    Import every tool module so their ``@tool`` decorators register.

    Called once at startup from ``main.py``. Import failures are logged, not
    fatal — SAM degrades gracefully when an optional dependency is missing.
    """
    modules = [
        "backend.app.tools.system_tools",
        "backend.app.tools.pc_tools",
        "backend.app.tools.terminal_tools",
        "backend.app.tools.files_tools",
        "backend.app.tools.browser_tools",
        "backend.app.tools.research_tools",
        "backend.app.tools.phone_tools",
        "backend.app.tools.creative_tools",
        "backend.app.tools.data_tools",
        "backend.app.tools.memory_tools",
        "backend.app.tools.security_tools",
        "backend.app.tools.coding_tools",
        "backend.app.tools.scheduler_tools",
        "backend.app.tools.email_tools",
        "backend.app.tools.vision_tools",
        "backend.app.tools.core_tools",
        "backend.app.tools.web_tools",
        "backend.app.tools.math_tools",
        "backend.app.tools.market_tools",
        "backend.app.tools.text_tools",
        "backend.app.tools.code_exec_tools",
    ]
    import importlib

    loaded = 0
    for mod in modules:
        try:
            importlib.import_module(mod)
            loaded += 1
        except Exception as exc:  # pragma: no cover
            log.warning("could not import %s: %s", mod, exc)
    log.info("tool modules loaded: %d/%d, tools registered: %d",
             loaded, len(modules), len(registry.names()))
    return len(registry.names())
