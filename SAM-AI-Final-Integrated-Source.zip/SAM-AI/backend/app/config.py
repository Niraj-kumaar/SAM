"""
backend.app.config
==================

Single source of truth for every SAM setting.

All values are loaded from environment variables / the project ``.env`` file.
Nothing in this file contains a secret — secrets live only in ``.env``.

Usage::

    from backend.app.config import settings
    print(settings.sam_port, settings.sam_mode)
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import List, Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
BACKEND_DIR = Path(__file__).resolve().parent.parent          # .../SAM-AI/backend
PROJECT_ROOT = BACKEND_DIR.parent                             # .../SAM-AI


def _expand_list(raw: str) -> List[str]:
    """Split a comma separated env value into a trimmed, non-empty list."""
    return [p.strip() for p in (raw or "").split(",") if p.strip()]


class Settings(BaseSettings):
    """Runtime configuration for the whole SAM platform."""

    model_config = SettingsConfigDict(
        env_file=(PROJECT_ROOT / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ------------------------------------------------------------ core ----
    sam_name: str = "SAM"
    sam_env: Literal["development", "production"] = "development"
    sam_host: str = "0.0.0.0"
    sam_port: int = 8000
    sam_log_level: str = "INFO"
    sam_data_dir: Path = PROJECT_ROOT / "data"
    sam_secret_key: str = "change-me-to-a-long-random-string-please-64-chars-minimum"
    sam_api_token: str = ""          # optional bearer token for the REST/WS API
    sam_allowed_origins: str = "http://localhost:5173,http://127.0.0.1:5173,app://sam"

    # ------------------------------------------------------------ modes ---
    sam_mode: Literal["online", "local", "hybrid"] = "hybrid"

    # privacy toggles (Privacy Mode dashboard)
    privacy_cloud_ai: bool = False
    privacy_external_web: bool = False
    privacy_phone_sync: bool = False
    privacy_telemetry: bool = False
    privacy_local_models: bool = True
    privacy_local_memory: bool = True

    # ------------------------------------------------- model provider keys -
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    anthropic_api_key: str = ""
    anthropic_base_url: str = "https://api.anthropic.com"
    google_api_key: str = ""
    groq_api_key: str = ""
    openrouter_api_key: str = ""
    mistral_api_key: str = ""
    together_api_key: str = ""

    ollama_enabled: bool = True
    ollama_base_url: str = "http://127.0.0.1:11434"

    # ------------------------------------------------------- model router -
    model_primary: str = "auto"
    model_reasoning: str = "auto"
    model_fast: str = "auto"
    model_coding: str = "auto"
    model_vision: str = "auto"
    model_voice_stt: str = "auto"
    model_voice_tts: str = "auto"
    model_translation: str = "auto"
    model_embedding: str = "auto"
    model_image: str = "auto"
    model_local: str = "auto"
    model_fallback: str = "auto"
    model_auto_routing: bool = True

    model_local_default: str = "llama3.1:8b"
    model_local_fast_default: str = "llama3.2:3b"
    model_local_coding_default: str = "qwen2.5-coder:7b"
    model_local_vision_default: str = "llava:7b"
    model_local_embedding_default: str = "nomic-embed-text"

    # -------------------------------------------------------------- voice -
    voice_enabled: bool = True
    voice_wake_word: str = "hey sam"
    voice_wake_word_enabled: bool = False
    voice_porcupine_access_key: str = ""
    voice_sample_rate: int = 16000
    voice_language: str = "auto"
    voice_tts_provider: Literal["auto", "edge", "openai", "elevenlabs", "piper", "system"] = "auto"
    voice_tts_voice: str = "en-US-AriaNeural"
    voice_tts_speed: float = 1.0
    elevenlabs_api_key: str = ""
    piper_voice_dir: Path = PROJECT_ROOT / "data" / "voices" / "piper"

    # --------------------------------------------------------- pc control -
    pc_control_enabled: bool = True
    pc_keyboard_enabled: bool = True
    pc_mouse_enabled: bool = True
    pc_screen_capture_enabled: bool = True
    pc_terminal_enabled: bool = True
    pc_power_control_enabled: bool = False
    pc_max_window_actions_per_task: int = 25

    # ------------------------------------------------------------ browser -
    browser_enabled: bool = True
    browser_provider: Literal["playwright", "cdp"] = "playwright"
    browser_headless: bool = False
    browser_channel: str = "chrome"
    browser_cdp_url: str = ""
    browser_user_data_dir: Path = PROJECT_ROOT / "data" / "browser-profile"

    # -------------------------------------------------------------- phone -
    phone_enabled: bool = True
    phone_transport: Literal["websocket", "adb"] = "websocket"
    phone_pairing_secret: str = ""
    adb_path: str = "adb"
    phone_allow_accessibility: bool = False
    phone_allow_sms: bool = False
    phone_allow_calls: bool = False
    phone_allow_contacts: bool = False

    # -------------------------------------------------------------- files -
    files_enabled: bool = True
    files_allowed_roots: str = "~/Documents,~/Downloads,~/Desktop,~/Pictures"
    files_denied_patterns: str = (
        "**/.ssh/**,**/.aws/**,**/AppData/Roaming/Microsoft/Credentials/**,"
        "**/.gnupg/**,**/wallet*.dat"
    )
    files_max_upload_mb: int = 200
    files_index_enabled: bool = True
    files_index_extensions: str = (
        ".pdf,.docx,.pptx,.xlsx,.csv,.txt,.md,.py,.js,.ts,.json,.html,.css,.java,.kt,.c,.cpp,.h"
    )

    # ----------------------------------------------------------- security -
    security_risk_mode: Literal["strict", "balanced", "permissive"] = "balanced"
    security_audit_enabled: bool = True
    security_require_confirmation_medium: bool = True
    security_confirmation_timeout_seconds: int = 300
    security_max_retries: int = 2

    # ---------------------------------------------------------- scheduler -
    scheduler_enabled: bool = True
    scheduler_timezone: str = "Asia/Kolkata"
    scheduler_max_concurrent_tasks: int = 4

    # ---------------------------------------------------------- proactive -
    proactive_level: Literal["off", "important_only", "normal", "proactive"] = "normal"
    proactive_check_interval_seconds: int = 60

    # ------------------------------------------------------- integrations -
    gmail_client_id: str = ""
    gmail_client_secret: str = ""
    notion_api_key: str = ""
    github_token: str = ""
    slack_bot_token: str = ""

    # search / research providers (all optional — SAM works keyless via DDG,
    # Wikipedia and arXiv, and simply skips a provider whose key is empty)
    brave_api_key: str = ""
    tavily_api_key: str = ""
    bing_api_key: str = ""
    news_api_key: str = ""
    serpapi_key: str = ""

    # image generation
    stability_api_key: str = ""
    stable_diffusion_url: str = "http://127.0.0.1:7860"
    comfyui_url: str = "http://127.0.0.1:8188"
    image_provider: Literal["auto", "openai", "stability", "local", "none"] = "auto"

    # ------------------------------------------------------- markets ------
    # Market Analyzer brain (forex / binary options / crypto / stocks).
    # SAM analyses and paper-trades; it never places a real order.
    market_enabled: bool = True
    market_data_provider: Literal["auto", "yahoo", "twelvedata", "alpha_vantage"] = "auto"
    twelvedata_api_key: str = ""
    alpha_vantage_api_key: str = ""
    market_watchlist: str = "EURUSD,GBPUSD,USDJPY,BTC-USD,^NSEI,GC=F"
    market_default_timeframe: str = "1h"
    market_paper_balance: float = 10000.0
    market_risk_per_trade: float = 1.0            # % of the account risked per trade
    market_max_risk_per_trade: float = 5.0        # hard ceiling SAM will not exceed
    market_alerts_enabled: bool = True
    market_alert_poll_seconds: int = 120
    # Live execution is OFF and stays off unless the user deliberately enables
    # it AND connects a broker bridge AND confirms every order.
    market_allow_live_trading: bool = False
    market_mt_bridge_url: str = ""                # e.g. http://127.0.0.1:8765 (MT bridge)
    market_broker_api_key: str = ""

    # ------------------------------------------------------------ email ---
    email_enabled: bool = False
    email_provider: Literal["none", "imap", "gmail", "graph"] = "imap"
    email_address: str = ""
    email_display_name: str = "SAM"
    imap_host: str = ""
    imap_port: int = 993
    imap_user: str = ""
    imap_password: str = ""          # app password, never the account password
    imap_folder: str = "INBOX"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_starttls: bool = True
    email_max_fetch: int = 50
    email_always_confirm_send: bool = True

    # ------------------------------------------------------------- derived
    database_url: str = Field(default="", description="Override; empty => sqlite in data dir")

    # ----------------------------------------------------------------------
    @field_validator("sam_data_dir", "piper_voice_dir", "browser_user_data_dir", mode="before")
    @classmethod
    def _abs_path(cls, v: object) -> object:
        if isinstance(v, (str, Path)):
            p = Path(v).expanduser()
            return p if p.is_absolute() else (PROJECT_ROOT / p).resolve()
        return v

    # ----------------------------------------------------------------------
    @property
    def allowed_origins(self) -> List[str]:
        return _expand_list(self.sam_allowed_origins)

    @property
    def allowed_roots(self) -> List[Path]:
        return [Path(p).expanduser().resolve() for p in _expand_list(self.files_allowed_roots)]

    @property
    def denied_patterns(self) -> List[str]:
        return _expand_list(self.files_denied_patterns)

    @property
    def index_extensions(self) -> List[str]:
        return [e.strip().lower() for e in _expand_list(self.files_index_extensions)]

    @property
    def db_path(self) -> Path:
        return self.sam_data_dir / "db" / "sam.db"

    @property
    def effective_database_url(self) -> str:
        return self.database_url or f"sqlite+aiosqlite:///{self.db_path.as_posix()}"

    @property
    def cloud_enabled(self) -> bool:
        """True when SAM is allowed to call external AI providers."""
        if self.sam_mode == "local" or self.privacy_cloud_ai:
            return False
        return bool(self.any_cloud_key)

    @property
    def any_cloud_key(self) -> bool:
        return any(
            [
                self.openai_api_key,
                self.anthropic_api_key,
                self.google_api_key,
                self.groq_api_key,
                self.openrouter_api_key,
                self.mistral_api_key,
                self.together_api_key,
            ]
        )

    @property
    def web_enabled(self) -> bool:
        return not self.privacy_external_web

    def ensure_dirs(self) -> None:
        """Create every runtime directory SAM needs."""
        for sub in ("memory", "tasks", "logs", "cache", "db", "browser-profile", "voices/piper",
                    "documents", "creative/images", "creative/charts", "backups", "transfers",
                    "artifacts/code", "artifacts/documents", "artifacts/data",
                    "artifacts/creative", "artifacts/reports"):
            (self.sam_data_dir / sub).mkdir(parents=True, exist_ok=True)
        (PROJECT_ROOT / "data").mkdir(parents=True, exist_ok=True)

    def public_dict(self) -> dict:
        """Config view that is safe to send to the UI (no secrets)."""
        redacted = {}
        for k, v in self.model_dump().items():
            if any(s in k for s in ("api_key", "secret", "token", "password")):
                redacted[k] = "SET" if v else ""
            elif isinstance(v, Path):
                redacted[k] = str(v)
            else:
                redacted[k] = v
        return redacted


@lru_cache
def get_settings() -> Settings:
    cached = Settings()
    cached.ensure_dirs()
    return cached


settings: Settings = get_settings()

# Make PROJECT_ROOT importable for path helpers across the codebase
ROOT = PROJECT_ROOT
os.environ.setdefault("SAM_PROJECT_ROOT", str(PROJECT_ROOT))
