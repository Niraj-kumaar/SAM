"""
backend.app.memory.store
========================

**The Memory Brain.** Six memory types from the spec:

================  ==========================================================
short_term        the current conversation window (RAM only)
long_term         user-approved persistent preferences and facts
project           information belonging to a specific project
device            PC / phone configuration and state snapshots
task              active and completed task context
semantic          searchable knowledge extracted from permitted user files
================  ==========================================================

Search is hybrid:

1. lexical  — token overlap + SQLite ``LIKE``
2. semantic — cosine similarity over embeddings (Ollama ``nomic-embed-text``
   when available, otherwise SAM's deterministic hashed bag-of-words vectors)

The user has full control: view, edit, correct, disable, clear selected,
clear all, and choose what SAM may remember.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import delete, func, or_, select

from backend.app.config import settings
from backend.app.core.database import SessionLocal
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import Conversation, MemoryItem, Message
from backend.app.providers.heuristic import detect_language

log = get_logger("memory.store")

MEMORY_KINDS = ("short_term", "long_term", "project", "device", "task", "semantic")

# Phrases that mark something as explicitly worth remembering.
REMEMBER_TRIGGERS = (
    "remember", "note that", "keep in mind", "don't forget", "do not forget",
    "my name is", "i am called", "i prefer", "i like", "i hate", "i always",
    "i never", "my favourite", "my favorite", "from now on", "always use",
    "yaad rakho", "yaad rakhna", "ನೆನಪಿಟ್ಟುಕೋ", "ನೆನಪಿರಲಿ", "ஞாபகம்",
)

# Things SAM must never store, even if asked.
SENSITIVE_PATTERNS = (
    r"\bpassword\b", r"\bpasswd\b", r"\bpin\b(?!\s*code\s*is\s*not)", r"\bcvv\b",
    r"\botp\b", r"\bsecret\s*key\b", r"\bapi[_-]?key\b", r"\btoken\b",
    r"\bcredit\s*card\b", r"\bcard\s*number\b", r"\bupi\s*(pin|id)\b",
    r"\baadhaar\b", r"\bssn\b", r"\bsocial\s*security\b", r"\bprivate\s*key\b",
    r"\b\d{12,19}\b",
)


def _is_sensitive(text: str) -> bool:
    low = text.lower()
    return any(re.search(p, low) for p in SENSITIVE_PATTERNS)


def _tokens(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z\u0900-\u097F\u0C80-\u0CFF\u0B80-\u0BFF\u0980-\u09FF]{3,}",
                      (text or "").lower())


def cosine(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


class MemoryStore:
    """Persistent + short-term memory with hybrid retrieval."""

    def __init__(self) -> None:
        self.short_term: Dict[str, List[Dict[str, Any]]] = {}
        self.short_term_limit = 40
        self._embed_cache: Dict[str, List[float]] = {}
        self._router: Any = None

    def attach_router(self, router: Any) -> None:
        self._router = router

    # =======================================================================
    # Write
    # =======================================================================
    async def remember(
        self,
        content: str,
        *,
        kind: str = "long_term",
        key: str = "",
        scope: str = "global",
        tags: Optional[List[str]] = None,
        importance: float = 0.5,
        source: str = "user",
    ) -> Dict[str, Any]:
        """Store one memory item. Refuses to store secrets."""
        if kind not in MEMORY_KINDS:
            kind = "long_term"
        if not settings.privacy_local_memory and kind in ("long_term", "semantic", "project"):
            return {"ok": False, "reason": "Privacy Mode: local memory is disabled"}
        if _is_sensitive(content):
            log.info("refusing to store sensitive content")
            emit(Topics.NOTIFICATION, kind="security",
                 title="SAM refused to remember something",
                 body="The text looked like a password, key, card number or other secret.")
            return {"ok": False, "reason": "refused: content looks like a secret/credential",
                    "sensitive": True}

        key = key or _auto_key(content)
        vec = await self._embed(content)
        async with SessionLocal() as db:
            existing = (
                await db.execute(
                    select(MemoryItem).where(MemoryItem.kind == kind, MemoryItem.key == key)
                )
            ).scalar_one_or_none()
            if existing:
                existing.content = content
                existing.importance = importance
                existing.tags = json.dumps(sorted(set((tags or []) + _auto_tags(content))))
                existing.embedding_json = json.dumps(vec)
                existing.updated_at = datetime.now(timezone.utc)
                existing.enabled = True
                await db.commit()
                item = existing.to_dict()
                topic = Topics.MEMORY_UPDATED
            else:
                row = MemoryItem(
                    kind=kind, key=key, content=content, source=source, scope=scope,
                    importance=importance, tags=json.dumps(sorted(set((tags or []) + _auto_tags(content)))),
                    embedding_json=json.dumps(vec),
                )
                db.add(row)
                await db.commit()
                await db.refresh(row)
                item = row.to_dict()
                topic = Topics.MEMORY_STORED
        emit(topic, **{k: v for k, v in item.items() if k != "content"}, preview=content[:160])
        log.info("memory stored: %s/%s", kind, key)
        return {"ok": True, "item": item}

    async def store_from_text(self, text: str, *, source: str = "conversation",
                              language: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Extract a durable fact from a conversational sentence."""
        low = text.lower().strip()
        if not any(t in low for t in REMEMBER_TRIGGERS):
            return None
        if _is_sensitive(text):
            return {"ok": False, "reason": "refused: sensitive content"}

        cleaned = re.sub(
            r"^\s*(sam[,!]?\s*)?(please\s+)?(remember|note|note down|keep in mind|don'?t forget|"
            r"do not forget|yaad rakho|yaad rakhna|ನೆನಪಿಟ್ಟುಕೋ)\s*(that)?\s*[:\-]?\s*",
            "", text, flags=re.IGNORECASE,
        ).strip(" .!")
        if not cleaned or len(cleaned) < 4:
            return None

        kind = "long_term"
        scope = "global"
        proj = re.search(r"\b(?:for|in)\s+(?:the\s+)?project\s+([A-Za-z0-9 _\-]{2,40})", cleaned, re.I)
        if proj:
            kind, scope = "project", proj.group(1).strip().lower()

        return await self.remember(
            cleaned, kind=kind, scope=scope, source=source,
            importance=0.75, tags=[language or detect_language(text)],
        )

    # =======================================================================
    # Read / search
    # =======================================================================
    async def recall(self, query: str, *, limit: int = 8, kind: Optional[str] = None,
                     scope: Optional[str] = None) -> List[Dict[str, Any]]:
        """Hybrid retrieval. Returns items sorted by relevance (best first)."""
        if not query or not query.strip():
            return []
        if kind == "short_term":
            return self.recall_short_term(scope or "default", limit)

        q_tokens = set(_tokens(query))
        q_vec = await self._embed(query)

        async with SessionLocal() as db:
            stmt = select(MemoryItem).where(MemoryItem.enabled.is_(True))
            if kind:
                stmt = stmt.where(MemoryItem.kind == kind)
            if scope:
                stmt = stmt.where(or_(MemoryItem.scope == scope, MemoryItem.scope == "global"))
            rows = (await db.execute(stmt.order_by(MemoryItem.updated_at.desc()).limit(2000))).scalars().all()

        scored: List[Tuple[float, Dict[str, Any]]] = []
        for r in rows:
            content_tokens = set(_tokens(r.content + " " + r.key))
            overlap = len(q_tokens & content_tokens)
            lexical = overlap / max(1, len(q_tokens)) * 0.55
            try:
                vec = json.loads(r.embedding_json or "[]")
            except Exception:
                vec = []
            semantic = cosine(q_vec, vec) * 0.45 if vec else 0.0
            score = lexical + semantic + float(r.importance) * 0.12
            if q_tokens and overlap == 0 and semantic < 0.12:
                continue
            d = r.to_dict()
            d["score"] = round(score, 4)
            d["lexical"] = round(lexical, 4)
            d["semantic"] = round(semantic, 4)
            scored.append((score, d))

        scored.sort(key=lambda x: x[0], reverse=True)
        out = [d for _, d in scored[:limit]]

        # touch last_used_at (best effort, no await storm)
        if out:
            ids = [d["id"] for d in out]
            try:
                async with SessionLocal() as db:
                    await db.execute(
                        MemoryItem.__table__.update()
                        .where(MemoryItem.__table__.c.id.in_(ids))
                        .values(last_used_at=datetime.now(timezone.utc))
                    )
                    await db.commit()
            except Exception:
                pass
        return out

    def remember_short_term(self, scope: str, item: Dict[str, Any]) -> None:
        buf = self.short_term.setdefault(scope, [])
        buf.append({"ts": time.time(), **item})
        if len(buf) > self.short_term_limit:
            self.short_term[scope] = buf[-self.short_term_limit:]

    def recall_short_term(self, scope: str, limit: int = 20) -> List[Dict[str, Any]]:
        return self.short_term.get(scope, [])[-limit:]

    async def list_items(self, *, kind: Optional[str] = None, scope: Optional[str] = None,
                         search: str = "", limit: int = 100, offset: int = 0) -> Dict[str, Any]:
        async with SessionLocal() as db:
            stmt = select(MemoryItem)
            cnt = select(func.count(MemoryItem.id))
            if kind:
                stmt = stmt.where(MemoryItem.kind == kind)
                cnt = cnt.where(MemoryItem.kind == kind)
            if scope:
                stmt = stmt.where(MemoryItem.scope == scope)
                cnt = cnt.where(MemoryItem.scope == scope)
            if search:
                like = f"%{search}%"
                stmt = stmt.where(or_(MemoryItem.content.ilike(like), MemoryItem.key.ilike(like)))
                cnt = cnt.where(or_(MemoryItem.content.ilike(like), MemoryItem.key.ilike(like)))
            total = (await db.execute(cnt)).scalar_one()
            rows = (
                await db.execute(stmt.order_by(MemoryItem.updated_at.desc()).limit(limit).offset(offset))
            ).scalars().all()
            by_kind = dict(
                (
                    await db.execute(select(MemoryItem.kind, func.count(MemoryItem.id)).group_by(MemoryItem.kind))
                ).all()
            )
        return {"total": total, "items": [r.to_dict() for r in rows], "by_kind": by_kind}

    async def get_item(self, item_id: int) -> Optional[Dict[str, Any]]:
        async with SessionLocal() as db:
            row = await db.get(MemoryItem, item_id)
            return row.to_dict() if row else None

    # =======================================================================
    # User control
    # =======================================================================
    async def update_item(self, item_id: int, *, content: Optional[str] = None,
                          key: Optional[str] = None, importance: Optional[float] = None,
                          tags: Optional[List[str]] = None, enabled: Optional[bool] = None,
                          scope: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if content and _is_sensitive(content):
            return {"ok": False, "reason": "refused: content looks like a secret"}
        async with SessionLocal() as db:
            row = await db.get(MemoryItem, item_id)
            if row is None:
                return None
            if content is not None:
                row.content = content
                row.embedding_json = json.dumps(await self._embed(content))
            if key is not None:
                row.key = key
            if importance is not None:
                row.importance = max(0.0, min(1.0, float(importance)))
            if tags is not None:
                row.tags = json.dumps(tags)
            if enabled is not None:
                row.enabled = bool(enabled)
            if scope is not None:
                row.scope = scope
            row.updated_at = datetime.now(timezone.utc)
            await db.commit()
            out = row.to_dict()
        emit(Topics.MEMORY_UPDATED, id=item_id, kind=out["kind"], key=out["key"])
        return out

    async def forget(self, item_id: int) -> bool:
        async with SessionLocal() as db:
            row = await db.get(MemoryItem, item_id)
            if row is None:
                return False
            await db.delete(row)
            await db.commit()
        emit(Topics.MEMORY_UPDATED, event="deleted", id=item_id)
        return True

    async def forget_key(self, key: str, kind: Optional[str] = None) -> int:
        async with SessionLocal() as db:
            stmt = delete(MemoryItem).where(MemoryItem.key == key)
            if kind:
                stmt = stmt.where(MemoryItem.kind == kind)
            res = await db.execute(stmt)
            await db.commit()
            n = res.rowcount or 0
        emit(Topics.MEMORY_UPDATED, event="deleted", key=key, count=n)
        return n

    async def clear(self, *, kind: Optional[str] = None, scope: Optional[str] = None,
                    include_short_term: bool = True) -> int:
        """Clear selected memory. ``kind=None`` clears everything."""
        n = 0
        async with SessionLocal() as db:
            stmt = delete(MemoryItem)
            if kind:
                stmt = stmt.where(MemoryItem.kind == kind)
            if scope:
                stmt = stmt.where(MemoryItem.scope == scope)
            res = await db.execute(stmt)
            await db.commit()
            n = res.rowcount or 0
        if include_short_term:
            if kind in (None, "short_term"):
                self.short_term.clear()
        self._embed_cache.clear()
        emit(Topics.MEMORY_UPDATED, event="cleared", kind=kind, scope=scope, count=n)
        audit = get_logger("audit")
        audit.info(json.dumps({"ts": datetime.now(timezone.utc).isoformat(),
                               "action": "memory.cleared", "count": n, "kind": kind}))
        return n

    async def stats(self) -> Dict[str, Any]:
        async with SessionLocal() as db:
            by_kind = dict(
                (await db.execute(select(MemoryItem.kind, func.count(MemoryItem.id)).group_by(MemoryItem.kind))).all()
            )
            disabled = (
                await db.execute(select(func.count(MemoryItem.id)).where(MemoryItem.enabled.is_(False)))
            ).scalar_one()
            convs = (await db.execute(select(func.count(Conversation.id)))).scalar_one()
            msgs = (await db.execute(select(func.count(Message.id)))).scalar_one()
        return {
            "total": sum(by_kind.values()),
            "by_kind": by_kind,
            "disabled": disabled,
            "conversations": convs,
            "messages": msgs,
            "short_term_scopes": len(self.short_term),
            "short_term_items": sum(len(v) for v in self.short_term.values()),
            "local_memory_enabled": settings.privacy_local_memory,
            "embedding_model": "ollama" if (self._router and settings.ollama_enabled) else "hash-bow",
        }

    # =======================================================================
    # Conversations / messages
    # =======================================================================
    async def ensure_conversation(self, conv_id: str, *, title: str = "", channel: str = "text",
                                  language: str = "auto") -> str:
        async with SessionLocal() as db:
            row = await db.get(Conversation, conv_id)
            if row is None:
                row = Conversation(id=conv_id, title=title or "New conversation",
                                   channel=channel, language=language)
                db.add(row)
                await db.commit()
            elif title and row.title in ("", "New conversation"):
                row.title = title[:200]
                await db.commit()
        return conv_id

    async def add_message(self, conv_id: str, role: str, content: str, *, agent: str = "core",
                          task_id: Optional[str] = None, channel: str = "text",
                          attachments: Optional[List[Dict[str, Any]]] = None,
                          language: str = "en", model: str = "",
                          meta: Optional[Dict[str, Any]] = None) -> Optional[int]:
        await self.ensure_conversation(conv_id, title=content[:60] if role == "user" else "",
                                       channel=channel, language=language)
        async with SessionLocal() as db:
            row = Message(
                conversation_id=conv_id, role=role, content=content, agent=agent,
                task_id=task_id, attachments_json=json.dumps(attachments or [], default=str),
                meta_json=json.dumps(meta or {}, default=str), model=model,
            )
            db.add(row)
            conv = await db.get(Conversation, conv_id)
            if conv is not None:
                conv.updated_at = datetime.now(timezone.utc)
                if role == "user" and conv.title in ("", "New conversation"):
                    conv.title = content[:60]
            await db.commit()
            await db.refresh(row)
            msg_id = row.id

        self.remember_short_term(conv_id, {"role": role, "content": content, "agent": agent})
        return msg_id

    async def list_conversations(self, limit: int = 50) -> List[Dict[str, Any]]:
        async with SessionLocal() as db:
            rows = (
                await db.execute(select(Conversation).order_by(Conversation.updated_at.desc()).limit(limit))
            ).scalars().all()
            return [r.to_dict() for r in rows]

    async def get_conversation(self, conv_id: str, limit: int = 200) -> Optional[Dict[str, Any]]:
        async with SessionLocal() as db:
            conv = await db.get(Conversation, conv_id)
            if conv is None:
                return None
            rows = (
                await db.execute(
                    select(Message).where(Message.conversation_id == conv_id)
                    .order_by(Message.created_at.asc()).limit(limit)
                )
            ).scalars().all()
            out = conv.to_dict()
            out["messages"] = [r.to_dict() for r in rows]
            return out

    async def delete_conversation(self, conv_id: str) -> bool:
        async with SessionLocal() as db:
            conv = await db.get(Conversation, conv_id)
            if conv is None:
                return False
            await db.delete(conv)
            await db.commit()
        self.short_term.pop(conv_id, None)
        return True

    # =======================================================================
    # Embeddings
    # =======================================================================
    async def _embed(self, text: str) -> List[float]:
        if not text:
            return []
        cache_key = hashlib.md5(text.encode("utf-8", "ignore")).hexdigest()
        if cache_key in self._embed_cache:
            return self._embed_cache[cache_key]

        vec: List[float] = []
        if self._router is not None:
            try:
                vecs = await asyncio.wait_for(self._router.embed([text]), timeout=8.0)
                if vecs and vecs[0] and any(vecs[0]):
                    vec = vecs[0]
            except Exception as exc:  # pragma: no cover
                log.debug("embedding failed (%s) — using hashed BoW", exc)

        if not vec:
            from backend.app.models.router import _hash_embedding

            vec = _hash_embedding(text)

        if len(self._embed_cache) > 4000:
            self._embed_cache.clear()
        self._embed_cache[cache_key] = vec
        return vec

    # =======================================================================
    # Context assembly for the orchestrator
    # =======================================================================
    async def build_prompt_context(self, query: str, conv_id: Optional[str] = None,
                                   limit: int = 6) -> str:
        """Render the memory block that gets injected into a model prompt."""
        items = await self.recall(query, limit=limit)
        parts: List[str] = []
        if items:
            parts.append("RELEVANT LONG-TERM MEMORY (approved by the user):")
            parts += [f"- [{i['kind']}] {i['content'][:300]}" for i in items]
        if conv_id:
            st = self.recall_short_term(conv_id, 8)
            if st:
                parts.append("\nRECENT CONVERSATION:")
                parts += [f"- {t['role']}: {str(t['content'])[:300]}" for t in st]
        return "\n".join(parts)


# ---------------------------------------------------------------------------
def _auto_key(content: str) -> str:
    """Derive a stable key so repeated facts overwrite instead of duplicating."""
    tokens = _tokens(content)
    head = "_".join(tokens[:6]) or hashlib.md5(content.encode()).hexdigest()[:10]
    return head[:120]


STOP_TAGS = {"the", "and", "for", "with", "that", "this", "from", "have", "will", "should"}


def _auto_tags(content: str) -> List[str]:
    freq: Dict[str, int] = {}
    for t in _tokens(content):
        if t in STOP_TAGS or len(t) < 4:
            continue
        freq[t] = freq.get(t, 0) + 1
    top = sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:5]
    tags = [k for k, _ in top]
    lang = detect_language(content)
    if lang != "en":
        tags.append(lang)
    return tags


memory_store = MemoryStore()
