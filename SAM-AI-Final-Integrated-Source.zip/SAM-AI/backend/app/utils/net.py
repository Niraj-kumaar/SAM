"""
backend.app.utils.net
=====================

Shared, offline-safe networking helpers for SAM's web/knowledge tools.

Design rules
------------
1. **Keyless first.** Every helper tries a public endpoint that needs no API
   key (DuckDuckGo HTML, Wikipedia REST, Open-Meteo, GitHub, Stooq, arXiv,
   Hacker News) and only then upgrades to a paid provider if the user has
   configured a key in ``.env``.
2. **Never raise at import time.** Missing optional deps (``bs4``, ``lxml``)
   degrade to SAM's own regex-based HTML stripper.
3. **Respect Privacy Mode.** ``settings.web_enabled`` is checked by the
   permission engine, but helpers also fail closed so a tool can never leak
   traffic when the user turned the web off.
4. **Cache.** Repeated identical lookups inside ``CACHE_TTL`` are served from
   memory — that keeps SAM fast and polite to public endpoints.
"""

from __future__ import annotations

import asyncio
import html as _html
import json
import re
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus, urljoin, urlparse

import httpx

from backend.app.config import settings
from backend.app.core.logging_config import get_logger

log = get_logger("utils.net")

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 SAM/1.0"
)

DEFAULT_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

CACHE_TTL = 300.0
_cache: Dict[str, Tuple[float, Any]] = {}
_client: Optional[httpx.AsyncClient] = None
_lock = asyncio.Lock()


class WebBlocked(RuntimeError):
    """Raised when Privacy Mode / configuration forbids network access."""


# ---------------------------------------------------------------------------
# client + request
# ---------------------------------------------------------------------------
async def client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=10.0),
            headers=DEFAULT_HEADERS,
            follow_redirects=True,
        )
    return _client


async def close() -> None:
    global _client
    if _client is not None and not _client.is_closed:
        await _client.aclose()
    _client = None


def _assert_web() -> None:
    if not settings.web_enabled:
        raise WebBlocked(
            "External web access is turned off (PRIVACY_EXTERNAL_WEB=true in .env). "
            "Enable it in Settings → Privacy, or use SAM's offline/local knowledge tools."
        )


def _cache_key(url: str, params: Optional[Dict[str, Any]]) -> str:
    return url + "|" + json.dumps(params or {}, sort_keys=True, default=str)


async def get(
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 30.0,
    cache: bool = True,
    ttl: float = CACHE_TTL,
    as_json: bool = False,
) -> Any:
    """
    GET a URL. Returns ``str`` (or parsed JSON when ``as_json``).

    Raises :class:`WebBlocked` when the user disabled external web access, and
    ``httpx.HTTPError`` subclasses on transport failure.
    """
    _assert_web()
    key = _cache_key(url, params)
    if cache:
        hit = _cache.get(key)
        if hit and (time.time() - hit[0]) < ttl:
            return hit[1]
    c = await client()
    resp = await c.get(url, params=params, headers=headers, timeout=timeout)
    resp.raise_for_status()
    out: Any = resp.json() if as_json else resp.text
    if cache:
        _cache[key] = (time.time(), out)
    return out


async def get_json(url: str, *, params: Optional[Dict[str, Any]] = None,
                   headers: Optional[Dict[str, str]] = None, timeout: float = 30.0,
                   cache: bool = True, ttl: float = CACHE_TTL) -> Any:
    """GET and parse JSON. ``ttl`` sets how long the payload may be cached."""
    return await get(url, params=params, headers=headers, timeout=timeout,
                     cache=cache, ttl=ttl, as_json=True)


async def post_json(url: str, payload: Dict[str, Any], *,
                    headers: Optional[Dict[str, str]] = None,
                    timeout: float = 60.0) -> Any:
    _assert_web()
    c = await client()
    resp = await c.post(url, json=payload, headers=headers, timeout=timeout)
    resp.raise_for_status()
    try:
        return resp.json()
    except Exception:
        return resp.text


async def gather(*coros: Any, timeout: float = 40.0) -> List[Any]:
    """Run coroutines concurrently, converting failures into ``{"ok": False}``."""
    async def wrap(c: Any) -> Any:
        try:
            return await asyncio.wait_for(c, timeout=timeout)
        except Exception as exc:
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    return list(await asyncio.gather(*(wrap(c) for c in coros), return_exceptions=False))


# ---------------------------------------------------------------------------
# HTML -> readable text / markdown
# ---------------------------------------------------------------------------
_TAG_RE = re.compile(r"<(script|style|noscript|svg|iframe|template|head)\b.*?</\1>",
                     re.S | re.I)
_COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
_BLOCK_RE = re.compile(r"</(p|div|li|tr|h[1-6]|section|article|blockquote|pre)>", re.I)
_TAG_ANY_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"[ \t\r\f\v]+")
_BLANK_RE = re.compile(r"\n{3,}")


def html_to_text(raw_html: str, *, limit: int = 20000) -> str:
    """Strip markup to readable prose. Uses bs4 when available."""
    if not raw_html:
        return ""
    try:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(raw_html, "html.parser")
        for tag in soup(["script", "style", "noscript", "svg", "iframe", "template", "head", "nav", "footer"]):
            tag.decompose()
        text = soup.get_text("\n")
    except Exception:  # pragma: no cover - bs4 optional
        body = _COMMENT_RE.sub(" ", raw_html)
        body = _TAG_RE.sub(" ", body)
        body = _BLOCK_RE.sub("\n", body)
        text = _TAG_ANY_RE.sub(" ", body)
    text = _html.unescape(text)
    lines = [_WS_RE.sub(" ", ln).strip() for ln in text.splitlines()]
    text = _BLANK_RE.sub("\n\n", "\n".join(ln for ln in lines if ln))
    return text[:limit]


def html_to_markdown(raw_html: str, *, base_url: str = "", limit: int = 24000) -> str:
    """
    Convert a page to compact Markdown: headings, lists, links, paragraphs.

    Deliberately small — SAM summarises from this, it does not archive the web.
    """
    if not raw_html:
        return ""
    try:
        from bs4 import BeautifulSoup
    except Exception:  # pragma: no cover
        return html_to_text(raw_html, limit=limit)

    soup = BeautifulSoup(raw_html, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg", "iframe", "template", "head", "nav",
                     "footer", "aside", "form", "button"]):
        tag.decompose()
    root = soup.find("main") or soup.find("article") or soup.body or soup

    out: List[str] = []
    title = soup.title.get_text(strip=True) if soup.title else ""
    if title:
        out.append(f"# {title}\n")

    def walk(node: Any) -> None:
        name = getattr(node, "name", None)
        if name is None:
            txt = str(node).strip()
            if txt:
                out.append(_WS_RE.sub(" ", _html.unescape(txt)))
            return
        if name in ("h1", "h2", "h3", "h4", "h5", "h6"):
            level = int(name[1])
            out.append("\n" + "#" * level + " " + node.get_text(" ", strip=True) + "\n")
        elif name == "li":
            out.append("- " + node.get_text(" ", strip=True))
        elif name == "pre" or name == "code":
            out.append("```\n" + node.get_text("", strip=False).strip() + "\n```")
        elif name == "a":
            href = node.get("href") or ""
            label = node.get_text(" ", strip=True)
            if href and label and href not in ("#",) and not href.startswith("javascript:"):
                if base_url:
                    href = urljoin(base_url, href)
                out.append(f"[{label}]({href})")
        elif name in ("p", "blockquote"):
            txt = node.get_text(" ", strip=True)
            if txt:
                out.append(("\n> " if name == "blockquote" else "\n") + txt + "\n")
        elif name == "br":
            out.append("\n")
        elif name in ("table",):
            rows = []
            for tr in node.find_all("tr"):
                cells = [td.get_text(" ", strip=True) for td in tr.find_all(["td", "th"])]
                if cells:
                    rows.append("| " + " | ".join(cells) + " |")
            if rows:
                rows.insert(1, "|" + "---|" * len(rows[0].split("|")[1:-1]))
                out.append("\n".join(rows) + "\n")
        else:
            for child in node.children:
                walk(child)

    walk(root)
    md = _BLANK_RE.sub("\n\n", "\n".join(out))
    md = re.sub(r"\n{2,}(?=- )", "\n", md)
    return md[:limit]


def extract_meta(raw_html: str) -> Dict[str, Any]:
    """Pull title / description / canonical / og:image out of a page."""
    meta: Dict[str, Any] = {}
    m = re.search(r"<title[^>]*>(.*?)</title>", raw_html, re.S | re.I)
    if m:
        meta["title"] = _html.unescape(m.group(1)).strip()[:300]
    for name, key in (("description", "description"), ("og:title", "og_title"),
                      ("og:description", "og_description"), ("og:image", "og_image"),
                      ("author", "author"), ("keywords", "keywords")):
        m = re.search(rf'<meta[^>]+(?:name|property)=["\']{re.escape(name)}["\'][^>]*content=["\'](.*?)["\']',
                      raw_html, re.S | re.I)
        if m:
            meta[key] = _html.unescape(m.group(1)).strip()[:500]
    m = re.search(r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\'](.*?)["\']', raw_html, re.I)
    if m:
        meta["canonical"] = m.group(1)
    return meta


def extract_links(raw_html: str, base_url: str = "", limit: int = 40) -> List[Dict[str, str]]:
    links: List[Dict[str, str]] = []
    seen = set()
    for href, label in re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                                  raw_html, re.S | re.I):
        text = _html.unescape(_TAG_ANY_RE.sub("", label)).strip()
        if not text or href.startswith(("#", "javascript:", "mailto:")):
            continue
        if base_url:
            href = urljoin(base_url, href)
        if href in seen:
            continue
        seen.add(href)
        links.append({"url": href, "text": text[:160]})
        if len(links) >= limit:
            break
    return links


def normalise_url(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    return url


def domain_of(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# keyless search backends
# ---------------------------------------------------------------------------
async def duckduckgo(query: str, limit: int = 8, *, region: str = "us-en") -> List[Dict[str, Any]]:
    """
    Keyless web search.

    Endpoint order (the ``lite`` endpoint is far more tolerant of automation than
    the HTML endpoint, which starts returning HTTP 202 anomaly pages after a few
    requests):

        1. https://lite.duckduckgo.com/lite/
        2. https://html.duckduckgo.com/html/   (POST)
        3. https://html.duckduckgo.com/html/   (GET)

    Returns ``[{title, url, snippet, source, engine}]``.
    """
    _assert_web()
    c = await client()

    # ---- 1. lite -------------------------------------------------------
    try:
        r = await c.get("https://lite.duckduckgo.com/lite/",
                        params={"q": query, "kl": region}, timeout=25.0)
        if r.status_code < 400:
            out = _parse_ddg_lite(r.text, limit)
            if out:
                return out
    except Exception as exc:  # pragma: no cover
        log.debug("ddg lite failed: %s", exc)

    # ---- 2/3. html endpoint -------------------------------------------
    for method in ("post", "get"):
        try:
            if method == "post":
                r = await c.post("https://html.duckduckgo.com/html/", data={"q": query, "kl": region},
                                 timeout=25.0,
                                 headers={**DEFAULT_HEADERS,
                                          "Content-Type": "application/x-www-form-urlencoded"})
            else:
                r = await c.get("https://html.duckduckgo.com/html/",
                                params={"q": query, "kl": region}, timeout=25.0)
            if r.status_code < 400:
                out = _parse_ddg_html(r.text, limit)
                if out:
                    return out
        except Exception as exc:  # pragma: no cover
            log.debug("ddg %s failed: %s", method, exc)
    return []


def _parse_ddg_lite(body: str, limit: int) -> List[Dict[str, Any]]:
    """Parse lite.duckduckgo.com result rows."""
    results: List[Dict[str, Any]] = []
    # each result is an anchor with class='result-link'; the snippet follows it.
    parts = re.split(r'<a[^>]+class=[\'"]result-link[\'"][^>]*>', body)[1:]
    anchors = re.findall(r'<a[^>]+class=[\'"]result-link[\'"][^>]*href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>',
                         body, re.S)
    snippets = re.findall(r'<td[^>]+class=[\'"]result-snippet[\'"][^>]*>(.*?)</td>', body, re.S)
    for i, (href, title) in enumerate(anchors):
        real = _ddg_unwrap(href)
        if not real:
            continue
        results.append({
            "title": _clean(title),
            "url": real,
            "snippet": _clean(snippets[i]) if i < len(snippets) else "",
            "source": domain_of(real),
            "engine": "duckduckgo-lite",
        })
        if len(results) >= limit:
            break
    return results


def _parse_ddg_html(body: str, limit: int) -> List[Dict[str, Any]]:
    """Parse html.duckduckgo.com result blocks."""
    results: List[Dict[str, Any]] = []
    blocks = re.split(r'<div class="result\s+results_links', body)[1:]
    for block in blocks:
        m = re.search(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', block, re.S)
        if not m:
            continue
        real = _ddg_unwrap(m.group(1))
        if not real:
            continue
        sn = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', block, re.S)
        results.append({
            "title": _clean(m.group(2)),
            "url": real,
            "snippet": _clean(sn.group(1)) if sn else "",
            "source": domain_of(real),
            "engine": "duckduckgo",
        })
        if len(results) >= limit:
            break
    return results


async def web_search(query: str, limit: int = 8) -> List[Dict[str, Any]]:
    """
    Best available search: paid providers first (if keyed), then keyless DDG.
    Never raises — returns ``[]`` when every engine fails.
    """
    engines: List[Any] = []
    if settings.brave_api_key:
        engines.append(brave_search(query, limit))
    if settings.tavily_api_key:
        engines.append(tavily_search(query, limit))
    engines.append(duckduckgo(query, limit))
    for coro in engines:
        try:
            out = await coro
            if out:
                return out[:limit]
        except Exception as exc:
            log.debug("search engine failed: %s", exc)
    return []


async def image_search(query: str, limit: int = 6) -> List[Dict[str, Any]]:
    """
    Keyless image search over Openverse (Creative-Commons catalogues) with a
    Wikipedia thumbnail fallback.
    """
    try:
        data = await get_json("https://api.openverse.org/v1/images/",
                              params={"q": query, "page_size": min(limit, 20)})
        out = []
        for item in data.get("results") or []:
            out.append({"title": item.get("title"), "url": item.get("url"),
                        "thumbnail": item.get("thumbnail"), "page": item.get("foreign_landing_url"),
                        "license": item.get("license"), "creator": item.get("creator"),
                        "source": item.get("source"), "engine": "openverse"})
        if out:
            return out[:limit]
    except Exception as exc:
        log.debug("openverse failed: %s", exc)
    try:
        data = await get_json("https://en.wikipedia.org/w/api.php",
                              params={"action": "query", "generator": "search", "gsrsearch": query,
                                      "gsrlimit": limit, "prop": "pageimages", "piprop": "thumbnail",
                                      "pithumbsize": 600, "format": "json"})
        pages = ((data.get("query") or {}).get("pages") or {})
        out = []
        for p in sorted(pages.values(), key=lambda x: x.get("index", 99)):
            thumb = (p.get("thumbnail") or {}).get("source")
            if thumb:
                out.append({"title": p.get("title"), "url": thumb, "thumbnail": thumb,
                            "page": f"https://en.wikipedia.org/?curid={p.get('pageid')}",
                            "license": "Wikipedia", "engine": "wikipedia"})
        return out[:limit]
    except Exception as exc:
        log.debug("wikipedia image fallback failed: %s", exc)
        return []


async def translate_text(text: str, target: str, source: str = "auto") -> Dict[str, Any]:
    """Keyless machine translation (Google's public gtx endpoint)."""
    data = await get_json("https://translate.googleapis.com/translate_a/single",
                          params={"client": "gtx", "sl": source or "auto", "tl": target,
                                  "dt": "t", "q": text}, cache=True)
    if not isinstance(data, list) or not data:
        return {"ok": False, "error": "translation service returned nothing"}
    chunks = [c[0] for c in (data[0] or []) if isinstance(c, list) and c and c[0]]
    detected = ""
    if len(data) > 2 and isinstance(data[2], str):
        detected = data[2]
    return {"ok": True, "text": text, "translated": "".join(chunks), "target": target,
            "source_detected": detected, "engine": "google-gtx"}



def _ddg_unwrap(href: str) -> str:
    href = _html.unescape(href)
    if href.startswith("//"):
        href = "https:" + href
    if "duckduckgo.com/l/?" in href or href.startswith("/l/?"):
        m = re.search(r"uddg=([^&]+)", href)
        if m:
            from urllib.parse import unquote
            return unquote(m.group(1))
        return ""
    if href.startswith(("http://", "https://")) and "duckduckgo.com" not in href:
        return href
    return ""


async def wikipedia_search(query: str, limit: int = 5, lang: str = "en") -> List[Dict[str, Any]]:
    data = await get_json(
        f"https://{lang}.wikipedia.org/w/api.php",
        params={"action": "query", "list": "search", "srsearch": query, "srlimit": limit,
                "format": "json", "utf8": 1},
    )
    hits = (data.get("query") or {}).get("search") or []
    return [{"title": h.get("title"), "snippet": _clean(h.get("snippet", "")),
             "url": f"https://{lang}.wikipedia.org/wiki/{quote_plus(h['title'].replace(' ', '_'))}",
             "pageid": h.get("pageid")} for h in hits]


async def wikipedia_summary(title: str, lang: str = "en") -> Dict[str, Any]:
    return await get_json(f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{quote_plus(title)}")


def _clean(s: str) -> str:
    s = _html.unescape(_TAG_ANY_RE.sub("", s or ""))
    return _WS_RE.sub(" ", s).strip()


# ---------------------------------------------------------------------------
# provider-backed search (only when the user configured a key)
# ---------------------------------------------------------------------------
async def brave_search(query: str, limit: int = 8) -> List[Dict[str, Any]]:
    if not settings.brave_api_key:
        return []
    data = await get_json("https://api.search.brave.com/res/v1/web/search",
                          params={"q": query, "count": min(limit, 20)},
                          headers={"X-Subscription-Token": settings.brave_api_key,
                                   "Accept": "application/json"}, cache=False)
    out = []
    for item in ((data.get("web") or {}).get("results") or [])[:limit]:
        out.append({"title": item.get("title"), "url": item.get("url"),
                    "snippet": item.get("description"), "source": domain_of(item.get("url", "")),
                    "age": item.get("age"), "engine": "brave"})
    return out


async def tavily_search(query: str, limit: int = 8) -> List[Dict[str, Any]]:
    if not settings.tavily_api_key:
        return []
    data = await post_json("https://api.tavily.com/search",
                           {"api_key": settings.tavily_api_key, "query": query,
                            "max_results": min(limit, 10), "include_answer": True})
    out = []
    if isinstance(data, dict):
        if data.get("answer"):
            out.append({"title": "Tavily answer", "url": "", "snippet": data["answer"],
                        "source": "tavily", "engine": "tavily"})
        for item in data.get("results") or []:
            out.append({"title": item.get("title"), "url": item.get("url"),
                        "snippet": item.get("content"), "source": domain_of(item.get("url", "")),
                        "engine": "tavily"})
    return out[:limit]


async def news_search(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """News via NewsAPI when keyed, else Google News RSS (keyless)."""
    if settings.news_api_key:
        try:
            data = await get_json("https://newsapi.org/v2/everything",
                                  params={"q": query, "apiKey": settings.news_api_key,
                                          "pageSize": limit, "sortBy": "publishedAt"}, cache=False)
            out = []
            for a in data.get("articles") or []:
                out.append({"title": a.get("title"), "url": a.get("url"),
                            "snippet": a.get("description"), "source": (a.get("source") or {}).get("name"),
                            "published": a.get("publishedAt"), "engine": "newsapi"})
            if out:
                return out[:limit]
        except Exception as exc:  # pragma: no cover
            log.debug("newsapi failed: %s", exc)
    return await google_news_rss(query, limit)


async def google_news_rss(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    xml = await get("https://news.google.com/rss/search", params={"q": query, "hl": "en-US", "gl": "US"})
    items = re.findall(r"<item>(.*?)</item>", xml, re.S)
    out = []
    for block in items[:limit]:
        def field(tag: str) -> str:
            m = re.search(rf"<{tag}>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</{tag}>", block, re.S)
            return _clean(m.group(1)) if m else ""

        out.append({"title": field("title"), "url": field("link"), "snippet": field("description"),
                    "source": field("source"), "published": field("pubDate"), "engine": "google-news-rss"})
    return out


async def read_rss(url: str, limit: int = 15) -> List[Dict[str, Any]]:
    xml = await get(url, timeout=25.0)
    items = re.findall(r"<(?:item|entry)[ >](.*?)</(?:item|entry)>", xml, re.S)
    out = []
    for block in items[:limit]:
        def field(tag: str) -> str:
            m = re.search(rf"<{tag}[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</{tag}>", block, re.S)
            return _clean(m.group(1)) if m else ""

        link = field("link")
        if not link:
            m = re.search(r'<link[^>]*href="([^"]+)"', block)
            link = m.group(1) if m else ""
        out.append({"title": field("title"), "url": link,
                    "snippet": field("summary") or field("description"),
                    "published": field("pubDate") or field("updated") or field("published")})
    return out


# ---------------------------------------------------------------------------
# misc keyless data sources
# ---------------------------------------------------------------------------
async def exchange_rates(base: str = "USD") -> Dict[str, float]:
    data = await get_json("https://open.er-api.com/v6/latest/" + base.upper())
    return data.get("rates") or {}


async def crypto_price(symbol: str, vs: str = "usd") -> Dict[str, Any]:
    data = await get_json("https://api.coingecko.com/api/v3/simple/price",
                          params={"ids": symbol.lower(), "vs_currencies": vs.lower(),
                                  "include_24hr_change": "true"})
    return data.get(symbol.lower()) or {}


async def stock_quote(symbol: str) -> Dict[str, Any]:
    """Live quote from Yahoo Finance's public chart endpoint (no key)."""
    try:
        data = await get_json(f"https://query1.finance.yahoo.com/v8/finance/chart/{quote_plus(symbol)}",
                              params={"interval": "1d", "range": "5d"}, cache=True, ttl=60.0)
        result = ((data.get("chart") or {}).get("result") or [{}])[0]
        meta = result.get("meta") or {}
        price = meta.get("regularMarketPrice")
        prev = meta.get("chartPreviousClose") or meta.get("previousClose")
        change = None
        if price is not None and prev:
            change = round(((price - prev) / prev) * 100, 3)
        closes = ((result.get("indicators") or {}).get("quote") or [{}])[0].get("close") or []
        closes = [c for c in closes if c is not None]
        return {"ok": True, "symbol": meta.get("symbol", symbol),
                "name": meta.get("longName") or meta.get("shortName") or "",
                "exchange": meta.get("fullExchangeName") or meta.get("exchangeName"),
                "currency": meta.get("currency"), "price": price,
                "previous_close": prev, "change_percent": change,
                "day_high": meta.get("regularMarketDayHigh"),
                "day_low": meta.get("regularMarketDayLow"),
                "volume": meta.get("regularMarketVolume"),
                "market_time": meta.get("regularMarketTime"),
                "recent_closes": [round(c, 4) for c in closes[-5:]],
                "source": "yahoo-finance"}
    except Exception as exc:
        log.debug("yahoo quote failed for %s: %s", symbol, exc)
        return {"ok": False, "symbol": symbol, "error": f"no quote available for '{symbol}'"}


async def ip_info(ip: str = "") -> Dict[str, Any]:
    url = "https://ipapi.co/" + ((ip + "/json") if ip else "json/")
    return await get_json(url, timeout=20.0)


async def geocode(place: str) -> Optional[Dict[str, Any]]:
    data = await get_json("https://geocoding-api.open-meteo.com/v1/search",
                          params={"name": place, "count": 1, "language": "en", "format": "json"})
    results = data.get("results") or []
    return results[0] if results else None


async def weather(place: str = "", lat: Optional[float] = None,
                  lon: Optional[float] = None, days: int = 1) -> Dict[str, Any]:
    location: Dict[str, Any] = {}
    if lat is None or lon is None:
        if not place:
            info = await ip_info()
            lat, lon = info.get("latitude"), info.get("longitude")
            location = {"name": info.get("city"), "country": info.get("country_name"),
                        "source": "ip"}
        else:
            geo = await geocode(place)
            if not geo:
                return {"ok": False, "error": f"could not find a place called '{place}'"}
            lat, lon = geo.get("latitude"), geo.get("longitude")
            location = {"name": geo.get("name"), "country": geo.get("country"),
                        "region": geo.get("admin1"), "source": "open-meteo-geocoder"}
    daily = {"temperature_2m_max": "max_temp_c", "temperature_2m_min": "min_temp_c",
             "precipitation_probability_max": "rain_chance_percent", "weathercode": "code"}
    params: Dict[str, Any] = {
        "latitude": lat, "longitude": lon,
        "current": ("temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,"
                    "wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover,precipitation"),
        "daily": ",".join(daily), "forecast_days": max(1, min(days, 7)), "timezone": "auto",
    }
    data = await get_json("https://api.open-meteo.com/v1/forecast", params=params)
    cur = data.get("current") or {}
    out: Dict[str, Any] = {
        "ok": True, "location": {**location, "latitude": lat, "longitude": lon,
                                 "timezone": data.get("timezone")},
        "current": {
            "temperature_c": cur.get("temperature_2m"), "feels_like_c": cur.get("apparent_temperature"),
            "humidity_percent": cur.get("relative_humidity_2m"), "condition": WMO.get(cur.get("weather_code"), "unknown"),
            "weather_code": cur.get("weather_code"), "wind_kmh": cur.get("wind_speed_10m"),
            "wind_direction_deg": cur.get("wind_direction_10m"), "pressure_hpa": cur.get("pressure_msl"),
            "cloud_cover_percent": cur.get("cloud_cover"), "precipitation_mm": cur.get("precipitation"),
            "observed_at": cur.get("time"),
        },
        "forecast": [],
        "source": "open-meteo.com",
    }
    d = data.get("daily") or {}
    dates = d.get("time") or []
    for i, day in enumerate(dates):
        out["forecast"].append({
            "date": day,
            "max_temp_c": (d.get("temperature_2m_max") or [None])[i],
            "min_temp_c": (d.get("temperature_2m_min") or [None])[i],
            "rain_chance_percent": (d.get("precipitation_probability_max") or [None])[i],
            "condition": WMO.get((d.get("weathercode") or [None])[i], "unknown"),
        })
    return out


WMO = {
    0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "depositing rime fog", 51: "light drizzle", 53: "moderate drizzle",
    55: "dense drizzle", 56: "light freezing drizzle", 57: "dense freezing drizzle",
    61: "slight rain", 63: "moderate rain", 65: "heavy rain", 66: "light freezing rain",
    67: "heavy freezing rain", 71: "slight snow", 73: "moderate snow", 75: "heavy snow",
    77: "snow grains", 80: "slight rain showers", 81: "moderate rain showers",
    82: "violent rain showers", 85: "slight snow showers", 86: "heavy snow showers",
    95: "thunderstorm", 96: "thunderstorm with slight hail", 99: "thunderstorm with heavy hail",
}


async def definitions(word: str) -> Dict[str, Any]:
    """Dictionary lookup with three independent keyless sources."""
    # ---- 1. dictionaryapi.dev ------------------------------------------
    try:
        data = await get_json(f"https://api.dictionaryapi.dev/api/v2/entries/en/{quote_plus(word)}")
        if isinstance(data, list) and data:
            entry = data[0]
            senses = []
            for meaning in entry.get("meanings") or []:
                for d in (meaning.get("definitions") or [])[:3]:
                    senses.append({
                        "part_of_speech": meaning.get("partOfSpeech"),
                        "definition": d.get("definition"),
                        "example": d.get("example"),
                        "synonyms": (d.get("synonyms") or meaning.get("synonyms") or [])[:6],
                        "antonyms": (d.get("antonyms") or meaning.get("antonyms") or [])[:4],
                    })
            phon = entry.get("phonetics") or [{}]
            return {"ok": True, "word": entry.get("word"), "phonetic": entry.get("phonetic"),
                    "pronunciation": next((p.get("text") for p in phon if p.get("text")), ""),
                    "audio": next((p.get("audio") for p in phon if p.get("audio")), ""),
                    "origin": entry.get("origin"), "senses": senses[:8],
                    "source": "dictionaryapi.dev"}
    except Exception as exc:
        log.debug("dictionaryapi failed for %s: %s", word, exc)

    # ---- 2. Wiktionary REST --------------------------------------------
    try:
        data = await get_json(
            f"https://en.wiktionary.org/api/rest_v1/page/definition/{quote_plus(word)}",
            headers={**DEFAULT_HEADERS, "Accept": "application/json"})
        entries = data.get("en") or []
        senses = []
        for e in entries:
            for d in (e.get("definitions") or [])[:4]:
                senses.append({"part_of_speech": e.get("partOfSpeech"),
                               "definition": _clean(d.get("definition", "")),
                               "example": "", "synonyms": [], "antonyms": []})
        if senses:
            return {"ok": True, "word": word, "phonetic": "", "pronunciation": "",
                    "senses": senses[:8], "source": "wiktionary"}
    except Exception as exc:
        log.debug("wiktionary failed for %s: %s", word, exc)

    # ---- 3. Datamuse (meaning/synonym expansion only) -------------------
    try:
        data = await get_json("https://api.datamuse.com/words",
                              params={"ml": word, "max": 8})
        words = [d["word"] for d in data if d.get("word")]
        if words:
            return {"ok": True, "word": word, "phonetic": "", "pronunciation": "",
                    "senses": [{"part_of_speech": "related", "definition": "",
                                "synonyms": words, "antonyms": []}],
                    "note": "no dictionary entry found — showing related words instead",
                    "source": "datamuse"}
    except Exception as exc:
        log.debug("datamuse failed for %s: %s", word, exc)

    return {"ok": False, "error": f"'{word}' was not found in any dictionary source"}


async def synonyms(word: str, kind: str = "syn", limit: int = 12) -> List[str]:
    """Datamuse relation lookup: syn / ant / rel / triggers."""
    rel = {"syn": "ml", "synonym": "ml", "ant": "rel_ant", "antonym": "rel_ant",
           "related": "rel_trg", "rhyme": "rel_rhy", "sounds_like": "rel_sls",
           "spelled_like": "rel_spc", "kind_of": "rel_syn", "part_of": "rel_par",
           "triggers": "rel_trg"}.get(kind, "ml")
    data = await get_json("https://api.datamuse.com/words",
                          params={rel: word, "max": limit})
    return [d["word"] for d in data if d.get("word")]



async def arxiv_search(query: str, limit: int = 6) -> List[Dict[str, Any]]:
    xml = await get("http://export.arxiv.org/api/query",
                    params={"search_query": f"all:{query}", "start": 0, "max_results": limit})
    out = []
    for block in re.findall(r"<entry>(.*?)</entry>", xml, re.S):
        def field(tag: str) -> str:
            m = re.search(rf"<{tag}>(.*?)</{tag}>", block, re.S)
            return _clean(m.group(1)) if m else ""

        authors = re.findall(r"<name>(.*?)</name>", block)
        out.append({"title": field("title"), "summary": field("summary")[:900],
                    "url": field("id"), "published": field("published"),
                    "authors": [a.strip() for a in authors[:6]]})
    return out


async def hn_top(story_type: str = "top", limit: int = 10) -> List[Dict[str, Any]]:
    ids = await get_json(f"https://hacker-news.firebaseio.com/v0/{story_type}stories.json")
    ids = ids[:limit]
    async def one(i: int) -> Dict[str, Any]:
        s = await get_json(f"https://hacker-news.firebaseio.com/v0/item/{i}.json")
        return {"id": s.get("id"), "title": s.get("title"), "url": s.get("url"),
                "score": s.get("score"), "comments": s.get("descendants"),
                "by": s.get("by"), "hn_link": f"https://news.ycombinator.com/item?id={s.get('id')}"}
    return [r for r in await gather(*(one(i) for i in ids)) if isinstance(r, dict) and r.get("title")]
