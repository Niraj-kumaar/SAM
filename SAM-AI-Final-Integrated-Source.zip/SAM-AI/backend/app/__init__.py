"""
SAM — Personal AI Operating Platform
=====================================

A multi-brain, multi-agent AI operating assistant that unifies:

* AI conversation and reasoning over many model providers
* Voice interaction (STT / TTS / wake word)
* Windows PC control (apps, keyboard, mouse, screen, terminal, files)
* Android phone control via the SAM Companion app
* Browser automation and internet research
* Coding, creative, document and data workspaces
* Memory, scheduling, automation and proactive assistance
* A central permission / risk / confirmation / audit security layer

Entry point:  ``backend/app/main.py``  ->  ``uvicorn backend.app.main:app``
"""

__version__ = "1.0.0"
__product__ = "SAM"
__tagline__ = "Personal AI Operating Platform"
