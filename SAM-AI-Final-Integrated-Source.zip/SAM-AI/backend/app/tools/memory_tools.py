"""
backend.app.tools.memory_tools
==============================

The Memory Brain's tools: store, search, list, correct and erase memory.

All writes go through :class:`backend.app.memory.store.MemoryStore`, which
refuses to persist anything that looks like a credential.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.app.core.logging_config import get_logger
from backend.app.memory.store import MEMORY_KINDS, memory_store
from backend.app.tools.registry import ToolContext, tool

log = get_logger("tools.memory")


@tool(
    name="memory.write",
    capability="memory.write",
    agent="memory",
    device="pc",
    description="Store a fact, preference or project note in long-term memory",
    schema={"content": {"type": "string", "required": True}, "kind": {"type": "string"},
            "key": {"type": "string"}, "scope": {"type": "string"}},
    risk="LOW",
    timeout=60,
)
async def memory_write(ctx: ToolContext, content: str = "", kind: str = "long_term",
                       key: str = "", scope: str = "global", tags: Optional[List[str]] = None,
                       importance: float = 0.6, request: str = "") -> Dict[str, Any]:
    text = content or request or ctx.user_text
    if not text.strip():
        return {"ok": False, "error": "nothing to remember"}
    if kind not in MEMORY_KINDS:
        kind = "long_term"
    if not key:
        # try to lift the fact out of a "remember that ..." sentence
        extracted = await memory_store.store_from_text(text, source=ctx.agent,
                                                       language=ctx.language)
        if extracted and extracted.get("ok"):
            return {"ok": True, "stored": True, **extracted}
    return await memory_store.remember(
        text, kind=kind, key=key, scope=scope, tags=tags or [],
        importance=float(importance), source=ctx.agent or "user",
    )


@tool(
    name="memory.search",
    capability="memory.read",
    agent="memory",
    device="pc",
    description="Recall memory by meaning (hybrid lexical + semantic search)",
    schema={"query": {"type": "string", "required": True}},
    risk="LOW",
    timeout=60,
)
async def memory_search(ctx: ToolContext, query: str = "", kind: Optional[str] = None,
                        scope: Optional[str] = None, limit: int = 8,
                        request: str = "") -> Dict[str, Any]:
    text = query or request or ctx.user_text
    if not text.strip():
        return {"ok": True, "count": 0, "items": [], "note": "empty query"}
    items = await memory_store.recall(text, limit=int(limit), kind=kind, scope=scope)
    answer = ""
    if items:
        answer = "What I remember about that:\n" + "\n".join(
            f"- {i['content'][:240]}" for i in items[:6]
        )
    else:
        answer = f"I have nothing stored about “{text[:80]}” yet."
    return {"ok": True, "query": text, "count": len(items), "items": items, "answer": answer}


@tool(
    name="memory.list",
    capability="memory.read",
    agent="memory",
    device="pc",
    description="List stored memory items, optionally filtered by kind or scope",
    risk="LOW",
    timeout=60,
)
async def memory_list(ctx: ToolContext, kind: Optional[str] = None, scope: Optional[str] = None,
                      search: str = "", limit: int = 50) -> Dict[str, Any]:
    data = await memory_store.list_items(kind=kind, scope=scope, search=search,
                                        limit=int(limit))
    data["ok"] = True
    data["stats"] = await memory_store.stats()
    return data


@tool(
    name="memory.forget",
    capability="memory.delete",
    agent="memory",
    device="pc",
    description="Erase a memory item by id or key, or clear a whole category",
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def memory_forget(ctx: ToolContext, item_id: Optional[int] = None, key: str = "",
                        kind: Optional[str] = None, everything: bool = False,
                        request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    if everything or "everything" in text or "all memory" in text or "forget everything" in text:
        n = await memory_store.clear(kind=kind)
        return {"ok": True, "cleared": n, "scope": "all" if kind is None else kind}
    if item_id is not None:
        ok = await memory_store.forget(int(item_id))
        return {"ok": ok, "deleted": int(item_id) if ok else None,
                "error": None if ok else "no memory item with that id"}
    if key:
        n = await memory_store.forget_key(key, kind=kind)
        return {"ok": n > 0, "deleted": n, "key": key}
    if kind:
        n = await memory_store.clear(kind=kind)
        return {"ok": True, "cleared": n, "kind": kind}
    return {"ok": False, "error": "give an item_id, a key, a kind, or everything=true"}


@tool(
    name="memory.correct",
    capability="memory.write",
    agent="memory",
    device="pc",
    description="Correct or update an existing memory item",
    risk="LOW",
    timeout=60,
)
async def memory_correct(ctx: ToolContext, item_id: Optional[int] = None, key: str = "",
                         content: str = "", importance: Optional[float] = None,
                         enabled: Optional[bool] = None) -> Dict[str, Any]:
    target_id = item_id
    if target_id is None and key:
        found = await memory_store.list_items(search=key, limit=1)
        items = found.get("items") or []
        exact = [i for i in items if i["key"] == key]
        pick = (exact or items)[0] if (exact or items) else None
        target_id = pick["id"] if pick else None
    if target_id is None:
        return {"ok": False, "error": f"no memory item found for key '{key}'"}
    updated = await memory_store.update_item(
        int(target_id), content=content or None, importance=importance, enabled=enabled
    )
    if updated is None:
        return {"ok": False, "error": "update failed"}
    return {"ok": True, "item": updated}


@tool(
    name="memory.stats",
    capability="memory.read",
    agent="memory",
    device="pc",
    description="Report memory usage statistics per category",
    risk="LOW",
    timeout=30,
)
async def memory_stats(ctx: ToolContext) -> Dict[str, Any]:
    from backend.app.files.semantic_index import semantic_index

    stats = await memory_store.stats()
    stats["semantic_index"] = await semantic_index.stats()
    stats["ok"] = True
    return stats
