"""
backend.app.tools.text_tools
============================

**The writing / text toolbox** — the part of SAM that behaves like a ChatGPT-style
assistant for words rather than for actions.

Everything here runs **locally and deterministically** unless a tool explicitly
says it uses a model. That matters for two reasons:

* a language model may not be configured (no API key, no Ollama) — SAM must
  still summarise, count, clean, redact and compare text;
* text statistics must be *true*, not plausible. A word count that comes from a
  language model is a guess; the one here is a number.

Where a model is used (``text.summarise`` with ``method="model"``,
``text.rewrite``, ``text.bullets``), the tool falls back to the deterministic
implementation and says so, instead of returning the offline engine's canned
chat text.

Tool map
--------
=========================  ===================================================
``text.count``             words, characters, sentences, reading/speaking time
``text.readability``       Flesch, Flesch-Kincaid, Gunning Fog, ARI, SMOG
``text.summarise``         extractive (ranked sentences) or model summary
``text.rewrite``           change tone / length / voice
``text.grammar``           rule-based corrections with a change report
``text.extract``           emails, urls, phones, dates, tags, numbers, IPs
``text.sentiment``         lexicon sentiment, overall and per sentence
``text.keywords``          keywords, key phrases, SEO meta description
``text.similarity``        compare two texts, duplicate detection
``text.diff``              unified / side-by-side diff of two texts
``text.slug``              URL slug
``text.case``              snake/camel/pascal/kebab/title/sentence/…
``text.title``             proper English title case
``text.lines``             sort / dedupe / trim / number / filter lines
``text.template``          render ``{{placeholders}}`` from a mapping
``text.table``             rows → Markdown / CSV / HTML / JSON table
``text.bullets``           prose ↔ bullet points
``text.redact``            mask PII before sharing text
``text.markdown``          Markdown → HTML, HTML → text/Markdown
``text.lorem``             placeholder copy
=========================  ===================================================
"""

from __future__ import annotations

import difflib
import html as html_lib
import json
import math
import re
import unicodedata
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, tool

log = get_logger("tools.text")

# ---------------------------------------------------------------------------
# language data
# ---------------------------------------------------------------------------
STOPWORDS = set("""a about above after again against all am an and any are aren't as at be because
been before being below between both but by can cannot could couldn't did didn't do does doesn't
doing don't down during each few for from further had hadn't has hasn't have haven't having he he'd
he'll he's her here here's hers herself him himself his how how's i i'd i'll i'm i've if in into is
isn't it it's its itself let's me more most mustn't my myself no nor not of off on once only or
other ought our ours ourselves out over own same shan't she she'd she'll she's should shouldn't so
some such than that that's the their theirs them themselves then there there's these they they'd
they'll they're they've this those through to too under until up very was wasn't we we'd we'll we're
we've were weren't what what's when when's where where's which while who who's whom why why's with
won't would wouldn't you you'd you'll you're you've your yours yourself yourselves also will just
get got make made one two three many much however therefore thus please""".split())

POSITIVE = set("""good great excellent amazing wonderful fantastic superb brilliant outstanding
love like enjoy happy pleased perfect best better win won gain grow growth improve improved
strong strength positive success successful beat beats rally rallies surge surges boost boosted
upgrade bullish opportunity promising solid reliable efficient effective beautiful clean clear
easy fast quick safe secure smart innovation innovative record high award profit profitable
celebrate celebrate breakthrough hopeful optimistic stable calm healthy recover recovered
recommend recommended helpful valuable premium delight delight delighted""".split())

NEGATIVE = set("""bad worst worse terrible horrible awful poor fail failed failure lose lost loss
decline declines drop drops fall falls crash crashed crisis problem problems issue issues bug bugs
error errors broken break breaks weak weakness negative risk risky dangerous danger threat threats
scam fraud frauds fake false wrong slow slowest expensive costly cheap difficult hard confusing
complex ugly dirty messy unsafe insecure vulnerability vulnerable attack attacked breach breached
recall downgrade bearish worry worried anxious fear afraid panic crash delay delayed cancel
cancelled reject rejected deny denied complaint complaints sue sued fine fined penalty penalties
outage outage down degrade degraded disappointing disappoint disappoints loss losses""".split())

INTENSIFIERS = {"very": 1.6, "really": 1.5, "extremely": 2.0, "incredibly": 1.8, "so": 1.4,
                "absolutely": 1.8, "totally": 1.5, "quite": 1.2, "rather": 1.2, "highly": 1.6}
NEGATORS = {"not", "no", "never", "neither", "nobody", "nothing", "nor", "cannot", "can't",
            "don't", "doesn't", "didn't", "won't", "wouldn't", "shouldn't", "isn't", "aren't",
            "wasn't", "weren't", "hardly", "barely", "scarcely", "without"}

# small, high-value correction table — SAM never silently rewrites meaning
COMMON_FIXES: List[Tuple[str, str]] = [
    (r"\bcould of\b", "could have"), (r"\bshould of\b", "should have"),
    (r"\bwould of\b", "would have"), (r"\bmust of\b", "must have"),
    (r"\balot\b", "a lot"), (r"\bteh\b", "the"), (r"\brecieve\b", "receive"),
    (r"\brecieved\b", "received"), (r"\bseperate\b", "separate"),
    (r"\bdefinately\b", "definitely"), (r"\boccured\b", "occurred"),
    (r"\boccurence\b", "occurrence"), (r"\bwich\b", "which"), (r"\bthier\b", "their"),
    (r"\buntill\b", "until"), (r"\bbecuase\b", "because"), (r"\bneccessary\b", "necessary"),
    (r"\baccomodate\b", "accommodate"), (r"\barguement\b", "argument"),
    (r"\bcalender\b", "calendar"), (r"\bconcious\b", "conscious"),
    (r"\benviroment\b", "environment"), (r"\bgoverment\b", "government"),
    (r"\bindependant\b", "independent"), (r"\boccassion\b", "occasion"),
    (r"\bperseverence\b", "perseverance"), (r"\bpriviledge\b", "privilege"),
    (r"\bpublically\b", "publicly"), (r"\brecomend\b", "recommend"),
    (r"\brefered\b", "referred"), (r"\bsuccesful\b", "successful"),
    (r"\btommorow\b", "tomorrow"), (r"\btruely\b", "truly"),
    (r"\bwritting\b", "writing"), (r"\btransfered\b", "transferred"),
    (r"\b(\w+)ing\s+is\s+ing\b", r"\1ing is"),
]

LOREM = ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt "
         "ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco "
         "laboris nisi aliquip ex ea commodo consequat duis aute irure in reprehenderit voluptate "
         "velit esse cillum eu fugiat nulla pariatur excepteur sint occaecat cupidatat non "
         "proident sunt culpa qui officia deserunt mollit anim id est laborum").split()

VOWELS = set("aeiouy")

# words that must stay upper-case in a title even when the input is lower-case
ACRONYMS = {"AI", "API", "URL", "URI", "SEO", "UX", "UI", "SQL", "CSV", "JSON", "HTML", "CSS",
            "XML", "YAML", "ID", "IDS", "TV", "CEO", "CTO", "CFO", "COO", "IPO", "OK", "USA",
            "US", "UK", "EU", "IN", "RBI", "SEBI", "GST", "EMI", "SIP", "ATM", "PIN", "OTP",
            "SMS", "PDF", "DOCX", "XLSX", "HTTP", "HTTPS", "FTP", "SSH", "VPN", "CPU", "GPU",
            "RAM", "ROM", "OS", "IT", "HR", "PR", "MD", "PhD", "II", "III", "IV", "2FA", "MFA"}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _bad(message: str, **extra: Any) -> Dict[str, Any]:
    return {"ok": False, "error": message, **extra}


async def _source(text: str, path: str, ctx: ToolContext) -> Tuple[str, Optional[Dict[str, Any]]]:
    """
    Return the text to work on.

    When a ``path`` is given the file is read **through the ``files.read`` tool**
    rather than with a raw open(), so the read still goes through the permission
    engine, the path jail and the audit log.
    """
    if text and text.strip():
        return text, None
    if path and path.strip():
        try:
            from backend.app.tools.registry import registry

            res = await registry.execute("files.read", ctx, path=path.strip(), max_chars=400_000)
            if isinstance(res, dict) and res.get("ok"):
                return str(res.get("content") or res.get("text") or ""), None
            if isinstance(res, dict):
                return "", _bad(str(res.get("error") or "could not read the file"),
                                path=path.strip())
            return "", _bad(f"unexpected result reading '{path}'")
        except Exception as exc:
            return "", _bad(f"could not read '{path}': {type(exc).__name__}: {exc}")
    return "", _bad("give me some text (or a path to a text file)")


def _tokens(text: str) -> List[str]:
    return re.findall(r"[A-Za-zÀ-ÿ0-9'’\-]+", text or "")


def _words(text: str) -> List[str]:
    return re.findall(r"[A-Za-zÀ-ÿ]+(?:['’\-][A-Za-zÀ-ÿ]+)*", text or "")


_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(])|(?<=[.!?])\s*$|\n{2,}")


def _sentences(text: str) -> List[str]:
    parts = [p.strip() for p in _SENT_SPLIT.split((text or "").replace("\r", "")) if p and p.strip()]
    return parts or ([text.strip()] if text.strip() else [])


def _syllables(word: str) -> int:
    w = re.sub(r"[^a-z]", "", word.lower())
    if not w:
        return 0
    if len(w) <= 3:
        return 1
    w = re.sub(r"(?:[^laeiouy]es|ed|[^laeiouy]e)$", "", w)
    w = re.sub(r"^y", "", w)
    groups = re.findall(r"[aeiouy]{1,2}", w)
    return max(1, len(groups))


def _strip_html(raw: str) -> str:
    """HTML → readable text (bs4 when available, regex fallback)."""
    if not raw:
        return ""
    try:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(raw, "html.parser")
        for tag in soup(["script", "style", "noscript", "template", "svg", "iframe"]):
            tag.decompose()
        return re.sub(r"\n{3,}", "\n\n", soup.get_text("\n")).strip()
    except Exception:
        txt = re.sub(r"(?is)<(script|style|noscript|template|svg|iframe).*?>.*?</\1>", " ", raw)
        txt = re.sub(r"(?s)<[^>]+>", " ", txt)
        return re.sub(r"\s+", " ", html_lib.unescape(txt)).strip()


def _markdown_to_html(md: str) -> str:
    """A small, dependency-free Markdown → HTML converter (block level)."""
    if not md:
        return ""
    # Markdown (both CommonMark and the python-markdown library) needs a blank
    # line between a paragraph and the list that follows it — writers rarely
    # type one, so insert it rather than swallowing the list into the paragraph.
    md = re.sub(r"(?m)([^\n\s>\-|`#].*)\n([-*+]\s+|\d+\.\s+)", r"\1\n\n\2", md or "")
    try:
        import markdown as md_lib                              # type: ignore

        return md_lib.markdown(md, extensions=["tables", "fenced_code", "sane_lists"])
    except Exception:
        pass
    out: List[str] = []
    in_code = in_list = in_table = False
    for raw_line in (md or "").splitlines():
        line = raw_line.rstrip()
        if line.startswith("```"):
            out.append("</code></pre>" if in_code else "<pre><code>")
            in_code = not in_code
            continue
        if in_code:
            out.append(html_lib.escape(line))
            continue
        if not line.strip():
            if in_list:
                out.append("</ul>")
                in_list = False
            if in_table:
                out.append("</tbody></table>")
                in_table = False
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            level = len(m.group(1))
            out.append(f"<h{level}>{_inline_md(m.group(2))}</h{level}>")
            continue
        if re.match(r"^\s*(?:[-*+]|\d+\.)\s+", line):
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{_inline_md(re.sub(r'^\\s*(?:[-*+]|\\d+\\.)\\s+', '', line))}</li>")
            continue
        if "|" in line and re.match(r"^\s*\|?[\s:|-]+\|?\s*$", line):
            continue                                            # the |---|---| separator row
        if "|" in line:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if not in_table:
                out.append('<table border="1" cellpadding="4"><tbody>')
                in_table = True
                out.append("<tr>" + "".join(f"<th>{_inline_md(c)}</th>" for c in cells) + "</tr>")
            else:
                out.append("<tr>" + "".join(f"<td>{_inline_md(c)}</td>" for c in cells) + "</tr>")
            continue
        if re.match(r"^\s*&gt;\s?", line) or line.startswith("> "):
            out.append(f"<blockquote>{_inline_md(line.lstrip('> '))}</blockquote>")
            continue
        out.append(f"<p>{_inline_md(line)}</p>")
    if in_list:
        out.append("</ul>")
    if in_table:
        out.append("</tbody></table>")
    if in_code:
        out.append("</code></pre>")
    return "\n".join(out)


def _inline_md(text: str) -> str:
    t = html_lib.escape(text or "")
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
    t = re.sub(r"~~([^~]+)~~", r"<del>\1</del>", t)
    return t


async def _model_text(prompt: str, system: str, fallback: str, *, role: str = "writing",
                      max_tokens: int = 900, temperature: float = 0.5) -> Tuple[str, str]:
    """
    Ask the router for prose. Returns ``(text, engine)`` where ``engine`` is
    ``"model"`` or ``"offline"``.

    SAM never lets the offline rule engine's canned chat text masquerade as a
    rewrite, so when no real model is configured the caller's deterministic
    ``fallback`` is used instead and the answer says which engine produced it.
    """
    from backend.app.models.router import router

    markers = ("I'll research that across several sources", "I parsed that as intent",
               "No cloud or local model is configured yet", "built-in offline engine",
               "sam-rules-v1")
    try:
        res = await router.ask(prompt, role=role, system=system or None,
                               max_tokens=max_tokens, temperature=temperature)
    except Exception as exc:
        log.debug("text model call failed: %s", exc)
        return fallback, "offline"
    text = (res.text or "").strip()
    if not text or getattr(res, "provider", "") == "heuristic" or \
            any(m.lower() in text.lower() for m in markers):
        return fallback, "offline"
    return text, "model"


# ===========================================================================
# 1. MEASURE
# ===========================================================================
@tool(
    name="text.count",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Count words, characters, sentences, paragraphs and estimate reading/speaking time",
    schema={"text": {"type": "string", "description": "the text to measure"},
            "path": {"type": "string", "description": "or a text file to measure"},
            "wpm_read": {"type": "integer", "default": 238},
            "wpm_speak": {"type": "integer", "default": 150}},
    risk="LOW",
    timeout=60,
)
async def text_count(ctx: ToolContext, text: str = "", path: str = "", wpm_read: int = 238,
                     wpm_speak: int = 150, request: str = "") -> Dict[str, Any]:
    body, err = await _source(text or request, path, ctx)
    if err:
        return err
    words = _words(body)
    sentences = _sentences(body)
    paragraphs = [p for p in re.split(r"\n\s*\n", body) if p.strip()]
    unique = {w.lower() for w in words}
    freq = Counter(w.lower() for w in words if w.lower() not in STOPWORDS)
    longest = max(words, key=len) if words else ""
    read_min = len(words) / max(int(wpm_read or 238), 1)
    speak_min = len(words) / max(int(wpm_speak or 150), 1)
    out = {
        "ok": True,
        "characters": len(body), "characters_no_spaces": len(re.sub(r"\s", "", body)),
        "words": len(words), "unique_words": len(unique),
        "sentences": len(sentences), "paragraphs": len(paragraphs),
        "lines": body.count("\n") + (1 if body else 0),
        "average_words_per_sentence": round(len(words) / len(sentences), 2) if sentences else 0,
        "average_word_length": round(sum(len(w) for w in words) / len(words), 2) if words else 0,
        "longest_word": longest, "longest_word_length": len(longest),
        "longest_sentence_words": max((len(_words(s)) for s in sentences), default=0),
        "reading_time_minutes": round(read_min, 2),
        "reading_time": f"{int(read_min)}m {int((read_min % 1) * 60):02d}s",
        "speaking_time_minutes": round(speak_min, 2),
        "speaking_time": f"{int(speak_min)}m {int((speak_min % 1) * 60):02d}s",
        "top_words": [{"word": w, "count": c} for w, c in freq.most_common(12)],
        "digits": sum(ch.isdigit() for ch in body),
        "uppercase_words": sum(1 for w in words if w.isupper() and len(w) > 1),
        "punctuation": sum(1 for ch in body if ch in ".,;:!?\"'()[]{}-—–"),
    }
    out["answer"] = (
        f"{out['words']:,} words · {out['characters']:,} characters "
        f"({out['characters_no_spaces']:,} without spaces) · {out['sentences']} sentences · "
        f"{out['paragraphs']} paragraphs.\n"
        f"Reading time {out['reading_time']} at {wpm_read} wpm; speaking time "
        f"{out['speaking_time']} at {wpm_speak} wpm.\n"
        f"Average sentence {out['average_words_per_sentence']} words; longest word "
        f"'{longest}' ({len(longest)} letters); {out['unique_words']:,} unique words.\n"
        f"Most used: " + (", ".join(f"{d['word']} ×{d['count']}" for d in out["top_words"][:6])
                          or "none"))
    return out


@tool(
    name="text.readability",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Readability scores: Flesch reading ease, Flesch-Kincaid grade, Gunning Fog, ARI, SMOG, Coleman-Liau",
    schema={"text": {"type": "string"}, "path": {"type": "string"}},
    risk="LOW",
    timeout=60,
)
async def text_readability(ctx: ToolContext, text: str = "", path: str = "",
                           request: str = "") -> Dict[str, Any]:
    body, err = await _source(text or request, path, ctx)
    if err:
        return err
    words = _words(body)
    sentences = _sentences(body)
    if len(words) < 20 or not sentences:
        return _bad("need at least ~20 words for a meaningful readability score",
                    words=len(words))
    w = len(words)
    s = len(sentences)
    syl = sum(_syllables(x) for x in words)
    complex_words = sum(1 for x in words if _syllables(x) >= 3)
    letters = sum(len(x) for x in words)
    flesch = 206.835 - 1.015 * (w / s) - 84.6 * (syl / w)
    fk_grade = 0.39 * (w / s) + 11.8 * (syl / w) - 15.59
    fog = 0.4 * ((w / s) + 100 * (complex_words / w))
    ari = 4.71 * (letters / w) + 0.5 * (w / s) - 21.43
    coleman = 0.0588 * (letters / w * 100) - 0.296 * (w / s * 100) / 100 - 15.8
    smog = 1.0430 * math.sqrt(complex_words * (30 / s)) + 3.1291 if s >= 30 else None

    def verdict(score: float) -> str:
        if score >= 90:
            return "very easy — a 5th grader could read this"
        if score >= 80:
            return "easy — conversational, plain language"
        if score >= 70:
            return "fairly easy — good for a general audience"
        if score >= 60:
            return "standard — plain English, 8th–9th grade"
        if score >= 50:
            return "fairly difficult — some readers will struggle"
        if score >= 30:
            return "difficult — academic or legal register"
        return "very difficult — rewrite it unless the audience is specialist"

    grade = round(fk_grade, 1)
    grade_note = ("primary school" if grade < 7 else "middle school" if grade < 10 else
                  "high school" if grade < 13 else "undergraduate" if grade < 17 else
                  "post-graduate / professional")
    out = {
        "ok": True,
        "flesch_reading_ease": round(flesch, 2), "verdict": verdict(flesch),
        "flesch_kincaid_grade": grade, "grade_level": grade_note,
        "gunning_fog": round(fog, 2), "ari": round(ari, 2),
        "coleman_liau": round(coleman, 2),
        "smog": round(smog, 2) if smog is not None else None,
        "words": w, "sentences": s, "syllables": syl, "complex_words": complex_words,
        "complex_word_percent": round(complex_words / w * 100, 1),
        "average_words_per_sentence": round(w / s, 1),
        "average_syllables_per_word": round(syl / w, 2),
        "long_sentences": [sn for sn in sentences if len(_words(sn)) > 30][:5],
    }
    out["answer"] = (
        f"Readability: Flesch {out['flesch_reading_ease']}/100 — {out['verdict']}.\n"
        f"Grade level {grade} ({grade_note}); Gunning Fog {out['gunning_fog']}, "
        f"ARI {out['ari']}, Coleman-Liau {out['coleman_liau']}"
        + (f", SMOG {out['smog']}" if out["smog"] else "") + ".\n"
        f"{w} words in {s} sentences ({out['average_words_per_sentence']} words each), "
        f"{out['complex_word_percent']}% complex words (3+ syllables).\n"
        + (f"To make it easier, break up sentences like: '{out['long_sentences'][0][:110]}…'"
           if out["long_sentences"] else
           "No sentence is over 30 words — the pacing is fine."))
    return out


@tool(
    name="text.sentiment",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Lexicon sentiment analysis: overall score, label, drivers and a per-sentence breakdown",
    schema={"text": {"type": "string"}, "path": {"type": "string"}},
    risk="LOW",
    timeout=60,
)
async def text_sentiment(ctx: ToolContext, text: str = "", path: str = "",
                         request: str = "") -> Dict[str, Any]:
    body, err = await _source(text or request, path, ctx)
    if err:
        return err
    tokens = [t.lower() for t in _tokens(body)]
    score = 0.0
    hits: List[Dict[str, Any]] = []
    for i, tok in enumerate(tokens):
        base = 1.0 if tok in POSITIVE else -1.0 if tok in NEGATIVE else 0.0
        if not base:
            continue
        mult = 1.0
        negated = False
        for j in range(max(0, i - 3), i):
            if tokens[j] in INTENSIFIERS:
                mult *= INTENSIFIERS[tokens[j]]
            if tokens[j] in NEGATORS:
                negated = True
        if negated:
            base = -base * 0.75
        score += base * mult
        hits.append({"word": tok, "polarity": round(base * mult, 2),
                     "negated": negated, "position": i})
    norm = max(1, len(tokens))
    scaled = max(-100.0, min(100.0, score / math.sqrt(norm) * 12))
    label = ("very positive" if scaled > 40 else "positive" if scaled > 12 else
             "slightly positive" if scaled > 4 else
             "neutral" if scaled >= -4 else "slightly negative" if scaled >= -12 else
             "negative" if scaled >= -40 else "very negative")
    sentences = _sentences(body)
    per_sentence = []
    for sn in sentences[:40]:
        toks = [t.lower() for t in _tokens(sn)]
        sub = sum((1.0 if t in POSITIVE else -1.0 if t in NEGATIVE else 0.0) for t in toks)
        per_sentence.append({"sentence": sn[:160], "score": round(sub, 2),
                             "label": ("positive" if sub > 0 else "negative" if sub < 0 else "neutral")})
    out = {
        "ok": True, "score": round(scaled, 1), "raw_score": round(score, 2), "label": label,
        "tokens": len(tokens), "positive_hits": sum(1 for h in hits if h["polarity"] > 0),
        "negative_hits": sum(1 for h in hits if h["polarity"] < 0),
        "drivers": sorted(hits, key=lambda h: -abs(h["polarity"]))[:12],
        "per_sentence": per_sentence,
        "engine": "lexicon",
        "note": "Keyword lexicon scoring: fast, local and honest about being shallow. It cannot "
                "read sarcasm, context or domain jargon — use it as a tilt, not a verdict.",
    }
    out["answer"] = (
        f"Sentiment: **{label}** ({scaled:+.1f}/100) over {len(tokens)} tokens — "
        f"{out['positive_hits']} positive vs {out['negative_hits']} negative words.\n"
        + ("Strongest signals: " + ", ".join(f"{h['word']} ({h['polarity']:+})"
                                            for h in out["drivers"][:6]) + ".\n"
           if out["drivers"] else "No sentiment-bearing words found.\n")
        + out["note"])
    return out


@tool(
    name="text.keywords",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Extract keywords, key phrases and an SEO meta description from text",
    schema={"text": {"type": "string"}, "path": {"type": "string"},
            "limit": {"type": "integer", "default": 15},
            "phrases": {"type": "boolean", "default": True},
            "meta_description": {"type": "boolean", "default": True}},
    risk="LOW",
    timeout=60,
)
async def text_keywords(ctx: ToolContext, text: str = "", path: str = "", limit: int = 15,
                        phrases: bool = True, meta_description: bool = True,
                        request: str = "") -> Dict[str, Any]:
    body, err = await _source(text or request, path, ctx)
    if err:
        return err
    n = max(1, min(int(limit), 50))
    tokens = [t.lower() for t in _words(body)]
    kept = [t for t in tokens if t not in STOPWORDS and len(t) > 2]
    freq = Counter(kept)
    total = max(1, len(kept))
    keywords = [{"keyword": w, "count": c, "density_percent": round(c / total * 100, 2)}
                for w, c in freq.most_common(n)]
    key_phrases: List[Dict[str, Any]] = []
    if phrases:
        bigrams = Counter(zip(kept, kept[1:]))
        trigrams = Counter(zip(kept, kept[1:], kept[2:]))
        for gram, counter, size in ((bigrams, bigrams, 2), (trigrams, trigrams, 3)):
            for combo, count in counter.most_common(n):
                if count < 2:
                    continue
                key_phrases.append({"phrase": " ".join(combo), "count": count, "words": size})
        key_phrases = sorted(key_phrases, key=lambda d: (-d["count"], -d["words"]))[:n]
    sentences = _sentences(body)
    top_words = {k["keyword"] for k in keywords[:6]}
    best = ""
    best_score = -1.0
    for sn in sentences[:60]:
        toks = {t.lower() for t in _words(sn)}
        overlap = len(toks & top_words)
        length_penalty = abs(len(sn) - 150) / 400
        sc = overlap * 2 - length_penalty + (1.0 if sentences and sn == sentences[0] else 0.0)
        if sc > best_score and 60 <= len(sn) <= 320:
            best_score, best = sc, sn
    meta = (best[:155].rstrip() + ("…" if len(best) > 155 else "")) if best else ""
    out = {
        "ok": True, "keywords": keywords, "key_phrases": key_phrases,
        "meta_description": meta if meta_description else "",
        "tokens": len(tokens), "unique_tokens": len(set(tokens)),
        "comma_separated": ", ".join(k["keyword"] for k in keywords),
    }
    out["answer"] = (
        f"Top keywords: " + ", ".join(f"{k['keyword']} ({k['count']}×, {k['density_percent']}%)"
                                      for k in keywords[:10]) + ".\n"
        + (f"Key phrases: " + ", ".join(f'"{p["phrase"]}" ×{p["count"]}'
                                        for p in key_phrases[:6]) + ".\n" if key_phrases else "")
        + (f"SEO meta description ({len(meta)} chars): {meta}" if meta else ""))
    return out


@tool(
    name="text.similarity",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Compare two texts: sequence ratio, Jaccard, cosine similarity and a duplicate verdict",
    schema={"text_a": {"type": "string", "required": True}, "text_b": {"type": "string", "required": True},
            "threshold": {"type": "number", "default": 0.85}},
    risk="LOW",
    timeout=90,
)
async def text_similarity(ctx: ToolContext, text_a: str = "", text_b: str = "",
                          threshold: float = 0.85, request: str = "") -> Dict[str, Any]:
    if not text_a.strip() or not text_b.strip():
        return _bad("give me two texts to compare (text_a and text_b)")
    a, b = text_a.strip(), text_b.strip()
    ta, tb = [t.lower() for t in _words(a)], [t.lower() for t in _words(b)]
    sa, sb = set(ta), set(tb)
    ratio = difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()
    word_ratio = difflib.SequenceMatcher(None, ta, tb).ratio()
    jaccard = len(sa & sb) / len(sa | sb) if (sa | sb) else 0.0
    ca, cb = Counter(ta), Counter(tb)
    common = set(ca) & set(cb)
    dot = sum(ca[w] * cb[w] for w in common)
    mag = math.sqrt(sum(v * v for v in ca.values())) * math.sqrt(sum(v * v for v in cb.values()))
    cosine = dot / mag if mag else 0.0
    overall = round((ratio + word_ratio + jaccard + cosine) / 4, 4)
    thr = float(threshold or 0.85)
    verdict = ("effectively the same text" if overall >= thr else
               "very similar — likely a rewrite or a copy with edits" if overall >= thr - 0.15 else
               "partially overlapping — they share material" if overall >= 0.4 else
               "different texts" if overall >= 0.15 else "unrelated")
    matches = difflib.SequenceMatcher(None, ta, tb).get_matching_blocks()
    shared = []
    for m in sorted(matches, key=lambda x: -x.size)[:6]:
        if m.size >= 4:
            shared.append(" ".join(ta[m.a:m.a + m.size]))
    out = {
        "ok": True, "sequence_ratio_characters": round(ratio, 4),
        "sequence_ratio_words": round(word_ratio, 4), "jaccard": round(jaccard, 4),
        "cosine": round(cosine, 4), "overall": overall, "threshold": thr, "verdict": verdict,
        "words_a": len(ta), "words_b": len(tb), "shared_unique_words": len(sa & sb),
        "only_in_a": sorted(sa - sb)[:20], "only_in_b": sorted(sb - sa)[:20],
        "longest_shared_runs": shared,
        "note": "Lexical similarity only — it detects copying and near-duplicates, not paraphrase "
                "of meaning. Two texts can say the same thing with different words.",
    }
    out["answer"] = (
        f"Similarity {overall * 100:.1f}% ⇒ {verdict}.\n"
        f"- character sequence ratio {ratio * 100:.1f}%\n"
        f"- word sequence ratio {word_ratio * 100:.1f}%\n"
        f"- Jaccard (shared vocabulary) {jaccard * 100:.1f}%\n"
        f"- cosine (word frequency) {cosine * 100:.1f}%\n"
        f"{len(sa & sb)} words in common; {len(sa - sb)} only in A, {len(sb - sa)} only in B.\n"
        + (f"Longest shared run: '{shared[0][:120]}'\n" if shared else "")
        + out["note"])
    return out


# ===========================================================================
# 2. TRANSFORM
# ===========================================================================
@tool(
    name="text.case",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Convert text between snake_case, camelCase, PascalCase, kebab-case, CONSTANT_CASE, Title Case, Sentence case, UPPER and lower",
    schema={"text": {"type": "string", "required": True},
            "to": {"type": "string", "required": True,
                   "description": "snake | camel | pascal | kebab | constant | title | sentence | "
                                  "upper | lower | dot | path | slug"}},
    risk="LOW",
    timeout=30,
)
async def text_case(ctx: ToolContext, text: str = "", to: str = "snake",
                    request: str = "") -> Dict[str, Any]:
    body = (text or request or "").strip()
    if not body:
        return _bad("give me the text to convert")
    kind = (to or "snake").strip().lower().replace("-", "_").replace(" ", "_")
    parts = [p for p in re.split(r"[\s_\-./]+|(?<=[a-z0-9])(?=[A-Z])", body) if p]
    low = [p.lower() for p in parts]
    variants = {
        "snake": "_".join(low),
        "camel": (low[0] + "".join(p.capitalize() for p in low[1:])) if low else "",
        "pascal": "".join(p.capitalize() for p in low),
        "kebab": "-".join(low),
        "constant": "_".join(p.upper() for p in low),
        "title": " ".join(p.capitalize() for p in low),
        "sentence": (" ".join(low)[:1].upper() + " ".join(low)[1:]) if low else "",
        "upper": body.upper(),
        "lower": body.lower(),
        "dot": ".".join(low),
        "path": "/".join(low),
        "slug": _slugify(body),
        "alternating": "".join(c.upper() if i % 2 else c.lower() for i, c in enumerate(body)),
        "inverse": body.swapcase(),
    }
    if kind not in variants:
        return _bad(f"unknown case '{to}'. Available: {', '.join(sorted(variants))}")
    converted = variants[kind]
    out = {"ok": True, "from_text": body[:400], "case": kind, "text": converted,
           "words": len(parts),
           "all_variants": variants}
    out["answer"] = f"{kind}: `{converted}`"
    return out


def _slugify(text: str, max_len: int = 80) -> str:
    t = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode()
    t = re.sub(r"[^\w\s-]", "", t.lower())
    t = re.sub(r"[\s_-]+", "-", t).strip("-")
    return t[:max_len].rstrip("-")


@tool(
    name="text.slug",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Make a URL-safe slug from a title (ASCII-folds, strips punctuation, limits length)",
    schema={"text": {"type": "string", "required": True},
            "max_length": {"type": "integer", "default": 80},
            "separator": {"type": "string", "default": "-"}},
    risk="LOW",
    timeout=30,
)
async def text_slug(ctx: ToolContext, text: str = "", max_length: int = 80, separator: str = "-",
                    request: str = "") -> Dict[str, Any]:
    body = (text or request or "").strip()
    if not body:
        return _bad("give me the title to slugify")
    slug = _slugify(body, int(max_length or 80))
    if separator and separator != "-":
        slug = slug.replace("-", separator)
    out = {"ok": True, "slug": slug, "length": len(slug), "input": body[:200],
           "suggestions": [slug] + [f"{slug}-{i}" for i in range(2, 5)]}
    out["answer"] = f"Slug: `{slug}` ({len(slug)} chars)"
    return out


@tool(
    name="text.title",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Proper English title case: small words stay lower-case unless they open or close the title",
    schema={"text": {"type": "string", "required": True}, "style": {"type": "string", "default": "apa"}},
    risk="LOW",
    timeout=30,
)
async def text_title(ctx: ToolContext, text: str = "", style: str = "apa",
                     request: str = "") -> Dict[str, Any]:
    body = (text or request or "").strip()
    if not body:
        return _bad("give me the heading to fix")
    small = {"a", "an", "and", "as", "at", "but", "by", "for", "from", "in", "into", "nor", "of",
             "off", "on", "onto", "or", "over", "per", "the", "to", "up", "upon", "via", "vs",
             "with", "yet"}
    if (style or "apa").lower().startswith("chicago"):
        small |= {"about", "across", "after", "against", "along", "among", "around", "before",
                  "behind", "below", "beneath", "beside", "between", "beyond", "during", "except"}
    words = body.split()
    out_words: List[str] = []
    for i, w in enumerate(words):
        core = re.sub(r"[^\w]", "", w)
        keep = w
        if core.lower() in small and 0 < i < len(words) - 1 and len(core) <= 4:
            keep = re.sub(core, core.lower(), w, count=1)
        elif core.upper() in ACRONYMS:
            keep = re.sub(core, core.upper(), w, count=1)   # ai → AI, url → URL
        elif core and core.isupper() and len(core) <= 5 and core not in ("A", "I"):
            keep = w                                   # leave acronyms alone (NASA, RBI, USD)
        elif "-" in core:
            keep = "-".join(p.capitalize() if p.lower() not in small else p.lower()
                            for p in w.split("-"))
        else:
            keep = w[:1].upper() + w[1:].lower() if w.islower() or w.isupper() else w
        out_words.append(keep)
    titled = " ".join(out_words)
    return {"ok": True, "title": titled, "style": (style or "apa").lower(),
            "small_words": sorted(small)[:14], "answer": f"Title case ({style}): {titled}"}


@tool(
    name="text.lines",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Line tools: sort, dedupe, trim, number, reverse, filter by pattern, take head/tail",
    schema={"text": {"type": "string", "required": True},
            "operation": {"type": "string", "required": True,
                          "description": "dedupe | sort | sort_desc | reverse | number | trim | "
                                         "filter_in | filter_out | head | tail | shuffle | "
                                         "remove_empty | wrap | unwrap"},
            "pattern": {"type": "string", "description": "regex for filter_in / filter_out"},
            "limit": {"type": "integer", "default": 10},
            "wrap_width": {"type": "integer", "default": 80}},
    risk="LOW",
    timeout=60,
)
async def text_lines(ctx: ToolContext, text: str = "", operation: str = "dedupe", pattern: str = "",
                     limit: int = 10, wrap_width: int = 80, request: str = "") -> Dict[str, Any]:
    body = text or request or ""
    if not body.strip():
        return _bad("give me the text to work on")
    op = (operation or "dedupe").strip().lower()
    lines = body.splitlines()
    original_count = len(lines)
    if op == "dedupe":
        seen: set = set()
        result = [l for l in lines if not (l in seen or seen.add(l))]
    elif op == "sort":
        result = sorted(lines, key=lambda l: l.strip().lower())
    elif op == "sort_desc":
        result = sorted(lines, key=lambda l: l.strip().lower(), reverse=True)
    elif op == "reverse":
        result = list(reversed(lines))
    elif op == "number":
        width = max(2, len(str(len(lines))))
        result = [f"{i + 1:>{width}}. {l}" for i, l in enumerate(lines)]
    elif op == "trim":
        result = [l.strip() for l in lines]
    elif op == "remove_empty":
        result = [l for l in lines if l.strip()]
    elif op in ("filter_in", "filter_out"):
        if not pattern:
            return _bad(f"{op} needs a 'pattern' (a regular expression)")
        try:
            rx = re.compile(pattern, re.I)
        except re.error as exc:
            return _bad(f"invalid regex: {exc}")
        keep = op == "filter_in"
        result = [l for l in lines if bool(rx.search(l)) == keep]
    elif op in ("head", "tail"):
        n = max(1, int(limit or 10))
        result = lines[:n] if op == "head" else lines[-n:]
    elif op == "shuffle":
        import random
        result = lines[:]
        random.shuffle(result)
    elif op == "wrap":
        import textwrap
        result = []
        for l in lines:
            result.extend(textwrap.wrap(l, max(20, int(wrap_width or 80))) or [""])
    elif op == "unwrap":
        result = [" ".join(l.split()) for l in re.split(r"\n\s*\n", body)]
    else:
        return _bad(f"unknown operation '{operation}'. Try dedupe, sort, reverse, number, trim, "
                    f"filter_in, filter_out, head, tail, shuffle, remove_empty, wrap, unwrap")
    text_out = "\n".join(result)
    out = {"ok": True, "operation": op, "text": text_out, "lines_in": original_count,
           "lines_out": len(result), "removed": original_count - len(result),
           "pattern": pattern or None}
    out["answer"] = (f"{op}: {original_count} line(s) → {len(result)}"
                     + (f" ({out['removed']} removed)" if out["removed"] else "")
                     + f"\n{text_out[:1500]}")
    return out


@tool(
    name="text.diff",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Diff two texts or files: unified patch, word-level changes and a change summary",
    schema={"text_a": {"type": "string"}, "text_b": {"type": "string"},
            "path_a": {"type": "string"}, "path_b": {"type": "string"},
            "mode": {"type": "string", "default": "unified",
                     "description": "unified | words | side_by_side | summary"},
            "context_lines": {"type": "integer", "default": 3}},
    risk="LOW",
    timeout=90,
)
async def text_diff(ctx: ToolContext, text_a: str = "", text_b: str = "", path_a: str = "",
                    path_b: str = "", mode: str = "unified", context_lines: int = 3,
                    request: str = "") -> Dict[str, Any]:
    a, err = await _source(text_a, path_a, ctx)
    if err:
        return err
    b, err = await _source(text_b, path_b, ctx)
    if err:
        return err
    mode = (mode or "unified").lower()
    la, lb = a.splitlines(), b.splitlines()
    added = [l for l in lb if l not in set(la)]
    removed = [l for l in la if l not in set(lb)]
    if mode == "words":
        sm = difflib.SequenceMatcher(None, _words(a), _words(b))
        changes = []
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "equal":
                continue
            changes.append({"change": tag,
                            "from": " ".join(_words(a)[i1:i2])[:200],
                            "to": " ".join(_words(b)[j1:j2])[:200]})
        body = "\n".join(f"{c['change']}: '{c['from']}' → '{c['to']}'" for c in changes) or \
            "the two texts use the same words"
        return {"ok": True, "mode": "words", "changes": changes, "text": body,
                "added_lines": len(added), "removed_lines": len(removed),
                "answer": f"Word-level diff: {len(changes)} change(s), {len(added)} line(s) added, "
                          f"{len(removed)} removed.\n{body[:1500]}"}
    if mode == "side_by_side":
        rows = list(difflib.ndiff(la, lb))
        body = "\n".join(rows[:400])
        return {"ok": True, "mode": "side_by_side", "text": body, "rows": len(rows),
                "added_lines": len(added), "removed_lines": len(removed),
                "answer": f"Side-by-side diff ({len(rows)} rows):\n```diff\n{body[:1500]}\n```"}
    patch = "\n".join(difflib.unified_diff(la, lb, fromfile=(path_a or "a"), tofile=(path_b or "b"),
                                           n=max(0, int(context_lines or 3)), lineterm=""))
    ratio = difflib.SequenceMatcher(None, a, b).ratio()
    if mode == "summary":
        body = (f"{len(added)} line(s) added, {len(removed)} removed, "
                f"{ratio * 100:.1f}% identical")
    else:
        body = patch or "no differences"
    out = {"ok": True, "mode": mode, "text": body, "added_lines": len(added),
           "removed_lines": len(removed), "identical_percent": round(ratio * 100, 2),
           "lines_a": len(la), "lines_b": len(lb), "added_sample": added[:20],
           "removed_sample": removed[:20]}
    out["answer"] = (f"Diff: {len(added)} added, {len(removed)} removed, "
                     f"{ratio * 100:.1f}% identical ({len(la)} → {len(lb)} lines).\n"
                     f"```diff\n{body[:2000]}\n```" if mode != "summary" else body)
    return out


@tool(
    name="text.template",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Render {{placeholders}} in a template from a JSON mapping; lists every missing key",
    schema={"template": {"type": "string", "required": True},
            "values": {"type": "object", "description": "JSON object of placeholder → value"},
            "values_json": {"type": "string", "description": "or the same thing as a JSON string"},
            "missing_placeholder": {"type": "string", "default": "[missing]"}},
    risk="LOW",
    timeout=30,
)
async def text_template(ctx: ToolContext, template: str = "", values: Optional[Dict[str, Any]] = None,
                        values_json: str = "", missing_placeholder: str = "[missing]",
                        request: str = "") -> Dict[str, Any]:
    body = template or request or ""
    if not body.strip():
        return _bad("give me a template with {{placeholders}}")
    data: Dict[str, Any] = dict(values or {})
    if values_json:
        try:
            loaded = json.loads(values_json)
            if isinstance(loaded, dict):
                data.update(loaded)
        except json.JSONDecodeError as exc:
            return _bad(f"values_json is not valid JSON: {exc}")
    today = datetime.now()
    auto = {"date": today.strftime("%Y-%m-%d"), "time": today.strftime("%H:%M"),
            "year": str(today.year), "today": today.strftime("%Y-%m-%d"),
            "now": today.strftime("%H:%M"), "timestamp": str(int(today.timestamp()))}
    found = sorted(set(re.findall(r"\{\{\s*([\w.\-]+)\s*\}\}", body)))
    missing = [k for k in found if k not in data and k not in auto]

    def repl(m: "re.Match[str]") -> str:
        key = m.group(1).strip()
        if key in data:
            return str(data[key])
        if key in auto:
            return auto[key]
        return missing_placeholder or ""

    rendered = re.sub(r"\{\{\s*([\w.\-]+)\s*\}\}", repl, body)
    out = {"ok": True, "text": rendered, "placeholders": found, "provided": sorted(data),
           "missing": missing, "filled": len(found) - len(missing),
           "auto_filled": sorted(k for k in found if k in auto and k not in data),
           "note": "{{date}}, {{time}}, {{today}}, {{now}}, {{year}} and {{timestamp}} fill "
                   "themselves from the system clock"}
    out["answer"] = (f"Rendered {len(found)} placeholder(s)"
                     + (f"; missing: {', '.join(missing)}" if missing else "; all filled")
                     + f"\n\n{rendered[:2000]}")
    return out


@tool(
    name="text.table",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Build a table (Markdown, CSV, HTML or JSON) from delimited text or a JSON list of rows",
    schema={"rows_json": {"type": "string", "description": 'JSON list of objects, e.g. [{"a":1}]'},
            "text": {"type": "string", "description": "or delimited rows"},
            "delimiter": {"type": "string", "default": ","},
            "format": {"type": "string", "default": "markdown",
                       "description": "markdown | csv | html | json | text"},
            "has_header": {"type": "boolean", "default": True},
            "sort_by": {"type": "string", "description": "column name to sort by"},
            "descending": {"type": "boolean", "default": False},
            "limit": {"type": "integer", "default": 0}},
    risk="LOW",
    timeout=60,
)
async def text_table(ctx: ToolContext, rows_json: str = "", text: str = "", delimiter: str = ",",
                     format: str = "markdown", has_header: bool = True, sort_by: str = "",
                     descending: bool = False, limit: int = 0,
                     request: str = "") -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    if rows_json:
        try:
            loaded = json.loads(rows_json)
        except json.JSONDecodeError as exc:
            return _bad(f"rows_json is not valid JSON: {exc}")
        if isinstance(loaded, dict):
            loaded = loaded.get("rows") or loaded.get("data") or [loaded]
        if not isinstance(loaded, list):
            return _bad("rows_json must be a JSON list of objects")
        for item in loaded:
            rows.append(item if isinstance(item, dict) else {"value": item})
    elif (text or request).strip():
        sep = delimiter or ","
        if sep == "\\t":
            sep = "\t"
        lines = [l for l in (text or request).splitlines() if l.strip()]
        if lines and has_header:
            header = [c.strip() for c in lines[0].split(sep)]
            for line in lines[1:]:
                cells = [c.strip() for c in line.split(sep)]
                rows.append({header[i]: (cells[i] if i < len(cells) else "")
                             for i in range(len(header))})
        else:
            for i, line in enumerate(lines):
                cells = [c.strip() for c in line.split(sep)]
                rows.append({f"col{j + 1}": c for j, c in enumerate(cells)})
    if not rows:
        return _bad("no rows to build a table from — pass rows_json or delimited text")
    columns: List[str] = []
    for r in rows:
        for k in r:
            if k not in columns:
                columns.append(k)
    if sort_by and sort_by in columns:
        def key(r: Dict[str, Any]) -> Any:
            v = r.get(sort_by, "")
            try:
                return (0, float(v))
            except (TypeError, ValueError):
                return (1, str(v))
        rows = sorted(rows, key=key, reverse=bool(descending))
    total = len(rows)
    if limit and int(limit) > 0:
        rows = rows[:int(limit)]
    fmt = (format or "markdown").lower()
    if fmt == "json":
        body = json.dumps(rows, indent=2, default=str)
    elif fmt == "csv":
        import csv
        import io
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
        body = buf.getvalue().strip()
    elif fmt == "html":
        head = "".join(f"<th>{html_lib.escape(str(c))}</th>" for c in columns)
        body_rows = "".join("<tr>" + "".join(
            f"<td>{html_lib.escape(str(r.get(c, '')))}</td>" for c in columns) + "</tr>"
            for r in rows)
        body = f'<table border="1" cellpadding="4"><thead><tr>{head}</tr></thead>' \
               f"<tbody>{body_rows}</tbody></table>"
    elif fmt == "text":
        widths = {c: max(len(str(c)), *(len(str(r.get(c, ""))) for r in rows)) for c in columns}
        line = "  ".join(str(c).ljust(widths[c]) for c in columns)
        body = "\n".join([line, "  ".join("-" * widths[c] for c in columns)]
                         + ["  ".join(str(r.get(c, "")).ljust(widths[c]) for c in columns)
                            for r in rows])
    else:
        header = "| " + " | ".join(str(c) for c in columns) + " |"
        sep_row = "| " + " | ".join("---" for _ in columns) + " |"
        body = "\n".join([header, sep_row]
                         + ["| " + " | ".join(str(r.get(c, "")).replace("|", "\\|")
                                              for c in columns) + " |" for r in rows])
    out = {"ok": True, "format": fmt, "text": body, "columns": columns, "rows": total,
           "rows_shown": len(rows), "sorted_by": sort_by or None, "descending": bool(descending)}
    out["answer"] = f"{fmt.upper()} table — {total} row(s), {len(columns)} column(s)" \
                    + (f", showing {len(rows)}" if len(rows) != total else "") + f":\n\n{body[:2500]}"
    return out


@tool(
    name="text.redact",
    capability="text.transform",
    agent="security",
    device="both",
    description="Mask PII before sharing text: emails, phone numbers, cards, IPs, URLs and custom names",
    schema={"text": {"type": "string", "required": True},
            "mask_char": {"type": "string", "default": "*"},
            "keep_edges": {"type": "integer", "default": 2,
                           "description": "characters kept visible at each end (0 = full mask)"},
            "names": {"type": "string", "description": "comma separated names to mask"},
            "targets": {"type": "string",
                        "description": "comma list of: email,phone,card,ip,url,name,number; "
                                       "default all"}},
    risk="LOW",
    timeout=60,
)
async def text_redact(ctx: ToolContext, text: str = "", mask_char: str = "*", keep_edges: int = 2,
                      names: str = "", targets: str = "", request: str = "") -> Dict[str, Any]:
    body = text or request or ""
    if not body.strip():
        return _bad("give me the text to redact")
    ch = (mask_char or "*")[:1]
    keep = max(0, int(keep_edges or 0))
    wanted = {t.strip().lower() for t in (targets or "").split(",") if t.strip()} or \
        {"email", "phone", "card", "ip", "url", "name", "number"}
    found: Dict[str, List[str]] = {}

    def mask(value: str) -> str:
        if keep and len(value) > keep * 2 + 1:
            return value[:keep] + ch * (len(value) - keep * 2) + value[-keep:]
        return ch * max(len(value), 3)

    patterns: List[Tuple[str, str]] = [
        ("email", r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"),
        ("card", r"\b(?:\d[ \-]?){13,19}\b"),
        ("phone", r"(?<![\w.])(?:\+?\d{1,3}[ \-]?)?(?:\(\d{2,4}\)[ \-]?)?\d{3,5}[ \-]?\d{4}"
                  r"(?:[ \-]?\d{2,4})?(?![\w.])"),
        ("ip", r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
        ("url", r"\bhttps?://[^\s<>\"')]+"),
    ]
    out_text = body
    for kind, rx in patterns:
        if kind not in wanted:
            continue
        hits = []

        def repl(m: "re.Match[str]", kind: str = kind, hits: List[str] = hits) -> str:
            val = m.group(0)
            if kind == "card" and len(re.sub(r"\D", "", val)) < 13:
                return val
            if kind == "phone" and len(re.sub(r"\D", "", val)) < 8:
                return val
            hits.append(val)
            return mask(val)

        out_text = re.sub(rx, repl, out_text)
        if hits:
            found[kind] = sorted(set(hits))[:20]
    name_list = [n.strip() for n in (names or "").split(",") if n.strip()]
    if name_list and "name" in wanted:
        hits = []
        for nm in name_list:
            if nm.lower() in out_text.lower():
                hits.append(nm)
                out_text = re.sub(re.escape(nm), mask(nm), out_text, flags=re.I)
        if hits:
            found["name"] = hits
    if "number" in wanted and name_list is not None:
        pass                                                    # numbers are covered by card/phone
    total = sum(len(v) for v in found.values())
    out = {"ok": True, "text": out_text, "redacted_count": total, "found": found,
           "kept_edges": keep, "mask_char": ch,
           "note": "Redaction is pattern-based: it catches the common shapes of PII, not every "
                   "possible one. Read the output before you share it."}
    out["answer"] = (f"Redacted {total} item(s)"
                     + (": " + ", ".join(f"{k} ×{len(v)}" for k, v in found.items()) if found
                        else " — nothing that looked like PII was found")
                     + f"\n\n{out_text[:2000]}\n\n_{out['note']}_")
    return out


# ===========================================================================
# 3. GENERATE / EDIT
# ===========================================================================
@tool(
    name="text.summarise",
    capability="text.generate",
    agent="writing",
    device="both",
    description="Summarise text: ranked-sentence extractive summary offline, or a model-written one when a provider is configured",
    schema={"text": {"type": "string"}, "path": {"type": "string"},
            "max_sentences": {"type": "integer", "default": 5},
            "method": {"type": "string", "default": "auto",
                       "description": "auto | extractive | model"},
            "style": {"type": "string", "default": "neutral",
                      "description": "neutral | bullets | executive | simple | technical"}},
    risk="LOW",
    timeout=180,
)
async def text_summarise(ctx: ToolContext, text: str = "", path: str = "", max_sentences: int = 5,
                         method: str = "auto", style: str = "neutral",
                         request: str = "") -> Dict[str, Any]:
    body, err = await _source(text or request, path, ctx)
    if err:
        return err
    if len(body.split()) < 25:
        return _bad("that text is already short — nothing to summarise", words=len(body.split()))
    n = max(1, min(int(max_sentences or 5), 20))
    sentences = _sentences(body)
    freq = Counter(w.lower() for w in _words(body) if w.lower() not in STOPWORDS and len(w) > 2)
    top = max(freq.values()) if freq else 1
    scored = []
    for i, sn in enumerate(sentences):
        toks = [t.lower() for t in _words(sn) if t.lower() in freq]
        if not toks:
            continue
        score = sum(freq[t] / top for t in toks) / math.sqrt(len(toks))
        if i == 0:
            score *= 1.25                                        # the lead carries the topic
        if i == len(sentences) - 1:
            score *= 1.05
        if 8 <= len(toks) <= 40:
            score *= 1.1
        scored.append({"index": i, "sentence": sn, "score": round(score, 3)})
    picked = sorted(scored, key=lambda d: -d["score"])[:n]
    picked.sort(key=lambda d: d["index"])
    extractive = " ".join(p["sentence"] for p in picked)
    ratio = round(len(extractive.split()) / max(1, len(body.split())) * 100, 1)

    want_model = method == "model" or (method == "auto" and style != "extractive")
    summary, engine = extractive, "extractive"
    if want_model:
        style_hint = {"bullets": "as 4-6 bullet points",
                      "executive": "as a 3-sentence executive brief a manager can act on",
                      "simple": "in plain words a 12-year-old would follow",
                      "technical": "keeping the technical detail and the numbers",
                      }.get(style, "as a tight neutral summary")
        prompt = (f"Summarise the text below {style_hint}. Keep every number, name and date that "
                  f"matters. Do not add anything that is not in the text. Maximum {n * 2} "
                  f"sentences.\n\nTEXT:\n{body[:24000]}")
        summary, engine = await _model_text(prompt, "You are SAM's writing brain: precise, "
                                                    "faithful to the source, never invents facts.",
                                            extractive, max_tokens=900)
    out = {
        "ok": True, "summary": summary, "engine": engine, "method": method, "style": style,
        "source_words": len(body.split()), "summary_words": len(summary.split()),
        "compression_percent": ratio, "sentences_used": len(picked),
        "ranked_sentences": picked, "key_points": [p["sentence"] for p in picked],
        "note": ("model-written" if engine == "model" else
                 "extractive (ranked sentences from the source, so every word is original)"),
    }
    out["answer"] = (f"Summary ({engine}, {out['summary_words']} of {out['source_words']} words, "
                     f"{ratio}% of the original):\n\n{summary}")
    return out


@tool(
    name="text.rewrite",
    capability="text.generate",
    agent="writing",
    device="both",
    description="Rewrite text in another tone, length or voice (model-written, with a deterministic offline pass)",
    schema={"text": {"type": "string", "required": True},
            "tone": {"type": "string", "default": "professional",
                     "description": "professional | casual | friendly | persuasive | formal | "
                                    "empathetic | confident | neutral"},
            "length": {"type": "string", "default": "same",
                       "description": "same | shorter | longer | half | double | one_sentence"},
            "audience": {"type": "string", "default": "",
                         "description": "e.g. 'a busy CFO', 'teenagers', 'engineers'"},
            "instructions": {"type": "string", "default": ""},
            "keep_numbers": {"type": "boolean", "default": True}},
    risk="LOW",
    timeout=180,
)
async def text_rewrite(ctx: ToolContext, text: str = "", tone: str = "professional",
                       length: str = "same", audience: str = "", instructions: str = "",
                       keep_numbers: bool = True, request: str = "") -> Dict[str, Any]:
    body = (text or request or "").strip()
    if not body:
        return _bad("give me the text to rewrite")
    tone = (tone or "professional").lower()
    length = (length or "same").lower()

    # ---- deterministic offline pass: always available, never invents facts --
    sentences = _sentences(body)
    hedging = ["just", "actually", "basically", "simply", "really", "very", "quite", "maybe",
               "possibly", "somewhat", "kind of", "sort of", "I think", "I believe"]
    offline = []
    for sn in sentences:
        fixed = re.sub(r"\s{2,}", " ", sn).strip()
        if tone in ("professional", "formal", "confident"):
            for h in hedging:
                fixed = re.sub(rf"\b{re.escape(h)}\b\s*", "", fixed, flags=re.I)
            fixed = re.sub(r"\bcontractions?\b", "contraction", fixed)
            fixed = re.sub(r"\bgonna\b", "going to", fixed, flags=re.I)
            fixed = re.sub(r"\bwanna\b", "want to", fixed, flags=re.I)
            fixed = re.sub(r"\byeah\b", "yes", fixed, flags=re.I)
            fixed = re.sub(r"\bok\b", "acceptable", fixed, flags=re.I)
            fixed = re.sub(r"\b!\s*$", ".", fixed)
        if tone == "casual":
            fixed = re.sub(r"\bdo not\b", "don't", fixed, flags=re.I)
            fixed = re.sub(r"\bcannot\b", "can't", fixed, flags=re.I)
            fixed = re.sub(r"\bhowever\b", "but", fixed, flags=re.I)
            fixed = re.sub(r"\butilize\b", "use", fixed, flags=re.I)
        if tone in ("concise",) or length in ("shorter", "half", "one_sentence"):
            fixed = re.sub(r"\b(in order to)\b", "to", fixed, flags=re.I)
            fixed = re.sub(r"\bdue to the fact that\b", "because", fixed, flags=re.I)
            fixed = re.sub(r"\bat this point in time\b", "now", fixed, flags=re.I)
            fixed = re.sub(r"\bin the event that\b", "if", fixed, flags=re.I)
        for rx, repl in COMMON_FIXES:                 # spelling/wording the rules know
            fixed = re.sub(rx, repl, fixed, flags=re.I)
        fixed = re.sub(r"\s+([,.;:!?])", r"\1", fixed)          # space before punctuation
        fixed = re.sub(r",\s*\.", ".", fixed)                  # ", ." left by a removed hedge
        fixed = re.sub(r"\.\s*\.", ".", fixed)
        fixed = re.sub(r",{2,}", ",", fixed)
        fixed = re.sub(r"^\s*[,;.]\s*", "", fixed)             # dangling opener
        fixed = re.sub(r"\s{2,}", " ", fixed).strip()
        fixed = fixed[:1].upper() + fixed[1:] if fixed else fixed
        if fixed and len(_words(fixed)) >= 1:
            offline.append(fixed)
    if length in ("shorter", "half"):
        keep = max(1, len(offline) // 2)
        offline = offline[:keep]
    elif length == "one_sentence":
        offline = offline[:1]
    elif length in ("longer", "double"):
        offline = offline + ["In short: " + s for s in offline[:max(1, len(offline) // 2)]]
    fallback = " ".join(offline) or body

    length_hint = {"shorter": "about half the length", "half": "about half the length",
                   "longer": "roughly twice as long, adding only what the source supports",
                   "double": "roughly twice as long, adding only what the source supports",
                   "one_sentence": "as ONE clear sentence",
                   "same": "about the same length"}.get(length, "about the same length")
    prompt = (
        f"Rewrite the text below.\n"
        f"TONE: {tone}\nLENGTH: {length_hint}\n"
        + (f"AUDIENCE: {audience}\n" if audience else "")
        + (f"EXTRA INSTRUCTIONS: {instructions}\n" if instructions else "")
        + ("RULE: keep every number, name, date and factual claim exactly as given. Do not add "
           "facts. Do not use em dashes or marketing clichés. Return only the rewritten text.\n\n"
           if keep_numbers else "")
        + f"TEXT:\n{body[:20000]}")
    rewritten, engine = await _model_text(prompt, "You are SAM's writing brain. You rewrite "
                                                  "faithfully: same facts, better delivery.",
                                          fallback, max_tokens=1200, temperature=0.6)
    out = {"ok": True, "text": rewritten, "engine": engine, "tone": tone, "length": length,
           "audience": audience or None, "instructions": instructions or None,
           "original_words": len(_words(body)), "rewritten_words": len(_words(rewritten)),
           "offline_version": fallback,
           "note": ("written by the configured language model" if engine == "model" else
                    "no language model is configured, so this is SAM's rule-based edit — it fixes "
                    "hedges, spacing, punctuation and length, but it cannot restyle prose. "
                    "Add a model key to .env for a real rewrite.")}
    out["answer"] = (f"Rewrite ({tone}, {length}, {engine} engine) — "
                     f"{out['rewritten_words']} words from {out['original_words']}:\n\n{rewritten}\n\n"
                     f"_{out['note']}_")
    return out


@tool(
    name="text.grammar",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Rule-based grammar and style check: corrections, explanations and a clean version",
    schema={"text": {"type": "string", "required": True},
            "apply": {"type": "boolean", "default": True,
                      "description": "false = report only, do not rewrite"},
            "strict": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=90,
)
async def text_grammar(ctx: ToolContext, text: str = "", apply: bool = True, strict: bool = False,
                       request: str = "") -> Dict[str, Any]:
    body = text or request or ""
    if not body.strip():
        return _bad("give me the text to check")
    issues: List[Dict[str, Any]] = []
    fixed = body

    def note(rule: str, message: str, before: str = "", after: str = "", severity: str = "style") -> None:
        issues.append({"rule": rule, "message": message, "before": before[:120],
                       "after": after[:120], "severity": severity})

    # repeated words: "the the"
    for m in re.finditer(r"\b(\w+)\s+\1\b", fixed, flags=re.I):
        if m.group(1).lower() in ("had", "that"):
            continue
        note("repeated_word", f"'{m.group(1)}' is repeated", m.group(0), m.group(1), "error")
    fixed = re.sub(r"\b(\w+)(\s+\1\b)+", r"\1", fixed, flags=re.I)

    # spacing around punctuation
    if re.search(r"\s+[,.;:!?]", fixed):
        note("punctuation_spacing", "space before punctuation removed", " ,", ",", "error")
        fixed = re.sub(r"\s+([,.;:!?])", r"\1", fixed)
    if re.search(r"[,;:]\w", fixed):
        note("punctuation_spacing", "missing space after punctuation", ",word", ", word", "error")
        fixed = re.sub(r"([,;:])(?=\w)", r"\1 ", fixed)
    if "  " in re.sub(r"\n\s*\n", "\n\n", fixed):
        note("double_space", "collapsed double spaces", "a  b", "a b", "style")
        fixed = re.sub(r"[^\S\n]{2,}", " ", fixed)

    # capitalisation after a full stop
    def cap_after_period(m: "re.Match[str]") -> str:
        return m.group(1) + m.group(2).upper()
    if re.search(r"[.!?]\s+[a-z]", fixed):
        note("sentence_capital", "capitalised the first letter of each sentence", ". the", ". The",
             "error")
        fixed = re.sub(r"([.!?]\s+)([a-z])", cap_after_period, fixed)

    # a / an
    for m in re.finditer(r"\b(a)\s+([aeiouAEIOU]\w+)", fixed):
        word = m.group(2)
        if not re.match(r"(?i)^(eu|uni|one|once|useful|used|user)", word):
            note("article", f"'a {word}' → 'an {word}'", m.group(0), f"an {word}", "error")
    fixed = re.sub(r"\ba\s+(?!(?:eu|uni|one|once|useful|used|user))([aeiouAEIOU]\w+)",
                   r"an \1", fixed)
    for m in re.finditer(r"\b(an)\s+([^aeiouAEIOU\s]\w+)", fixed):
        note("article", f"'an {m.group(2)}' → 'a {m.group(2)}'", m.group(0), f"a {m.group(2)}",
             "error")
    fixed = re.sub(r"\ban\s+([^aeiouAEIOU\s]\w+)", r"a \1", fixed)

    # the curated correction table
    for rx, repl in COMMON_FIXES:
        for m in re.finditer(rx, fixed, flags=re.I):
            note("wording", f"'{m.group(0)}' → '{repl}'", m.group(0), repl, "error")
        fixed = re.sub(rx, repl, fixed, flags=re.I)

    # contractions in formal text, passive voice, long sentences (strict only)
    if strict:
        for m in re.finditer(r"\b(\w+n't|\w+'ll|\w+'re|\w+'ve|\w+'s)\b", fixed):
            note("formal_contractions", f"consider expanding '{m.group(0)}' in formal writing",
                 m.group(0), "", "style")
        for m in re.finditer(r"\b(?:is|are|was|were|be|been)\s+(\w+ed|\w+en)\b", fixed):
            note("passive_voice", f"possible passive voice: '{m.group(0)}'", m.group(0), "",
                 "style")
        for sn in _sentences(fixed):
            if len(_words(sn)) > 35:
                note("long_sentence", f"{len(_words(sn))}-word sentence — consider splitting",
                     sn[:100], "", "style")
        for m in re.finditer(r"\b(?:very|really|extremely|totally|absolutely)\b", fixed,
                             flags=re.I):
            note("intensifier", f"'{m.group(0)}' adds little — use a stronger word",
                 m.group(0), "", "style")
    errors = sum(1 for i in issues if i["severity"] == "error")
    styles = len(issues) - errors
    if not apply:
        fixed = body
    out = {"ok": True, "text": fixed, "changed": fixed != body, "issues": issues,
           "error_count": errors, "style_count": styles, "applied": bool(apply),
           "strict": bool(strict), "words": len(_words(body)),
           "note": "SAM applies spelling, spacing, capitalisation, article and repeated-word "
                   "fixes with rules — it never rewrites meaning. Deeper grammar needs a model."}
    out["answer"] = (
        ("No issues found — the text looks clean." if not issues else
         f"Found {len(issues)} issue(s): {errors} error(s), {styles} style note(s)"
         + ("" if apply else " (report only, nothing changed)") + ".\n"
         + "\n".join(f"- **{i['rule']}**: {i['message']}" for i in issues[:15])
         + ("\n\nCorrected text:\n" + fixed if apply and fixed != body else ""))
        + f"\n\n_{out['note']}_")
    return out


@tool(
    name="text.extract",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Pull structured data out of free text: emails, URLs, phones, dates, times, money, hashtags, mentions, IPs, numbers",
    schema={"text": {"type": "string"}, "path": {"type": "string"},
            "kinds": {"type": "string",
                      "description": "comma list of: email,url,phone,date,time,money,hashtag,"
                                     "mention,ip,number,card,ipv6; default all"}},
    risk="LOW",
    timeout=90,
)
async def text_extract(ctx: ToolContext, text: str = "", path: str = "", kinds: str = "",
                       request: str = "") -> Dict[str, Any]:
    body, err = await _source(text or request, path, ctx)
    if err:
        return err
    wanted = {k.strip().lower() for k in (kinds or "").split(",") if k.strip()}
    patterns: Dict[str, str] = {
        "email": r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}",
        "url": r"\bhttps?://[^\s<>\"')\]]+",
        "phone": r"(?<![\w.])(?:\+?\d{1,3}[ \-]?)?(?:\(\d{2,5}\)[ \-]?)?\d{3,5}[ \-]?\d{4}"
                 r"(?:[ \-]?\d{2,4})?(?![\w.])",
        "date": r"\b(?:\d{4}-\d{2}-\d{2}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|"
                r"\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*"
                r"(?:,?\s+\d{4})?|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*"
                r"\s+\d{1,2},?\s+\d{4})\b",
        "time": r"\b(?:[01]?\d|2[0-3]):[0-5]\d(?::[0-5]\d)?\s*(?:am|pm)?\b|\b\d{1,2}\s*"
                r"(?:am|pm)\b",
        "money": r"(?:[$€£¥₹]\s?\d[\d,]*(?:\.\d+)?|\d[\d,]*(?:\.\d+)?\s?"
                 r"(?:USD|EUR|GBP|INR|JPY|AED|SGD|dollars?|rupees?|euros?|pounds?))",
        "hashtag": r"(?<![\w])#[A-Za-z0-9_]{2,}",
        "mention": r"(?<![\w])@[A-Za-z0-9_]{2,}",
        "ip": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        "ipv6": r"\b(?:[A-Fa-f0-9]{1,4}:){2,7}[A-Fa-f0-9]{1,4}\b",
        "card": r"\b(?:\d[ \-]?){13,19}\b",
        "number": r"(?<![\w.$€£¥₹])-?\d+(?:[.,]\d+)?(?![\w])",
        "percent": r"\b\d+(?:\.\d+)?\s?%",
        "hex_color": r"(?<![\w])#[0-9A-Fa-f]{6}\b|(?<![\w])#[0-9A-Fa-f]{3}\b",
        "file_path": r"(?:[A-Za-z]:\\|\.{0,2}/)[^\s:*?\"<>|]+",
    }
    found: Dict[str, List[str]] = {}
    for kind, rx in patterns.items():
        if wanted and kind not in wanted:
            continue
        hits = [h.strip() for h in re.findall(rx, body, flags=re.I)]
        hits = [h for h in hits if h]
        if kind == "phone":
            hits = [h for h in hits if len(re.sub(r"\D", "", h)) >= 8]
        if kind == "card":
            hits = [h for h in hits if len(re.sub(r"\D", "", h)) >= 13]
        if hits:
            seen: set = set()
            found[kind] = [h for h in hits if not (h in seen or seen.add(h))][:50]
    # ISO-normalise the dates we can parse
    normalised: List[Dict[str, str]] = []
    for d in found.get("date", [])[:20]:
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%d %b %Y", "%d %B %Y",
                    "%b %d, %Y", "%B %d, %Y", "%d %b %Y"):
            try:
                normalised.append({"raw": d, "iso": datetime.strptime(d.replace(",", ""),
                                                                     fmt).strftime("%Y-%m-%d")})
                break
            except ValueError:
                continue
    total = sum(len(v) for v in found.values())
    out = {"ok": True, "found": found, "total": total, "dates_iso": normalised,
           "characters": len(body),
           "counts": {k: len(v) for k, v in found.items()},
           "note": "Anything that looks like a card number is reported but never stored; mask it "
                   "with text.redact before you share the text."}
    if not total:
        out["answer"] = "I found no emails, URLs, phones, dates, money, tags or numbers in that text."
    else:
        lines = [f"- **{k}** ({len(v)}): " + ", ".join(x[:40] for x in v[:8])
                 + (" …" if len(v) > 8 else "") for k, v in found.items()]
        out["answer"] = f"Extracted {total} item(s):\n" + "\n".join(lines)
    return out


@tool(
    name="text.bullets",
    capability="text.generate",
    agent="writing",
    device="both",
    description="Turn prose into bullet points, or bullets back into flowing prose",
    schema={"text": {"type": "string", "required": True},
            "direction": {"type": "string", "default": "to_bullets",
                          "description": "to_bullets | to_prose"},
            "bullet": {"type": "string", "default": "-"},
            "max_bullets": {"type": "integer", "default": 8}},
    risk="LOW",
    timeout=120,
)
async def text_bullets(ctx: ToolContext, text: str = "", direction: str = "to_bullets",
                       bullet: str = "-", max_bullets: int = 8,
                       request: str = "") -> Dict[str, Any]:
    body = (text or request or "").strip()
    if not body:
        return _bad("give me the text to convert")
    direction = (direction or "to_bullets").lower()
    mark = (bullet or "-")[:2]
    n = max(2, min(int(max_bullets or 8), 25))
    if direction.startswith("to_bullet") or direction in ("bullets", "list"):
        sentences = _sentences(body)
        picked = sentences[:n] if len(sentences) <= n else \
            sorted(range(len(sentences)),
                   key=lambda i: -len([w for w in _words(sentences[i])
                                       if w.lower() not in STOPWORDS]))[:n]
        picked = sorted(picked)
        local = [re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", sentences[i]).strip() for i in picked]
        local = [s for s in local if s]
        fallback = "\n".join(f"{mark} {s}" for s in local)
        prompt = (f"Convert this text into at most {n} bullet points. Each bullet must be one "
                  f"self-contained line starting with a verb or a noun phrase, no more than 25 "
                  f"words. Keep every number and name. Return only the bullets, one per line, "
                  f"each starting with '{mark} '.\n\nTEXT:\n{body[:16000]}")
        result, engine = await _model_text(prompt, "You are SAM's writing brain: you compress "
                                                   "without losing facts.", fallback,
                                           max_tokens=800)
        lines = [l.strip() for l in result.splitlines() if l.strip()]
        out = {"ok": True, "text": result, "engine": engine, "bullets": lines,
               "count": len(lines), "source_sentences": len(sentences)}
        out["answer"] = f"{len(lines)} bullet(s) from {len(sentences)} sentence(s) [{engine}]:\n\n{result}"
        return out
    # ---- bullets → prose ----
    items = [re.sub(r"^\s*(?:[-*•+]|\d+[.)])\s*", "", l).strip()
             for l in body.splitlines() if l.strip()]
    items = [i for i in items if i]
    local_prose = " ".join(i if i.endswith((".", "!", "?", ",")) else i + "." for i in items)
    prompt = ("Turn these bullet points into 1-3 paragraphs of clear, connected prose. Do not add "
              "facts, do not drop any bullet, and keep every number and name.\n\nBULLETS:\n"
              + "\n".join(f"- {i}" for i in items[:40]))
    result, engine = await _model_text(prompt, "You are SAM's writing brain.", local_prose,
                                       max_tokens=900)
    out = {"ok": True, "text": result, "engine": engine, "bullets_found": len(items),
           "words": len(_words(result))}
    out["answer"] = f"{len(items)} bullet(s) → prose ({out['words']} words) [{engine}]:\n\n{result}"
    return out


@tool(
    name="text.markdown",
    capability="text.transform",
    agent="writing",
    device="both",
    description="Convert Markdown to HTML, or HTML to plain text / Markdown",
    schema={"text": {"type": "string"}, "path": {"type": "string"},
            "direction": {"type": "string", "default": "md_to_html",
                          "description": "md_to_html | html_to_text | html_to_markdown"},
            "standalone": {"type": "boolean", "default": False,
                           "description": "wrap the HTML in a full document"}},
    risk="LOW",
    timeout=90,
)
async def text_markdown(ctx: ToolContext, text: str = "", path: str = "",
                        direction: str = "md_to_html", standalone: bool = False,
                        request: str = "") -> Dict[str, Any]:
    body, err = await _source(text or request, path, ctx)
    if err:
        return err
    direction = (direction or "md_to_html").lower()
    if direction == "md_to_html":
        html = _markdown_to_html(body)
        if standalone:
            html = ("<!doctype html><html><head><meta charset='utf-8'>"
                    "<title>SAM document</title><style>body{font-family:system-ui,sans-serif;"
                    "max-width:52rem;margin:2rem auto;line-height:1.6;padding:0 1rem}"
                    "table{border-collapse:collapse}pre{background:#f6f8fa;padding:.75rem;"
                    "overflow:auto;border-radius:6px}code{background:#f6f8fa;padding:.1rem .3rem;"
                    "border-radius:4px}</style></head><body>" + html + "</body></html>")
        out = {"ok": True, "format": "html", "text": html, "characters": len(html),
               "standalone": bool(standalone)}
        out["answer"] = f"Markdown → HTML ({len(html):,} characters):\n\n```html\n{html[:2000]}\n```"
        return out
    if direction == "html_to_text":
        plain = _strip_html(body)
        return {"ok": True, "format": "text", "text": plain, "characters": len(plain),
                "answer": f"HTML → plain text ({len(plain):,} characters):\n\n{plain[:2000]}"}
    # html_to_markdown
    try:
        from backend.app.utils import net

        md = net.html_to_markdown(body)
    except Exception as exc:
        md = _strip_html(body)
        log.debug("html_to_markdown fell back to text: %s", exc)
    return {"ok": True, "format": "markdown", "text": md, "characters": len(md),
            "answer": f"HTML → Markdown ({len(md):,} characters):\n\n{md[:2000]}"}


@tool(
    name="text.lorem",
    capability="text.generate",
    agent="writing",
    device="both",
    description="Generate placeholder copy: N words, sentences or paragraphs",
    schema={"count": {"type": "integer", "default": 3},
            "unit": {"type": "string", "default": "paragraphs",
                     "description": "words | sentences | paragraphs"},
            "start_with_lorem": {"type": "boolean", "default": True}},
    risk="LOW",
    timeout=30,
)
async def text_lorem(ctx: ToolContext, count: int = 3, unit: str = "paragraphs",
                     start_with_lorem: bool = True, request: str = "") -> Dict[str, Any]:
    import random

    n = max(1, min(int(count or 1), 100))
    unit = (unit or "paragraphs").lower().rstrip("s")
    rng = random.Random()

    def sentence(min_words: int = 6, max_words: int = 16) -> str:
        words = [rng.choice(LOREM) for _ in range(rng.randint(min_words, max_words))]
        s = " ".join(words).capitalize()
        return s + "."

    if unit == "word":
        words = [rng.choice(LOREM) for _ in range(n)]
        if start_with_lorem:
            words[:2] = ["lorem", "ipsum"]
        body = " ".join(words)
    elif unit == "sentence":
        body = " ".join(sentence() for _ in range(n))
        if start_with_lorem:
            body = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " + body
    else:
        paras = []
        for i in range(n):
            sentences = [sentence() for _ in range(rng.randint(3, 6))]
            para = " ".join(sentences)
            if i == 0 and start_with_lorem:
                para = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod " \
                       "tempor incididunt ut labore et dolore magna aliqua. " + para
            paras.append(para)
        body = "\n\n".join(paras)
    out = {"ok": True, "text": body, "unit": unit, "count": n, "words": len(_words(body)),
           "characters": len(body)}
    out["answer"] = f"{n} {unit}(s) of placeholder copy ({out['words']} words):\n\n{body[:2000]}"
    return out
