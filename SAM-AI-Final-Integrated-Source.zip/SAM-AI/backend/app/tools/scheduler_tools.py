"""
backend.app.tools.scheduler_tools
=================================

The Planning Brain's tools: scheduled jobs, the Automation Builder
(WHEN → IF → DO → VERIFY) and calendar entries.

Jobs and rules are persisted in the SAM database and driven by
:mod:`backend.app.automation.scheduler` (APScheduler, with an internal poll loop
as a fallback).
"""

from __future__ import annotations

import json
import re
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from backend.app.automation.rules import WHEN_TYPES
from backend.app.core.logging_config import get_logger
from backend.app.core.models import ScheduledJob
from backend.app.core.database import session_scope
from backend.app.tools.registry import ToolContext, tool
from sqlalchemy import select

log = get_logger("tools.scheduler")

CRON_PRESETS = {
    "daily": "0 9 * * *", "weekdays": "0 9 * * 1-5", "weekly": "0 9 * * 1",
    "monthly": "0 9 1 * *", "hourly": "0 * * * *", "every-30-min": "*/30 * * * *",
    "every-15-min": "*/15 * * * *", "every-5-min": "*/5 * * * *",
    "weekends": "0 10 * * 6,0", "yearly": "0 9 1 1 *",
}
WEEKDAYS: Dict[str, int] = {
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3, "friday": 4,
    "saturday": 5, "sunday": 6, "mon": 0, "tue": 1, "wed": 2, "thu": 3,
    "fri": 4, "sat": 5, "sun": 6,
}
DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
UNIT_SECONDS = {"second": 1, "sec": 1, "minute": 60, "min": 60, "hour": 3600,
                "hr": 3600, "day": 86400, "week": 604800, "month": 2592000}
EVENT_TRIGGERS = (
    "battery low", "battery full", "battery charging", "file changed", "file added",
    "new email", "on startup", "startup", "idle", "plugged in", "unplugged",
    "device connected", "device disconnected", "task finished", "screenshot taken",
    "window opened", "low disk space", "high cpu",
)

# DB kind names -> human kind names used by the scheduler engine
_KIND_DB = {"one-time": "once", "once": "once", "date": "once", "recurring": "cron",
            "cron": "cron", "interval": "interval", "event": "event"}


def _spec_to_row(spec: Dict[str, Any]) -> Dict[str, str]:
    """Map a parsed schedule spec onto the ScheduledJob columns."""
    kind = _KIND_DB.get(spec.get("kind", "once"), "once")
    expression = ""
    if kind == "cron":
        expression = str(spec.get("cron") or "")
    elif kind == "once":
        expression = str(spec.get("at") or "")
    elif kind == "interval":
        expression = f"every {spec.get('seconds')}s"
    elif kind == "event":
        expression = str(spec.get("event") or "")
    return {"kind": kind, "expression": expression, "payload_json": json.dumps(spec)}


def _parse_when(when: str = "", at: str = "", every: str = "", on: str = "",
                request: str = "") -> Dict[str, Any]:
    """
    Turn natural language into a scheduler spec::

        {"kind": once|cron|interval|event, "at": iso, "cron": str,
         "seconds": int, "event": str, "human": str}
    """
    now = datetime.now()
    text = " ".join(x for x in (when, request) if x).lower().strip()
    spec: Dict[str, Any] = {"kind": "once", "human": "", "request": when or request or ""}

    # --- explicit time (HH:MM or ISO)
    if at:
        at = at.strip()
        parsed = _parse_clock(at, now)
        if parsed:
            spec.update(kind="once", at=parsed.isoformat(timespec="seconds"),
                        human=parsed.strftime("%A %d %b %H:%M"))
            return spec

    # --- interval: "every 30 minutes"
    m = re.search(r"every\s+(\d+)\s*(second|sec|minute|min|hour|hr|day|week|month)s?", text)
    if not m and every:
        m = re.match(r"\s*(\d+)\s*(second|sec|minute|min|hour|hr|day|week|month)s?",
                     every.strip().lower())
    if m:
        value, unit = int(m.group(1)), m.group(2)
        seconds = value * UNIT_SECONDS[unit]
        spec.update(kind="interval", seconds=seconds, human=f"every {value} {unit}")
        return spec

    # --- presets and raw cron
    normalised = text.replace("_", "-")
    for key, cron in CRON_PRESETS.items():
        if key in normalised:
            spec.update(kind="cron", cron=cron, human=key.replace("-", " "))
            return spec
    if re.fullmatch(r"[\d*/,\-\s]+", text) and text.count(" ") >= 3:
        spec.update(kind="cron", cron=text.strip(), human=f"cron: {text.strip()}")
        return spec

    # --- event triggers
    if on:
        spec.update(kind="event", event=on.strip().lower(), human=f"when {on.strip()}")
        return spec
    for trigger in EVENT_TRIGGERS:
        if trigger in text:
            spec.update(kind="event", event=trigger, human=f"when {trigger}")
            return spec

    # --- relative: "in 20 minutes"
    m = re.search(r"\bin\s+(\d+)\s*(second|sec|minute|min|hour|hr|day)s?\b", text)
    if m:
        value, unit = int(m.group(1)), m.group(2)
        dt = now + timedelta(seconds=value * UNIT_SECONDS[unit])
        spec.update(kind="once", at=dt.isoformat(timespec="seconds"),
                    human=f"in {value} {unit} ({dt.strftime('%a %H:%M')})")
        return spec

    # --- clock time inside the sentence
    hour, minute, found_time = _extract_clock(text, now)

    weekday = None
    for name, index in WEEKDAYS.items():
        if re.search(rf"\b{name}\b", text):
            weekday = index
            break

    if "daily" in text or "every day" in text or "everyday" in text or "each day" in text:
        spec.update(kind="cron", cron=f"{minute} {hour} * * *",
                    human=f"every day at {hour:02d}:{minute:02d}")
        return spec
    if any(k in text for k in ("weekly", "every week")):
        day = weekday if weekday is not None else 0
        spec.update(kind="cron", cron=f"{minute} {hour} * * {day}",
                    human=f"every {DAY_NAMES[day]} at {hour:02d}:{minute:02d}")
        return spec
    if "monthly" in text or "every month" in text:
        spec.update(kind="cron", cron=f"{minute} {hour} 1 * *",
                    human=f"the 1st of every month at {hour:02d}:{minute:02d}")
        return spec

    if weekday is not None:
        if "every" in text or text.startswith("on ") or "each" in text:
            spec.update(kind="cron", cron=f"{minute} {hour} * * {weekday}",
                        human=f"every {DAY_NAMES[weekday]} at {hour:02d}:{minute:02d}")
            return spec
        days_ahead = (weekday - now.weekday()) % 7 or 7
        dt = (now + timedelta(days=days_ahead)).replace(hour=hour, minute=minute,
                                                        second=0, microsecond=0)
        spec.update(kind="once", at=dt.isoformat(timespec="seconds"),
                    human=dt.strftime("%A %d %b %H:%M"))
        return spec

    if "tomorrow" in text:
        dt = (now + timedelta(days=1)).replace(hour=hour, minute=minute, second=0, microsecond=0)
        spec.update(kind="once", at=dt.isoformat(timespec="seconds"),
                    human=f"tomorrow at {hour:02d}:{minute:02d}")
        return spec
    if "tonight" in text:
        dt = now.replace(hour=20, minute=0, second=0, microsecond=0)
        if dt <= now:
            dt += timedelta(days=1)
        spec.update(kind="once", at=dt.isoformat(timespec="seconds"), human="tonight at 20:00")
        return spec

    if found_time:
        dt = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if dt <= now:
            dt += timedelta(days=1)
            spec.update(kind="once", at=dt.isoformat(timespec="seconds"),
                        human=f"tomorrow at {hour:02d}:{minute:02d} (that time has passed today)")
        else:
            spec.update(kind="once", at=dt.isoformat(timespec="seconds"),
                        human=f"today at {hour:02d}:{minute:02d}")
        return spec

    # --- nothing recognisable: default to 09:00 daily and say so
    spec.update(kind="cron", cron="0 9 * * *",
                human="every day at 09:00 (default — no time was understood)")
    return spec


def _parse_clock(value: str, now: datetime) -> Optional[datetime]:
    value = value.strip()
    m = re.fullmatch(r"(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?", value, re.I)
    if m:
        hour = int(m.group(1))
        meridiem = (m.group(4) or "").lower()
        if meridiem == "pm" and hour != 12:
            hour += 12
        elif meridiem == "am" and hour == 12:
            hour = 0
        if hour > 23:
            return None
        dt = now.replace(hour=hour, minute=int(m.group(2)),
                         second=int(m.group(3) or 0), microsecond=0)
        return dt + timedelta(days=1) if dt <= now else dt
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        return None


def _extract_clock(text: str, now: datetime) -> tuple:
    """Return (hour, minute, found) from phrases like '6pm', '18:30', '9 am'."""
    m = re.search(r"\b(\d{1,2}):(\d{2})\s*(am|pm)?\b", text)
    if m:
        hour = int(m.group(1))
        if (m.group(3) or "").lower() == "pm" and hour != 12:
            hour += 12
        elif (m.group(3) or "").lower() == "am" and hour == 12:
            hour = 0
        return (hour % 24, int(m.group(2)), True)
    m = re.search(r"\b(\d{1,2})\s*(am|pm)\b", text)
    if m:
        hour = int(m.group(1))
        if m.group(2) == "pm" and hour != 12:
            hour += 12
        elif m.group(2) == "am" and hour == 12:
            hour = 0
        return (hour % 24, 0, True)
    if "morning" in text:
        return (8, 0, True)
    if "afternoon" in text:
        return (14, 0, True)
    if "evening" in text:
        return (18, 0, True)
    if "night" in text or "midnight" in text:
        return (22, 0, True)
    return (9, 0, False)


# ===========================================================================
# SCHEDULER
# ===========================================================================
@tool(
    name="scheduler.create",
    capability="scheduler.create",
    agent="planning",
    device="pc",
    description="Schedule a task: one-time, recurring, interval or event-triggered",
    schema={"instruction": {"type": "string", "required": True}},
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def scheduler_create(ctx: ToolContext, instruction: str = "", when: str = "", at: str = "",
                           every: str = "", on: str = "", priority: str = "normal",
                           device: str = "pc", name: str = "", enabled: bool = True,
                           request: str = "") -> Dict[str, Any]:
    from backend.app.automation.scheduler import scheduler

    text = instruction or request or ctx.user_text
    if not text:
        return {"ok": False, "error": "nothing to schedule"}
    spec = _parse_when(when, at=at, every=every, on=on, request=request)
    job_id = f"sam-{int(time.time() * 1000)}"
    title = name or text[:120]
    row = _spec_to_row(spec)

    async with session_scope() as db:
        db.add(ScheduledJob(
            id=job_id, name=title, instruction=text, kind=row["kind"],
            expression=row["expression"], payload_json=row["payload_json"],
            device=device, priority=priority, enabled=enabled, source="tool",
        ))

    armed = scheduler.add_job(job_id, spec, title, text, device=device,
                              priority=priority, enabled=enabled)
    return {
        "ok": True, "job_id": job_id, "title": title, "instruction": text,
        "schedule": spec, "armed": armed.get("ok", False), "engine": armed.get("engine"),
        "next_run": armed.get("next_run") or spec.get("at"),
        "human": spec.get("human") or spec["kind"],
        "device": device, "priority": priority, "enabled": enabled,
        "answer": f"Scheduled: “{title}” — {spec.get('human') or spec['kind']}.",
    }


@tool(
    name="scheduler.list",
    capability="scheduler.read",
    agent="planning",
    device="pc",
    description="List scheduled jobs with their next run time",
    risk="LOW",
    timeout=30,
)
async def scheduler_list(ctx: ToolContext, include_disabled: bool = True,
                         search: str = "") -> Dict[str, Any]:
    from backend.app.automation.scheduler import scheduler

    async with session_scope() as db:
        rows = (await db.execute(select(ScheduledJob))).scalars().all()
    live = {j["id"]: j for j in scheduler.jobs()}
    items: List[Dict[str, Any]] = []
    for r in rows:
        if not include_disabled and not r.enabled:
            continue
        if search:
            blob = f"{r.name} {r.instruction}".lower()
            if search.lower() not in blob:
                continue
        payload = r.to_dict().get("payload") or {}
        item = r.to_dict()
        item["human"] = payload.get("human") or r.expression or r.kind
        item["cron"] = payload.get("cron")
        item["at"] = payload.get("at")
        item["seconds"] = payload.get("seconds")
        item["event"] = payload.get("event")
        engine_job = live.get(r.id)
        item["armed_in_engine"] = bool(engine_job)
        if engine_job and engine_job.get("next_run"):
            item["next_run"] = engine_job["next_run"]
        items.append(item)
    items.sort(key=lambda x: (not x["enabled"], str(x.get("next_run") or "9999")))
    return {"ok": True, "count": len(items), "jobs": items, **scheduler.status()}


@tool(
    name="scheduler.update",
    capability="scheduler.update",
    agent="planning",
    device="pc",
    description="Change, enable, disable or reschedule an existing job",
    risk="MEDIUM",
    confirm=True,
    timeout=30,
)
async def scheduler_update(ctx: ToolContext, job_id: str = "", enabled: Optional[bool] = None,
                           when: str = "", at: str = "", every: str = "", on: str = "",
                           priority: str = "", instruction: str = "", title: str = "",
                           request: str = "") -> Dict[str, Any]:
    from backend.app.automation.scheduler import scheduler

    job_id = job_id or _find_job_id(request or ctx.user_text)
    if not job_id:
        return {"ok": False, "error": "which job? give job_id (see scheduler.list)"}

    spec: Optional[Dict[str, Any]] = None
    async with session_scope() as db:
        row = await db.get(ScheduledJob, job_id)
        if row is None:
            return {"ok": False, "error": f"no scheduled job with id {job_id}"}
        if when or at or every or on:
            spec = _parse_when(when, at=at, every=every, on=on, request=request)
            mapped = _spec_to_row(spec)
            row.kind = mapped["kind"]
            row.expression = mapped["expression"]
            row.payload_json = mapped["payload_json"]
        if enabled is not None:
            row.enabled = bool(enabled)
        if priority:
            row.priority = priority
        if instruction:
            row.instruction = instruction
        if title:
            row.name = title
        snapshot = row.to_dict()

    armed = scheduler.reschedule(job_id, snapshot, spec)
    return {"ok": True, "job": snapshot, "schedule": spec, "armed": armed.get("ok", False),
            "engine": armed.get("engine"), "next_run": armed.get("next_run")}


def _find_job_id(text: str) -> str:
    m = re.search(r"\b(sam-(?:rem-)?\d+)\b", text or "")
    return m.group(1) if m else ""


@tool(
    name="scheduler.remove",
    capability="scheduler.delete",
    agent="planning",
    device="pc",
    description="Cancel a scheduled job",
    risk="MEDIUM",
    confirm=True,
    timeout=30,
)
async def scheduler_remove(ctx: ToolContext, job_id: str = "", request: str = "",
                           all_disabled: bool = False) -> Dict[str, Any]:
    from backend.app.automation.scheduler import scheduler

    removed: List[str] = []
    async with session_scope() as db:
        if all_disabled and not job_id:
            for r in (await db.execute(select(ScheduledJob))).scalars().all():
                if not r.enabled:
                    await db.delete(r)
                    removed.append(r.id)
        else:
            job_id = job_id or _find_job_id(request or ctx.user_text)
            if not job_id:
                return {"ok": False, "error": "which job? give job_id (see scheduler.list)"}
            row = await db.get(ScheduledJob, job_id)
            if row is None:
                return {"ok": False, "error": f"no scheduled job with id {job_id}"}
            await db.delete(row)
            removed.append(row.id)
    for jid in removed:
        scheduler.remove_job(jid)
    return {"ok": True, "removed": removed, "count": len(removed)}


@tool(
    name="scheduler.run_now",
    capability="scheduler.update",
    agent="planning",
    device="pc",
    description="Execute a scheduled job immediately, out of band",
    risk="MEDIUM",
    confirm=True,
    timeout=600,
)
async def scheduler_run_now(ctx: ToolContext, job_id: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.automation.scheduler import scheduler

    job_id = job_id or _find_job_id(request or ctx.user_text)
    async with session_scope() as db:
        row = await db.get(ScheduledJob, job_id) if job_id else None
        if row is None:
            return {"ok": False, "error": f"no scheduled job with id '{job_id}'"}
        instruction, title = row.instruction, row.name
        device, priority = row.device, row.priority
    result = await scheduler.fire(job_id, title or "", instruction or "", device=device or "pc",
                                  priority=priority or "normal", manual=True)
    return {"ok": bool(result.get("ok")), "job_id": job_id, "result": result}


# ===========================================================================
# AUTOMATION BUILDER  (WHEN -> IF -> DO -> VERIFY)
# ===========================================================================
@tool(
    name="automation.create",
    capability="automation.create",
    agent="planning",
    device="pc",
    description="Build a WHEN -> IF -> DO -> VERIFY automation rule",
    schema={"instruction": {"type": "string"}},
    risk="MEDIUM",
    confirm=True,
    timeout=120,
)
async def automation_create(ctx: ToolContext, instruction: str = "", name: str = "",
                            when: str = "", condition: str = "", action: str = "",
                            verify: str = "", enabled: bool = True, priority: str = "normal",
                            request: str = "") -> Dict[str, Any]:
    from backend.app.automation.builder import build_rule
    from backend.app.automation.rules import rule_store
    from backend.app.automation.scheduler import scheduler

    text = instruction or request or ctx.user_text
    if not text and not (when and action):
        return {"ok": False,
                "error": "describe the automation, e.g. “when battery is low, enable battery saver”"}
    rule = await build_rule(text, name=name, when=when, condition=condition, action=action,
                            verify=verify, priority=priority, enabled=enabled)
    saved = await rule_store.save(rule)

    armed: Dict[str, Any] = {}
    if rule.when_type in ("time", "cron", "interval", "event") and enabled:
        trigger = dict(rule.trigger or {})
        if rule.when_type == "cron":
            trigger["kind"] = "cron"
        elif rule.when_type == "interval":
            trigger["kind"] = "interval"
        elif rule.when_type == "event":
            trigger["kind"] = "event"
        else:
            trigger["kind"] = "once"
        armed = scheduler.add_job(f"rule-{rule.id}", trigger, rule.name,
                                  f"Run automation {rule.id}: {rule.action_description}",
                                  device=rule.device, priority=rule.priority, enabled=True)
        saved["schedule_job"] = f"rule-{rule.id}"
        saved["armed"] = armed.get("ok", False)

    return {"ok": True, "rule": saved, "id": saved["id"], "summary": _rule_summary(saved),
            "engine": armed.get("engine"), "next_run": armed.get("next_run"),
            "answer": f"Automation created: {_rule_summary(saved)}"}


def _rule_summary(rule: Dict[str, Any]) -> str:
    return (f"WHEN {rule.get('when') or rule.get('when_type') or '?'} → "
            f"IF {rule.get('condition') or 'always'} → "
            f"DO {rule.get('action_description') or '(no action)'} → "
            f"VERIFY {rule.get('verify') or 'the result is reported back'}")


@tool(
    name="automation.list",
    capability="automation.read",
    agent="planning",
    device="pc",
    description="List automation rules and how often they have fired",
    risk="LOW",
    timeout=30,
)
async def automation_list(ctx: ToolContext, include_disabled: bool = True,
                          search: str = "") -> Dict[str, Any]:
    from backend.app.automation.rules import rule_store

    rules = await rule_store.list_all(include_disabled=include_disabled, search=search)
    for r in rules:
        r["summary"] = _rule_summary(r)
    return {"ok": True, "count": len(rules), "rules": rules, "when_types": sorted(WHEN_TYPES)}


@tool(
    name="automation.toggle",
    capability="automation.update",
    agent="planning",
    device="pc",
    description="Enable, disable, rename, reprioritise or delete an automation rule",
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def automation_toggle(ctx: ToolContext, rule_id: str = "", enabled: Optional[bool] = None,
                            delete: bool = False, name: str = "", priority: str = "",
                            request: str = "") -> Dict[str, Any]:
    from backend.app.automation.rules import rule_store
    from backend.app.automation.scheduler import scheduler

    rule_id = rule_id or _find_rule_id(request or ctx.user_text)
    if not rule_id:
        return {"ok": False, "error": "which automation? give rule_id (see automation.list)"}
    if delete:
        ok = await rule_store.delete(rule_id)
        scheduler.remove_job(f"rule-{rule_id}")
        return {"ok": ok, "deleted": rule_id if ok else None,
                "error": None if ok else f"no rule with id {rule_id}"}
    updates: Dict[str, Any] = {}
    if enabled is not None:
        updates["enabled"] = bool(enabled)
    if name:
        updates["name"] = name
    if priority:
        updates["priority"] = priority
    if not updates:
        return {"ok": False, "error": "nothing to change — set enabled, name or priority"}
    updated = await rule_store.update(rule_id, **updates)
    if updated is None:
        return {"ok": False, "error": f"no rule with id {rule_id}"}
    if enabled is False:
        scheduler.remove_job(f"rule-{rule_id}")
    elif enabled is True and updated.get("trigger"):
        trigger = dict(updated["trigger"])
        trigger["kind"] = {"time": "once", "cron": "cron", "interval": "interval",
                           "event": "event"}.get(updated.get("when_type"), "once")
        scheduler.add_job(f"rule-{rule_id}", trigger, updated["name"],
                          f"Run automation {rule_id}: {updated.get('action_description', '')}",
                          device=updated.get("device", "pc"),
                          priority=updated.get("priority", "normal"), enabled=True)
    return {"ok": True, "rule": updated, "summary": _rule_summary(updated)}


def _find_rule_id(text: str) -> str:
    m = re.search(r"\b(auto-[a-z0-9\-]+)\b", text or "")
    return m.group(1) if m else ""


@tool(
    name="automation.run",
    capability="automation.update",
    agent="planning",
    device="pc",
    description="Test an automation rule right now without waiting for its trigger",
    risk="MEDIUM",
    confirm=True,
    timeout=600,
)
async def automation_run(ctx: ToolContext, rule_id: str = "", dry_run: bool = False,
                         request: str = "") -> Dict[str, Any]:
    from backend.app.automation.executor import execute_rule
    from backend.app.automation.rules import AutomationRule, rule_store

    rule_id = rule_id or _find_rule_id(request or ctx.user_text)
    data = await rule_store.get(rule_id)
    if data is None:
        return {"ok": False, "error": f"no automation rule with id '{rule_id}'"}
    return await execute_rule(AutomationRule.from_dict(data), ctx_base=ctx,
                              dry_run=dry_run, manual=True)


# ===========================================================================
# CALENDAR
# ===========================================================================
@tool(
    name="calendar.upsert",
    capability="calendar.manage",
    agent="planning",
    device="pc",
    description="Create or update a calendar event in the SAM calendar",
    schema={"title": {"type": "string", "required": True}},
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def calendar_upsert(ctx: ToolContext, title: str = "", start: str = "", end: str = "",
                          when: str = "", at: str = "", duration_minutes: int = 60,
                          location: str = "", notes: str = "", reminder_minutes: int = 15,
                          all_day: bool = False, event_id: str = "",
                          request: str = "") -> Dict[str, Any]:
    from backend.app.automation.calendar_store import calendar_store
    from backend.app.automation.scheduler import scheduler

    text = request or ctx.user_text
    if not title and text:
        m = re.search(r"(?:meeting|call|event|reminder|appointment|standup|interview)\s+"
                      r"(?:with|for|about|at)?\s*(.+)", text, re.I)
        title = (m.group(1) if m and m.group(1).strip() else text)[:100].strip(" .,")
    if not title:
        return {"ok": False, "error": "what is the event called?"}

    dt_start: Optional[datetime] = None
    if start:
        dt_start = _parse_iso(start)
    if dt_start is None and (when or at or text):
        spec = _parse_when(when, at=at, request=text)
        dt_start = _parse_iso(spec.get("at") or "")
    if dt_start is None:
        dt_start = datetime.now() + timedelta(hours=1)

    dt_end = dt_start + timedelta(days=1) if all_day else \
        dt_start + timedelta(minutes=max(1, int(duration_minutes)))
    if end:
        parsed_end = _parse_iso(end)
        if parsed_end:
            dt_end = parsed_end

    event = await calendar_store.upsert(
        event_id=event_id or None, title=title, start=dt_start, end=dt_end,
        location=location, notes=notes, all_day=all_day,
        reminder_minutes=int(reminder_minutes), device=ctx.device or "pc",
    )

    # the reminder becomes a real scheduled job, so SAM actually speaks up
    reminder_job = None
    if reminder_minutes and int(reminder_minutes) > 0 and not all_day:
        remind_at = dt_start - timedelta(minutes=int(reminder_minutes))
        if remind_at > datetime.now():
            job_id = f"sam-rem-{int(time.time() * 1000)}"
            instruction = (f"Remind the user: {title} at {dt_start.strftime('%H:%M')}"
                           + (f" in {location}" if location else ""))
            spec = {"kind": "once", "at": remind_at.isoformat(timespec="seconds"),
                    "human": f"reminder {int(reminder_minutes)} min before {title}"}
            async with session_scope() as db:
                db.add(ScheduledJob(
                    id=job_id, name=f"Reminder: {title}", instruction=instruction,
                    kind="once", expression=remind_at.isoformat(timespec="seconds"),
                    payload_json=json.dumps(spec), device=ctx.device or "pc",
                    priority="high", enabled=True, source="calendar",
                    automation_id=event.get("id"),
                ))
            scheduler.add_job(job_id, spec, f"Reminder: {title}", instruction,
                              device=ctx.device or "pc", priority="high", enabled=True)
            reminder_job = job_id
            await calendar_store.set_reminder_job(event["id"], job_id)

    return {"ok": True, "event": event, "reminder_job": reminder_job,
            "human": f"{title} — {dt_start.strftime('%a %d %b %H:%M')}"
                     f"{'–' + dt_end.strftime('%H:%M') if not all_day else ' (all day)'}",
            "answer": f"Added to your calendar: {title} on "
                      f"{dt_start.strftime('%A %d %B at %H:%M')}."}


def _parse_iso(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt.replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        return None


@tool(
    name="calendar.list",
    capability="calendar.read",
    agent="planning",
    device="pc",
    description="List calendar events for a day, week or range",
    risk="LOW",
    timeout=30,
)
async def calendar_list(ctx: ToolContext, days: int = 7, date: str = "", include_past: bool = False,
                        search: str = "") -> Dict[str, Any]:
    from backend.app.automation.calendar_store import calendar_store

    events = await calendar_store.list_events(days=int(days), date=date,
                                              include_past=include_past, search=search)
    lines = [f"- {(e['start'] or '')[:16].replace('T', ' ')} — **{e['title']}**"
             + (f" @ {e['location']}" if e.get("location") else "")
             for e in events[:20]]
    return {"ok": True, "count": len(events), "events": events,
            "answer": ("Your calendar:\n" + "\n".join(lines)) if lines
                      else f"Nothing scheduled in the next {days} days."}


@tool(
    name="calendar.remove",
    capability="calendar.manage",
    agent="planning",
    device="pc",
    description="Delete a calendar event (and its reminder job)",
    risk="MEDIUM",
    confirm=True,
    timeout=30,
)
async def calendar_remove(ctx: ToolContext, event_id: str = "", title: str = "",
                          request: str = "") -> Dict[str, Any]:
    from backend.app.automation.calendar_store import calendar_store
    from backend.app.automation.scheduler import scheduler

    if not event_id and title:
        matches = await calendar_store.list_events(days=90, include_past=True, search=title)
        if not matches:
            return {"ok": False, "error": f"no event matching '{title}'"}
        event_id = matches[0]["id"]
    if not event_id:
        m = re.search(r"\b(evt-[a-z0-9\-]+)\b", request or ctx.user_text or "")
        event_id = m.group(1) if m else ""
    if not event_id:
        return {"ok": False, "error": "which event? give event_id or title"}
    event = await calendar_store.get(event_id)
    ok = await calendar_store.delete(event_id)
    if ok and event and event.get("reminder_job_id"):
        scheduler.remove_job(event["reminder_job_id"])
        async with session_scope() as db:
            row = await db.get(ScheduledJob, event["reminder_job_id"])
            if row is not None:
                await db.delete(row)
    return {"ok": ok, "deleted": event_id if ok else None,
            "error": None if ok else f"no event with id {event_id}"}
