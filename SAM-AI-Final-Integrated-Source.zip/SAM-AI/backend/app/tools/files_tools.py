"""
backend.app.tools.files_tools
=============================

The File Agent's executable surface: search, read, write, move, rename,
delete, convert, archive, organise and de-duplicate.

Every path is validated by :mod:`backend.app.files.file_ops` against
``FILES_ALLOWED_ROOTS`` / ``FILES_DENIED_PATTERNS``, and every mutating call
passes through the security guard (permission -> risk -> confirmation -> audit).
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.files import file_ops
from backend.app.files.file_ops import (
    FileSecurityError,
    assert_allowed,
    extract_text,
    human_size,
    is_allowed,
    stat_path,
    walk,
)
from backend.app.files.search_index import Query, parse_query, searcher
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.files")


# ===========================================================================
# SEARCH
# ===========================================================================
@tool(
    name="files.search",
    capability="files.search",
    agent="files",
    device="pc",
    description=("Search files by name, extension, date, size, folder, full-text content "
                 "and semantic meaning"),
    schema={"query": {"type": "string", "required": True}, "folder": {"type": "string"},
            "ext": {"type": "string"}, "limit": {"type": "integer"}, "sort": {"type": "string"}},
    risk="LOW",
    timeout=180,
)
async def files_search(ctx: ToolContext, query: str = "", folder: str = "", ext: str = "",
                       limit: int = 25, sort: str = "relevance",
                       modified_within: str = "", min_size: str = "",
                       content: str = "", roots: Optional[List[str]] = None) -> Dict[str, Any]:
    overrides: Dict[str, Any] = {"limit": int(limit), "sort": sort}
    if folder:
        overrides["folder"] = folder
    if ext:
        overrides["ext"] = ext if ext.startswith(".") else "." + ext
    if modified_within:
        overrides["modified_within"] = modified_within
    if min_size:
        overrides["min_size"] = _size_to_bytes(min_size)
    if content:
        overrides["content"] = content
    if roots:
        overrides["roots"] = roots

    q = parse_query(query or "", **{k: v for k, v in overrides.items() if v})
    result = await searcher.search(q)
    if not result.get("ok"):
        return result

    hits = result["hits"]
    summary = _summarise_hits(hits, q)
    result["summary"] = summary
    return result


def _size_to_bytes(value: str) -> Optional[int]:
    m = re.match(r"\s*(\d+(?:\.\d+)?)\s*(b|kb|mb|gb|tb)?\s*$", str(value).lower())
    if not m:
        return None
    units = {"b": 1, "kb": 1024, "mb": 1024**2, "gb": 1024**3, "tb": 1024**4}
    return int(float(m.group(1)) * units.get(m.group(2) or "b", 1))


def _summarise_hits(hits: List[Dict[str, Any]], q: Query) -> str:
    if not hits:
        parts = []
        if q.text:
            parts.append(f"“{q.text}”")
        if q.ext:
            parts.append(f"of type {q.ext}")
        if q.folder:
            parts.append(f"in {q.folder}")
        if q.modified_within:
            parts.append(f"modified within {q.modified_within}")
        scope = " ".join(parts) or "matching that description"
        return f"No files {scope}."
    top = hits[:5]
    lines = [f"Found {len(hits)} file(s). Top matches:"]
    for h in top:
        why = ", ".join(h["matched_on"])
        lines.append(f"- {h['name']} ({h['size_human']}, {h['modified_ago']}) — matched on {why}")
        if h.get("snippet"):
            lines.append(f"    {h['snippet'][:160]}")
    return "\n".join(lines)


@tool(
    name="files.scan",
    capability="files.read",
    agent="files",
    device="pc",
    description="Scan a folder and report its structure, sizes and file-type breakdown",
    risk="LOW",
    timeout=180,
)
async def files_scan(ctx: ToolContext, folder: str = "", depth: int = 3,
                     limit: int = 500) -> Dict[str, Any]:
    root = Path(folder or settings.allowed_roots[0] if settings.allowed_roots else ".")
    try:
        root = assert_allowed(root)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc)}
    if not root.exists():
        return {"ok": False, "error": f"folder does not exist: {root}"}

    by_ext: Counter = Counter()
    size_by_ext: Dict[str, int] = defaultdict(int)
    largest: List[Dict[str, Any]] = []
    newest: List[Dict[str, Any]] = []
    total_size = 0
    count = 0
    dirs = 0

    for path in walk(root, max_files=100_000):
        try:
            st = path.stat()
        except OSError:
            continue
        count += 1
        total_size += st.st_size
        ext = path.suffix.lower() or "(no extension)"
        by_ext[ext] += 1
        size_by_ext[ext] += st.st_size
        largest.append({"path": str(path), "name": path.name, "size": st.st_size,
                        "size_human": human_size(st.st_size), "ext": ext})
        newest.append({"path": str(path), "name": path.name, "modified": st.st_mtime,
                       "modified_ago": time.strftime("%Y-%m-%d", time.localtime(st.st_mtime))})
        if count >= limit * 20:
            break

    for d in root.rglob("*"):
        if d.is_dir():
            dirs += 1

    largest.sort(key=lambda d: d["size"], reverse=True)
    newest.sort(key=lambda d: d["modified"], reverse=True)

    return {
        "ok": True,
        "root": str(root),
        "files": count,
        "folders": dirs,
        "total_size": total_size,
        "total_size_human": human_size(total_size),
        "by_extension": [{"ext": e, "count": c, "size_human": human_size(size_by_ext[e])}
                         for e, c in by_ext.most_common(20)],
        "largest": largest[:15],
        "newest": [{k: v for k, v in n.items() if k != "modified"} for n in newest[:15]],
    }


# ===========================================================================
# READ / WRITE
# ===========================================================================
@tool(
    name="files.read",
    capability="files.read",
    agent="files",
    device="pc",
    description="Read a file or list a folder (extracts text from PDF/DOCX/PPTX/XLSX/CSV/images)",
    schema={"path": {"type": "string", "required": True}},
    risk="LOW",
    timeout=120,
)
async def files_read(ctx: ToolContext, path: str = "", max_chars: int = 60_000) -> Dict[str, Any]:
    if not path:
        return {"ok": False, "error": "no path was given"}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, lambda: file_ops.safe_read(path, max_chars=int(max_chars))
        )
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}


@tool(
    name="files.write",
    capability="files.write",
    agent="files",
    device="pc",
    description="Create or overwrite a text file inside an allowed root",
    schema={"path": {"type": "string", "required": True}, "content": {"type": "string"}},
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def files_write(ctx: ToolContext, path: str = "", content: str = "",
                      append: bool = False) -> Dict[str, Any]:
    if not path:
        return {"ok": False, "error": "no path was given"}
    try:
        p = assert_allowed(path, for_write=True)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}
    p.parent.mkdir(parents=True, exist_ok=True)
    existed = p.exists()
    if append and existed:
        with open(p, "a", encoding="utf-8") as fh:
            fh.write(content)
    else:
        p.write_text(content, encoding="utf-8")
    return {"ok": True, "path": str(p), "bytes": p.stat().st_size,
            "created": not existed, "appended": bool(append and existed)}


@tool(
    name="files.copy",
    capability="files.write",
    agent="files",
    device="pc",
    description="Copy a file or folder",
    risk="MEDIUM",
    confirm=True,
    timeout=300,
)
async def files_copy(ctx: ToolContext, src: str = "", dst: str = "",
                     overwrite: bool = False) -> Dict[str, Any]:
    try:
        return file_ops.safe_copy(src, dst, overwrite=overwrite)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}


@tool(
    name="files.move",
    capability="files.move",
    agent="files",
    device="pc",
    description="Move or rename a file or folder",
    risk="MEDIUM",
    confirm=True,
    timeout=300,
)
async def files_move(ctx: ToolContext, src: str = "", dst: str = "",
                     new_name: str = "", overwrite: bool = False) -> Dict[str, Any]:
    try:
        if new_name:
            return file_ops.safe_rename(src, new_name)
        return file_ops.safe_move(src, dst, overwrite=overwrite)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}


@tool(
    name="files.rename",
    capability="files.move",
    agent="files",
    device="pc",
    description="Rename a file, optionally with a bulk pattern",
    risk="MEDIUM",
    confirm=True,
    timeout=120,
)
async def files_rename(ctx: ToolContext, path: str = "", new_name: str = "",
                       pattern: str = "", replacement: str = "") -> Dict[str, Any]:
    try:
        if path and new_name:
            return file_ops.safe_rename(path, new_name)
        if pattern:
            p = assert_allowed(path, for_write=True)
            target = Path(re.sub(pattern, replacement, p.name))
            return file_ops.safe_rename(p, target.name)
        return {"ok": False, "error": "provide new_name, or pattern + replacement"}
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}


@tool(
    name="files.delete",
    capability="files.delete",
    agent="files",
    device="pc",
    description="Delete a file (moved to the recycle bin / SAM trash first)",
    risk="HIGH",
    confirm=True,
    timeout=120,
)
async def files_delete(ctx: ToolContext, path: str = "", to_trash: bool = True,
                       paths: Optional[List[str]] = None) -> Dict[str, Any]:
    targets = paths or ([path] if path else [])
    if not targets:
        return {"ok": False, "error": "nothing to delete"}
    results = []
    for t in targets[:200]:
        try:
            results.append(file_ops.safe_delete(t, to_trash=to_trash))
        except FileSecurityError as exc:
            results.append({"ok": False, "path": t, "error": str(exc), "blocked": True})
    ok = sum(1 for r in results if r.get("ok"))
    return {"ok": ok == len(results), "deleted": ok, "total": len(results), "results": results}


# ===========================================================================
# ARCHIVES
# ===========================================================================
@tool(
    name="files.archive",
    capability="files.archive",
    agent="files",
    device="pc",
    description="Compress files/folders into zip or tar.gz, or extract an archive",
    risk="MEDIUM",
    confirm=True,
    timeout=600,
)
async def files_archive(ctx: ToolContext, action: str = "create", sources: Optional[List[str]] = None,
                        source: str = "", output: str = "", dest: str = "",
                        fmt: str = "zip") -> Dict[str, Any]:
    action = (action or "create").lower()
    try:
        if action in ("create", "compress", "zip"):
            items = sources or ([source] if source else [])
            if not items:
                return {"ok": False, "error": "no sources to archive"}
            if not output:
                first = Path(items[0]).expanduser()
                output = str(first.parent / f"{first.stem}.{'zip' if fmt == 'zip' else 'tar.gz'}")
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, file_ops.make_archive, items, output, fmt)
        if action in ("extract", "unzip", "decompress"):
            if not source:
                return {"ok": False, "error": "no archive path given"}
            target = dest or str(Path(source).expanduser().parent / Path(source).stem)
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, file_ops.extract_archive, source, target)
        return {"ok": False, "error": f"unknown archive action '{action}'"}
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}


# ===========================================================================
# DUPLICATES
# ===========================================================================
@tool(
    name="files.duplicates",
    capability="files.search",
    agent="files",
    device="pc",
    description="Find duplicate files by size + SHA-256 and report wasted space",
    risk="LOW",
    timeout=600,
)
async def files_duplicates(ctx: ToolContext, folder: str = "", min_size: str = "1kb",
                           max_files: int = 20_000) -> Dict[str, Any]:
    roots = [folder] if folder else [str(r) for r in settings.allowed_roots if r.exists()]
    if not roots:
        return {"ok": False, "error": "no folder given and no allowed roots configured"}
    loop = asyncio.get_running_loop()
    result = await loop.run_in_executor(
        None,
        lambda: file_ops.find_duplicates(
            roots, max_files=int(max_files), min_size=int(_size_to_bytes(min_size) or 1024)
        ),
    )
    if result.get("ok") and result.get("groups"):
        top = result["groups"][:5]
        result["summary"] = (
            f"{result['duplicate_groups']} duplicate group(s) wasting "
            f"{result['wasted_human']}. Largest: "
            + "; ".join(f"{Path(g['files'][0]).name} x{g['count']} ({g['size_human']})" for g in top)
        )
    return result


# ===========================================================================
# ORGANISE
# ===========================================================================
CATEGORY_MAP: Dict[str, List[str]] = {
    "Documents": [".pdf", ".docx", ".doc", ".odt", ".rtf", ".txt", ".md", ".tex", ".pages"],
    "Spreadsheets": [".xlsx", ".xls", ".csv", ".tsv", ".ods", ".numbers"],
    "Presentations": [".pptx", ".ppt", ".key", ".odp"],
    "Images": [".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".heic", ".svg", ".tif", ".tiff", ".raw"],
    "Videos": [".mp4", ".mkv", ".avi", ".mov", ".webm", ".flv", ".wmv", ".m4v"],
    "Audio": [".mp3", ".wav", ".flac", ".m4a", ".ogg", ".aac", ".wma", ".opus"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".iso"],
    "Code": [".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".kt", ".c", ".cpp", ".h", ".cs", ".go",
             ".rs", ".rb", ".php", ".swift", ".sh", ".ps1", ".bat", ".sql", ".html", ".css",
             ".json", ".yaml", ".yml", ".toml", ".xml", ".vue", ".svelte"],
    "Ebooks": [".epub", ".mobi", ".azw", ".azw3", ".djvu"],
    "Fonts": [".ttf", ".otf", ".woff", ".woff2"],
    "Installers": [".exe", ".msi", ".apk", ".dmg", ".pkg", ".deb", ".rpm", ".appimage"],
}


def _category_for(ext: str) -> str:
    ext = ext.lower()
    for cat, exts in CATEGORY_MAP.items():
        if ext in exts:
            return cat
    return "Other"


@tool(
    name="files.plan_organise",
    capability="files.search",
    agent="reasoning",
    device="pc",
    description="Analyse a folder and propose an organisation plan without changing anything",
    risk="LOW",
    timeout=300,
)
async def plan_organise(ctx: ToolContext, folder: str = "", strategy: str = "type",
                        query: str = "") -> Dict[str, Any]:
    root = Path(folder or (settings.allowed_roots[0] if settings.allowed_roots else "."))
    try:
        root = assert_allowed(root)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc)}
    if not root.exists():
        return {"ok": False, "error": f"folder does not exist: {root}"}

    strategy = (strategy or "type").lower()
    if query and "date" in query.lower():
        strategy = "date"
    if query and ("project" in query.lower() or "name" in query.lower()):
        strategy = "type"

    plan: List[Dict[str, Any]] = []
    groups: Dict[str, List[Path]] = defaultdict(list)
    for path in walk(root, max_files=20_000):
        if path.parent == root:
            key = _category_for(path.suffix) if strategy == "type" else \
                time.strftime("%Y-%m", time.localtime(path.stat().st_mtime)) if strategy == "date" else "All"
            groups[key].append(path)
        if len(plan) > 20_000:
            break

    for key, files in sorted(groups.items()):
        dest_dir = root / key
        for f in files[:2000]:
            plan.append({
                "from": str(f),
                "to": str(dest_dir / f.name),
                "category": key,
                "size_human": human_size(f.stat().st_size),
                "collision": (dest_dir / f.name).exists(),
            })

    collisions = sum(1 for p in plan if p["collision"])
    summary = {
        "ok": True, "root": str(root), "strategy": strategy,
        "files": len(plan), "groups": len(groups), "collisions": collisions,
        "group_summary": [{"category": k, "count": len(v),
                           "size_human": human_size(sum(f.stat().st_size for f in v[:2000]))}
                          for k, v in sorted(groups.items(), key=lambda kv: -len(kv[1]))],
        "plan_preview": plan[:40],
        "note": "Nothing was moved. Approve files.organise to apply this plan.",
    }
    return summary


@tool(
    name="files.organise",
    capability="files.move",
    agent="files",
    device="pc",
    description="Apply a file organisation plan (moves files into category/date folders)",
    risk="MEDIUM",
    confirm=True,
    timeout=900,
)
async def organise(ctx: ToolContext, folder: str = "", strategy: str = "type",
                   dry_run: bool = False, max_moves: int = 2000) -> Dict[str, Any]:
    proposal = await plan_organise(ctx, folder=folder, strategy=strategy)
    if not proposal.get("ok"):
        return proposal
    plan = proposal.get("plan_preview") or []

    # rebuild the full plan (plan_organise only previews 40 entries)
    root = assert_allowed(proposal["root"])
    groups: Dict[str, List[Path]] = defaultdict(list)
    for path in walk(root, max_files=20_000):
        if path.parent == root:
            key = _category_for(path.suffix) if strategy == "date" and False else \
                (time.strftime("%Y-%m", time.localtime(path.stat().st_mtime)) if strategy == "date"
                 else _category_for(path.suffix))
            groups[key].append(path)

    if dry_run:
        return {"ok": True, "dry_run": True, "would_move": sum(len(v) for v in groups.values()),
                "groups": {k: len(v) for k, v in groups.items()}}

    moved, failed, skipped = [], [], []
    count = 0
    for key, files in groups.items():
        dest_dir = root / key
        for f in files:
            if count >= max_moves:
                skipped.append({"path": str(f), "reason": "max_moves reached"})
                continue
            target = dest_dir / f.name
            if target.exists():
                stem, ext = f.stem, f.suffix
                i = 1
                while target.exists() and i < 1000:
                    target = dest_dir / f"{stem}_{i}{ext}"
                    i += 1
            try:
                assert_allowed(target, for_write=True)
                dest_dir.mkdir(parents=True, exist_ok=True)
                shutil.move(str(f), str(target))
                moved.append({"from": str(f), "to": str(target), "category": key})
                count += 1
            except (FileSecurityError, OSError, shutil.Error) as exc:
                failed.append({"path": str(f), "error": str(exc)})

    return {
        "ok": not failed, "root": str(root), "strategy": strategy,
        "moved": len(moved), "failed": len(failed), "skipped": len(skipped),
        "moves": moved[:100], "failures": failed[:50], "skipped_items": skipped[:50],
        "verified": all(Path(m["to"]).exists() for m in moved[:50]),
    }


# ===========================================================================
# CONVERSION
# ===========================================================================
@tool(
    name="files.convert",
    capability="files.convert",
    agent="files",
    device="pc",
    description=("Convert between document formats: md/html/txt/csv <-> docx/pdf/xlsx, "
                 "images <-> png/jpg/webp"),
    risk="MEDIUM",
    confirm=True,
    timeout=300,
)
async def files_convert(ctx: ToolContext, path: str = "", to: str = "",
                        output: str = "", query: str = "") -> Dict[str, Any]:
    from backend.app.coding.documents import convert_document

    src = path or _first_path_in(query)
    if not src:
        return {"ok": False, "error": "no source file given"}
    fmt = (to or _target_format(query) or "").lower().lstrip(".")
    if not fmt:
        return {"ok": False, "error": "no target format given (pdf, docx, md, html, txt, csv, xlsx, png, jpg)"}
    try:
        assert_allowed(src)
        if output:
            assert_allowed(output, for_write=True)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, convert_document, src, fmt, output)


def _first_path_in(text: str) -> str:
    m = re.search(r"([A-Za-z]:[\\/][^\s'\"]+|~/[^\s'\"]+|/[^\s'\"]+|\./[^\s'\"]+)", text or "")
    return m.group(1) if m else ""


def _target_format(text: str) -> str:
    m = re.search(r"\b(?:to|as|into)\s+(?:a\s+)?(\w+)\b", (text or "").lower())
    if m and m.group(1) in ("pdf", "docx", "word", "md", "markdown", "html", "txt", "text",
                            "csv", "xlsx", "excel", "png", "jpg", "jpeg", "webp", "pptx"):
        alias = {"word": "docx", "markdown": "md", "text": "txt", "excel": "xlsx", "jpeg": "jpg"}
        return alias.get(m.group(1), m.group(1))
    return ""


# ===========================================================================
# INFO / INDEX
# ===========================================================================
@tool(
    name="files.info",
    capability="files.read",
    agent="files",
    device="pc",
    description="Show metadata for a file or folder (size, dates, hash, mime, permissions)",
    risk="LOW",
    timeout=120,
)
async def files_info(ctx: ToolContext, path: str = "", include_hash: bool = True) -> Dict[str, Any]:
    try:
        p = assert_allowed(path)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}
    if not p.exists():
        return {"ok": False, "error": f"does not exist: {p}"}
    loop = asyncio.get_running_loop()
    info = await loop.run_in_executor(None, lambda: stat_path(p, include_hash=include_hash).to_dict(include_hash=include_hash))
    allowed, reason = is_allowed(p)
    info["ok"] = True
    info["sam_allowed"] = allowed
    info["sam_note"] = reason or "inside an allowed root"
    if p.is_dir():
        children = list(p.iterdir())
        info["children"] = len(children)
        info["child_names"] = [c.name for c in children[:50]]
    return info


@tool(
    name="files.index",
    capability="files.index",
    agent="files",
    device="pc",
    description="Build or refresh the local semantic index over the allowed roots",
    risk="LOW",
    timeout=1800,
)
async def files_index(ctx: ToolContext, folder: str = "", limit: int = 2000,
                      extensions: Optional[List[str]] = None) -> Dict[str, Any]:
    if not settings.files_index_enabled:
        return {"ok": False, "error": "indexing is disabled (FILES_INDEX_ENABLED=false)"}
    from backend.app.files.semantic_index import semantic_index

    roots = [folder] if folder else [str(r) for r in settings.allowed_roots if r.exists()]
    return await semantic_index.build(roots, limit=int(limit), extensions=extensions or settings.index_extensions)


@tool(
    name="memory.semantic_search",
    capability="files.search",
    agent="memory",
    device="pc",
    description="Semantic search over indexed file contents ('the invoice from Acme last March')",
    risk="LOW",
    timeout=120,
)
async def semantic_search(ctx: ToolContext, query: str = "", limit: int = 10) -> Dict[str, Any]:
    from backend.app.files.semantic_index import semantic_index

    return await semantic_index.search(query, limit=int(limit))


# ===========================================================================
# BACKUP  (spec §Files: "backup")
# ===========================================================================
BACKUP_DIR = settings.sam_data_dir / "backups"


@tool(
    name="files.backup",
    capability="files.backup",
    agent="files",
    device="pc",
    description="Back up a file or folder into SAM's backup store as a timestamped archive",
    schema={"path": {"type": "string", "required": True}},
    risk="MEDIUM",
    confirm=True,
    timeout=1800,
)
async def files_backup(ctx: ToolContext, path: str = "", label: str = "",
                       keep: int = 5, include_hidden: bool = False,
                       target: str = "", request: str = "") -> Dict[str, Any]:
    src_text = path or target or _first_path_in(request or ctx.user_text)
    if not src_text:
        return {"ok": False, "error": "which file or folder should I back up?"}
    try:
        src = assert_allowed(src_text)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}
    if not src.exists():
        return {"ok": False, "error": f"not found: {src}"}

    stamp = time.strftime("%Y%m%d-%H%M%S")
    slug = re.sub(r"[^\w.-]+", "-", (label or src.name)).strip("-")[:60] or "backup"
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    archive_base = BACKUP_DIR / f"{slug}_{stamp}"

    def _do() -> Dict[str, Any]:
        if src.is_file():
            dest = archive_base.with_suffix(src.suffix or ".bak")
            shutil.copy2(src, dest)
            return {"path": str(dest), "bytes": dest.stat().st_size, "files": 1,
                    "kind": "copy"}
        count = 0
        total = 0
        for p in walk(src, max_files=200000):
            if not include_hidden and any(part.startswith(".") for part in p.relative_to(src).parts):
                continue
            count += 1
            try:
                total += p.stat().st_size
            except OSError:
                pass
        made = shutil.make_archive(str(archive_base), "zip", root_dir=str(src.parent),
                                   base_dir=src.name)
        return {"path": made, "bytes": Path(made).stat().st_size, "files": count,
                "source_bytes": total, "kind": "zip"}

    try:
        result = await asyncio.to_thread(_do)
    except (OSError, shutil.Error) as exc:
        return {"ok": False, "error": f"backup failed: {exc}", "source": str(src)}

    # rotate: keep only the newest `keep` backups for this label
    pruned: List[str] = []
    try:
        siblings = sorted(BACKUP_DIR.glob(f"{slug}_*"), reverse=True)
        for old in siblings[max(1, int(keep)):]:
            old.unlink(missing_ok=True)
            pruned.append(old.name)
    except OSError:
        pass

    verified = Path(result["path"]).exists() and Path(result["path"]).stat().st_size > 0
    return {
        "ok": verified, "source": str(src), "backup": result["path"],
        "bytes": result["bytes"], "size": human_size(result["bytes"]),
        "files": result["files"], "kind": result["kind"], "verified": verified,
        "pruned": pruned, "backup_dir": str(BACKUP_DIR),
        "answer": f"Backed up {result['files']} file(s) ({human_size(result['source_bytes']) if 'source_bytes' in result else human_size(result['bytes'])}) "
                  f"to {Path(result['path']).name}.",
    }


@tool(
    name="files.restore",
    capability="files.write",
    agent="files",
    device="pc",
    description="List SAM backups, or restore one back to a destination folder",
    risk="HIGH",
    confirm=True,
    timeout=900,
)
async def files_restore(ctx: ToolContext, backup: str = "", destination: str = "",
                        list_backups: bool = True) -> Dict[str, Any]:
    if list_backups and not backup:
        if not BACKUP_DIR.exists():
            return {"ok": True, "count": 0, "backups": [], "backup_dir": str(BACKUP_DIR)}
        items = []
        for p in sorted(BACKUP_DIR.glob("*"), key=lambda x: x.stat().st_mtime, reverse=True)[:50]:
            if p.is_file():
                items.append({"name": p.name, "path": str(p), "bytes": p.stat().st_size,
                              "size": human_size(p.stat().st_size),
                              "created": time.strftime("%Y-%m-%d %H:%M:%S",
                                                       time.localtime(p.stat().st_mtime))})
        return {"ok": True, "count": len(items), "backups": items,
                "backup_dir": str(BACKUP_DIR)}

    src = Path(backup).expanduser()
    if not src.is_absolute():
        src = BACKUP_DIR / src.name
    if not src.exists():
        return {"ok": False, "error": f"backup not found: {src}"}
    dest = Path(destination).expanduser() if destination else \
        (settings.allowed_roots[0] if settings.allowed_roots else settings.sam_data_dir)
    try:
        dest = assert_allowed(dest, for_write=True)
        assert_allowed(src)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}
    dest.mkdir(parents=True, exist_ok=True)

    def _do() -> int:
        if src.suffix.lower() in (".zip", ".tar", ".gz", ".bz2", ".xz"):
            from backend.app.files.file_ops import extract_archive

            extract_archive(str(src), str(dest))
            return sum(1 for _ in dest.rglob("*") if _.is_file())
        target = dest / src.name
        shutil.copy2(src, target)
        return 1

    try:
        count = await asyncio.to_thread(_do)
    except (OSError, shutil.Error, ValueError) as exc:
        return {"ok": False, "error": f"restore failed: {exc}"}
    return {"ok": True, "restored_from": str(src), "destination": str(dest), "files": count,
            "verified": dest.exists(),
            "answer": f"Restored {src.name} into {dest}."}


# ===========================================================================
# CLEANUP  (temp / cache / junk, always to the recycle bin)
# ===========================================================================
JUNK_DIRS = {
    "windows": [r"%TEMP%", r"%LOCALAPPDATA%\Temp", r"C:\Windows\Temp",
                r"%LOCALAPPDATA%\Microsoft\Windows\INetCache"],
    "linux": ["/tmp", os.path.expanduser("~/.cache")],
    "darwin": [os.path.expanduser("~/Library/Caches"), "/private/tmp"],
}
JUNK_SUFFIXES = (".tmp", ".temp", ".bak", ".old", ".log", ".crdownload", ".part",
                 ".pyc", ".pyo", ".dmp", "~")


@tool(
    name="files.clean",
    capability="files.clean",
    agent="files",
    device="pc",
    description="Find (and optionally clear) temporary, cache and junk files",
    risk="MEDIUM",
    confirm=True,
    timeout=900,
)
async def files_clean(ctx: ToolContext, folder: str = "", apply: bool = False,
                      min_age_days: int = 1, max_mb: int = 2000,
                      include_suffixes: Optional[List[str]] = None,
                      request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    if not folder:
        system = "windows" if os.name == "nt" else ("darwin" if os.uname().sysname == "Darwin" else "linux")
        candidates = JUNK_DIRS.get(system, [])
        roots: List[Path] = []
        for raw in candidates:
            expanded = Path(os.path.expandvars(raw)).expanduser()
            if expanded.exists() and expanded.is_dir():
                roots.append(expanded)
        if not roots:
            roots = [r for r in settings.allowed_roots if r.exists()]
    else:
        try:
            roots = [assert_allowed(folder)]
        except FileSecurityError as exc:
            return {"ok": False, "error": str(exc), "blocked": True}

    suffixes = tuple(s.lower() for s in (include_suffixes or JUNK_SUFFIXES))
    cutoff = time.time() - max(0, int(min_age_days)) * 86400
    budget = int(max_mb) * 1024 * 1024

    def _scan() -> Dict[str, Any]:
        found: List[Dict[str, Any]] = []
        total = 0
        for root in roots:
            for dirpath, dirnames, filenames in os.walk(root, onerror=lambda e: None):
                dirnames[:] = [d for d in dirnames if d not in file_ops.SKIP_DIRS]
                for name in filenames:
                    p = Path(dirpath) / name
                    if not name.lower().endswith(suffixes):
                        continue
                    try:
                        st = p.stat()
                    except OSError:
                        continue
                    if st.st_mtime > cutoff:
                        continue
                    found.append({"path": str(p), "bytes": st.st_size,
                                  "age_days": round((time.time() - st.st_mtime) / 86400, 1)})
                    total += st.st_size
                    if total >= budget or len(found) >= 5000:
                        return {"items": found, "total": total, "truncated": True}
        return {"items": found, "total": total, "truncated": False}

    scan = await asyncio.to_thread(_scan)
    items = scan["items"]
    by_folder: Dict[str, int] = defaultdict(int)
    for it in items:
        by_folder[str(Path(it["path"]).parent)] += it["bytes"]
    top_folders = sorted(({"folder": k, "bytes": v, "size": human_size(v)}
                          for k, v in by_folder.items()), key=lambda x: -x["bytes"])[:10]

    result: Dict[str, Any] = {
        "ok": True, "scanned_roots": [str(r) for r in roots], "candidates": len(items),
        "reclaimable_bytes": scan["total"], "reclaimable": human_size(scan["total"]),
        "top_folders": top_folders, "truncated": scan["truncated"],
        "applied": False, "items": items[:200],
    }

    if not apply or "just find" in text or "how much" in text:
        result["answer"] = (f"Found {len(items):,} junk file(s) — "
                            f"{human_size(scan['total'])} reclaimable. "
                            f"Say “clean it” to move them to the recycle bin.")
        return result

    freed = 0
    deleted = 0
    failures: List[Dict[str, str]] = []
    for it in items:
        try:
            p = assert_allowed(it["path"], for_write=True)
            file_ops.safe_delete(p, to_trash=True)
            freed += it["bytes"]
            deleted += 1
        except (FileSecurityError, OSError) as exc:
            failures.append({"path": it["path"], "error": str(exc)[:160]})
        if freed >= budget:
            break

    result.update({
        "applied": True, "deleted": deleted, "freed_bytes": freed,
        "freed": human_size(freed), "failures": failures[:20],
        "verified": deleted > 0 or not items,
        "answer": f"Cleared {deleted:,} file(s) and reclaimed {human_size(freed)}. "
                  + (f"{len(failures)} could not be removed." if failures else ""),
    })
    return result
