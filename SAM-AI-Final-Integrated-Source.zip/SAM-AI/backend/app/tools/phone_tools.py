"""
backend.app.tools.phone_tools
=============================

The Phone Agent's executable surface.

Each tool sends an RPC to the **SAM Companion** Android app through
:mod:`backend.app.devices.phone_bridge`. If no companion is connected, SAM falls
back to ADB for the small subset of read-only operations ADB can do.

Android stays in charge of security: if the user has not granted the matching
runtime permission, the companion replies ``permission_denied`` and SAM reports
that honestly instead of pretending it worked.

Communication actions (SMS / call / email) follow the required pattern::

    Prepare -> Preview -> User confirmation -> Send
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.devices.phone_bridge import phone_bridge
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.phone")


def _device_id(ctx: ToolContext, explicit: str = "") -> Optional[str]:
    if explicit:
        return explicit
    if ctx.params.get("device_id"):
        return str(ctx.params["device_id"])
    return phone_bridge.first_device_id()


def _no_phone(method: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "blocked": True,
        "method": method,
        "error": ("no Android device is connected to SAM. Install the SAM Companion app, "
                  "pair it with this PC, and grant the matching Android permission."),
        "hint": "Settings -> Devices -> Phone -> Pair, or enable PHONE_TRANSPORT=adb with USB debugging",
    }


# ===========================================================================
# CONNECTION / STATE
# ===========================================================================
@tool(
    name="phone.status",
    capability="phone.state.read",
    agent="phone",
    device="phone",
    description="Report the phone connection, capabilities and Android permissions",
    risk="LOW",
    timeout=30,
)
async def phone_status(ctx: ToolContext) -> Dict[str, Any]:
    status = phone_bridge.status()
    adb = await phone_bridge.adb_devices()
    status["adb_devices"] = adb.get("devices", [])
    return {"ok": True, **status}


@tool(
    name="phone.system_state",
    capability="phone.state.read",
    agent="phone",
    device="phone",
    description="Read battery, wifi, network, storage and display state from the phone",
    risk="LOW",
    timeout=45,
)
async def system_state(ctx: ToolContext, device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("system.state")
    res = await phone_bridge.send(did, "system.state", {})
    if res.get("ok") and isinstance(res.get("result"), dict):
        phone_bridge.update_state(did, res["result"])
    return res


@tool(
    name="phone.battery",
    capability="phone.state.read",
    agent="phone",
    device="phone",
    description="Read phone battery level and charging state",
    risk="LOW",
    timeout=30,
)
async def battery(ctx: ToolContext, device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("battery.get")
    return await phone_bridge.send(did, "battery.get", {})


@tool(
    name="phone.dispatch",
    capability="phone.apps.launch",
    agent="phone",
    device="phone",
    description="Interpret a natural-language phone request and run the matching phone action",
    risk="MEDIUM",
    confirm=True,
    timeout=90,
)
async def dispatch(ctx: ToolContext, request: str = "", device_id: str = "") -> Dict[str, Any]:
    """
    Natural-language phone router. "open whatsapp", "set volume to 60%",
    "turn on wifi", "what's my battery" all land here from the Planner.
    """
    text = (request or ctx.user_text or "").strip().lower()
    if not text:
        return {"ok": False, "error": "no phone request given"}
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("dispatch")

    # --- battery / status -------------------------------------------------
    if re.search(r"\b(battery|charge|charging)\b", text):
        return await phone_bridge.send(did, "battery.get", {})
    if re.search(r"\b(storage|space|memory|free space)\b", text):
        return await phone_bridge.send(did, "storage.get", {})
    if re.search(r"\b(wifi|wi-fi)\b", text):
        if re.search(r"\b(on|enable|turn on|start)\b", text):
            return await phone_bridge.send(did, "wifi.set", {"enabled": True})
        if re.search(r"\b(off|disable|turn off|stop)\b", text):
            return await phone_bridge.send(did, "wifi.set", {"enabled": False})
        return await phone_bridge.send(did, "wifi.state", {})
    if re.search(r"\b(bluetooth)\b", text):
        enabled = not re.search(r"\b(off|disable|turn off)\b", text)
        return await phone_bridge.send(did, "bluetooth.set", {"enabled": enabled})
    if re.search(r"\b(volume|sound|media|ringtone)\b", text):
        m = re.search(r"(\d{1,3})\s*(%|percent)?", text)
        if m:
            percent = min(100, int(m.group(1)))
            return await phone_bridge.send(did, "media.volume", {"percent": percent})
        if re.search(r"\b(mute|silent)\b", text):
            return await phone_bridge.send(did, "media.volume", {"percent": 0})
        if re.search(r"\b(up|louder|increase)\b", text):
            return await phone_bridge.send(did, "media.volume", {"delta": 10})
        if re.search(r"\b(down|quieter|decrease)\b", text):
            return await phone_bridge.send(did, "media.volume", {"delta": -10})
        return await phone_bridge.send(did, "media.state", {})
    if re.search(r"\b(brightness)\b", text):
        m = re.search(r"(\d{1,3})", text)
        return await phone_bridge.send(did, "display.brightness",
                                       {"percent": int(m.group(1)) if m else None})
    if re.search(r"\b(notification)s?\b", text):
        if re.search(r"\b(read|show|list|check|unread)\b", text):
            return await phone_bridge.send(did, "notifications.list", {"limit": 25})
        return await phone_bridge.send(did, "notifications.list", {"limit": 25})
    if re.search(r"\b(alarm|timer|remind)\b", text):
        minutes = _extract_minutes(text)
        label = re.sub(r".*\b(to|for)\b\s*", "", text).strip()[:80] or "SAM reminder"
        if minutes is None:
            return {"ok": False, "error": "could not find a time in that request",
                    "example": "set a timer for 20 minutes"}
        return await phone_bridge.send(did, "alarm.create",
                                       {"minutes": minutes, "label": label})
    if re.search(r"\b(app|apps|installed|applications)\b", text) and re.search(r"\b(list|installed|what)\b", text):
        return await phone_bridge.send(did, "apps.list", {})
    if re.search(r"\b(camera|photo|picture|selfie)\b", text):
        return await phone_bridge.send(did, "media.camera", {"facing": "back"})
    if re.search(r"\b(play|pause|next|previous|stop)\b.*\b(music|song|media|video)\b", text) or \
       re.search(r"\b(music|song|media)\b.*\b(play|pause|next|stop)\b", text):
        cmd = "play_pause"
        if re.search(r"\bnext\b", text):
            cmd = "next"
        elif re.search(r"\b(previous|prev|back)\b", text):
            cmd = "previous"
        elif re.search(r"\bstop\b", text):
            cmd = "stop"
        elif re.search(r"\bplay\b", text):
            cmd = "play"
        elif re.search(r"\bpause\b", text):
            cmd = "pause"
        return await phone_bridge.send(did, "media.control", {"command": cmd})
    if re.search(r"\b(screenshot)\b", text):
        return await phone_bridge.send(did, "screen.capture", {})
    if re.search(r"\b(calendar|event|meeting)\b", text):
        return await phone_bridge.send(did, "calendar.list", {"days": 7})

    # --- open an app ------------------------------------------------------
    if re.search(r"\b(open|launch|start)\b", text):
        app = re.sub(r".*\b(open|launch|start)\b\s*(the\s+|my\s+)?", "", text).strip()
        app = re.sub(r"\b(app|application|on my phone|please)\b", "", app).strip()
        if app:
            return await phone_bridge.send(did, "apps.launch", {"query": app})

    # --- send a message ---------------------------------------------------
    if re.search(r"\b(message|sms|text|whatsapp)\b", text) and re.search(r"\b(send|to)\b", text):
        return await phone_bridge.send(did, "message.prepare", {"request": text})

    return await phone_bridge.send(did, "system.state", {"hint": text})


def _extract_minutes(text: str) -> Optional[int]:
    m = re.search(r"(\d+)\s*(second|sec|minute|min|hour|hr|day)s?", text)
    if not m:
        return None
    n = int(m.group(1))
    unit = m.group(2)
    factor = {"second": 1 / 60, "sec": 1 / 60, "minute": 1, "min": 1,
              "hour": 60, "hr": 60, "day": 1440}[unit]
    return max(1, int(n * factor))


# ===========================================================================
# APPS
# ===========================================================================
@tool(
    name="phone.apps.list",
    capability="phone.state.read",
    agent="phone",
    device="phone",
    description="List applications installed on the phone",
    risk="LOW",
    timeout=45,
)
async def apps_list(ctx: ToolContext, device_id: str = "", search: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("apps.list")
    return await phone_bridge.send(did, "apps.list", {"search": search})


@tool(
    name="phone.apps.launch",
    capability="phone.apps.launch",
    agent="phone",
    device="phone",
    description="Launch an app on the phone by name, package or deep link",
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def apps_launch(ctx: ToolContext, app: str = "", package: str = "", deep_link: str = "",
                      device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("apps.launch")
    params = {k: v for k, v in {"query": app, "package": package, "uri": deep_link}.items() if v}
    if not params:
        return {"ok": False, "error": "no app, package or deep link given"}
    return await phone_bridge.send(did, "apps.launch", params)


# ===========================================================================
# SETTINGS
# ===========================================================================
@tool(
    name="phone.wifi",
    capability="phone.settings.write",
    agent="phone",
    device="phone",
    description="Read or toggle phone Wi-Fi (Android may restrict toggling)",
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def wifi(ctx: ToolContext, enabled: Optional[bool] = None, device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("wifi.set")
    if enabled is None:
        return await phone_bridge.send(did, "wifi.state", {})
    return await phone_bridge.send(did, "wifi.set", {"enabled": bool(enabled)})


@tool(
    name="phone.bluetooth",
    capability="phone.settings.write",
    agent="phone",
    device="phone",
    description="Read or toggle phone Bluetooth",
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def bluetooth(ctx: ToolContext, enabled: Optional[bool] = None,
                    device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("bluetooth.set")
    if enabled is None:
        return await phone_bridge.send(did, "bluetooth.state", {})
    return await phone_bridge.send(did, "bluetooth.set", {"enabled": bool(enabled)})


@tool(
    name="phone.volume",
    capability="phone.settings.write",
    agent="phone",
    device="phone",
    description="Get or set phone media/ring volume (percent or delta)",
    risk="LOW",
    timeout=45,
)
async def phone_volume(ctx: ToolContext, percent: Optional[int] = None, delta: Optional[int] = None,
                       stream: str = "music", device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("media.volume")
    params: Dict[str, Any] = {"stream": stream}
    if percent is not None:
        params["percent"] = max(0, min(100, int(percent)))
    if delta is not None:
        params["delta"] = int(delta)
    return await phone_bridge.send(did, "media.volume", params)


@tool(
    name="phone.brightness",
    capability="phone.settings.write",
    agent="phone",
    device="phone",
    description="Set screen brightness (needs WRITE_SETTINGS granted on the phone)",
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def phone_brightness(ctx: ToolContext, percent: Optional[int] = None,
                           device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("display.brightness")
    return await phone_bridge.send(did, "display.brightness",
                                   {"percent": None if percent is None else max(0, min(100, int(percent)))})


# ===========================================================================
# NOTIFICATIONS
# ===========================================================================
@tool(
    name="phone.notifications.list",
    capability="phone.notifications.read",
    agent="phone",
    device="phone",
    description="Read phone notifications (needs Notification Listener permission)",
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def notifications_list(ctx: ToolContext, limit: int = 25, app: str = "",
                             device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("notifications.list")
    return await phone_bridge.send(did, "notifications.list", {"limit": int(limit), "app": app})


@tool(
    name="phone.notify",
    capability="phone.notifications.post",
    agent="phone",
    device="phone",
    description="Post a notification on the phone",
    risk="LOW",
    timeout=45,
)
async def notify_phone(ctx: ToolContext, title: str = "SAM", body: str = "",
                       request: str = "", device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("notifications.post")
    text = body or request or ctx.user_text
    return await phone_bridge.send(did, "notifications.post",
                                   {"title": title, "body": text[:1000]})


@tool(
    name="phone.alarm",
    capability="phone.alarm",
    agent="phone",
    device="phone",
    description="Create a phone alarm or timer",
    risk="LOW",
    confirm=True,
    timeout=45,
)
async def phone_alarm(ctx: ToolContext, minutes: Optional[int] = None, label: str = "SAM alarm",
                      request: str = "", device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("alarm.create")
    if minutes is None:
        minutes = _extract_minutes(request or ctx.user_text or "")
    if minutes is None:
        return {"ok": False, "error": "no duration found — say e.g. 'set a timer for 20 minutes'"}
    return await phone_bridge.send(did, "alarm.create", {"minutes": int(minutes), "label": label})


# ===========================================================================
# COMMUNICATION  (prepare -> preview -> confirm -> send)
# ===========================================================================
@tool(
    name="phone.message.prepare",
    capability="phone.sms.send",
    agent="communication",
    device="phone",
    description="Draft an SMS/WhatsApp message for preview — does NOT send anything",
    risk="LOW",
    timeout=60,
)
async def message_prepare(ctx: ToolContext, to: str = "", body: str = "", app: str = "sms",
                          request: str = "") -> Dict[str, Any]:
    """
    Stage 1 of the communication pipeline. Always safe: nothing leaves the phone.
    The draft is returned so the UI can show it, then ``phone.message.send``
    performs the actual send after an explicit HIGH-risk confirmation.
    """
    from backend.app.models.router import router

    text = request or ctx.user_text or ""
    if not to and not body:
        parsed = await router.ask_json(
            f"Extract the recipient and the message body from this request. "
            f"Respond ONLY with JSON {{\"to\": \"...\", \"body\": \"...\", \"app\": \"sms|whatsapp\"}}.\n\n"
            f"REQUEST: {text}",
            role="fast", default={},
        )
        if isinstance(parsed, dict):
            to = to or str(parsed.get("to") or "")
            body = body or str(parsed.get("body") or "")
            app = str(parsed.get("app") or app)

    if not body:
        body = text
    draft = {
        "ok": True, "stage": "preview", "to": to, "app": app, "body": body[:1000],
        "char_count": len(body), "segments": (len(body) // 160) + 1,
        "note": ("Nothing has been sent. Review this draft, then confirm to send "
                 "(phone.message.send)."),
    }
    did = _device_id(ctx)
    if did:
        resolved = await phone_bridge.send(did, "contacts.resolve", {"query": to})
        if resolved.get("ok"):
            draft["resolved_contacts"] = resolved.get("result", {}).get("matches", [])
    return draft


@tool(
    name="phone.message.send",
    capability="phone.sms.send",
    agent="communication",
    device="phone",
    description="Send the prepared message from the phone (requires confirmation)",
    risk="HIGH",
    confirm=True,
    timeout=90,
)
async def message_send(ctx: ToolContext, to: str = "", body: str = "", app: str = "sms",
                       device_id: str = "") -> Dict[str, Any]:
    if not settings.phone_allow_sms:
        return {"ok": False, "blocked": True,
                "error": "SMS sending is disabled (PHONE_ALLOW_SMS=false in .env)"}
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("message.send")
    if not to:
        return {"ok": False, "error": "no recipient"}
    return await phone_bridge.send(did, "message.send",
                                   {"to": to, "body": body[:1000], "app": app})


@tool(
    name="phone.call",
    capability="phone.call",
    agent="communication",
    device="phone",
    description="Place a phone call (dial only; the user still presses call on Android)",
    risk="HIGH",
    confirm=True,
    timeout=60,
)
async def phone_call(ctx: ToolContext, number: str = "", contact: str = "",
                     device_id: str = "") -> Dict[str, Any]:
    if not settings.phone_allow_calls:
        return {"ok": False, "blocked": True,
                "error": "calls are disabled (PHONE_ALLOW_CALLS=false in .env)"}
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("call.dial")
    target = number or contact
    if not target:
        return {"ok": False, "error": "no number or contact given"}
    return await phone_bridge.send(did, "call.dial", {"target": target})


@tool(
    name="phone.contacts",
    capability="phone.contacts",
    agent="communication",
    device="phone",
    description="Search phone contacts",
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def contacts(ctx: ToolContext, query: str = "", limit: int = 20,
                   device_id: str = "") -> Dict[str, Any]:
    if not settings.phone_allow_contacts:
        return {"ok": False, "blocked": True,
                "error": "contacts are disabled (PHONE_ALLOW_CONTACTS=false in .env)"}
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("contacts.search")
    return await phone_bridge.send(did, "contacts.search", {"query": query, "limit": int(limit)})


@tool(
    name="phone.calendar",
    capability="phone.calendar",
    agent="planning",
    device="phone",
    description="List or create phone calendar events",
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def calendar(ctx: ToolContext, action: str = "list", title: str = "",
                   start: str = "", days: int = 7, device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("calendar." + action)
    if action in ("list", "read", "get"):
        return await phone_bridge.send(did, "calendar.list", {"days": int(days)})
    if action in ("create", "add"):
        if not title or not start:
            return {"ok": False, "error": "create needs a title and a start time"}
        return await phone_bridge.send(did, "calendar.create", {"title": title, "start": start})
    return {"ok": False, "error": f"unknown calendar action '{action}'"}


# ===========================================================================
# MEDIA / FILES
# ===========================================================================
@tool(
    name="phone.media",
    capability="phone.media",
    agent="phone",
    device="phone",
    description="Control phone media playback or open the camera",
    risk="LOW",
    confirm=True,
    timeout=45,
)
async def media(ctx: ToolContext, command: str = "play_pause", device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("media.control")
    if command not in ("play", "pause", "play_pause", "next", "previous", "stop"):
        return {"ok": False, "error": f"unknown media command '{command}'"}
    return await phone_bridge.send(did, "media.control", {"command": command})


@tool(
    name="phone.files.list",
    capability="phone.files",
    agent="phone",
    device="phone",
    description="List phone files inside Android-accessible storage",
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def phone_files(ctx: ToolContext, folder: str = "Download", limit: int = 100,
                      device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("files.list")
    return await phone_bridge.send(did, "files.list", {"folder": folder, "limit": int(limit)})


@tool(
    name="phone.screen.capture",
    capability="phone.media",
    agent="vision",
    device="phone",
    description="Capture the phone screen (needs the MediaProjection prompt approved)",
    risk="MEDIUM",
    confirm=True,
    timeout=90,
)
async def phone_screenshot(ctx: ToolContext, device_id: str = "") -> Dict[str, Any]:
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("screen.capture")
    return await phone_bridge.send(did, "screen.capture", {}, timeout=60.0)


@tool(
    name="phone.accessibility.tap",
    capability="phone.accessibility",
    agent="phone",
    device="phone",
    description="Tap or type inside another app via the Accessibility Service (opt-in only)",
    risk="HIGH",
    confirm=True,
    timeout=90,
)
async def accessibility_tap(ctx: ToolContext, action: str = "tap", text: str = "",
                            x: Optional[int] = None, y: Optional[int] = None,
                            device_id: str = "") -> Dict[str, Any]:
    if not settings.phone_allow_accessibility:
        return {"ok": False, "blocked": True,
                "error": ("accessibility automation is disabled "
                          "(PHONE_ALLOW_ACCESSIBILITY=false in .env)")}
    did = _device_id(ctx, device_id)
    if not did:
        return _no_phone("accessibility." + action)
    return await phone_bridge.send(did, f"accessibility.{action}",
                                   {"text": text, "x": x, "y": y})
