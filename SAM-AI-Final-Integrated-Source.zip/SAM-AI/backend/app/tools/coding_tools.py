"""
backend.app.tools.coding_tools
==============================

The Coding Agent's pipeline::

    Requirement Analyzer -> Architecture Planner -> Code Generator -> File Manager
    -> Execution Engine -> Test Engine -> Error Analyzer -> Repair Engine
    -> Retest -> Documentation

Each stage is a separate tool so the Planner can run only the stages a request
actually needs, and so a failure in one stage does not lose the work of the
previous ones.
"""

from __future__ import annotations

import asyncio
import json
import re
import shutil
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.files.file_ops import FileSecurityError, assert_allowed
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.coding")

LANG_EXT = {
    "python": ".py", "javascript": ".js", "typescript": ".ts", "java": ".java",
    "kotlin": ".kt", "c": ".c", "cpp": ".cpp", "csharp": ".cs", "go": ".go",
    "rust": ".rs", "html": ".html", "css": ".css", "sql": ".sql", "bash": ".sh",
    "powershell": ".ps1", "json": ".json", "yaml": ".yml", "markdown": ".md",
    "php": ".php", "ruby": ".rb", "swift": ".swift", "dart": ".dart",
}
EXT_LANG = {v: k for k, v in LANG_EXT.items()}

RUNNERS: Dict[str, List[str]] = {
    "python": ["python", "{file}"],
    "javascript": ["node", "{file}"],
    "typescript": ["npx", "ts-node", "{file}"],
    "bash": ["bash", "{file}"],
    "java": ["java", "{file}"],
    "go": ["go", "run", "{file}"],
    "rust": ["cargo", "run"],
    "c": ["gcc", "{file}", "-o", "{out}", "&&", "{out}"],
    "cpp": ["g++", "{file}", "-o", "{out}", "&&", "{out}"],
}


def _detect_language(text: str, path_hint: str = "") -> str:
    if path_hint:
        ext = Path(path_hint).suffix.lower()
        if ext in EXT_LANG:
            return EXT_LANG[ext]
    low = (text or "").lower()
    for lang in ("python", "javascript", "typescript", "java", "kotlin", "c++", "c#", "go",
                 "rust", "html", "css", "sql", "bash", "powershell", "php", "ruby", "swift",
                 "dart", "react", "node"):
        if lang in low:
            return {"c++": "cpp", "c#": "csharp", "react": "javascript", "node": "javascript"}.get(lang, lang)
    if re.search(r"\b(def |import |print\(|pandas|numpy|flask|fastapi)\b", text):
        return "python"
    if re.search(r"\b(const |let |=> |console\.log)\b", text):
        return "javascript"
    if re.search(r"\b(public static void main|System\.out)\b", text):
        return "java"
    if re.search(r"\b(SELECT|INSERT|UPDATE|CREATE TABLE)\b", text, re.I):
        return "sql"
    return "python"


# ===========================================================================
# 1. REQUIREMENT ANALYZER
# ===========================================================================
@tool(
    name="coding.analyse",
    capability="ai.reasoning",
    agent="coding",
    device="pc",
    description="Analyse a coding request into concrete, testable requirements",
    risk="LOW",
    timeout=120,
)
async def coding_analyse(ctx: ToolContext, goal: str = "", language: str = "",
                         project_path: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.models.router import router

    brief = goal or request or ctx.user_text
    if not brief:
        return {"ok": False, "error": "no coding goal given"}
    lang = language or _detect_language(brief, project_path)

    existing = ""
    if project_path:
        try:
            root = assert_allowed(project_path)
            if root.exists():
                existing = _describe_project(root)
        except FileSecurityError as exc:
            existing = f"(could not read the project: {exc})"

    prompt = f"""You are SAM's Coding Brain, stage 1: Requirement Analyzer.

GOAL:
{brief}

LANGUAGE: {lang}
EXISTING PROJECT CONTEXT:
{existing or '(new project)'}

Return ONLY valid JSON:
{{
  "summary": "one sentence restating the goal",
  "language": "{lang}",
  "requirements": [{{"id": "R1", "text": "...", "priority": "must|should|could",
                     "testable": "how we will know it works"}}],
  "constraints": ["..."],
  "assumptions": ["..."],
  "risks": ["..."],
  "out_of_scope": ["..."],
  "deliverables": ["file or artefact names"],
  "estimated_complexity": "low|medium|high"
}}"""
    data = await router.ask_json(prompt, role="coding", temperature=0.2, default=None)
    if not isinstance(data, dict):
        data = {
            "summary": brief[:200], "language": lang,
            "requirements": [{"id": "R1", "text": brief, "priority": "must",
                              "testable": "the program runs and produces the expected output"}],
            "constraints": [], "assumptions": ["no external services are required"],
            "risks": ["requirements are inferred from a short prompt"],
            "out_of_scope": [], "deliverables": [f"main{LANG_EXT.get(lang, '.py')}"],
            "estimated_complexity": "medium", "generated_by": "sam-offline-heuristic",
        }
    data.update({"ok": True, "goal": brief, "stage": "requirements"})
    return data


def _describe_project(root: Path, max_files: int = 60) -> str:
    from backend.app.files.file_ops import SKIP_DIRS, walk

    lines = [f"ROOT: {root}"]
    files: List[str] = []
    for p in walk(root, max_files=5000):
        rel = p.relative_to(root).as_posix()
        files.append(rel)
        if len(files) >= max_files:
            break
    lines.append(f"FILES ({len(files)} shown):")
    lines += [f"  {f}" for f in files]
    for marker in ("package.json", "requirements.txt", "pyproject.toml", "Cargo.toml",
                   "go.mod", "pom.xml", "build.gradle", "build.gradle.kts", "README.md"):
        mp = root / marker
        if mp.exists():
            try:
                lines.append(f"\n--- {marker} ---\n{mp.read_text(encoding='utf-8', errors='replace')[:1200]}")
            except Exception:
                pass
    return "\n".join(lines)[:6000]


# ===========================================================================
# 2. ARCHITECTURE PLANNER
# ===========================================================================
@tool(
    name="coding.architecture",
    capability="ai.reasoning",
    agent="reasoning",
    device="pc",
    description="Design the file/module architecture for the analysed requirements",
    risk="LOW",
    timeout=150,
)
async def coding_architecture(ctx: ToolContext, goal: str = "", language: str = "",
                              project_path: str = "") -> Dict[str, Any]:
    from backend.app.models.router import router

    prior: Dict[str, Any] = {}
    for value in (ctx.outputs or {}).values():
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict) and inner.get("requirements"):
                prior = inner
                break
    brief = goal or prior.get("goal") or ctx.user_text
    lang = language or prior.get("language") or _detect_language(brief, project_path)

    prompt = f"""You are SAM's Coding Brain, stage 2: Architecture Planner.

GOAL: {brief}
LANGUAGE: {lang}
REQUIREMENTS:
{json.dumps(prior.get('requirements', []), indent=2)[:3000] or '(not analysed)'}

Design a minimal, clean architecture. Return ONLY valid JSON:
{{
  "pattern": "e.g. single-module CLI / layered service / MVC web app",
  "language": "{lang}",
  "files": [
    {{"path": "relative/path", "purpose": "one line",
      "public_api": ["function or class names"], "depends_on": ["other paths"]}}
  ],
  "dependencies": ["third-party packages, with a reason each"],
  "data_model": ["entities and their fields, if any"],
  "test_plan": ["what each test asserts"],
  "run_command": "exact command to run the result",
  "notes": ["trade-offs you made"]
}}
Keep it to the fewest files that satisfy the requirements."""
    data = await router.ask_json(prompt, role="reasoning", temperature=0.25, default=None)
    if not isinstance(data, dict):
        main_file = f"main{LANG_EXT.get(lang, '.py')}"
        data = {
            "pattern": "single-module script", "language": lang,
            "files": [{"path": main_file, "purpose": brief[:120], "public_api": ["main"],
                       "depends_on": []},
                      {"path": f"test_main{LANG_EXT.get(lang, '.py')}",
                       "purpose": "smoke tests", "public_api": ["test_main"], "depends_on": [main_file]},
                      {"path": "README.md", "purpose": "how to run it", "public_api": [],
                       "depends_on": []}],
            "dependencies": [], "data_model": [], "test_plan": ["the program exits 0"],
            "run_command": f"python {main_file}" if lang == "python" else f"node {main_file}",
            "notes": ["offline fallback architecture"], "generated_by": "sam-offline-heuristic",
        }
    data.update({"ok": True, "goal": brief, "stage": "architecture"})
    return data


# ===========================================================================
# 3. CODE GENERATOR
# ===========================================================================
@tool(
    name="coding.generate",
    capability="ai.reasoning",
    agent="coding",
    device="pc",
    description="Generate the source code for the planned architecture",
    risk="MEDIUM",
    timeout=300,
)
async def coding_generate(ctx: ToolContext, goal: str = "", language: str = "",
                          files: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    from backend.app.models.router import router

    prior_files: List[Dict[str, Any]] = []
    prior_goal = ""
    for value in (ctx.outputs or {}).values():
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict):
                if inner.get("files"):
                    prior_files = inner["files"]
                    prior_goal = inner.get("goal") or prior_goal
                if inner.get("requirements") and not prior_goal:
                    prior_goal = inner.get("goal", "")
    plan = files or prior_files
    brief = goal or prior_goal or ctx.user_text
    lang = language or _detect_language(brief)
    if not plan:
        plan = [{"path": f"main{LANG_EXT.get(lang, '.py')}", "purpose": brief[:120],
                 "public_api": ["main"], "depends_on": []}]

    generated: List[Dict[str, Any]] = []
    for spec in plan[:12]:
        path = str(spec.get("path") or f"file{len(generated)}{LANG_EXT.get(lang, '.py')}")
        purpose = str(spec.get("purpose") or "")
        api = ", ".join(spec.get("public_api") or []) or "n/a"
        deps = ", ".join(spec.get("depends_on") or []) or "none"

        prompt = f"""You are SAM's Coding Brain, stage 3: Code Generator.

PROJECT GOAL: {brief}
LANGUAGE: {lang}
FILE TO WRITE: {path}
PURPOSE: {purpose}
PUBLIC API: {api}
DEPENDS ON: {deps}

Write the COMPLETE file. Rules:
- Production quality: types, error handling, no placeholder comments like "TODO".
- Only standard library unless a dependency was explicitly planned.
- Include a short module docstring explaining what this file does.
- No secrets, no network calls that were not requested.

Respond with ONLY the file content inside one fenced code block:
```{lang}
...
```"""
        res = await router.ask(prompt, role="coding", temperature=0.2, max_tokens=3000)
        code = _extract_code_block(res.text)
        generated.append({
            "path": path, "language": lang, "purpose": purpose, "code": code,
            "lines": len(code.splitlines()), "chars": len(code),
            "model": res.model, "provider": res.provider,
            "looks_complete": _looks_complete(code, lang),
        })

    return {"ok": True, "stage": "generation", "goal": brief, "language": lang,
            "file_count": len(generated), "files": generated,
            "total_lines": sum(f["lines"] for f in generated)}


def _extract_code_block(text: str) -> str:
    if not text:
        return ""
    blocks = re.findall(r"```[\w+-]*\n(.*?)```", text, re.S)
    if blocks:
        return max(blocks, key=len).strip("\n")
    # no fence: assume the whole thing is code if it looks like it
    stripped = text.strip()
    if stripped and not stripped.startswith(("Here", "Sure", "This", "Below", "#1")):
        return stripped
    return ""


def _looks_complete(code: str, lang: str) -> bool:
    if not code or len(code) < 20:
        return False
    if re.search(r"\b(TODO|FIXME|placeholder|\.\.\.\s*$|pass  # )", code):
        return False
    if lang == "python" and not re.search(r"\b(def |class |import |print\()", code):
        return False
    return True


# ===========================================================================
# 4. FILE MANAGER
# ===========================================================================
@tool(
    name="coding.write_files",
    capability="coding.file.write",
    agent="coding",
    device="pc",
    description="Write generated source files into a project directory",
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def coding_write_files(ctx: ToolContext, project_path: str = "",
                             files: Optional[List[Dict[str, Any]]] = None,
                             overwrite: bool = True) -> Dict[str, Any]:
    prior = files
    if not prior:
        for value in (ctx.outputs or {}).values():
            if isinstance(value, dict):
                inner = value.get("value") if isinstance(value.get("value"), dict) else value
                if isinstance(inner, dict) and inner.get("files") and \
                        any(isinstance(f, dict) and f.get("code") for f in inner["files"]):
                    prior = inner["files"]
                    break
    if not prior:
        return {"ok": False, "error": "no generated files to write"}

    root = Path(project_path or _default_project_dir(ctx))
    try:
        root = assert_allowed(root, for_write=True)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}
    root.mkdir(parents=True, exist_ok=True)

    written: List[Dict[str, Any]] = []
    failed: List[Dict[str, Any]] = []
    for spec in prior[:40]:
        if not isinstance(spec, dict):
            continue
        rel = str(spec.get("path") or "").strip().lstrip("/\\")
        code = spec.get("code")
        if not rel or code is None:
            continue
        rel = re.sub(r"[<>:\"|?*\x00-\x1f]", "_", rel)
        target = (root / rel).resolve()
        # path traversal guard
        if not str(target).startswith(str(root.resolve())):
            failed.append({"path": rel, "error": "path escapes the project directory"})
            continue
        try:
            assert_allowed(target, for_write=True)
        except FileSecurityError as exc:
            failed.append({"path": rel, "error": str(exc)})
            continue
        if target.exists() and not overwrite:
            failed.append({"path": rel, "error": "exists and overwrite=false"})
            continue
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(str(code), encoding="utf-8")
            written.append({"path": str(target), "relative": rel, "bytes": target.stat().st_size,
                            "lines": len(str(code).splitlines())})
        except OSError as exc:
            failed.append({"path": rel, "error": str(exc)})

    return {"ok": not failed, "root": str(root), "written": len(written),
            "failed": len(failed), "files": written, "failures": failed,
            "verified": all(Path(f["path"]).exists() for f in written)}


def _default_project_dir(ctx: ToolContext) -> str:
    slug = re.sub(r"[^\w]+", "-", (ctx.user_text or "sam-project").lower())[:40].strip("-")
    base = settings.allowed_roots[0] if settings.allowed_roots else settings.sam_data_dir / "projects"
    return str(Path(base) / "SAM-Projects" / f"{slug or 'project'}-{int(time.time()) % 100000}")


# ===========================================================================
# 5-6. EXECUTION + TEST ENGINE
# ===========================================================================
@tool(
    name="coding.run_tests",
    capability="coding.test",
    agent="coding",
    device="pc",
    description="Run the project (or its test suite) and capture the output",
    risk="HIGH",
    confirm=True,
    timeout=600,
)
async def coding_run_tests(ctx: ToolContext, project_path: str = "", command: str = "",
                           language: str = "") -> Dict[str, Any]:
    root = Path(project_path or _project_from_ctx(ctx))
    if not root or not root.exists():
        return {"ok": False, "error": f"project directory not found: {root}"}
    try:
        assert_allowed(root)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}

    cmd = command or _infer_test_command(root, language)
    if not cmd:
        return {"ok": False, "error": "could not infer a test command for this project",
                "root": str(root),
                "hint": "pass command explicitly, e.g. 'pytest -q' or 'npm test'"}

    terminal = registry.get("pc.terminal")
    if terminal is None:
        return {"ok": False, "error": "terminal tool is not registered"}
    result = await terminal.fn(ctx, command=cmd, cwd=str(root), timeout=300)

    analysis = _analyse_test_output(result.get("stdout", "") + "\n" + result.get("stderr", ""))
    return {
        "ok": bool(result.get("ok")),
        "command": cmd,
        "root": str(root),
        "returncode": result.get("returncode"),
        "stdout": result.get("stdout", "")[:20000],
        "stderr": result.get("stderr", "")[:8000],
        "duration_ms": result.get("duration_ms"),
        "tests": analysis,
        "blocked": result.get("blocked", False),
        "error": result.get("error"),
    }


def _project_from_ctx(ctx: ToolContext) -> str:
    for value in (ctx.outputs or {}).values():
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict) and inner.get("root"):
                return str(inner["root"])
    return ctx.params.get("project_path") or ""


def _infer_test_command(root: Path, language: str = "") -> str:
    if (root / "pytest.ini").exists() or (root / "pyproject.toml").exists() or \
            list(root.glob("test_*.py")) or list(root.glob("**/test_*.py"))[:1]:
        if shutil.which("pytest"):
            return "pytest -q --maxfail=5"
        return "python -m pytest -q --maxfail=5"
    if (root / "package.json").exists():
        try:
            pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
            scripts = pkg.get("scripts", {})
            if "test" in scripts:
                return "npm test --silent"
        except Exception:
            pass
        return "npm test --silent"
    if (root / "Cargo.toml").exists():
        return "cargo test --quiet"
    if (root / "go.mod").exists():
        return "go test ./..."
    if (root / "pom.xml").exists():
        return "mvn -q test"
    if (root / "build.gradle").exists() or (root / "build.gradle.kts").exists():
        return "gradle test --console=plain"
    if (root / "requirements.txt").exists() or list(root.glob("*.py")):
        mains = [p for p in root.glob("*.py") if p.name in ("main.py", "app.py", "run.py")]
        if mains:
            return f"python {mains[0].name}"
        return "python -m compileall -q ."
    if list(root.glob("*.js")):
        mains = [p for p in root.glob("*.js") if p.name in ("index.js", "main.js", "app.js")]
        if mains:
            return f"node {mains[0].name}"
    return ""


def _analyse_test_output(output: str) -> Dict[str, Any]:
    """Parse common test-runner output into a summary."""
    out = output or ""
    summary: Dict[str, Any] = {"passed": None, "failed": None, "total": None,
                               "failures": [], "errors": []}

    m = re.search(r"(\d+) passed", out)
    if m:
        summary["passed"] = int(m.group(1))
    m = re.search(r"(\d+) failed", out)
    if m:
        summary["failed"] = int(m.group(1))
    m = re.search(r"(\d+) error", out)
    if m:
        summary["errors"].append(f"{m.group(1)} collection/import errors")
    m = re.search(r"Tests:\s*(\d+) passed,\s*(\d+) total", out)      # jest
    if m:
        summary["passed"], summary["total"] = int(m.group(1)), int(m.group(2))
    m = re.search(r"FAIL\s+(\S+)", out)
    if m:
        summary["failures"].append(m.group(1))

    # python tracebacks
    for tb in re.finditer(r'File "([^"]+)", line (\d+), in (\S+)\n\s*(.*)', out):
        summary["failures"].append({"file": tb.group(1), "line": int(tb.group(2)),
                                    "function": tb.group(3), "code": tb.group(4).strip()[:160]})
    exc = re.findall(r"^(\w*(?:Error|Exception|Failure))\s*:\s*(.*)$", out, re.M)
    for kind, msg in exc[:10]:
        summary["errors"].append(f"{kind}: {msg[:200]}")

    if summary["passed"] is not None and summary["failed"] is not None:
        summary["total"] = summary["passed"] + summary["failed"]
    summary["failures"] = summary["failures"][:12]
    return summary


# ===========================================================================
# 7-8. ERROR ANALYZER + REPAIR ENGINE
# ===========================================================================
@tool(
    name="coding.analyse_error",
    capability="ai.reasoning",
    agent="reasoning",
    device="pc",
    description="Diagnose a build/test/runtime error and propose a precise fix",
    risk="LOW",
    timeout=150,
)
async def coding_analyse_error(ctx: ToolContext, error: str = "", problem: str = "",
                               project_path: str = "") -> Dict[str, Any]:
    from backend.app.models.router import router

    prior = ""
    for value in (ctx.outputs or {}).values():
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict) and (inner.get("stderr") or inner.get("tests")):
                prior = json.dumps({
                    "command": inner.get("command"), "returncode": inner.get("returncode"),
                    "stderr": (inner.get("stderr") or "")[:3000],
                    "tests": inner.get("tests"),
                }, indent=2)
                break
    blob = error or problem or prior or ctx.user_text
    if not blob:
        return {"ok": False, "error": "no error information to analyse"}

    root = Path(project_path or _project_from_ctx(ctx))
    context = ""
    if root and root.exists():
        try:
            assert_allowed(root)
            context = _describe_project(root)
        except FileSecurityError:
            context = ""

    prompt = f"""You are SAM's Coding Brain, stage 7: Error Analyzer.

FAILURE OUTPUT:
{blob[:8000]}

PROJECT CONTEXT:
{context[:4000] or '(unknown)'}

Return ONLY valid JSON:
{{
  "root_cause": "one precise sentence",
  "category": "syntax|import|runtime|logic|environment|test|build|permission|network",
  "confidence": 0.0,
  "fix": "what must change, concretely",
  "files": [{{"path": "...", "change": "..."}}],
  "commands": ["commands to apply/verify the fix"],
  "prevention": "how to stop this recurring"
}}"""
    data = await router.ask_json(prompt, role="reasoning", temperature=0.15, default=None)
    if not isinstance(data, dict):
        data = _heuristic_diagnosis(blob)
        data["generated_by"] = "sam-offline-heuristic"
    data.update({"ok": True, "stage": "diagnosis"})
    return data


def _heuristic_diagnosis(blob: str) -> Dict[str, Any]:
    rules: List[Tuple[str, str, str, List[str]]] = [
        (r"ModuleNotFoundError: No module named '([^']+)'", "import",
         "a required Python package is not installed",
         ["pip install {1}"]),
        (r"Cannot find module '([^']+)'", "import", "a Node package is missing",
         ["npm install {1}"]),
        (r"SyntaxError", "syntax", "the source has a syntax error", []),
        (r"IndentationError", "syntax", "inconsistent indentation", []),
        (r"NameError: name '([^']+)' is not defined", "runtime",
         "a variable is used before it is defined", []),
        (r"TypeError: (.*)", "runtime", "a value of the wrong type was used", []),
        (r"KeyError: (.*)", "runtime", "a dictionary key is missing", []),
        (r"IndexError", "runtime", "a list index is out of range", []),
        (r"PermissionError|Access is denied|EACCES", "permission",
         "the process lacks permission for that path or port", []),
        (r"Address already in use|EADDRINUSE", "environment",
         "another process already owns that port", []),
        (r"command not found|is not recognized", "environment",
         "a required executable is not on PATH", []),
        (r"ConnectionError|getaddrinfo|ENOTFOUND|Failed to resolve", "network",
         "a network host could not be reached", []),
        (r"assert|AssertionError|FAILED", "test", "a test assertion failed", []),
        (r"Traceback \(most recent call last\)", "runtime", "an unhandled Python exception", []),
    ]
    for pattern, category, cause, commands in rules:
        m = re.search(pattern, blob)
        if m:
            cmds = [c.format(*m.groups()) if "{1}" in c else c for c in commands]
            return {
                "root_cause": cause + (f": {m.group(1)}" if m.groups() else ""),
                "category": category, "confidence": 0.6,
                "fix": f"Address the {category} error: {cause}.",
                "files": [], "commands": cmds,
                "prevention": "add a check or test that catches this before runtime",
                "matched": m.group(0)[:200],
            }
    return {"root_cause": "the failure output did not match a known pattern",
            "category": "unknown", "confidence": 0.2,
            "fix": "re-run with more verbose logging and inspect the first error, not the last",
            "files": [], "commands": [], "prevention": "add structured logging"}


@tool(
    name="coding.repair",
    capability="coding.file.write",
    agent="coding",
    device="pc",
    description="Apply the diagnosed fix to the source files",
    risk="MEDIUM",
    confirm=True,
    timeout=300,
)
async def coding_repair(ctx: ToolContext, project_path: str = "", fix: str = "",
                        files: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    from backend.app.models.router import router

    diagnosis: Dict[str, Any] = {}
    failure: Dict[str, Any] = {}
    for value in (ctx.outputs or {}).values():
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict):
                if inner.get("root_cause"):
                    diagnosis = inner
                if inner.get("stderr") or inner.get("tests"):
                    failure = inner

    root = Path(project_path or diagnosis.get("project_path") or _project_from_ctx(ctx))
    if not root.exists():
        return {"ok": False, "error": f"project directory not found: {root}"}
    try:
        assert_allowed(root, for_write=True)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}

    # candidate files: from the diagnosis, or every source file in the project
    targets = [root / f["path"] for f in (files or diagnosis.get("files") or [])
               if isinstance(f, dict) and f.get("path")]
    if not targets:
        targets = [p for p in root.rglob("*")
                   if p.is_file() and p.suffix.lower() in set(LANG_EXT.values())
                   and not any(part in p.parts for part in ("node_modules", ".git", ".venv"))][:12]
    if not targets:
        return {"ok": False, "error": "no source files found to repair", "root": str(root)}

    sources = ""
    for t in targets:
        try:
            content = t.read_text(encoding="utf-8", errors="replace")[:12000]
        except OSError:
            continue
        sources += f"\n\n===== FILE: {t.relative_to(root).as_posix()} =====\n{content}"

    prompt = f"""You are SAM's Coding Brain, stage 8: Repair Engine.

FAILURE:
{json.dumps({k: failure.get(k) for k in ('command', 'returncode', 'stderr', 'tests') if k in failure}, indent=2)[:3000] or '(no captured failure)'}

DIAGNOSIS:
{json.dumps(diagnosis, indent=2)[:2000] or fix or '(none)'}

SOURCE FILES:
{sources[:16000]}

Produce the corrected version of ONLY the file(s) that must change.
Respond with ONLY valid JSON:
{{
  "explanation": "what was wrong and what you changed",
  "files": [{{"path": "relative/path", "code": "the complete corrected file content"}}]
}}"""
    data = await router.ask_json(prompt, role="coding", temperature=0.15, default=None)
    if not isinstance(data, dict) or not data.get("files"):
        return {"ok": False, "error": "could not produce a repair",
                "diagnosis": diagnosis, "hint": "give SAM a model with coding capability"}

    written: List[Dict[str, Any]] = []
    for spec in data["files"][:8]:
        if not isinstance(spec, dict):
            continue
        rel = str(spec.get("path") or "").strip().lstrip("/\\")
        code = spec.get("code")
        if not rel or not isinstance(code, str):
            continue
        target = (root / rel).resolve()
        if not str(target).startswith(str(root.resolve())):
            continue
        try:
            assert_allowed(target, for_write=True)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(code, encoding="utf-8")
            written.append({"path": str(target), "relative": rel, "lines": len(code.splitlines())})
        except (FileSecurityError, OSError) as exc:
            log.debug("repair write failed for %s: %s", rel, exc)

    return {"ok": bool(written), "stage": "repair", "root": str(root),
            "explanation": data.get("explanation", ""), "files_changed": len(written),
            "files": written, "next": "run coding.run_tests again to confirm the fix"}


# ===========================================================================
# 9. EXPLAIN / DOCUMENT
# ===========================================================================
@tool(
    name="coding.explain",
    capability="files.read",
    agent="coding",
    device="pc",
    description="Explain what a piece of code or a project does, line by line where useful",
    risk="LOW",
    timeout=180,
)
async def coding_explain(ctx: ToolContext, path: str = "", code: str = "",
                         target: str = "", depth: str = "standard") -> Dict[str, Any]:
    from backend.app.models.router import router

    source = code
    resolved = path or _first_path(target or ctx.user_text)
    if not source and resolved:
        try:
            p = assert_allowed(resolved)
            if p.is_file():
                source = p.read_text(encoding="utf-8", errors="replace")[:20000]
            elif p.is_dir():
                source = _describe_project(p)
        except FileSecurityError as exc:
            return {"ok": False, "error": str(exc), "blocked": True}
        except OSError as exc:
            return {"ok": False, "error": f"could not read {resolved}: {exc}"}
    if not source:
        source = ctx.user_text
    if not source.strip():
        return {"ok": False, "error": "nothing to explain — give a file path or paste the code"}

    lang = _detect_language(source, resolved)
    detail = {"standard": "Explain the purpose, the main flow and the key functions.",
              "brief": "Two or three sentences on what this does.",
              "deep": "Explain every function, the data flow, edge cases, complexity and "
                      "anything risky or unclear."}.get(depth, "Explain the purpose and flow.")

    res = await router.ask(
        f"You are SAM's Coding Brain. {detail}\n\nLANGUAGE: {lang}\n"
        f"FILE: {resolved or '(pasted snippet)'}\n\n```\n{source[:16000]}\n```\n\n"
        "Use Markdown. Be concrete. Point out bugs, security issues or dead code if present.",
        role="coding", temperature=0.25, max_tokens=2000,
    )
    return {"ok": True, "path": resolved, "language": lang, "explanation": res.text,
            "model": res.model, "chars": len(source)}


@tool(
    name="coding.document",
    capability="creative.document.generate",
    agent="writing",
    device="pc",
    description="Generate a README / API documentation for a project",
    risk="LOW",
    timeout=180,
)
async def coding_document(ctx: ToolContext, project_path: str = "", write: bool = True) -> Dict[str, Any]:
    from backend.app.models.router import router

    root = Path(project_path or _project_from_ctx(ctx))
    if not root.exists():
        return {"ok": False, "error": f"project directory not found: {root}"}
    try:
        assert_allowed(root)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}

    context = _describe_project(root, max_files=80)
    snippets = ""
    for p in list(root.rglob("*"))[:8]:
        if p.is_file() and p.suffix.lower() in set(LANG_EXT.values()):
            try:
                snippets += f"\n\n--- {p.relative_to(root).as_posix()} ---\n" + \
                            p.read_text(encoding="utf-8", errors="replace")[:2500]
            except OSError:
                continue

    res = await router.ask(
        f"""Write a professional README.md for this project.

PROJECT STRUCTURE:
{context[:5000]}

KEY SOURCE:
{snippets[:9000]}

Include: title, one-paragraph description, features, requirements, installation,
usage with a real command example, project structure tree, configuration, testing,
troubleshooting and licence. Output ONLY the Markdown.""",
        role="primary", temperature=0.35, max_tokens=2500,
    )
    markdown = res.text.strip() or _fallback_readme(root)
    if not markdown.startswith("#"):
        markdown = f"# {root.name}\n\n{markdown}"

    out: Dict[str, Any] = {"ok": True, "markdown": markdown, "root": str(root),
                           "word_count": len(markdown.split())}
    if write:
        target = root / "README.md"
        try:
            assert_allowed(target, for_write=True)
            target.write_text(markdown, encoding="utf-8")
            out["written"] = str(target)
            out["bytes"] = target.stat().st_size
        except (FileSecurityError, OSError) as exc:
            out["write_error"] = str(exc)
    return out


def _fallback_readme(root: Path) -> str:
    files = [p.relative_to(root).as_posix() for p in root.rglob("*")
             if p.is_file() and not any(part in p.parts for part in ("node_modules", ".git"))][:40]
    return "\n".join([
        f"# {root.name}", "",
        "Generated by SAM. Add a real description here.", "",
        "## Project structure", "", "```", *files, "```", "",
        "## Usage", "", "```bash", _infer_test_command(root) or "python main.py", "```", "",
    ])


def _first_path(text: str) -> str:
    m = re.search(r"([A-Za-z]:[\\/][^\s'\"]+|~/[^\s'\"]+|/[^\s'\"]+|\./[^\s'\"]+|[\w\-./\\]+\.\w{1,6})",
                  text or "")
    return m.group(1) if m else ""


# ===========================================================================
# PROJECT SCAFFOLD
# ===========================================================================
@tool(
    name="coding.project.create",
    capability="coding.project.create",
    agent="coding",
    device="pc",
    description="Scaffold a new project with a working skeleton and run instructions",
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def coding_project_create(ctx: ToolContext, name: str = "", kind: str = "python-cli",
                                path: str = "", goal: str = "") -> Dict[str, Any]:
    from backend.app.models.router import router

    name = re.sub(r"[^\w\-]+", "-", (name or _slug(goal or ctx.user_text) or "sam-project")).strip("-")[:60]
    base = Path(path or (settings.allowed_roots[0] if settings.allowed_roots
                         else settings.sam_data_dir / "projects")) / "SAM-Projects" / name
    try:
        base = assert_allowed(base, for_write=True)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}
    if base.exists() and any(base.iterdir()):
        return {"ok": False, "error": f"directory already exists and is not empty: {base}"}
    base.mkdir(parents=True, exist_ok=True)

    data = await router.ask_json(
        f"""Scaffold a `{kind}` project named "{name}". GOAL: {goal or ctx.user_text or '(general)'}

Return ONLY valid JSON:
{{"description": "...",
  "files": [{{"path": "relative/path", "content": "full file content"}}],
  "run": "exact command to run it", "test": "exact command to test it",
  "next_steps": ["..."]}}
Include a README.md, a .gitignore and at least one test file. Keep every file complete.""",
        role="coding", temperature=0.3, default=None,
    )

    written: List[str] = []
    if isinstance(data, dict) and isinstance(data.get("files"), list):
        for spec in data["files"][:30]:
            if not isinstance(spec, dict):
                continue
            rel = str(spec.get("path") or "").strip().lstrip("/\\")
            content = spec.get("content")
            if not rel or not isinstance(content, str):
                continue
            target = (base / rel).resolve()
            if not str(target).startswith(str(base.resolve())):
                continue
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8")
                written.append(rel)
            except OSError:
                continue

    if not written:
        written = _scaffold_offline(base, name, kind, goal or ctx.user_text)

    return {"ok": True, "name": name, "kind": kind, "root": str(base),
            "files": written, "count": len(written),
            "description": (data or {}).get("description", ""),
            "run": (data or {}).get("run", ""), "test": (data or {}).get("test", ""),
            "next_steps": (data or {}).get("next_steps", [])}


def _slug(text: str) -> str:
    words = re.findall(r"[a-zA-Z]{3,}", text or "")[:4]
    return "-".join(w.lower() for w in words)


def _scaffold_offline(base: Path, name: str, kind: str, goal: str) -> List[str]:
    """Minimal but real skeleton so scaffolding never produces an empty folder."""
    written: List[str] = []

    def write(rel: str, content: str) -> None:
        p = base / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        written.append(rel)

    write("README.md", f"""# {name}

{goal or 'A project scaffolded by SAM.'}

## Requirements

- Python 3.11+ (or the toolchain for this project type)

## Install

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

## Run

```bash
python main.py
```

## Test

```bash
pytest -q
```

## Structure

```
{name}/
├── main.py
├── tests/
│   └── test_main.py
├── requirements.txt
└── README.md
```

---
Scaffolded by SAM · {time.strftime('%Y-%m-%d')}
""")
    write(".gitignore", "__pycache__/\n*.pyc\n.venv/\n.env\n.pytest_cache/\ndist/\nbuild/\n")
    write("requirements.txt", "pytest>=8.0\n")
    write("main.py", f'''"""{name} — entry point.

Goal: {goal or "describe the goal here"}
Generated by SAM. Replace the body with the real implementation.
"""

from __future__ import annotations

import sys
from typing import Sequence


def run(argv: Sequence[str]) -> int:
    """Execute the program. Returns a process exit code."""
    if not argv:
        print("{name}: no arguments given. Try --help")
        return 0
    if argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    for item in argv:
        print(f"processing: {{item}}")
    return 0


def main() -> int:
    return run(sys.argv[1:])


if __name__ == "__main__":
    raise SystemExit(main())
''')
    write("tests/test_main.py", f'''"""Smoke tests for {name}."""

from main import run


def test_run_without_arguments_returns_zero() -> None:
    assert run([]) == 0


def test_run_with_arguments_returns_zero() -> None:
    assert run(["alpha", "beta"]) == 0


def test_help_returns_zero() -> None:
    assert run(["--help"]) == 0
''')
    return written
