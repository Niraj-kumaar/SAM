"""
backend.app.tools.registry
==========================

Central registry of every executable tool in SAM.

A **tool** is the smallest unit of action. Tools never touch the OS directly —
they declare the capability they need and the Orchestrator runs them through
:func:`backend.app.core.guard.guard`, which enforces::

    permission check -> risk scoring -> confirmation -> execute -> verify -> audit

Registering a tool::

    @tool(
        name="pc.launch_app",
        capability="pc.apps.launch",
        agent="pc",
        device="pc",
        description="Launch a desktop application by name or path",
        schema={"app": "str"},
    )
    async def launch_app(ctx: ToolContext, app: str) -> dict:
        ...
"""

from __future__ import annotations

import asyncio
import inspect
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional

from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import RiskLevel

log = get_logger("tools.registry")

ToolFn = Callable[..., Awaitable[Any]]


@dataclass
class ToolContext:
    """Everything a tool is allowed to know about the call it is serving."""

    task_id: Optional[str] = None
    step_id: Optional[str] = None
    agent: str = "core"
    device: str = "pc"
    conversation_id: Optional[str] = None
    user_text: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    outputs: Dict[str, Any] = field(default_factory=dict)   # results of prior steps
    language: str = "en"
    dry_run: bool = False
    meta: Dict[str, Any] = field(default_factory=dict)

    def prior(self, *names: str) -> Any:
        """Fetch an earlier step's output by step name or id."""
        for n in names:
            for key, value in self.outputs.items():
                if key == n:
                    return value
            for key, value in self.outputs.items():
                if isinstance(value, dict) and value.get("step_name") == n:
                    return value
        return None


@dataclass
class Tool:
    name: str
    fn: ToolFn
    capability: str
    agent: str = "core"
    device: str = "pc"
    description: str = ""
    schema: Dict[str, Any] = field(default_factory=dict)
    risk: str = "LOW"
    confirm: bool = False
    timeout: int = 120
    retries: int = 1
    verify: Optional[Callable[[Any], Awaitable[bool]]] = None
    platform: Optional[str] = None            # 'windows' | 'linux' | 'darwin' | None (any)
    enabled: bool = True
    calls: int = 0
    failures: int = 0
    total_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "capability": self.capability,
            "agent": self.agent,
            "device": self.device,
            "description": self.description,
            "schema": self.schema,
            "risk": self.risk,
            "confirm": self.confirm,
            "timeout": self.timeout,
            "platform": self.platform,
            "available": self.is_available(),
            "stats": {"calls": self.calls, "failures": self.failures,
                      "avg_ms": round(self.total_ms / self.calls, 1) if self.calls else 0},
        }

    def is_available(self) -> bool:
        if not self.enabled:
            return False
        if self.platform is None:
            return True
        import platform as _pf

        current = {"windows": "Windows", "linux": "Linux", "darwin": "Darwin"}.get(self.platform, "")
        return _pf.system() == current


class ToolRegistry:
    """Name -> Tool lookup with stats and OpenAI-style schema export."""

    def __init__(self) -> None:
        self._tools: Dict[str, Tool] = {}

    # -------------------------------------------------------------- register
    def register(self, tool: Tool) -> Tool:
        if tool.name in self._tools:
            log.debug("re-registering tool %s", tool.name)
        self._tools[tool.name] = tool
        return tool

    def tool(
        self,
        name: str,
        capability: str,
        *,
        agent: str = "core",
        device: str = "pc",
        description: str = "",
        schema: Optional[Dict[str, Any]] = None,
        risk: str = "LOW",
        confirm: bool = False,
        timeout: int = 120,
        retries: int = 1,
        verify: Optional[Callable[[Any], Awaitable[bool]]] = None,
        platform: Optional[str] = None,
    ) -> Callable[[ToolFn], ToolFn]:
        """Decorator form of :meth:`register`."""

        def deco(fn: ToolFn) -> ToolFn:
            self.register(
                Tool(
                    name=name, fn=fn, capability=capability, agent=agent, device=device,
                    description=description or (inspect.getdoc(fn) or "").strip().splitlines()[0:1][0]
                    if inspect.getdoc(fn) else "",
                    schema=schema or _infer_schema(fn), risk=risk, confirm=confirm,
                    timeout=timeout, retries=retries, verify=verify, platform=platform,
                )
            )
            return fn

        return deco

    # ----------------------------------------------------------------- lookup
    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def names(self) -> List[str]:
        return sorted(self._tools)

    def all(self) -> List[Tool]:
        return [self._tools[n] for n in self.names()]

    def by_agent(self, agent: str) -> List[Tool]:
        return [t for t in self.all() if t.agent == agent]

    def available(self) -> List[Tool]:
        return [t for t in self.all() if t.is_available()]

    def stats(self) -> Dict[str, Any]:
        tools = self.all()
        return {
            "total": len(tools),
            "available": sum(1 for t in tools if t.is_available()),
            "by_agent": {
                agent: len([t for t in tools if t.agent == agent])
                for agent in sorted({t.agent for t in tools})
            },
            "calls": sum(t.calls for t in tools),
            "failures": sum(t.failures for t in tools),
        }

    # --------------------------------------------------------------- execute
    async def execute(self, name: str, ctx: ToolContext, **params: Any) -> Any:
        """
        Run a tool **through the security guard**. This is the only supported
        way to invoke a tool.
        """
        from backend.app.core.guard import GuardResult, guard

        tool = self._tools.get(name)
        if tool is None:
            raise KeyError(f"unknown tool: {name}. Known: {', '.join(self.names()[:20])}...")
        if not tool.is_available():
            raise PermissionError(
                f"tool {name} is not available on this platform "
                f"(requires {tool.platform or 'enabled'})"
            )

        # keep only parameters the tool actually accepts
        accepted = _accepted_params(tool.fn)
        kwargs = {k: v for k, v in params.items() if k in accepted} if accepted is not None else params

        # let tools declare their target for path/risk checks
        target = str(
            params.get("path")
            or params.get("url")
            or params.get("app")
            or params.get("command")
            or params.get("target")
            or ""
        )[:500]

        result: GuardResult = await guard(
            capability=tool.capability,
            action=name,
            target=target,
            device=tool.device if tool.device != "both" else ctx.device,
            agent=tool.agent,
            task_id=ctx.task_id,
            params={k: v for k, v in params.items() if isinstance(v, (str, int, float, bool))},
            timeout=tool.timeout,
            verify=tool.verify,
            run=lambda: self._invoke(tool, ctx, kwargs),
        )

        if not result.allowed:
            raise ToolExecutionError(
                message=result.reason or result.error or "blocked by SAM security",
                tool=name,
                denied_by=result.denied_by,
                risk=result.risk.value,
                confirmation_id=result.confirmation_id,
            )
        return result.value

    async def _invoke(self, tool: Tool, ctx: ToolContext, kwargs: Dict[str, Any]) -> Any:
        t0 = time.perf_counter()
        emit(Topics.AGENT_STARTED, agent=tool.agent, tool=tool.name, task_id=ctx.task_id)
        try:
            out = await tool.fn(ctx, **kwargs)
            tool.calls += 1
            tool.total_ms += int((time.perf_counter() - t0) * 1000)
            emit(Topics.AGENT_FINISHED, agent=tool.agent, tool=tool.name, task_id=ctx.task_id,
                 ok=True, ms=tool.total_ms)
            return out
        except Exception as exc:
            tool.failures += 1
            emit(Topics.AGENT_ERROR, agent=tool.agent, tool=tool.name, task_id=ctx.task_id,
                 error=str(exc))
            raise

    # ------------------------------------------------------- LLM tool schema
    def openai_tools(self, agent: Optional[str] = None) -> List[Dict[str, Any]]:
        """Export the registry as OpenAI-style function schemas."""
        out = []
        for t in self.available():
            if agent and t.agent != agent:
                continue
            out.append(
                {
                    "type": "function",
                    "function": {
                        "name": t.name.replace(".", "_"),
                        "description": t.description,
                        "parameters": {
                            "type": "object",
                            "properties": t.schema,
                            "required": [k for k, v in t.schema.items()
                                           if isinstance(v, dict) and v.get("required")],
                        },
                    },
                }
            )
        return out


class ToolExecutionError(RuntimeError):
    """Raised when the guard blocks or a tool raises."""

    def __init__(self, message: str, tool: str = "", denied_by: str = "", risk: str = "LOW",
                 confirmation_id: Optional[str] = None) -> None:
        super().__init__(message)
        self.tool = tool
        self.denied_by = denied_by
        self.risk = risk
        self.confirmation_id = confirmation_id

    def to_dict(self) -> Dict[str, Any]:
        return {"error": str(self), "tool": self.tool, "denied_by": self.denied_by,
                "risk": self.risk, "confirmation_id": self.confirmation_id}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _accepted_params(fn: ToolFn) -> Optional[Dict[str, Any]]:
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):  # pragma: no cover
        return None
    if any(p.kind == p.VAR_KEYWORD for p in sig.parameters.values()):
        return None
    return {
        name: p
        for name, p in sig.parameters.items()
        if name not in ("ctx", "self") and p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY)
    }


def _infer_schema(fn: ToolFn) -> Dict[str, Any]:
    """Build a rough JSON schema from the function signature + type hints."""
    hints = getattr(fn, "__annotations__", {}) or {}
    params = _accepted_params(fn) or {}
    schema: Dict[str, Any] = {}
    py_to_json = {str: "string", int: "integer", float: "number", bool: "boolean",
                  list: "array", dict: "object"}
    for name, p in params.items():
        hint = hints.get(name)
        origin = getattr(hint, "__origin__", None)
        jtype = py_to_json.get(hint, "string") if origin is None else py_to_json.get(origin, "object")
        entry: Dict[str, Any] = {"type": jtype}
        if p.default is inspect.Parameter.empty:
            entry["required"] = True
        elif p.default is not None:
            entry["default"] = p.default
        schema[name] = entry
    return schema


# ---------------------------------------------------------------- singleton
registry = ToolRegistry()
tool = registry.tool          # convenient import alias
