"""
backend.app.tools.web_tools
===========================

**SAM's live-internet brain — the tools that make SAM answer like ChatGPT.**

Everything here is *keyless by default*: SAM works out of the box on a fresh
install because the helpers in :mod:`backend.app.utils.net` talk to public
endpoints (DuckDuckGo, Wikipedia/Wiktionary, Open-Meteo, exchangerate.host,
CoinGecko, Yahoo Finance, GitHub, Hacker News, arXiv, Google News RSS,
Openverse, Google's public translate endpoint). If the user adds a
``BRAVE_API_KEY`` / ``TAVILY_API_KEY`` / ``NEWS_API_KEY`` in ``.env`` those
providers take over automatically — better quality, same tool names.

Every tool:

* respects Privacy Mode (``PRIVACY_EXTERNAL_WEB=true`` ⇒ clean refusal, never a
  silent failure),
* goes through the guard (capability + risk + audit) because it is registered
  with ``@tool``,
* returns ``{"ok": bool, ...}`` so the Orchestrator and the UI can show what
  happened, including *why* it failed.

Tool map
--------
=========================  =====================================================
``web.search``             search the web, ranked results + snippets
``web.ask``                search → read top pages → cited answer (deep mode)
``web.fetch``              download a URL as clean Markdown/text
``web.read``               fetch + summarise one page
``web.compare``            research two or more subjects side by side
``web.news``               news search (NewsAPI or Google News RSS)
``web.wiki``               Wikipedia summary / search
``web.arxiv``              academic paper search
``web.github``             GitHub repo + code search
``web.hackernews``         top/new/best HN stories
``web.images``             CC image search (Openverse + Wikipedia)
``web.rss``                read any RSS/Atom feed
``web.status``             is this site up? latency, headers, TLS
``web.weather``            current weather + 7-day forecast
``web.currency``           live FX rates and conversion
``web.crypto``             crypto price + 24h change
``web.stock``              stock/index quote
``web.time``               world clock, timezone maths
``web.translate``          machine translation
``web.define``             dictionary definition
``web.thesaurus``          synonyms / antonyms / rhymes
``web.ip``                 IP geolocation
``web.geocode``            place → coordinates, country, elevation
=========================  =====================================================
"""

from __future__ import annotations

import re
import time
from datetime import datetime
from datetime import timezone as dt_timezone
from typing import Any, Dict, List, Optional

import httpx

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, tool
from backend.app.utils import net

log = get_logger("tools.web")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _fail(exc: Exception, what: str = "web request") -> Dict[str, Any]:
    """Turn any network/library error into an honest, actionable result."""
    if isinstance(exc, net.WebBlocked):
        return {"ok": False, "error": str(exc), "blocked_by": "privacy_mode"}
    if isinstance(exc, httpx.TimeoutException):
        return {"ok": False, "error": f"{what} timed out — the site is slow or unreachable"}
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        return {"ok": False, "error": f"{what} failed with HTTP {code}",
                "url": str(exc.request.url)[:300]}
    if isinstance(exc, httpx.HTTPError):
        return {"ok": False, "error": f"{what} could not connect: {exc}"}
    return {"ok": False, "error": f"{what} failed: {type(exc).__name__}: {exc}"}


async def _llm(prompt: str, system: str = "", role: str = "primary",
               max_tokens: int = 900, temperature: float = 0.3) -> str:
    from backend.app.models.router import router

    res = await router.ask(prompt, role=role, system=system or None,
                           max_tokens=max_tokens, temperature=temperature)
    return (res.text or "").strip()


def _fmt_results(results: List[Dict[str, Any]]) -> str:
    lines = []
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r.get('title', '')}\n   {r.get('url', '')}\n   {r.get('snippet', '')[:220]}")
    return "\n".join(lines)


# ===========================================================================
# 1. SEARCH
# ===========================================================================
@tool(
    name="web.search",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Search the live web and return ranked results with titles, URLs and snippets",
    schema={"query": {"type": "string", "required": True, "description": "what to search for"},
            "limit": {"type": "integer", "default": 8},
            "freshness": {"type": "string", "description": "'day'|'week'|'month' to bias recent results"}},
    risk="LOW",
    timeout=60,
)
async def web_search(ctx: ToolContext, query: str = "", limit: int = 8, freshness: str = "",
                     request: str = "") -> Dict[str, Any]:
    text = (query or request or ctx.user_text or "").strip()
    if not text:
        return {"ok": False, "error": "nothing to search for"}
    if freshness in ("day", "week", "month"):
        text = f"{text} {freshness}"
    try:
        results = await net.web_search(text, int(limit))
    except Exception as exc:
        return _fail(exc, "web search")
    if not results:
        return {"ok": False, "query": text, "count": 0, "results": [],
                "error": "no results — the search engines did not answer. "
                         "Check the internet connection or add BRAVE_API_KEY / TAVILY_API_KEY."}
    return {"ok": True, "query": text, "count": len(results), "results": results,
            "engine": results[0].get("engine", ""),
            "answer": f"I found {len(results)} results for “{text}”:\n\n" + _fmt_results(results[:6])}


@tool(
    name="web.ask",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Research a question end to end: search the web, read the best sources and write a cited answer",
    schema={"question": {"type": "string", "required": True},
            "sources": {"type": "integer", "default": 3, "description": "how many pages to actually read"},
            "style": {"type": "string", "description": "'brief'|'detailed'|'bullet'|'technical'"}},
    risk="LOW",
    timeout=180,
)
async def web_ask(ctx: ToolContext, question: str = "", sources: int = 3, style: str = "detailed",
                  request: str = "") -> Dict[str, Any]:
    q = (question or request or ctx.user_text or "").strip()
    if not q:
        return {"ok": False, "error": "no question given"}
    t0 = time.perf_counter()
    try:
        results = await net.web_search(q, 8)
    except Exception as exc:
        return _fail(exc, "web search")
    if not results:
        return {"ok": False, "question": q, "error": "the search returned nothing — cannot answer from the web"}

    to_read = [r for r in results if r.get("url")][: max(1, int(sources))]
    pages = await net.gather(*(net.get(r["url"], timeout=25.0, cache=True) for r in to_read),
                            timeout=35.0)
    corpus: List[Dict[str, Any]] = []
    for r, page in zip(to_read, pages):
        if isinstance(page, str) and page.strip():
            corpus.append({"title": r.get("title"), "url": r["url"], "source": r.get("source"),
                           "text": net.html_to_text(page, limit=6000)})
        else:
            log.debug("could not read %s: %s", r.get("url"), page)

    if not corpus:
        # nothing readable — still answer from the snippets, clearly labelled
        corpus = [{"title": r.get("title"), "url": r.get("url"), "source": r.get("source"),
                   "text": r.get("snippet", "")} for r in results[:5]]
        note = "sources could not be opened; answer is built from search snippets only"
    else:
        note = ""

    evidence = "\n\n".join(
        f"[SOURCE {i}] {c['title']}\n{c['url']}\n{c['text'][:2500]}"
        for i, c in enumerate(corpus, 1)
    )
    style_hint = {
        "brief": "Answer in at most 120 words.",
        "bullet": "Answer as a bulleted list of the key facts.",
        "technical": "Answer precisely and technically, include numbers, versions and dates.",
    }.get(style, "Answer thoroughly but concisely: direct answer first, then the supporting detail.")

    prompt = (
        f"Question: {q}\n\n"
        f"Use ONLY the sources below. {style_hint}\n"
        "Cite sources inline like [1], [2] matching the SOURCE numbers. "
        "If the sources disagree, say so. If they do not answer the question, say that plainly — "
        "never invent facts, numbers or quotes.\n\n" + evidence
    )
    answer = await _llm(prompt, system="You are SAM, a research assistant. You are accurate, "
                                       "sourced and honest about uncertainty.",
                        role="reasoning", max_tokens=1200)
    if not answer:
        answer = ("The model produced no answer, so here is what the sources said:\n\n"
                  + "\n\n".join(f"[{i}] {c['title']} — {c['url']}\n{c['text'][:400]}"
                                for i, c in enumerate(corpus, 1)))

    refs = [{"index": i, "title": c["title"], "url": c["url"], "source": c["source"]}
            for i, c in enumerate(corpus, 1)]
    refs += [{"index": None, "title": r.get("title"), "url": r.get("url"), "source": r.get("source")}
             for r in results[len(corpus):6]]
    return {"ok": True, "question": q, "answer": answer, "sources": refs,
            "read_count": len(corpus), "note": note, "style": style,
            "took_ms": int((time.perf_counter() - t0) * 1000)}


@tool(
    name="web.fetch",
    capability="research.fetch_page",
    agent="research",
    device="cloud",
    description="Download a web page and return its readable content as Markdown plus metadata and links",
    schema={"url": {"type": "string", "required": True},
            "format": {"type": "string", "description": "'markdown' (default) | 'text' | 'html' | 'links'"},
            "max_chars": {"type": "integer", "default": 20000}},
    risk="LOW",
    timeout=90,
)
async def web_fetch(ctx: ToolContext, url: str = "", format: str = "markdown", max_chars: int = 20000,
                    request: str = "") -> Dict[str, Any]:
    target = net.normalise_url(url or request or ctx.user_text)
    if not target.startswith(("http://", "https://")):
        return {"ok": False, "error": f"'{url}' does not look like a URL — include https://"}
    t0 = time.perf_counter()
    try:
        raw = await net.get(target, timeout=45.0)
    except Exception as exc:
        return _fail(exc, f"fetching {net.domain_of(target)}")
    ctype_is_html = bool(re.search(r"<(html|body|div|article)\b", raw[:4000], re.I))
    meta = net.extract_meta(raw) if ctype_is_html else {}
    if format == "html":
        content = raw[: int(max_chars)]
    elif format == "text":
        content = net.html_to_text(raw, limit=int(max_chars))
    elif format == "links":
        return {"ok": True, "url": target, "links": net.extract_links(raw, target, limit=60),
                "meta": meta}
    else:
        content = net.html_to_markdown(raw, base_url=target, limit=int(max_chars))
    return {"ok": True, "url": target, "domain": net.domain_of(target), "format": format,
            "chars": len(content), "content": content, "meta": meta,
            "links": net.extract_links(raw, target, limit=15),
            "took_ms": int((time.perf_counter() - t0) * 1000)}


@tool(
    name="web.read",
    capability="research.fetch_page",
    agent="research",
    device="cloud",
    description="Read one web page and summarise it (optionally answering a specific question about it)",
    schema={"url": {"type": "string", "required": True},
            "question": {"type": "string", "description": "what to extract from the page"},
            "length": {"type": "string", "description": "'short'|'medium'|'long'"}},
    risk="LOW",
    timeout=120,
)
async def web_read(ctx: ToolContext, url: str = "", question: str = "", length: str = "medium",
                   request: str = "") -> Dict[str, Any]:
    target = net.normalise_url(url or request or ctx.user_text)
    try:
        raw = await net.get(target, timeout=40.0)
    except Exception as exc:
        return _fail(exc, f"reading {net.domain_of(target)}")
    text = net.html_to_text(raw, limit=30000)
    if len(text.strip()) < 80:
        return {"ok": False, "url": target,
                "error": "the page returned almost no readable text (it may need JavaScript or a login)"}
    words = {"short": 120, "medium": 300, "long": 700}.get(length, 300)
    ask = f"\nAnswer this question from the page: {question}" if question else ""
    summary = await _llm(
        f"Summarise this page in about {words} words. Keep every number, name and date that matters. "
        f"Do not add anything that is not in the page.{ask}\n\n"
        f"TITLE: {net.extract_meta(raw).get('title', '')}\nURL: {target}\n\n{text[:24000]}",
        role="fast", max_tokens=int(words * 2.2))
    return {"ok": True, "url": target, "domain": net.domain_of(target),
            "title": net.extract_meta(raw).get("title", ""),
            "summary": summary or text[:1200], "words_read": len(text.split()),
            "question": question, "length": length}


@tool(
    name="web.compare",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Research two or more options and produce a side-by-side comparison table with sources",
    schema={"items": {"type": "array", "description": "things to compare, e.g. ['react','vue']"},
            "criteria": {"type": "string", "description": "what to compare on, e.g. 'speed, ecosystem, learning curve'"},
            "question": {"type": "string"}},
    risk="LOW",
    timeout=180,
)
async def web_compare(ctx: ToolContext, items: Optional[List[str]] = None, criteria: str = "",
                      question: str = "", request: str = "") -> Dict[str, Any]:
    raw_items = items or []
    text = question or request or ctx.user_text or ""
    if not raw_items and text:
        m = re.search(r"\b(?:between|compare|vs\.?|versus)\b", text, re.I)
        if m:
            tail = text[m.end():]
            raw_items = [p.strip(" .?") for p in re.split(r"\b(?:and|vs\.?|versus|,)\b", tail, flags=re.I)
                         if p.strip()]
    raw_items = [i for i in raw_items if i][:5]
    if len(raw_items) < 2:
        return {"ok": False, "error": "give at least two things to compare, e.g. items=['iPhone 16','Pixel 9']"}

    found: Dict[str, List[Dict[str, Any]]] = {}
    for item in raw_items:
        query = f"{item} {criteria}".strip()
        try:
            found[item] = await net.web_search(query, 4)
        except Exception as exc:
            log.debug("compare search failed for %s: %s", item, exc)
            found[item] = []
    corpus = []
    for item, res in found.items():
        blocks = "\n".join(f"- {r.get('title')}: {r.get('snippet')}" for r in res[:4])
        corpus.append(f"### {item}\n{blocks}")
    verdict = await _llm(
        f"Compare these options: {', '.join(raw_items)}.\n"
        f"Comparison criteria: {criteria or 'the most decision-relevant ones'}.\n"
        "Produce a Markdown comparison table (rows = criteria, columns = options), then 3-5 sentences "
        "of recommendation guidance. Use only the evidence below; mark anything uncertain as 'unclear'.\n\n"
        + "\n\n".join(corpus),
        role="reasoning", max_tokens=1200)
    sources = [{"item": item, "results": [{"title": r.get("title"), "url": r.get("url")}
                                          for r in res[:4]]} for item, res in found.items()]
    return {"ok": True, "items": raw_items, "criteria": criteria, "comparison": verdict,
            "sources": sources}


# ===========================================================================
# 2. NEWS / FEEDS
# ===========================================================================
@tool(
    name="web.news",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Get the latest news on a topic (headlines, sources, links)",
    schema={"topic": {"type": "string", "required": True}, "limit": {"type": "integer", "default": 10}},
    risk="LOW",
    timeout=60,
)
async def web_news(ctx: ToolContext, topic: str = "", limit: int = 10, request: str = "") -> Dict[str, Any]:
    q = (topic or request or ctx.user_text or "").strip()
    q = re.sub(r"^(latest|recent|todays?|news\s+about|news\s+on)\s+", "", q, flags=re.I).strip()
    if not q:
        return {"ok": False, "error": "which topic should I look up news for?"}
    try:
        items = await net.news_search(q, int(limit))
    except Exception as exc:
        return _fail(exc, "news search")
    if not items:
        return {"ok": False, "topic": q, "error": "no news found for that topic"}
    return {"ok": True, "topic": q, "count": len(items), "articles": items,
            "engine": items[0].get("engine", ""),
            "answer": f"Latest on “{q}”:\n\n" + "\n".join(
                f"{i}. {a.get('title')} — {a.get('source') or net.domain_of(a.get('url', ''))}\n   {a.get('url')}"
                for i, a in enumerate(items[:8], 1))}


@tool(
    name="web.rss",
    capability="research.fetch_page",
    agent="research",
    device="cloud",
    description="Read an RSS or Atom feed and list its latest entries",
    schema={"url": {"type": "string", "required": True}, "limit": {"type": "integer", "default": 15}},
    risk="LOW",
    timeout=60,
)
async def web_rss(ctx: ToolContext, url: str = "", limit: int = 15, request: str = "") -> Dict[str, Any]:
    target = net.normalise_url(url or request or ctx.user_text)
    try:
        items = await net.read_rss(target, int(limit))
    except Exception as exc:
        return _fail(exc, f"reading the feed {target}")
    if not items:
        return {"ok": False, "url": target, "error": "that URL did not return a readable RSS/Atom feed"}
    return {"ok": True, "url": target, "count": len(items), "items": items,
            "answer": "\n".join(f"- {i.get('title')} ({i.get('published') or 'no date'})" for i in items[:10])}


# ===========================================================================
# 3. KNOWLEDGE SOURCES
# ===========================================================================
@tool(
    name="web.wiki",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Look something up on Wikipedia: summary, key facts and link for a topic",
    schema={"topic": {"type": "string", "required": True},
            "lang": {"type": "string", "default": "en", "description": "wikipedia language code, e.g. en, kn, hi"}},
    risk="LOW",
    timeout=45,
)
async def web_wiki(ctx: ToolContext, topic: str = "", lang: str = "en", request: str = "") -> Dict[str, Any]:
    q = (topic or request or ctx.user_text or "").strip()
    if not q:
        return {"ok": False, "error": "which topic should I look up?"}
    try:
        summary = await net.wikipedia_summary(q, lang)
        if summary.get("type") == "disambiguation" or not summary.get("extract"):
            hits = await net.wikipedia_search(q, 3, lang)
            if not hits:
                return {"ok": False, "query": q, "error": f"Wikipedia has no article for “{q}”"}
            title = hits[0]["title"]
            summary = await net.wikipedia_summary(title, lang)
            summary["candidates"] = hits
    except Exception as exc:
        return _fail(exc, f"Wikipedia lookup for “{q}”")
    return {"ok": True, "topic": q, "title": summary.get("title"),
            "description": summary.get("description"), "extract": summary.get("extract"),
            "url": summary.get("content_urls", {}).get("desktop", {}).get("page"),
            "thumbnail": (summary.get("thumbnail") or {}).get("source"),
            "candidates": summary.get("candidates"),
            "answer": summary.get("extract") or ""}


@tool(
    name="web.define",
    capability="research.web_search",
    agent="core",
    device="cloud",
    description="Look up the meaning, pronunciation and examples for a word",
    schema={"word": {"type": "string", "required": True}},
    risk="LOW",
    timeout=45,
)
async def web_define(ctx: ToolContext, word: str = "", request: str = "") -> Dict[str, Any]:
    w = (word or request or ctx.user_text or "").strip()
    w = re.sub(r"^(define|meaning\s+of|what\s+(does|is)\s+)", "", w, flags=re.I).strip(" ?.'\"")
    if not w:
        return {"ok": False, "error": "which word should I define?"}
    try:
        data = await net.definitions(w)
    except Exception as exc:
        return _fail(exc, f"defining “{w}”")
    if not data.get("ok"):
        return data
    senses = data.get("senses") or []
    answer = f"**{w}**" + (f" {data.get('phonetic') or data.get('pronunciation') or ''}\n\n").strip() + "\n\n"
    for i, s in enumerate(senses[:5], 1):
        pos = f"_{s.get('part_of_speech')}_" if s.get("part_of_speech") else ""
        answer += f"{i}. {pos} {s.get('definition', '')}\n"
        if s.get("example"):
            answer += f"   “{s['example']}”\n"
    if senses and senses[0].get("synonyms"):
        answer += "\nSynonyms: " + ", ".join(senses[0]["synonyms"])
    data["answer"] = answer.strip()
    return data


@tool(
    name="web.thesaurus",
    capability="research.web_search",
    agent="communication",
    device="cloud",
    description="Find synonyms, antonyms, rhymes or related words for a word",
    schema={"word": {"type": "string", "required": True},
            "kind": {"type": "string", "description": "syn|ant|related|rhyme|sounds_like|spelled_like|kind_of|part_of|triggers"}},
    risk="LOW",
    timeout=45,
)
async def web_thesaurus(ctx: ToolContext, word: str = "", kind: str = "syn",
                        limit: int = 14, request: str = "") -> Dict[str, Any]:
    w = (word or request or ctx.user_text or "").strip()
    w = re.sub(r"^(synonyms?|antonyms?|rhymes?|related\s+words?)\s+(for|of)\s+", "", w, flags=re.I).strip(" ?.")
    if "antonym" in (request or ctx.user_text or "").lower():
        kind = "ant"
    if not w:
        return {"ok": False, "error": "which word?"}
    try:
        words = await net.synonyms(w, kind, int(limit))
    except Exception as exc:
        return _fail(exc, f"thesaurus lookup for “{w}”")
    if not words:
        return {"ok": True, "word": w, "kind": kind, "words": [],
                "note": f"no {kind} relations found for “{w}”"}
    return {"ok": True, "word": w, "kind": kind, "count": len(words), "words": words,
            "answer": f"{kind} of “{w}”: " + ", ".join(words)}


@tool(
    name="web.arxiv",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Search arXiv for academic papers and return titles, authors, abstracts and links",
    schema={"query": {"type": "string", "required": True}, "limit": {"type": "integer", "default": 6}},
    risk="LOW",
    timeout=60,
)
async def web_arxiv(ctx: ToolContext, query: str = "", limit: int = 6, request: str = "") -> Dict[str, Any]:
    q = (query or request or ctx.user_text or "").strip()
    if not q:
        return {"ok": False, "error": "which research topic?"}
    try:
        papers = await net.arxiv_search(q, int(limit))
    except Exception as exc:
        return _fail(exc, "arXiv search")
    if not papers:
        return {"ok": False, "query": q, "error": "arXiv returned no papers for that query"}
    return {"ok": True, "query": q, "count": len(papers), "papers": papers,
            "answer": "Papers on arXiv:\n\n" + "\n\n".join(
                f"{i}. **{p['title']}**\n   {', '.join(p['authors'][:4])} ({p['published'][:10]})\n"
                f"   {p['summary'][:300]}…\n   {p['url']}"
                for i, p in enumerate(papers[:5], 1))}


@tool(
    name="web.github",
    capability="research.web_search",
    agent="coding",
    device="cloud",
    description="Search GitHub for repositories (or code) and report stars, language, description and links",
    schema={"query": {"type": "string", "required": True},
            "kind": {"type": "string", "description": "'repos' (default) | 'code' | 'issues' | 'users'"},
            "language": {"type": "string"}, "limit": {"type": "integer", "default": 8}},
    risk="LOW",
    timeout=60,
)
async def web_github(ctx: ToolContext, query: str = "", kind: str = "repos", language: str = "",
                     limit: int = 8, sort: str = "", request: str = "") -> Dict[str, Any]:
    q = (query or request or ctx.user_text or "").strip()
    q = re.sub(r"^(search|find)\s+(github\s+)?", "", q, flags=re.I).strip()
    if not q:
        return {"ok": False, "error": "what should I search for on GitHub?"}
    if language:
        q = f"{q} language:{language}"
    kind = kind if kind in ("repos", "code", "issues", "users") else "repos"
    try:
        data = await net.get_json(f"https://api.github.com/search/{kind}",
                                  params={"q": q, "per_page": min(int(limit), 20),
                                          "sort": sort or ("stars" if kind == "repos" else "")},
                                  headers={"Accept": "application/vnd.github+json"})
    except Exception as exc:
        return _fail(exc, "GitHub search")
    items = data.get("items") or []
    if not items:
        return {"ok": True, "query": q, "kind": kind, "count": 0, "items": [],
                "answer": f"GitHub found nothing for “{q}”."}
    out = []
    for it in items:
        if kind == "repos":
            out.append({"name": it.get("full_name"), "description": it.get("description"),
                        "stars": it.get("stargazers_count"), "forks": it.get("forks_count"),
                        "language": it.get("language"), "url": it.get("html_url"),
                        "open_issues": it.get("open_issues_count"), "updated": it.get("pushed_at"),
                        "license": (it.get("license") or {}).get("spdx_id"),
                        "topics": it.get("topics", [])[:8]})
        elif kind == "code":
            out.append({"name": it.get("name"), "path": it.get("path"),
                        "repo": (it.get("repository") or {}).get("full_name"),
                        "url": it.get("html_url"),
                        "language": it.get("language")})
        elif kind == "issues":
            out.append({"title": it.get("title"), "state": it.get("state"),
                        "url": it.get("html_url"), "comments": it.get("comments"),
                        "repo": (it.get("repository_url") or "").split("repos/")[-1]})
        else:
            out.append({"login": it.get("login"), "url": it.get("html_url"),
                        "type": it.get("type"), "repos": it.get("public_repos"),
                        "followers": it.get("followers")})
    total = data.get("total_count", len(out))
    answer = "\n".join(
        f"{i}. {r.get('name') or r.get('title') or r.get('login')}"
        + (f" ★{r['stars']}" if r.get("stars") is not None else "")
        + (f" [{r.get('language')}]" if r.get("language") else "")
        + f"\n   {(r.get('description') or '')[:150]}\n   {r.get('url')}"
        for i, r in enumerate(out[:6], 1))
    return {"ok": True, "query": q, "kind": kind, "total": total, "count": len(out),
            "items": out, "answer": f"{total} GitHub {kind} matched. Top results:\n\n{answer}"}


@tool(
    name="web.hackernews",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Get top, new, best or 'ask' stories from Hacker News",
    schema={"kind": {"type": "string", "description": "top|new|best|ask|show|job"},
            "limit": {"type": "integer", "default": 10}},
    risk="LOW",
    timeout=60,
)
async def web_hn(ctx: ToolContext, kind: str = "top", limit: int = 10,
                 request: str = "") -> Dict[str, Any]:
    kinds = {"top": "top", "new": "new", "best": "best", "ask": "ask", "show": "show", "job": "job"}
    text = (request or ctx.user_text or "").lower()
    for k in kinds:
        if k in text and kind == "top":
            kind = k
            break
    try:
        stories = await net.hn_top(kinds.get(kind, "top"), int(limit))
    except Exception as exc:
        return _fail(exc, "Hacker News")
    if not stories:
        return {"ok": False, "error": "Hacker News returned nothing"}
    return {"ok": True, "kind": kind, "count": len(stories), "stories": stories,
            "answer": f"Hacker News — {kind}:\n\n" + "\n".join(
                f"{i}. {s['title']} ({s.get('score')} pts, {s.get('comments')} comments)\n"
                f"   {s.get('url') or s.get('hn_link')}"
                for i, s in enumerate(stories[:10], 1))}


@tool(
    name="web.images",
    capability="research.web_search",
    agent="creative",
    device="cloud",
    description="Search for freely-licensed reference images (Openverse / Wikipedia) and return direct URLs",
    schema={"query": {"type": "string", "required": True}, "limit": {"type": "integer", "default": 6}},
    risk="LOW",
    timeout=60,
)
async def web_images(ctx: ToolContext, query: str = "", limit: int = 6, request: str = "") -> Dict[str, Any]:
    q = (query or request or ctx.user_text or "").strip()
    if not q:
        return {"ok": False, "error": "what images should I look for?"}
    try:
        images = await net.image_search(q, int(limit))
    except Exception as exc:
        return _fail(exc, "image search")
    if not images:
        return {"ok": False, "query": q, "error": "no freely-licensed images found for that query"}
    return {"ok": True, "query": q, "count": len(images), "images": images,
            "note": "results are Creative-Commons / Wikipedia assets — check the licence before reuse"}


# ===========================================================================
# 4. LIVE DATA
# ===========================================================================
@tool(
    name="web.weather",
    capability="research.fetch_page",
    agent="data",
    device="cloud",
    description="Get current weather and a 7-day forecast for a city (or the user's detected location)",
    schema={"place": {"type": "string", "description": "city name; empty = detect from IP"},
            "days": {"type": "integer", "default": 3}},
    risk="LOW",
    timeout=45,
)
async def web_weather(ctx: ToolContext, place: str = "", days: int = 3, request: str = "") -> Dict[str, Any]:
    text = (place or request or ctx.user_text or "").strip()
    text = re.sub(r"^(what'?s|what\s+is|the)?\s*(weather|temperature|forecast)\s*"
                  r"(like\s*)?(in|at|for|of)?\s*", "", text, flags=re.I).strip(" ?.")
    text = re.sub(r"\b(today|tomorrow|right\s+now|now)\b", "", text, flags=re.I).strip(" ?.,in at")
    try:
        data = await net.weather(text, days=int(days))
    except Exception as exc:
        return _fail(exc, "weather lookup")
    if not data.get("ok"):
        return data
    cur = data["current"]
    loc = data["location"]
    where = ", ".join(str(x) for x in (loc.get("name"), loc.get("region"), loc.get("country")) if x)
    lines = [f"**Weather for {where or 'your location'}** — {cur['condition']}, "
             f"{cur['temperature_c']}°C (feels {cur['feels_like_c']}°C), "
             f"humidity {cur['humidity_percent']}%, wind {cur['wind_kmh']} km/h."]
    for f in data["forecast"][: int(days)]:
        lines.append(f"- {f['date']}: {f['min_temp_c']}–{f['max_temp_c']}°C, "
                     f"{f['condition']}, rain {f['rain_chance_percent']}%")
    data["answer"] = "\n".join(lines)
    return data


@tool(
    name="web.currency",
    capability="research.fetch_page",
    agent="data",
    device="cloud",
    description="Convert an amount between currencies using live exchange rates",
    schema={"amount": {"type": "number", "default": 1},
            "from": {"type": "string", "required": True, "description": "source currency code, e.g. USD"},
            "to": {"type": "string", "description": "target currency code(s), comma separated"}},
    risk="LOW",
    timeout=45,
)
async def web_currency(ctx: ToolContext, amount: float = 1.0, **kw: Any) -> Dict[str, Any]:
    src = str(kw.get("from") or kw.get("source") or kw.get("base") or "").strip().upper()
    dst = str(kw.get("to") or kw.get("target") or "").strip().upper()
    request = kw.get("request") or ctx.user_text or ""
    if not src:
        m = re.findall(r"\b([A-Z]{3}|usd|inr|eur|gbp|jpy|aed|sgd|aud|cad|chf|cny)\b", request, re.I)
        codes = [c.upper() for c in m if len(c) == 3]
        if len(codes) >= 2:
            src, dst = codes[0], codes[1] if not dst else dst
        elif codes:
            src = codes[0]
        nums = re.findall(r"\b\d[\d,]*(?:\.\d+)?\b", request)
        if nums and amount in (0, 1):
            try:
                amount = float(nums[0].replace(",", ""))
            except ValueError:
                pass
    if not src:
        return {"ok": False, "error": "which currency? e.g. from='USD', to='INR', amount=100"}
    targets = [t.strip() for t in re.split(r"[,\s/]+", dst) if t.strip()] or [
        "USD", "INR", "EUR", "GBP", "JPY", "AED"]
    try:
        rates = await net.exchange_rates(src)
    except Exception as exc:
        return _fail(exc, "exchange-rate lookup")
    if not rates:
        return {"ok": False, "error": f"no rates returned for base {src}"}
    converted = {}
    missing = []
    for t in targets:
        if t in rates:
            converted[t] = round(float(amount) * float(rates[t]), 4)
        else:
            missing.append(t)
    if not converted:
        return {"ok": False, "from": src, "error": f"unknown currency code(s): {', '.join(missing)}",
                "known_sample": sorted(rates)[:40]}
    answer = f"{amount:,.2f} {src} = " + ", ".join(f"{v:,.2f} {k}" for k, v in converted.items())
    return {"ok": True, "amount": amount, "from": src, "rates": converted, "unknown": missing,
            "answer": answer, "source": "open.er-api.com"}


@tool(
    name="web.crypto",
    capability="research.fetch_page",
    agent="data",
    device="cloud",
    description="Get the live price and 24h change of a cryptocurrency",
    schema={"symbol": {"type": "string", "required": True, "description": "coin id or ticker, e.g. bitcoin / btc"},
            "vs": {"type": "string", "default": "usd"}},
    risk="LOW",
    timeout=45,
)
async def web_crypto(ctx: ToolContext, symbol: str = "", vs: str = "usd",
                     request: str = "") -> Dict[str, Any]:
    s = (symbol or request or ctx.user_text or "").strip().lower()
    s = re.sub(r"^(price\s+of|what\s+is\s+the\s+price\s+of|how\s+much\s+is)\s+", "", s, flags=re.I)
    s = re.sub(r"\s+(price|now|today|in\s+usd|in\s+inr)\b.*$", "", s, flags=re.I).strip(" ?.")
    aliases = {"btc": "bitcoin", "eth": "ethereum", "sol": "solana", "doge": "dogecoin",
               "xrp": "ripple", "ada": "cardano", "bnb": "binancecoin", "matic": "matic-network",
               "pol": "polygon-ecosystem-token", "avax": "avalanche-2", "dot": "polkadot",
               "link": "chainlink", "ltc": "litecoin", "tron": "tron", "trx": "tron",
               "shib": "shiba-inu", "atom": "cosmos", "near": "near", "apt": "aptos",
               "arb": "arbitrum", "op": "optimism"}
    coin = aliases.get(s, s.replace(" ", "-"))
    if "inr" in (request or ctx.user_text or "").lower():
        vs = "inr"
    try:
        data = await net.crypto_price(coin, vs)
    except Exception as exc:
        return _fail(exc, "crypto price lookup")
    if not data:
        return {"ok": False, "symbol": symbol, "coin_id": coin,
                "error": f"unknown coin '{coin}' — try the full name, e.g. 'bitcoin'"}
    price = data.get(vs)
    change = data.get(f"{vs}_24h_change")
    return {"ok": True, "coin": coin, "vs": vs.upper(), "price": price,
            "change_24h_percent": round(change, 3) if isinstance(change, (int, float)) else None,
            "answer": f"{coin.title()} is {price:,.2f} {vs.upper()}"
                      + (f" ({change:+.2f}% in 24h)" if isinstance(change, (int, float)) else ""),
            "source": "coingecko"}


@tool(
    name="web.stock",
    capability="research.fetch_page",
    agent="data",
    device="cloud",
    description="Get a live stock or index quote by ticker symbol (e.g. AAPL, RELIANCE.NS, ^NSEI)",
    schema={"symbol": {"type": "string", "required": True}},
    risk="LOW",
    timeout=45,
)
async def web_stock(ctx: ToolContext, symbol: str = "", request: str = "") -> Dict[str, Any]:
    s = (symbol or request or ctx.user_text or "").strip().upper()
    s = re.sub(r"^(STOCK|SHARE|PRICE|QUOTE)\s+(OF|FOR)?\s*", "", s, flags=re.I).strip(" ?.")
    s = re.sub(r"\s+(STOCK|SHARE|PRICE|TODAY|NOW)\b.*$", "", s, flags=re.I).strip()
    if not s:
        return {"ok": False, "error": "which ticker? e.g. AAPL, MSFT, RELIANCE.NS, TCS.NS, ^NSEI"}
    try:
        data = await net.stock_quote(s)
    except Exception as exc:
        return _fail(exc, "stock quote")
    if not data.get("ok"):
        return data
    chg = data.get("change_percent")
    data["answer"] = (f"{data.get('name') or s} ({data['symbol']}): "
                      f"{data.get('price')} {data.get('currency') or ''}"
                      + (f", {chg:+.2f}% vs previous close" if chg is not None else "")
                      + f" — {data.get('exchange') or ''}").strip()
    return data


@tool(
    name="web.time",
    capability="research.fetch_page",
    agent="data",
    device="cloud",
    description="Get the current date and time in any timezone, or convert a time between zones",
    schema={"timezone": {"type": "string", "description": "IANA zone (Asia/Kolkata) or city (Tokyo)"},
            "other_timezone": {"type": "string", "description": "second zone to compare with"}},
    risk="LOW",
    timeout=30,
)
async def web_time(ctx: ToolContext, timezone: str = "", other_timezone: str = "",
                   request: str = "") -> Dict[str, Any]:
    text = (timezone or request or ctx.user_text or "").strip()
    zones = [z for z in re.findall(r"[A-Za-z_]+/[A-Za-z_]+", text)]
    if not zones:
        zones = [z for z in re.findall(
            r"\b(London|New\s*York|Tokyo|Paris|Dubai|Singapore|Sydney|Berlin|Bengaluru|Bangalore|"
            r"Mumbai|Delhi|Kolkata|Chennai|Hyderabad|Los\s*Angeles|Chicago|Toronto|Seoul|"
            r"Shanghai|San\s*Francisco|Amsterdam|Zurich|Austin|Seattle)\b", text, re.I)]
    if other_timezone:
        zones.append(other_timezone)
    zones = zones or [settings.timezone]

    resolved = []
    for z in zones[:4]:
        zone = z if "/" in z else await _city_to_zone(z)
        try:
            from zoneinfo import ZoneInfo

            now = datetime.now(ZoneInfo(zone))
            resolved.append({"requested": z, "timezone": zone,
                             "datetime": now.isoformat(timespec="seconds"),
                             "time": now.strftime("%H:%M:%S"), "date": now.strftime("%A, %d %B %Y"),
                             "utc_offset": now.strftime("%z")})
        except Exception as exc:
            resolved.append({"requested": z, "error": f"unknown timezone '{z}' ({exc})"})

    ok = [r for r in resolved if "time" in r]
    if len(ok) >= 2:
        a, b = ok[0], ok[1]
        ta = datetime.fromisoformat(a["datetime"])
        tb = datetime.fromisoformat(b["datetime"])
        delta = (tb.utcoffset() - ta.utcoffset())
        hours = delta.total_seconds() / 3600
        answer = (f"It is {a['time']} on {a['date']} in {a['timezone']}, and {b['time']} "
                  f"in {b['timezone']} — {b['timezone']} is {hours:+.1f}h relative to {a['timezone']}.")
    elif ok:
        answer = f"It is {ok[0]['time']} on {ok[0]['date']} in {ok[0]['timezone']} (UTC{ok[0]['utc_offset']})."
    else:
        answer = "I could not resolve those timezones."
    return {"ok": bool(ok), "zones": resolved, "answer": answer,
            "utc_now": datetime.now(dt_timezone.utc).isoformat(timespec="seconds")}


async def _city_to_zone(city: str) -> str:
    table = {
        "london": "Europe/London", "new york": "America/New_York", "tokyo": "Asia/Tokyo",
        "paris": "Europe/Paris", "dubai": "Asia/Dubai", "singapore": "Asia/Singapore",
        "sydney": "Australia/Sydney", "berlin": "Europe/Berlin", "bengaluru": "Asia/Kolkata",
        "bangalore": "Asia/Kolkata", "mumbai": "Asia/Kolkata", "delhi": "Asia/Kolkata",
        "kolkata": "Asia/Kolkata", "chennai": "Asia/Kolkata", "hyderabad": "Asia/Kolkata",
        "india": "Asia/Kolkata", "los angeles": "America/Los_Angeles",
        "chicago": "America/Chicago", "toronto": "America/Toronto", "seoul": "Asia/Seoul",
        "shanghai": "Asia/Shanghai", "san francisco": "America/Los_Angeles",
        "amsterdam": "Europe/Amsterdam", "zurich": "Europe/Zurich", "austin": "America/Chicago",
        "seattle": "America/Los_Angeles", "utc": "UTC", "gmt": "UTC",
    }
    key = city.strip().lower()
    if key in table:
        return table[key]
    try:
        geo = await net.geocode(city)
        if geo:
            tz = geo.get("timezone")
            if tz:
                return tz
    except Exception as exc:  # pragma: no cover
        log.debug("geocode for timezone failed: %s", exc)
    return "UTC"


@tool(
    name="web.translate",
    capability="research.fetch_page",
    agent="communication",
    device="cloud",
    description="Translate text between languages online (offline model translation is used when the web is off)",
    schema={"text": {"type": "string", "required": True},
            "target": {"type": "string", "required": True, "description": "language name or code"},
            "source": {"type": "string", "default": "auto"}},
    risk="LOW",
    timeout=45,
)
async def web_translate(ctx: ToolContext, text: str = "", target: str = "", source: str = "auto",
                        request: str = "") -> Dict[str, Any]:
    body = (text or request or ctx.user_text or "").strip()
    if not body:
        return {"ok": False, "error": "nothing to translate"}
    codes = {"hindi": "hi", "kannada": "kn", "tamil": "ta", "telugu": "te", "malayalam": "ml",
             "marathi": "mr", "bengali": "bn", "gujarati": "gu", "punjabi": "pa", "urdu": "ur",
             "english": "en", "french": "fr", "german": "de", "spanish": "es", "portuguese": "pt",
             "italian": "it", "russian": "ru", "chinese": "zh-CN", "japanese": "ja",
             "korean": "ko", "arabic": "ar", "indonesian": "id", "dutch": "nl", "turkish": "tr",
             "vietnamese": "vi", "thai": "th", "polish": "pl", "swedish": "sv", "nepali": "ne",
             "sinhala": "si", "odia": "or", "assamese": "as", "sanskrit": "sa"}
    if not target:
        m = re.search(r"\b(?:to|into|in)\s+([a-z]+)\b", body, re.I)
        target = m.group(1) if m else ""
    target = codes.get(target.strip().lower(), target.strip().lower()[:5]) or "en"
    if not settings.web_enabled:
        from backend.app.models.router import router

        res = await router.translate(body, target_lang=target)
        return {"ok": bool(res.text), "text": body, "translated": res.text, "target": target,
                "engine": f"{res.provider}/{res.model}", "offline": True,
                "error": None if res.text else "no offline translation model available"}
    try:
        data = await net.translate_text(body, target, source or "auto")
    except Exception as exc:
        return _fail(exc, "translation")
    return data


@tool(
    name="web.ip",
    capability="research.fetch_page",
    agent="data",
    device="cloud",
    description="Look up geolocation, ISP and timezone for an IP address (or this machine's public IP)",
    schema={"ip": {"type": "string", "description": "empty = my own public IP"}},
    risk="LOW",
    timeout=45,
)
async def web_ip(ctx: ToolContext, ip: str = "", request: str = "") -> Dict[str, Any]:
    addr = (ip or "").strip()
    m = re.findall(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", request or ctx.user_text or "")
    if not addr and m:
        addr = m[0]
    try:
        data = await net.ip_info(addr)
    except Exception as exc:
        return _fail(exc, "IP lookup")
    keep = {k: data.get(k) for k in ("ip", "city", "region", "country", "country_name", "postal",
                                     "latitude", "longitude", "timezone", "org", "asn", "version")
            if data.get(k) is not None}
    keep["ok"] = True
    keep["answer"] = (f"{keep.get('ip', addr or 'your public IP')} appears to be in "
                      f"{keep.get('city', '?')}, {keep.get('country_name') or keep.get('country', '?')} "
                      f"({keep.get('org', 'unknown network')}).")
    return keep


@tool(
    name="web.geocode",
    capability="research.fetch_page",
    agent="data",
    device="cloud",
    description="Convert a place name into coordinates, country, region, timezone and elevation",
    schema={"place": {"type": "string", "required": True}, "limit": {"type": "integer", "default": 3}},
    risk="LOW",
    timeout=45,
)
async def web_geocode(ctx: ToolContext, place: str = "", limit: int = 3,
                      request: str = "") -> Dict[str, Any]:
    q = (place or request or ctx.user_text or "").strip()
    q = re.sub(r"^(where\s+is|coordinates\s+(of|for)|geocode)\s+", "", q, flags=re.I).strip(" ?")
    if not q:
        return {"ok": False, "error": "which place?"}
    try:
        data = await net.get_json("https://geocoding-api.open-meteo.com/v1/search",
                                  params={"name": q, "count": int(limit), "language": "en",
                                          "format": "json"})
    except Exception as exc:
        return _fail(exc, "geocoding")
    results = data.get("results") or []
    if not results:
        return {"ok": False, "query": q, "error": f"no place called “{q}” was found"}
    slim = [{"name": r.get("name"), "country": r.get("country"), "region": r.get("admin1"),
             "latitude": r.get("latitude"), "longitude": r.get("longitude"),
             "timezone": r.get("timezone"), "elevation": r.get("elevation"),
             "population": r.get("population")} for r in results]
    top = slim[0]
    return {"ok": True, "query": q, "count": len(slim), "places": slim,
            "answer": (f"{top['name']}, {top.get('region') or ''} {top.get('country') or ''} is at "
                       f"{top['latitude']}, {top['longitude']} ({top.get('timezone')}, "
                       f"elevation {top.get('elevation')} m).")}


@tool(
    name="web.status",
    capability="research.fetch_page",
    agent="verification",
    device="cloud",
    description="Check whether a website or API is up: status code, latency, headers, TLS and redirects",
    schema={"url": {"type": "string", "required": True},
            "method": {"type": "string", "default": "GET"},
            "expect": {"type": "integer", "description": "status code you expect, e.g. 200"}},
    risk="LOW",
    timeout=60,
)
async def web_status(ctx: ToolContext, url: str = "", method: str = "GET", expect: int = 0,
                     request: str = "") -> Dict[str, Any]:
    target = net.normalise_url(url or request or ctx.user_text)
    if not target.startswith(("http://", "https://")):
        return {"ok": False, "error": "give me a full URL, e.g. https://example.com"}
    t0 = time.perf_counter()
    try:
        c = await net.client()
        resp = await c.request(method.upper(), target, timeout=30.0)
        latency = int((time.perf_counter() - t0) * 1000)
        history = [{"status": h.status_code, "url": str(h.url)} for h in resp.history]
        out = {"ok": resp.status_code < 400, "url": target, "status": resp.status_code,
               "method": method.upper(), "latency_ms": latency, "redirects": history,
               "final_url": str(resp.url), "content_type": resp.headers.get("content-type"),
               "server": resp.headers.get("server"), "size_bytes": len(resp.content),
               "security_headers": {h: resp.headers.get(h) for h in
                                    ("strict-transport-security", "content-security-policy",
                                     "x-frame-options", "x-content-type-options")
                                    if resp.headers.get(h)},
               "tls": "yes" if str(resp.url).startswith("https://") else "no"}
        if expect:
            out["expected"] = expect
            out["matches_expectation"] = resp.status_code == int(expect)
            out["ok"] = out["matches_expectation"]
        out["answer"] = (f"{target} responded {resp.status_code} in {latency} ms"
                         f" ({len(resp.content)} bytes, {out['content_type'] or 'unknown type'}).")
        return out
    except Exception as exc:
        latency = int((time.perf_counter() - t0) * 1000)
        return {**_fail(exc, f"checking {target}"), "url": target, "latency_ms": latency,
                "ok": False, "answer": f"{target} is NOT reachable ({type(exc).__name__})."}
