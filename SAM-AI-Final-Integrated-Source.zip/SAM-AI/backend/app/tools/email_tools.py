"""
backend.app.tools.email_tools
=============================

The Communication Brain's email tools.

Design rules (from the specification):

* **SAM never sends anything silently.** ``email.send`` is Prepare → Preview →
  explicit user confirmation → Send, and it is a HIGH-risk action.
* SAM composes through your own mailbox. It does not have its own identity and
  never pretends to be you without saying so.
* Reading mail is a PRIVACY capability and is **off by default**.
* Only IMAP/SMTP (and Gmail/Graph when configured) are supported; credentials
  live in ``.env`` and are never written to the database or the audit log.
"""

from __future__ import annotations

import asyncio
import email
import email.utils
import imaplib
import re
import smtplib
import ssl
import time
from dataclasses import dataclass, field
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, tool

log = get_logger("tools.email")

DRAFT_DIR = settings.sam_data_dir / "outbox"


@dataclass
class Draft:
    """A composed-but-unsent email, held in memory and mirrored to disk."""

    id: str
    to: List[str]
    cc: List[str]
    subject: str
    body: str
    html: bool = False
    attachments: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%S"))
    tone: str = "neutral"
    language: str = "en"
    source: str = "user"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "to": self.to, "cc": self.cc, "subject": self.subject,
            "body": self.body, "html": self.html, "attachments": self.attachments,
            "created_at": self.created_at, "tone": self.tone, "language": self.language,
            "source": self.source, "word_count": len(self.body.split()),
            "preview": self.body[:400],
        }


_DRAFTS: Dict[str, Draft] = {}


def _configured() -> bool:
    return bool(settings.email_enabled and settings.smtp_host and settings.email_address)


def _read_configured() -> bool:
    return bool(settings.email_enabled and settings.imap_host and (settings.imap_user or settings.email_address))


def _not_configured(kind: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"email is not configured ({kind})",
        "configured": False,
        "how_to_enable": [
            "Open SAM-AI/.env",
            "Set EMAIL_ENABLED=true",
            f"Set {('IMAP_HOST / IMAP_USER / IMAP_PASSWORD' if kind == 'read' else 'SMTP_HOST / SMTP_USER / SMTP_PASSWORD')}",
            "Set EMAIL_ADDRESS=you@example.com",
            "Use an app password, not your account password",
            "Restart SAM",
        ],
    }


# ===========================================================================
# COMPOSE
# ===========================================================================
@tool(
    name="email.draft",
    capability="email.draft",
    agent="communication",
    device="pc",
    description="Compose an email draft. Never sends anything.",
    schema={"to": {"type": "string"}, "subject": {"type": "string"},
            "body": {"type": "string"}},
    risk="LOW",
    timeout=180,
)
async def email_draft(ctx: ToolContext, to: str = "", cc: str = "", subject: str = "",
                      body: str = "", tone: str = "", language: str = "",
                      instruction: str = "", attachments: Optional[List[str]] = None,
                      request: str = "") -> Dict[str, Any]:
    from backend.app.models.router import router

    text = instruction or request or ctx.user_text
    recipients = [r.strip() for r in re.split(r"[,;]", to) if r.strip()]
    copies = [r.strip() for r in re.split(r"[,;]", cc) if r.strip()]

    # lift addresses out of the sentence when they were not passed explicitly
    if not recipients and text:
        recipients = re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
    if not subject and text:
        m = re.search(r"subject[:\s\-]+([^\n,]{3,90})", text, re.I)
        if m:
            subject = m.group(1).strip()

    if not body and (text or subject):
        lang = language or ctx.language or "en"
        prompt = f"""Write an email.

RECIPIENT(S): {', '.join(recipients) or '(unknown)'}
SUBJECT: {subject or '(you choose)'}
INSTRUCTION: {text or subject}
TONE: {tone or 'professional and warm'}
LANGUAGE: {lang}

Rules: no placeholders, no [Name] brackets, no invented facts, keep it under 250 words.
Return ONLY JSON:
{{"subject": "...", "body": "plain text with \\n\\n between paragraphs", "tone": "..."}}"""
        data = await router.ask_json(prompt, role="primary", temperature=0.5, default=None)
        if isinstance(data, dict) and data.get("body"):
            body = str(data["body"]).strip()
            subject = subject or str(data.get("subject") or "").strip()
            tone = tone or str(data.get("tone") or "neutral")
        if not body:
            body = _fallback_body(text, recipients, subject, tone)

    if not body:
        return {"ok": False, "error": "nothing to write — tell SAM what the email should say"}
    if not subject:
        subject = body.strip().splitlines()[0][:80] or "Message from SAM"

    draft_id = f"msg-{int(time.time() * 1000) % 1000000}"
    draft = Draft(id=draft_id, to=recipients, cc=copies, subject=subject[:200],
                  body=body.strip(), tone=tone or "neutral", language=language or ctx.language,
                  attachments=[str(a) for a in (attachments or [])],
                  source=ctx.meta.get("source", "user") if ctx.meta else "user")
    _DRAFTS[draft_id] = draft
    _persist_draft(draft)

    return {
        "ok": True, "draft_id": draft_id, "draft": draft.to_dict(), "sent": False,
        "configured_for_sending": _configured(),
        "answer": f"Draft ready ({len(body.split())} words) to {', '.join(recipients) or 'no recipient yet'}. "
                  f"Say “send it” to review and send.",
        "next": "email.send with this draft_id — SAM will show a preview and ask you to confirm first",
    }


def _fallback_body(instruction: str, recipients: List[str], subject: str, tone: str) -> str:
    who = recipients[0].split("@")[0].replace(".", " ").replace("_", " ").title() \
        if recipients else "there"
    greeting = {"formal": f"Dear {who},", "casual": f"Hi {who},", "friendly": f"Hi {who},"}.get(
        (tone or "").lower(), f"Hello {who},")
    return "\n\n".join([
        greeting,
        (instruction or subject or "I wanted to follow up on the above.").strip().capitalize() + ".",
        "Please let me know if anything needs adjusting.",
        "Best regards",
    ])


def _persist_draft(draft: Draft) -> Optional[str]:
    try:
        DRAFT_DIR.mkdir(parents=True, exist_ok=True)
        path = DRAFT_DIR / f"{draft.id}.eml.md"
        path.write_text(
            f"To: {', '.join(draft.to)}\nCc: {', '.join(draft.cc)}\n"
            f"Subject: {draft.subject}\nDate: {draft.created_at}\n\n{draft.body}\n",
            encoding="utf-8",
        )
        return str(path)
    except OSError as exc:
        log.debug("could not persist draft %s: %s", draft.id, exc)
        return None


@tool(
    name="email.list_drafts",
    capability="email.draft",
    agent="communication",
    device="pc",
    description="List email drafts waiting in the SAM outbox",
    risk="LOW",
    timeout=30,
)
async def email_list_drafts(ctx: ToolContext) -> Dict[str, Any]:
    items = [d.to_dict() for d in sorted(_DRAFTS.values(), key=lambda x: x.created_at, reverse=True)]
    if not items and DRAFT_DIR.exists():
        for p in sorted(DRAFT_DIR.glob("msg-*.eml.md"), reverse=True)[:20]:
            items.append({"id": p.name.split(".")[0], "path": str(p),
                          "preview": p.read_text(encoding="utf-8", errors="replace")[:300]})
    return {"ok": True, "count": len(items), "drafts": items, "outbox": str(DRAFT_DIR)}


# ===========================================================================
# READ
# ===========================================================================
@tool(
    name="email.read",
    capability="email.read",
    agent="communication",
    device="pc",
    description="Read recent emails from the configured IMAP mailbox",
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def email_read(ctx: ToolContext, limit: int = 10, unread_only: bool = False,
                     search: str = "", folder: str = "", include_body: bool = True) -> Dict[str, Any]:
    if not _read_configured():
        return _not_configured("read")
    limit = max(1, min(int(limit), int(settings.email_max_fetch)))
    try:
        messages = await asyncio.to_thread(
            _imap_fetch, folder or settings.imap_folder, limit, unread_only, search, include_body
        )
    except Exception as exc:
        return {"ok": False, "error": f"could not read the mailbox: {exc}",
                "hint": "check IMAP_HOST/IMAP_USER/IMAP_PASSWORD in .env "
                        "(Gmail needs an app password)"}
    lines = [f"- {m['date'][:16]} · **{m['from']}** — {m['subject']}"
             + ("  (unread)" if m.get("unread") else "") for m in messages[:15]]
    return {"ok": True, "count": len(messages), "messages": messages,
            "folder": folder or settings.imap_folder, "unread_only": unread_only,
            "answer": ("Latest mail:\n" + "\n".join(lines)) if lines else "No matching messages."}


def _imap_fetch(folder: str, limit: int, unread_only: bool, search: str,
                include_body: bool) -> List[Dict[str, Any]]:
    context = ssl.create_default_context()
    mail = imaplib.IMAP4_SSL(settings.imap_host, int(settings.imap_port), ssl_context=context)
    try:
        mail.login(settings.imap_user or settings.email_address, settings.imap_password)
        mail.select(folder, readonly=True)
        criteria = "(UNSEEN)" if unread_only else "ALL"
        status, data = mail.search(None, criteria)
        if status != "OK":
            return []
        ids = data[0].split()[-limit:] if data and data[0] else []
        out: List[Dict[str, Any]] = []
        for num in reversed(ids):
            status, payload = mail.fetch(num, "(RFC822)")
            if status != "OK" or not payload or not payload[0]:
                continue
            raw = payload[0][1]
            msg = email.message_from_bytes(raw)
            body = ""
            if include_body:
                body = _extract_body(msg)[:6000]
            item = {
                "id": num.decode() if isinstance(num, bytes) else str(num),
                "message_id": msg.get("Message-ID", ""),
                "from": email.utils.parseaddr(msg.get("From", ""))[1] or msg.get("From", ""),
                "from_name": email.utils.parseaddr(msg.get("From", ""))[0],
                "to": msg.get("To", ""),
                "subject": str(email.header.decode_header(msg.get("Subject", "") or "")[0][0]
                               if email.header.decode_header(msg.get("Subject", "") or "") else ""),
                "date": msg.get("Date", ""),
                "unread": unread_only,
                "attachments": [p.get_filename() for p in msg.walk()
                                if p.get_filename()][:10],
            }
            item["subject"] = _decode_subject(msg.get("Subject", ""))
            if include_body:
                item["body"] = body
                item["preview"] = body[:300]
            if search:
                blob = f"{item['subject']} {item['from']} {body}".lower()
                if search.lower() not in blob:
                    continue
            out.append(item)
        return out
    finally:
        try:
            mail.logout()
        except Exception:
            pass


def _decode_subject(raw: str) -> str:
    try:
        parts = email.header.decode_header(raw or "")
        text = ""
        for chunk, charset in parts:
            if isinstance(chunk, bytes):
                text += chunk.decode(charset or "utf-8", errors="replace")
            else:
                text += chunk
        return text.strip()
    except Exception:
        return str(raw or "")


def _extract_body(msg: email.message.Message) -> str:
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            disp = str(part.get("Content-Disposition") or "")
            if ctype == "text/plain" and "attachment" not in disp:
                try:
                    return part.get_payload(decode=True).decode(
                        part.get_content_charset() or "utf-8", errors="replace")
                except Exception:
                    continue
        for part in msg.walk():
            if part.get_content_type() == "text/html":
                try:
                    html = part.get_payload(decode=True).decode(
                        part.get_content_charset() or "utf-8", errors="replace")
                    return re.sub(r"<[^>]+>", " ", html)
                except Exception:
                    continue
        return ""
    try:
        return msg.get_payload(decode=True).decode(
            msg.get_content_charset() or "utf-8", errors="replace")
    except Exception:
        return str(msg.get_payload() or "")


@tool(
    name="email.summarise",
    capability="email.read",
    agent="communication",
    device="pc",
    description="Summarise the inbox: what needs attention, what can wait",
    risk="MEDIUM",
    confirm=True,
    timeout=240,
)
async def email_summarise(ctx: ToolContext, limit: int = 25, unread_only: bool = True,
                          folder: str = "") -> Dict[str, Any]:
    if not _read_configured():
        return _not_configured("read")
    read = await email_read(ctx, limit=limit, unread_only=unread_only, folder=folder,
                            include_body=True)
    if not read.get("ok"):
        return read
    messages = read.get("messages") or []
    if not messages:
        return {"ok": True, "count": 0, "summary": "No unread mail.",
                "answer": "Your inbox is clear — nothing unread."}

    from backend.app.models.router import router

    corpus = "\n\n".join(
        f"[{i + 1}] From: {m['from']}\nSubject: {m['subject']}\nDate: {m['date']}\n"
        f"Body: {(m.get('body') or '')[:900]}"
        for i, m in enumerate(messages[:limit])
    )[:18000]
    data = await router.ask_json(
        f"""Summarise this inbox for the user.

{corpus}

Return ONLY JSON:
{{"headline": "one sentence overview",
  "needs_action": [{{"n": 1, "why": "...", "suggested_reply": "one line"}}],
  "informational": [{{"n": 1, "note": "..."}}],
  "can_ignore": [1, 2],
  "newsletter_count": 0,
  "markdown": "a short readable digest referencing message numbers"}}""",
        role="reasoning", temperature=0.25, default=None,
    )
    if not isinstance(data, dict):
        data = _fallback_digest(messages)
    data.update({"ok": True, "count": len(messages), "messages": messages[:limit]})
    if data.get("markdown"):
        data["answer"] = data["markdown"]
    elif data.get("headline"):
        data["answer"] = data["headline"]
    return data


def _fallback_digest(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
    lines = [f"{i + 1}. **{m['subject'] or '(no subject)'}** — {m['from']} ({m['date'][:16]})"
             for i, m in enumerate(messages)]
    return {
        "headline": f"{len(messages)} message(s) need a look.",
        "needs_action": [], "informational": [], "can_ignore": [],
        "newsletter_count": sum(1 for m in messages
                                if re.search(r"unsubscribe|newsletter|digest",
                                             f"{m['subject']} {m.get('body', '')}", re.I)),
        "markdown": "## Inbox digest\n\n" + "\n".join(lines),
        "generated_by": "sam-offline-heuristic",
    }


# ===========================================================================
# SEND  (Prepare -> Preview -> Confirm -> Send)
# ===========================================================================
@tool(
    name="email.preview",
    capability="email.draft",
    agent="communication",
    device="pc",
    description="Show exactly what would be sent, before anything is sent",
    risk="LOW",
    timeout=60,
)
async def email_preview(ctx: ToolContext, draft_id: str = "") -> Dict[str, Any]:
    draft = _DRAFTS.get(draft_id)
    if draft is None:
        return {"ok": False, "error": f"no draft with id '{draft_id}' — run email.draft first",
                "available": sorted(_DRAFTS)[-10:]}
    if not _configured():
        return {"ok": False, "draft": draft.to_dict(),
                "error": "email sending is not configured",
                "hint": "set EMAIL_ENABLED, SMTP_HOST, SMTP_USER, SMTP_PASSWORD and "
                        "EMAIL_ADDRESS in .env"}
    return {"ok": True, "draft": draft.to_dict(), "from_address": settings.email_address,
            "from_name": settings.email_display_name, "smtp": f"{settings.smtp_host}:{settings.smtp_port}",
            "markdown": _preview_markdown(draft),
            "warning": "Nothing has been sent. Confirm to send."}


def _preview_markdown(draft: Draft) -> str:
    head = [
        "## Email preview — nothing sent yet", "",
        f"**From:** {settings.email_display_name} <{settings.email_address}>",
        f"**To:** {', '.join(draft.to) or '(missing!)'}",
    ]
    if draft.cc:
        head.append(f"**Cc:** {', '.join(draft.cc)}")
    head += [f"**Subject:** {draft.subject}", ""]
    if draft.attachments:
        head += [f"**Attachments:** {', '.join(Path(a).name for a in draft.attachments)}", ""]
    head += ["---", "", draft.body, "", "---",
             f"_Drafted by SAM ({draft.tone}, {len(draft.body.split())} words) "
             f"at {draft.created_at}_"]
    return "\n".join(head)


@tool(
    name="email.send",
    capability="email.send",
    agent="communication",
    device="pc",
    description="Send a prepared draft. Always shows a preview and asks for confirmation.",
    schema={"draft_id": {"type": "string"}},
    risk="HIGH",
    confirm=True,
    timeout=180,
)
async def email_send(ctx: ToolContext, draft_id: str = "", to: str = "", subject: str = "",
                     body: str = "", cc: str = "", attachments: Optional[List[str]] = None,
                     request: str = "") -> Dict[str, Any]:
    draft = _DRAFTS.get(draft_id)
    if draft is None:
        # compose-on-the-fly only when the caller supplied everything
        if not (to and subject and body):
            if draft_id:
                return {"ok": False, "error": f"no draft with id '{draft_id}'",
                        "available": sorted(_DRAFTS)[-10:],
                        "hint": "run email.draft first, then email.send with its draft_id"}
            return {"ok": False, "error": "give a draft_id, or to + subject + body"}
        draft = Draft(id=draft_id or f"msg-{int(time.time() * 1000) % 1000000}",
                      to=[r.strip() for r in re.split(r"[,;]", to) if r.strip()],
                      cc=[r.strip() for r in re.split(r"[,;]", cc) if r.strip()],
                      subject=subject, body=body, attachments=[str(a) for a in (attachments or [])])
        _DRAFTS[draft.id] = draft

    if not draft.to:
        return {"ok": False, "error": "the draft has no recipient", "draft": draft.to_dict()}
    if not _configured():
        return {"ok": False, "draft": draft.to_dict(), **_not_configured("send")}
    for address in draft.to + draft.cc:
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", address):
            return {"ok": False, "error": f"'{address}' is not a valid email address",
                    "draft": draft.to_dict()}

    sent = await asyncio.to_thread(_smtp_send, draft)
    if not sent["ok"]:
        return {"ok": False, "error": sent["error"], "draft": draft.to_dict(),
                "hint": sent.get("hint", "")}
    _DRAFTS.pop(draft.id, None)
    return {"ok": True, "sent": True, "draft_id": draft.id, "to": draft.to, "cc": draft.cc,
            "subject": draft.subject, "message_id": sent.get("message_id"),
            "smtp": sent.get("smtp"), "bytes": sent.get("bytes"),
            "answer": f"Sent “{draft.subject}” to {', '.join(draft.to)}.",
            "verified": True}


def _smtp_send(draft: Draft) -> Dict[str, Any]:
    msg = EmailMessage()
    msg["From"] = email.utils.formataddr((settings.email_display_name, settings.email_address))
    msg["To"] = ", ".join(draft.to)
    if draft.cc:
        msg["Cc"] = ", ".join(draft.cc)
    msg["Subject"] = draft.subject
    msg["Date"] = email.utils.formatdate(localtime=True)
    msg["X-Mailer"] = "SAM AI Assistant"
    msg.set_content(draft.body)

    attached: List[str] = []
    for path in draft.attachments:
        p = Path(path).expanduser()
        if not p.is_file():
            continue
        if p.stat().st_size > 20 * 1024 * 1024:
            log.warning("skipping attachment over 20 MB: %s", p)
            continue
        try:
            msg.add_attachment(p.read_bytes(), maintype="application",
                               subtype="octet-stream", filename=p.name)
            attached.append(p.name)
        except OSError as exc:
            log.warning("could not attach %s: %s", p, exc)

    raw = bytes(msg)
    try:
        if int(settings.smtp_port) == 465:
            server = smtplib.SMTP_SSL(settings.smtp_host, int(settings.smtp_port),
                                      context=ssl.create_default_context(), timeout=60)
        else:
            server = smtplib.SMTP(settings.smtp_host, int(settings.smtp_port), timeout=60)
            if settings.smtp_starttls:
                server.starttls(context=ssl.create_default_context())
        with server:
            if settings.smtp_user:
                server.login(settings.smtp_user, settings.smtp_password)
            server.send_message(msg)
        return {"ok": True, "message_id": msg["Message-ID"],
                "smtp": f"{settings.smtp_host}:{settings.smtp_port}", "bytes": len(raw),
                "attachments": attached}
    except smtplib.SMTPAuthenticationError as exc:
        return {"ok": False, "error": f"SMTP authentication failed: {exc}",
                "hint": "use an app password (Gmail: Google Account → Security → App passwords)"}
    except smtplib.SMTPRecipientsRefused as exc:
        return {"ok": False, "error": f"recipient refused: {exc}"}
    except (smtplib.SMTPException, OSError, ssl.SSLError) as exc:
        return {"ok": False, "error": f"SMTP error: {exc}",
                "hint": f"check SMTP_HOST={settings.smtp_host} SMTP_PORT={settings.smtp_port}"}


@tool(
    name="email.status",
    capability="ai.chat",
    agent="communication",
    device="pc",
    description="Report whether email reading and sending are configured, without exposing secrets",
    risk="LOW",
    timeout=30,
)
async def email_status(ctx: ToolContext) -> Dict[str, Any]:
    return {
        "ok": True,
        "enabled": settings.email_enabled,
        "provider": settings.email_provider,
        "can_read": _read_configured(),
        "can_send": _configured(),
        "address": settings.email_address or "(not set)",
        "display_name": settings.email_display_name,
        "imap": f"{settings.imap_host}:{settings.imap_port}" if settings.imap_host else "(not set)",
        "smtp": f"{settings.smtp_host}:{settings.smtp_port}" if settings.smtp_host else "(not set)",
        "always_confirm_send": settings.email_always_confirm_send,
        "pending_drafts": len(_DRAFTS),
        "outbox": str(DRAFT_DIR),
        "secrets_exposed": False,
    }
