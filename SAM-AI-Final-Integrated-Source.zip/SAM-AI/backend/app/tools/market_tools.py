"""
backend.app.tools.market_tools
==============================

**Tools of the Market Analyzer brain (forex · binary options · crypto · stocks).**

Every tool goes through the guard like any other SAM action, so it is
permission-checked, risk-scored, audited and — where relevant — confirmed by the
user before it runs.

What SAM will do here
---------------------
* fetch real, live price data (keyless public feeds, or your keyed provider)
* compute a full technical-analysis snapshot (30+ indicators, levels, patterns)
* score a direction with an explicit, auditable list of reasons and conflicts
* size a position from *your* risk percentage, never from excitement
* backtest a rule on history, with costs, walk-forward folds and honest verdicts
* keep a trade journal and a **virtual (paper)** account
* watch price/indicator alerts in the background and notify you

What SAM will *not* do
----------------------
* place a real order, connect to a broker, or move money
* promise, predict or guarantee a profit
* hide a losing backtest, a negative edge, or a conflicting indicator
* analyse a binary-options trade without attaching the regulatory warning
  (binary options are banned for retail in the EU/UK and flagged as illegal for
  Indian residents by RBI/SEBI under FEMA)

Tool map
--------
=============================  ================================================
``market.quote``               live quote for any symbol
``market.candles``             OHLCV history for a timeframe
``market.forex_rates``         FX cross table for a base currency
``market.crypto_screener``     top/gainer/loser crypto scan
``market.watchlist``           quotes + signals for your watchlist
``market.feed_status``         data-source health and latency
``market.indicators``          full technical snapshot
``market.signal``              scored bias + confidence + reasons
``market.technical_report``    multi-timeframe Markdown report
``market.forex_plan``          entry / stop / targets / position size
``market.binary_analysis``     expiry-aware UP/DOWN analysis + payout maths
``market.regime``              trending / ranging / squeezing + strategies
``market.screener``            rank many symbols by setup quality
``market.multi_timeframe``     higher-timeframe alignment
``market.levels``              support / resistance / pivots / Fibonacci
``market.patterns``            candlestick + chart patterns
``market.volatility``          ATR, historical vol, expected move
``market.correlation``         correlation matrix between symbols
``market.sentiment``           news-driven sentiment for an asset
``market.compare``             two assets side by side
``market.calendar``            market news / risk events for a currency
``market.risk``                sizing, pip value, Kelly, ruin, drawdown, …
``market.backtest``            strategy replay, walk-forward, binary test
``market.journal.*``           add / list / close / stats / review
``market.alert.*``             set / list / remove / check
``market.paper.*``             open / close / portfolio / reset
``market.explain``             explain an indicator, concept or product
``market.broker.status``       broker/live-trading policy status
``market.status``              the brain's own health report
=============================  ================================================
"""

from __future__ import annotations

import asyncio
import math
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.markets import backtest as bt
from backend.app.markets import data_feed
from backend.app.markets import indicators as ind
from backend.app.markets import risk as risk_math
from backend.app.markets import signals as sig_engine
from backend.app.markets.journal import alert_poller_status
from backend.app.tools.registry import ToolContext, tool
from backend.app.utils import net

log = get_logger("tools.markets")

RISK_NOTE = ("Educational analysis by an AI, not financial advice. Markets can move against any "
             "signal; only risk money you can afford to lose.")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _resolve(text: str) -> Dict[str, Any]:
    try:
        sym = data_feed.resolve_symbol(text)
        return {"ok": True, "symbol": sym}
    except Exception as exc:
        return {"ok": False, "error": f"could not understand the symbol '{text}': {exc}"}


def _nums(value: Any) -> List[float]:
    """
    Coerce anything a user or a model might send into a list of floats.

    Accepts ``[1.12, 1.13]``, ``"1.12, 1.13"``, ``"1.12/1.13"``, ``1.12``,
    ``None`` — and never iterates the characters of a string by accident.
    """
    if value is None or value == "":
        return []
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return [float(value)]
    if isinstance(value, str):
        parts = [p for p in re.split(r"[,;/\s]+", value.strip()) if p]
    elif isinstance(value, (list, tuple, set)):
        parts = []
        for item in value:
            parts.extend(_nums(item))
        return parts
    else:
        return []
    out: List[float] = []
    for part in parts:
        try:
            out.append(float(part))
        except (TypeError, ValueError):
            continue
    return out


def _bad(message: str, **extra: Any) -> Dict[str, Any]:
    return {"ok": False, "error": message, **extra}


# phrases the offline rule-based provider emits when no real model is wired up.
# SAM must never present those as a market answer, so _llm falls back to the
# deterministic local text instead.
_HEURISTIC_MARKERS = (
    "I'll research that across several sources",
    "I parsed that as intent",
    "No cloud or local model is configured yet",
    "built-in offline engine",
    "sam-rules-v1",
)


async def _llm(prompt: str, system: str = "", role: str = "reasoning",
               max_tokens: int = 1200, fallback: str = "") -> str:
    """
    Ask the model router for prose. Returns ``fallback`` when no real model is
    configured (the heuristic provider) so market answers stay factual and
    numeric instead of degrading into canned chat text.
    """
    from backend.app.models.router import router

    try:
        res = await router.ask(prompt, role=role, system=system or None, max_tokens=max_tokens,
                               temperature=0.3)
    except Exception as exc:  # pragma: no cover - provider crash
        log.debug("market narrative failed: %s", exc)
        return fallback
    text = (res.text or "").strip()
    if not text or getattr(res, "provider", "") == "heuristic" or \
            any(m.lower() in text.lower() for m in _HEURISTIC_MARKERS):
        return fallback
    return text


async def _snapshot(symbol: str, interval: str, limit: int = 300) -> Dict[str, Any]:
    """Fetch candles + full indicator snapshot in one call."""
    data = await data_feed.candles(symbol, interval, limit)
    if not data.get("ok"):
        return data
    snap = ind.full_snapshot(data["candles"], symbol=data.get("symbol", symbol),
                            interval=interval)
    if not snap.get("ok"):
        return {**data, **snap}
    snap["source"] = data.get("source")
    snap["feed_meta"] = data.get("meta")
    snap["candles_tail"] = data["candles"][-5:]
    return snap


def _fmt_price(value: Any, digits: int = 5) -> str:
    try:
        return f"{float(value):,.{digits}f}"
    except (TypeError, ValueError):
        return str(value)


def _digits(sym: data_feed.Symbol) -> int:
    if sym.asset_class == "forex":
        return 3 if sym.quote == "JPY" else 5
    if sym.asset_class == "crypto":
        return 2
    return 2


# ===========================================================================
# 1. DATA
# ===========================================================================
@tool(
    name="market.quote",
    capability="market.data.read",
    agent="markets",
    device="cloud",
    description="Get a live price quote for any forex pair, crypto, stock, index or commodity (e.g. EURUSD, BTC, NIFTY, gold, AAPL)",
    schema={"symbol": {"type": "string", "required": True,
                       "description": "EURUSD, GBP/JPY, BTC, bitcoin, NIFTY, SENSEX, gold, AAPL, RELIANCE.NS"}},
    risk="LOW",
    timeout=60,
)
async def market_quote(ctx: ToolContext, symbol: str = "", request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    text = re.sub(r"^(what(?:'s| is) the )?(price|quote|rate|value) of\s+", "", text, flags=re.I)
    text = re.sub(r"\s+(price|quote|now|today|currently)\b.*$", "", text, flags=re.I).strip(" ?.")
    if not text:
        return _bad("which market? e.g. EURUSD, BTC, NIFTY, gold, AAPL")
    res = _resolve(text)
    if not res["ok"]:
        return res
    sym = res["symbol"]
    try:
        data = await data_feed.quote(sym)
    except Exception as exc:
        return _bad(f"quote failed: {type(exc).__name__}: {exc}", symbol=sym.display)
    if not data.get("ok"):
        return data
    d = _digits(sym)
    change = data.get("change_percent")
    data["answer"] = (
        f"**{sym.display}** ({sym.asset_class}): {_fmt_price(data.get('price'), d)} "
        f"{data.get('currency') or ''}".strip()
        + (f", {change:+.2f}% vs previous close" if change is not None else "")
        + (f". Day range {_fmt_price(data.get('day_low'), d)}–{_fmt_price(data.get('day_high'), d)}"
           if data.get("day_low") else "")
        + f". Source: {data.get('source')}."
    )
    data["disclaimer"] = RISK_NOTE
    return data


@tool(
    name="market.candles",
    capability="market.data.read",
    agent="markets",
    device="cloud",
    description="Fetch OHLCV candle history for a symbol and timeframe (1m, 5m, 15m, 1h, 4h, 1d, 1wk)",
    schema={"symbol": {"type": "string", "required": True},
            "interval": {"type": "string", "default": "1h"},
            "limit": {"type": "integer", "default": 200}},
    risk="LOW",
    timeout=90,
)
async def market_candles(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                         limit: int = 200, request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    m = re.search(r"\b(1m|5m|15m|30m|1h|4h|1d|1w|1wk|daily|hourly|weekly)\b", text, re.I)
    if m and interval == "1h":
        interval = m.group(1)
    res = _resolve(text)
    if not res["ok"]:
        return res
    try:
        data = await data_feed.candles(text, interval, int(limit), sym=res["symbol"])
    except Exception as exc:
        return _bad(f"candle fetch failed: {type(exc).__name__}: {exc}", symbol=text)
    if not data.get("ok"):
        return data
    cs = data["candles"]
    closes = [c["close"] for c in cs]
    data["stats"] = {"first": cs[0], "last": cs[-1], "high": max(c["high"] for c in cs),
                     "low": min(c["low"] for c in cs), "range_percent":
                     round((max(c["high"] for c in cs) - min(c["low"] for c in cs)) /
                           min(c["low"] for c in cs) * 100, 4) if min(c["low"] for c in cs) else None,
                     "net_change_percent": round((closes[-1] / closes[0] - 1) * 100, 4)
                     if closes[0] else None,
                     "up_candles": sum(1 for c in cs if c["close"] > c["open"]),
                     "down_candles": sum(1 for c in cs if c["close"] < c["open"])}
    data["answer"] = (f"{data['symbol']} {interval}: {len(cs)} candles from {cs[0]['ts']} to "
                      f"{cs[-1]['ts']}. Last close {_fmt_price(closes[-1], 5)}, period "
                      f"{data['stats']['net_change_percent']:+.2f}%, range "
                      f"{_fmt_price(data['stats']['low'], 5)}–{_fmt_price(data['stats']['high'], 5)}.")
    return data


@tool(
    name="market.forex_rates",
    capability="market.data.read",
    agent="markets",
    device="cloud",
    description="Get the full FX cross-rate table for a base currency (ECB reference rates)",
    schema={"base": {"type": "string", "default": "USD"},
            "quotes": {"type": "array", "description": "limit to these currencies"}},
    risk="LOW",
    timeout=45,
)
async def market_forex_rates(ctx: ToolContext, base: str = "USD",
                             quotes: Optional[List[str]] = None, request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    for code in data_feed.FOREX_CCY.values():
        if code.lower() in text and base == "USD":
            base = code
            break
    try:
        data = await data_feed.fx_table(base, quotes)
    except Exception as exc:
        return _bad(f"FX table failed: {type(exc).__name__}: {exc}")
    if not data.get("ok"):
        return data
    majors = ["EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD", "INR", "CNY", "SGD", "AED"]
    rates = data["rates"]
    table = {k: v for k, v in rates.items() if k in majors}
    crosses = {}
    if base.upper() in rates:
        for a in ("EUR", "GBP", "USD"):
            for b in ("JPY", "CHF", "CAD", "AUD"):
                if a in rates and b in rates and rates.get(a):
                    crosses[f"{a}{b}"] = round(rates[b] / rates[a], 5)
    data.update({"majors": table, "crosses": crosses,
                 "answer": f"1 {base.upper()} = " + ", ".join(f"{v} {k}" for k, v in list(table.items())[:8])
                           + f" (source {data.get('source')}, as of {data.get('as_of')}). "
                           f"Note: ECB reference rates are daily; for live ticks use market.quote."})
    return data


@tool(
    name="market.crypto_screener",
    capability="market.data.read",
    agent="markets",
    device="cloud",
    description="Scan the crypto market: top coins by market cap, biggest 24h gainers and losers",
    schema={"limit": {"type": "integer", "default": 20},
            "sort": {"type": "string", "description": "market_cap|gainers|losers|volume"},
            "vs": {"type": "string", "default": "usd"}},
    risk="LOW",
    timeout=60,
)
async def market_crypto_screener(ctx: ToolContext, limit: int = 20, sort: str = "market_cap",
                                 vs: str = "usd", request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    if "gain" in text or "top performer" in text or "rising" in text:
        sort = "gainers"
    elif "los" in text or "dump" in text or "falling" in text:
        sort = "losers"
    elif "volume" in text:
        sort = "volume"
    if "inr" in text:
        vs = "inr"
    order = {"market_cap": "market_cap_desc", "gainers": "market_cap_desc",
             "losers": "market_cap_desc", "volume": "volume_desc"}.get(sort, "market_cap_desc")
    try:
        rows = await data_feed.crypto_markets(max(int(limit), 30), vs, order)
    except Exception as exc:
        return _bad(f"crypto screener failed: {type(exc).__name__}: {exc}")
    if not rows:
        return _bad("the crypto feed returned no rows")
    if sort == "gainers":
        rows = sorted(rows, key=lambda r: -(r.get("change_24h_percent") or -999))
    elif sort == "losers":
        rows = sorted(rows, key=lambda r: (r.get("change_24h_percent") or 999))
    rows = rows[: max(1, int(limit))]
    lines = [f"{i}. {r['symbol']} {r['name']} — {r['price']:,.4f} {vs.upper()} "
             f"({(r.get('change_24h_percent') or 0):+.2f}% 24h, "
             f"{(r.get('change_7d_percent') or 0):+.2f}% 7d, mcap #{r.get('market_cap_rank')})"
             for i, r in enumerate(rows, 1)]
    return {"ok": True, "sort": sort, "vs": vs, "count": len(rows), "coins": rows,
            "answer": f"Crypto screener ({sort}, {vs.upper()}):\n" + "\n".join(lines),
            "source": "coingecko"}


@tool(
    name="market.watchlist",
    capability="market.data.read",
    agent="markets",
    device="cloud",
    description="Show the user's market watchlist with live prices, daily change and a quick signal score",
    schema={"symbols": {"type": "array", "description": "override the configured watchlist"},
            "interval": {"type": "string", "default": "1h"},
            "with_signal": {"type": "boolean", "default": True}},
    risk="LOW",
    timeout=180,
)
async def market_watchlist(ctx: ToolContext, symbols: Optional[List[str]] = None,
                           interval: str = "1h", with_signal: bool = True,
                           request: str = "") -> Dict[str, Any]:
    configured = getattr(settings, "market_watchlist", "EURUSD,GBPUSD,USDJPY,BTC-USD,^NSEI,GC=F")
    wanted = symbols or [s.strip() for s in re.split(r"[,\s]+", configured) if s.strip()]
    if not wanted:
        return _bad("the watchlist is empty — set MARKET_WATCHLIST in .env or pass symbols")
    wanted = wanted[:12]

    async def one(text: str) -> Dict[str, Any]:
        res = _resolve(text)
        if not res["ok"]:
            return {"symbol": text, "ok": False, "error": res["error"]}
        sym = res["symbol"]
        out: Dict[str, Any] = {"symbol": sym.display, "asset_class": sym.asset_class}
        try:
            q = await data_feed.quote(sym)
            out.update({"price": q.get("price"), "change_percent": q.get("change_percent"),
                        "currency": q.get("currency"), "ok": q.get("ok", False)})
            if q.get("error"):
                out["error"] = q["error"]
            if with_signal and q.get("ok"):
                data = await data_feed.candles(sym.ticker, interval, 200, sym=sym)
                if data.get("ok") and len(data.get("candles") or []) >= 40:
                    snap = ind.full_snapshot(data["candles"], symbol=sym.display, interval=interval)
                    if snap.get("ok"):
                        s = sig_engine.build_signal(snap, symbol=sym.display, interval=interval)
                        out.update({"score": s["score"], "bias": s["bias"],
                                    "confidence": s["confidence"],
                                    "trend": (s.get("trend") or {}).get("trend"),
                                    "rsi": snap.get("rsi14"),
                                    "regime": s["regime"]["regime"]})
        except Exception as exc:
            out.update({"ok": False, "error": f"{type(exc).__name__}: {exc}"})
        return out

    rows = await net.gather(*(one(s) for s in wanted), timeout=90)
    rows = [r for r in rows if isinstance(r, dict)]
    scored = sorted([r for r in rows if r.get("score") is not None],
                    key=lambda r: -abs(r["score"]))
    lines = []
    for r in rows:
        if not r.get("ok"):
            lines.append(f"- {r.get('symbol')}: unavailable ({r.get('error', 'no data')})")
            continue
        extra = ""
        if r.get("score") is not None:
            extra = f" | score {r['score']:+.0f} {r.get('bias')} (conf {r.get('confidence'):.2f}, {r.get('regime')})"
        lines.append(f"- {r['symbol']}: {_fmt_price(r.get('price'), 5)} "
                     f"({(r.get('change_percent') or 0):+.2f}%) RSI {r.get('rsi')}{extra}")
    return {"ok": True, "interval": interval, "count": len(rows), "watchlist": rows,
            "strongest_setup": scored[0] if scored else None,
            "answer": f"Watchlist ({interval}):\n" + "\n".join(lines),
            "disclaimer": RISK_NOTE}


@tool(
    name="market.feed_status",
    capability="market.data.read",
    agent="markets",
    device="cloud",
    description="Check the health and latency of every market data source SAM uses",
    risk="LOW",
    timeout=60,
)
async def market_feed_status(ctx: ToolContext) -> Dict[str, Any]:
    try:
        health = await data_feed.feed_health()
    except Exception as exc:
        return _bad(f"feed health check failed: {exc}")
    health["configured_provider"] = getattr(settings, "market_data_provider", "auto")
    health["keyed_providers"] = [n for n, k in
                                 (("twelvedata", getattr(settings, "twelvedata_api_key", "")),
                                  ("alpha_vantage", getattr(settings, "alpha_vantage_api_key", "")),
                                  ("brave", settings.brave_api_key)) if k]
    health["answer"] = (f"{health['ready']}/{health['total']} market data sources are reachable"
                        + ("" if health["ok"] else " — some feeds are down, analysis may be partial"))
    return health


# ===========================================================================
# 2. ANALYSIS
# ===========================================================================
@tool(
    name="market.indicators",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Compute the full technical-analysis snapshot for a symbol: trend, RSI, MACD, Bollinger, ATR, ADX, Stochastic, Ichimoku, VWAP, levels, patterns, divergence",
    schema={"symbol": {"type": "string", "required": True},
            "interval": {"type": "string", "default": "1h"},
            "limit": {"type": "integer", "default": 300},
            "include_series": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=120,
)
async def market_indicators(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                            limit: int = 300, include_series: bool = False,
                            request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market should I analyse?")
    try:
        snap = await _snapshot(text, interval, int(limit))
    except Exception as exc:
        return _bad(f"analysis failed: {type(exc).__name__}: {exc}", symbol=text)
    if not snap.get("ok"):
        return snap
    if not include_series:
        snap.pop("series", None)
        snap.pop("candles_tail", None)
    trend = snap.get("trend") or {}
    levels = snap.get("levels") or {}
    ns, nr = levels.get("nearest_support"), levels.get("nearest_resistance")
    snap["answer"] = (
        f"**{snap['symbol']}** ({interval}, {snap['candles']} candles) — "
        f"{_fmt_price(snap['price'], 5)} ({snap['change_percent']:+.2f}%).\n"
        f"Trend: {trend.get('trend')} / {trend.get('strength')} (ADX {snap['adx'].get('value')}).\n"
        f"RSI(14) {snap.get('rsi14')} ({snap.get('rsi_state')}), "
        f"MACD {snap['macd'].get('macd')} vs signal {snap['macd'].get('signal')} "
        f"({snap['macd'].get('state')}).\n"
        f"Bollinger %B {snap['bollinger'].get('percent_b')} ({snap['bollinger'].get('state')}), "
        f"Stochastic %K {snap['stochastic'].get('k')} ({snap['stochastic'].get('state')}).\n"
        f"ATR {snap['atr'].get('value')} ({snap['atr'].get('percent')}% of price), "
        f"annualised volatility {(snap.get('volatility') or {}).get('annualised_volatility_percent')}%.\n"
        f"Support {ns.get('price') if ns else 'n/a'} · Resistance {nr.get('price') if nr else 'n/a'} · "
        f"Pivot {snap['pivots'].get('pivot')}.\n"
        f"Patterns: {', '.join(p['pattern'] for p in (snap.get('candle_patterns') or [])[:3]) or 'none'}"
    )
    snap["disclaimer"] = RISK_NOTE
    return snap


@tool(
    name="market.signal",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Produce a scored trading signal for a symbol: bias, confidence, every indicator vote, conflicts and the market regime",
    schema={"symbol": {"type": "string", "required": True},
            "interval": {"type": "string", "default": "1h"},
            "limit": {"type": "integer", "default": 300}},
    risk="LOW",
    timeout=120,
)
async def market_signal(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                        limit: int = 300, request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    try:
        snap = await _snapshot(text, interval, int(limit))
    except Exception as exc:
        return _bad(f"signal failed: {type(exc).__name__}: {exc}", symbol=text)
    if not snap.get("ok"):
        return snap
    sig = sig_engine.build_signal(snap, symbol=snap.get("symbol", text), interval=interval)
    sig["ok"] = True
    sig["answer"] = (
        f"**{sig['symbol']}** ({interval}): {sig['bias']} — score {sig['score']:+.1f}/100, "
        f"confidence {sig['confidence_label']} ({sig['confidence']:.2f}), "
        f"{sig['votes']['bullish']} bullish vs {sig['votes']['bearish']} bearish indicators.\n"
        f"Regime: {sig['regime']['regime']} — {sig['regime']['why']}.\n"
        f"Top drivers: " + "; ".join(f"{d['indicator']}: {d['reason']}"
                                     for d in sig["top_drivers"][:3])
        + ("\nConflicts: " + "; ".join(f"{c['indicator']}: {c['reason']}"
                                       for c in sig["conflicts"][:2]) if sig["conflicts"] else "")
        + "\n_" + RISK_NOTE + "_"
    )
    sig["disclaimer"] = RISK_NOTE
    return sig


@tool(
    name="market.technical_report",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Write a full multi-timeframe technical analysis report for a symbol, in Markdown, with numbers and a narrative",
    schema={"symbol": {"type": "string", "required": True},
            "timeframes": {"type": "array", "description": "e.g. ['15m','1h','4h','1d']"},
            "style": {"type": "string", "description": "brief|standard|deep"},
            "save": {"type": "boolean", "default": True}},
    risk="LOW",
    timeout=240,
)
async def market_technical_report(ctx: ToolContext, symbol: str = "",
                                  timeframes: Optional[List[str]] = None, style: str = "standard",
                                  save: bool = True, request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market should I write the report for?")
    tfs = timeframes or ["15m", "1h", "4h", "1d"]
    tfs = [t for t in tfs][:5]
    t0 = time.perf_counter()

    async def one(tf: str) -> Dict[str, Any]:
        try:
            snap = await _snapshot(text, tf, 300 if tf in ("4h", "1d", "1wk") else 200)
            if not snap.get("ok"):
                return {"timeframe": tf, "ok": False, "error": snap.get("error")}
            sig = sig_engine.build_signal(snap, symbol=snap.get("symbol", text), interval=tf)
            return {"timeframe": tf, "ok": True, "snapshot": snap, "signal": sig}
        except Exception as exc:
            return {"timeframe": tf, "ok": False, "error": f"{type(exc).__name__}: {exc}"}

    results = await net.gather(*(one(tf) for tf in tfs), timeout=150)
    good = [r for r in results if isinstance(r, dict) and r.get("ok")]
    if not good:
        return _bad("no timeframe produced usable data — check the symbol and the connection",
                    detail=[r for r in results if isinstance(r, dict)])

    mtf = sig_engine.multi_timeframe(text, {r["timeframe"]: r for r in good})
    primary = good[-1]                                   # highest timeframe with data
    snap, sig = primary["snapshot"], primary["signal"]
    levels = snap.get("levels") or {}

    md: List[str] = [
        f"# Technical report — {snap.get('symbol', text)}",
        f"_Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} by SAM's Market "
        f"Analyzer · data source: {snap.get('source', 'n/a')}_",
        "",
        f"**Price** {_fmt_price(snap.get('price'), 5)} ({snap.get('change_percent', 0):+.2f}% on the "
        f"last {primary['timeframe']} candle)",
        f"**Bias** {sig['bias']} · score {sig['score']:+.1f}/100 · confidence {sig['confidence_label']} "
        f"({sig['confidence']:.2f})",
        f"**Regime** {sig['regime']['regime']} — {sig['regime']['why']}",
        f"**Higher-timeframe agreement** {mtf['interpretation']}",
        "",
        "## Timeframes",
        "| TF | Price | Trend | ADX | RSI14 | MACD | Score | Bias | Confidence |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for r in good:
        s, g = r["signal"], r["snapshot"]
        md.append(f"| {r['timeframe']} | {_fmt_price(g.get('price'), 5)} | "
                  f"{(g.get('trend') or {}).get('trend')} | {(g.get('adx') or {}).get('value')} | "
                  f"{g.get('rsi14')} | {(g.get('macd') or {}).get('state')} | {s['score']:+.0f} | "
                  f"{s['bias']} | {s['confidence']:.2f} |")

    md += ["", "## Key levels",
           f"- Nearest support: {(levels.get('nearest_support') or {}).get('price')} "
           f"({(levels.get('nearest_support') or {}).get('touches')} touches)",
           f"- Nearest resistance: {(levels.get('nearest_resistance') or {}).get('price')} "
           f"({(levels.get('nearest_resistance') or {}).get('touches')} touches)",
           f"- Pivots ({snap['pivots'].get('kind')}): R2 {snap['pivots'].get('r2')} · "
           f"R1 {snap['pivots'].get('r1')} · P {snap['pivots'].get('pivot')} · "
           f"S1 {snap['pivots'].get('s1')} · S2 {snap['pivots'].get('s2')}",
           f"- Fibonacci ({snap['fibonacci'].get('trend')} swing "
           f"{snap['fibonacci'].get('swing_low')}–{snap['fibonacci'].get('swing_high')}): "
           + ", ".join(f"{k} {v}" for k, v in list((snap['fibonacci'].get('levels') or {}).items())[:5]),
           ""]

    md += ["## Indicators"]
    for row in [
        f"- RSI(14) {snap.get('rsi14')} — {snap.get('rsi_state')}",
        f"- MACD {snap['macd'].get('macd')} / signal {snap['macd'].get('signal')} / "
        f"histogram {snap['macd'].get('histogram')} — {snap['macd'].get('state')}",
        f"- Bollinger %B {snap['bollinger'].get('percent_b')}, bandwidth "
        f"{snap['bollinger'].get('bandwidth_percent')}% — {snap['bollinger'].get('state')}",
        f"- Stochastic %K {snap['stochastic'].get('k')} / %D {snap['stochastic'].get('d')} — "
        f"{snap['stochastic'].get('state')}",
        f"- ATR(14) {snap['atr'].get('value')} ({snap['atr'].get('percent')}% of price)",
        f"- ADX {snap['adx'].get('value')} (+DI {snap['adx'].get('plus_di')}, "
        f"−DI {snap['adx'].get('minus_di')}) — {snap['adx'].get('strength')}",
        f"- Williams %R {snap.get('williams_r')} · CCI {snap.get('cci')} · MFI {snap.get('mfi')} · "
        f"ROC(12) {snap.get('roc12')}",
        f"- Parabolic SAR {snap['psar'].get('value')} (trend {snap['psar'].get('trend')}, "
        f"{snap['psar'].get('flips')} flips)",
        f"- VWAP {snap.get('vwap')} · OBV trend {snap.get('obv_trend')}",
        f"- Volatility: annualised {(snap.get('volatility') or {}).get('annualised_volatility_percent')}% "
        f"({(snap.get('volatility') or {}).get('interpretation')})",
        f"- Squeeze: {snap['squeeze'].get('interpretation')}",
    ]:
        md.append(row)

    if snap.get("ichimoku", {}).get("ok"):
        ich = snap["ichimoku"]
        md += ["", "## Ichimoku",
               f"- Price {ich.get('position')}, bias {ich.get('bias')}",
               f"- Tenkan {ich.get('tenkan_sen')} · Kijun {ich.get('kijun_sen')} · "
               f"Senkou A {ich.get('senkou_span_a')} · Senkou B {ich.get('senkou_span_b')}",
               "- " + "\n- ".join(ich.get("signals") or [])]

    md += ["", "## Candlestick & chart patterns"]
    pats = (snap.get("candle_patterns") or []) + (snap.get("chart_patterns") or [])
    if pats:
        md += [f"- **{p.get('pattern')}** ({p.get('bias')}, {p.get('strength')}) — {p.get('meaning')}"
               for p in pats[:6]]
    else:
        md.append("- none detected")

    div = snap.get("divergence") or {}
    md += ["", "## Divergence", "- " + "\n- ".join(div.get("notes") or ["none"])]

    md += ["", "## Why (indicator votes)",
           "| Indicator | Vote | Weight | Reason |", "|---|---|---|---|"]
    for v in sig["all_votes"][:14]:
        md.append(f"| {v['indicator']} | {v['vote']:+.2f} | {v['weight']} | {v['reason']} |")
    if sig["conflicts"]:
        md += ["", "**Against the bias:**",
               *[f"- {c['indicator']}: {c['reason']}" for c in sig["conflicts"]]]

    md += ["", "## Suggested approach for this regime",
           *[f"- {s}" for s in sig["regime"]["suggested_strategies"]],
           f"- Avoid: {sig['regime']['avoid']}",
           "", "---",
           f"_{sig_engine.NO_ADVICE} {sig_engine.FOREX_WARNING}_",
           ]
    report = "\n".join(md)

    # deterministic note built from the numbers themselves — used whenever no
    # real language model is configured, so the report never degrades
    local_note = (
        f"{snap.get('symbol', text)} trades at {snap.get('price')} on the {interval} chart. "
        f"The indicator vote is {sig['bias']} ({sig['score']:+.1f}/100, confidence "
        f"{sig['confidence']:.2f} — {sig['confidence_label']}) in a "
        f"{sig['regime']['regime']} regime ({sig['regime']['why']}). "
        f"Nearest support {(levels.get('nearest_support') or {}).get('price', 'n/a')}, nearest "
        f"resistance {(levels.get('nearest_resistance') or {}).get('price', 'n/a')}, pivot "
        f"{snap['pivots'].get('pivot')}. ATR is {snap['atr'].get('value')} "
        f"({snap['atr'].get('percent')}% per candle), so a normal candle moves about that much — "
        f"any stop tighter than ~1 ATR is noise. "
        f"Strongest drivers: {'; '.join(d['reason'] for d in sig['top_drivers'][:3]) or 'none'}. "
        f"Conflicting evidence: {'; '.join(c['reason'] for c in sig['conflicts'][:3]) or 'none'}. "
        + (f"Patterns present: {', '.join(pat.get('pattern', '') for pat in pats[:3])}. " if pats else "")
        + f"Timeframes: " + ", ".join(
            f"{r['timeframe']} {r['signal']['bias']} ({r['signal']['score']:+.0f})" for r in good)
        + ". The view is invalid if price closes beyond the nearest structural level against the "
          "bias, or if the higher timeframe flips. "
        f"{sig_engine.NO_ADVICE}"
    )

    narrative = ""
    if style != "brief":
        evidence = "\n".join(
            f"{r['timeframe']}: score {r['signal']['score']:+.1f}, bias {r['signal']['bias']}, "
            f"trend {(r['snapshot'].get('trend') or {}).get('trend')}, "
            f"RSI {r['snapshot'].get('rsi14')}, ADX {(r['snapshot'].get('adx') or {}).get('value')}"
            for r in good)
        narrative = await _llm(
            f"Write a {('short' if style == 'standard' else 'detailed')} professional market note for "
            f"{snap.get('symbol', text)} based ONLY on this evidence. Be concrete about levels and "
            f"conditions, state what would invalidate the view, and never promise a result.\n\n"
            f"PRICE: {snap.get('price')}\nBIAS: {sig['bias']} ({sig['score']:+.1f}, "
            f"confidence {sig['confidence']})\nREGIME: {sig['regime']['regime']} — {sig['regime']['why']}\n"
            f"LEVELS: support {(levels.get('nearest_support') or {}).get('price')}, "
            f"resistance {(levels.get('nearest_resistance') or {}).get('price')}, "
            f"pivot {snap['pivots'].get('pivot')}\n"
            f"ATR: {snap['atr'].get('value')} ({snap['atr'].get('percent')}%)\n"
            f"MULTI-TIMEFRAME:\n{evidence}\n"
            f"PATTERNS: {', '.join(p.get('pattern', '') for p in pats[:5]) or 'none'}\n"
            f"TOP DRIVERS: {'; '.join(d['reason'] for d in sig['top_drivers'][:4])}\n"
            f"CONFLICTS: {'; '.join(c['reason'] for c in sig['conflicts'][:3]) or 'none'}",
            system="You are SAM's Market Analyzer. You are precise, numeric and calm. You never "
                   "promise profits, never invent numbers, and you always mention risk and "
                   "invalidation. You are an AI, not a licensed advisor.",
            max_tokens=700 if style == "standard" else 120,
            fallback=local_note)


    saved = None
    if save and report:
        try:
            from backend.app.coding.documents import documents

            slug = re.sub(r"[^A-Za-z0-9._-]+", "-", snap.get("symbol", text)).strip("-")
            saved = await documents.save_text(
                f"market-report-{slug}-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M')}.md",
                report + (("\n\n## Narrative\n\n" + narrative) if narrative else ""),
                category="documents")
        except Exception as exc:  # pragma: no cover
            log.debug("could not save the market report: %s", exc)

    return {"ok": True, "symbol": snap.get("symbol", text), "timeframes": [r["timeframe"] for r in good],
            "report": report, "narrative": narrative, "multi_timeframe": mtf,
            "bias": sig["bias"], "score": sig["score"], "confidence": sig["confidence"],
            "price": snap.get("price"), "saved": saved,
            "took_ms": int((time.perf_counter() - t0) * 1000),
            "answer": (narrative or report)[:1600],
            "disclaimer": sig_engine.FOREX_WARNING + " " + RISK_NOTE}


@tool(
    name="market.forex_plan",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Build a complete forex/CFD trade plan: direction, entry, ATR-based stop, targets, risk:reward and a position size from the account risk percentage",
    schema={"symbol": {"type": "string", "required": True},
            "interval": {"type": "string", "default": "1h"},
            "balance": {"type": "number", "description": "account balance for sizing"},
            "risk_percent": {"type": "number", "default": 1.0},
            "rr": {"type": "number", "default": 2.0, "description": "target risk:reward"},
            "htf": {"type": "string", "description": "higher timeframe to confirm, e.g. 4h"},
            "account_currency": {"type": "string", "default": "USD"}},
    risk="LOW",
    timeout=180,
)
async def market_forex_plan(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                            balance: float = 0.0, risk_percent: float = 1.0, rr: float = 2.0,
                            htf: str = "", account_currency: str = "USD",
                            request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which pair?")
    bal = float(balance or getattr(settings, "market_paper_balance", 10000) or 10000)
    rp = float(risk_percent or getattr(settings, "market_risk_per_trade", 1.0))
    rp = min(rp, float(getattr(settings, "market_max_risk_per_trade", 5.0)))
    try:
        snap = await _snapshot(text, interval, 300)
    except Exception as exc:
        return _bad(f"plan failed: {type(exc).__name__}: {exc}", symbol=text)
    if not snap.get("ok"):
        return snap
    htf_bias = None
    if htf:
        try:
            htf_snap = await _snapshot(text, htf, 300)
            if htf_snap.get("ok"):
                htf_bias = (htf_snap.get("trend") or {}).get("trend")
        except Exception as exc:
            log.debug("htf check failed: %s", exc)
    res = _resolve(text)
    sym = res.get("symbol") if res.get("ok") else None
    plan = sig_engine.forex_signal(
        snap, symbol=snap.get("symbol", text), interval=interval,
        account_currency=account_currency, balance=bal, risk_percent=rp, rr=float(rr),
        htf_bias=htf_bias, pair_type=(sym.asset_class if sym else "forex"))
    if sym and sym.asset_class == "forex":
        # express the stop distance in pips for forex
        stop = (plan.get("plan") or {}).get("stop_loss")
        price = plan.get("price")
        if stop and price:
            ps = risk_math.pip_size(sym.quote)
            pips = abs(price - stop) / ps
            plan["plan"]["stop_pips"] = round(pips, 1)
            plan["plan"]["stop_distance"] = round(abs(price - stop), 6)
            for i, t in enumerate(plan["plan"].get("take_profits") or [], 1):
                plan["plan"][f"tp{i}_pips"] = round(abs(t - price) / ps, 1)
    # journal the plan so the user can review it later
    try:
        from backend.app.markets.journal import journal

        trade = plan.get("plan") or {}
        entry = await journal.add(
            symbol=snap.get("symbol", text), direction=trade.get("direction", "flat"),
            product="paper" if plan.get("trade") else "spot",
            asset_class=(sym.asset_class if sym else "forex"),
            status="planned", account="journal", timeframe=interval,
            strategy=f"indicator-vote {plan.get('regime', {}).get('regime')}",
            entry=trade.get("entry"), stop=trade.get("stop_loss"),
            units=(trade.get("position") or {}).get("units", 0.0),
            targets=trade.get("take_profits") or [], signal_score=plan.get("score", 0),
            confidence=plan.get("confidence", 0),
            reasons=[d["reason"] for d in (plan.get("top_drivers") or [])[:5]],
            notes="; ".join(plan.get("no_trade_reasons") or [])[:400])
        plan["journal_id"] = entry.get("id")
    except Exception as exc:  # pragma: no cover
        log.debug("could not journal the plan: %s", exc)
    return plan


@tool(
    name="market.binary_analysis",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Analyse a binary-options setup: expiry-aware UP/DOWN probability, expected move, break-even win rate for the payout, and reasons not to trade. Always includes the regulatory warning.",
    schema={"symbol": {"type": "string", "required": True},
            "interval": {"type": "string", "default": "1m",
                         "description": "chart timeframe used for the analysis"},
            "expiry_minutes": {"type": "integer", "default": 5},
            "payout_percent": {"type": "number", "default": 80},
            "side": {"type": "string", "description": "'up'|'down' to test a specific side; empty = SAM's read"}},
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def market_binary_analysis(ctx: ToolContext, symbol: str = "", interval: str = "1m",
                                 expiry_minutes: int = 5, payout_percent: float = 80.0,
                                 side: str = "", request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market? e.g. EURUSD")
    exp = max(1, min(int(expiry_minutes), 1440))
    if exp <= 1:
        return {**_bad("SAM will not analyse a 60-second (or shorter) binary expiry: at that "
                       "horizon the outcome is dominated by spread and tick noise, and the "
                       "payout maths makes it negative expectancy by construction.",
                       symbol=text, expiry_minutes=exp),
                "warning": sig_engine.BINARY_WARNING}
    tf = interval if interval not in ("auto", "") else ("1m" if exp <= 5 else "5m" if exp <= 30
                                                        else "15m" if exp <= 120 else "1h")
    try:
        snap = await _snapshot(text, tf, 300)
    except Exception as exc:
        return _bad(f"binary analysis failed: {type(exc).__name__}: {exc}", symbol=text)
    if not snap.get("ok"):
        return snap
    out = sig_engine.binary_signal(snap, symbol=snap.get("symbol", text), interval=tf,
                                   expiry_minutes=exp, payout_percent=float(payout_percent),
                                   direction_preference=side)
    a = out["analysis"]
    out["answer"] = (
        f"**{out['symbol']}** binary analysis ({exp}-minute expiry, {tf} chart, "
        f"{payout_percent:g}% payout)\n"
        f"Read: **{a['recommended_side']}** — estimated {a['p_up_percent']:.1f}% up / "
        f"{a['p_down_percent']:.1f}% down (honest band "
        f"{a['probability_band'][0]:.1f}–{a['probability_band'][1]:.1f}%).\n"
        f"Expected move inside the expiry: {_fmt_price(a['expected_move_in_window'], 6)} "
        f"({a['expected_move_percent']}%) vs a noise floor of {_fmt_price(a['noise_floor'], 6)}"
        + (" — TOO QUIET to trade." if a["market_too_quiet"] else ".") + "\n"
        f"Break-even win rate at this payout: **{a['break_even_win_rate_percent']:.2f}%**. "
        f"Estimated edge: {a['estimated_edge_percent_points']:+.2f} points ⇒ "
        f"expectancy {a['expectancy_per_100_staked']:+.2f} per 100 staked.\n"
        f"Regime: {out['regime']['regime']} — {out['regime']['why']}.\n"
        f"Confidence {out['confidence_label']} ({out['confidence']:.2f}); "
        f"verdict: {'setup passes the minimum bar' if a['tradeable'] else 'NO TRADE'}.\n"
        + ("" if a["tradeable"] else "Reasons not to trade:\n" +
           "".join(f"- {r}\n" for r in out["reasons_not_to_trade"]))
        + "\n" + out["warning"]
    )
    try:
        from backend.app.markets.journal import journal

        entry = await journal.add(symbol=out["symbol"], direction=a["recommended_side"].split()[0].lower(),
                                  product="binary", asset_class=(snap.get("feed_meta") or {}).get(
                                      "instrument_type", "forex").lower(),
                                  status="planned", account="journal", timeframe=tf,
                                  strategy="indicator-vote binary", entry=out.get("price"),
                                  stake=100.0, signal_score=out.get("score", 0),
                                  confidence=out.get("confidence", 0),
                                  expiry_minutes=exp, payout_percent=float(payout_percent),
                                  reasons=out.get("why") or [],
                                  notes="; ".join(out.get("reasons_not_to_trade") or [])[:400])
        out["journal_id"] = entry.get("id")
    except Exception as exc:  # pragma: no cover
        log.debug("could not journal the binary analysis: %s", exc)
    return out


@tool(
    name="market.regime",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Classify the current market regime (trending, ranging, compressing, choppy) and list the strategies that fit it",
    schema={"symbol": {"type": "string", "required": True}, "interval": {"type": "string", "default": "1h"}},
    risk="LOW",
    timeout=120,
)
async def market_regime(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                        request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    snap = await _snapshot(text, interval, 300)
    if not snap.get("ok"):
        return snap
    regime = sig_engine.market_regime(snap)
    regime.update({"ok": True, "symbol": snap.get("symbol", text), "interval": interval,
                   "price": snap.get("price"),
                   "answer": f"{snap.get('symbol', text)} ({interval}) is **{regime['regime']}** — "
                             f"{regime['why']}. Suggested: "
                             + "; ".join(regime["suggested_strategies"])
                             + f". Avoid {regime['avoid']}."})
    return regime


@tool(
    name="market.screener",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Scan many symbols and rank them by setup quality (score, confidence, trend agreement, volatility)",
    schema={"symbols": {"type": "array", "description": "symbols to scan; empty = the configured watchlist"},
            "interval": {"type": "string", "default": "1h"},
            "min_confidence": {"type": "number", "default": 0.4},
            "direction": {"type": "string", "description": "'long'|'short'|'any'"}},
    risk="LOW",
    timeout=300,
)
async def market_screener(ctx: ToolContext, symbols: Optional[List[str]] = None,
                          interval: str = "1h", min_confidence: float = 0.4,
                          direction: str = "any", request: str = "") -> Dict[str, Any]:
    configured = getattr(settings, "market_watchlist", "EURUSD,GBPUSD,USDJPY,BTC-USD,^NSEI")
    wanted = symbols or [s.strip() for s in re.split(r"[,\s]+", configured) if s.strip()]
    wanted = wanted[:15]
    if len(wanted) < 1:
        return _bad("nothing to scan — pass symbols or configure MARKET_WATCHLIST")

    async def one(text: str) -> Dict[str, Any]:
        try:
            snap = await _snapshot(text, interval, 250)
            if not snap.get("ok"):
                return {"symbol": text, "ok": False, "error": snap.get("error", "no data")}
            sig = sig_engine.build_signal(snap, symbol=snap.get("symbol", text), interval=interval)
            quality = round(abs(sig["score"]) / 100 * sig["confidence"] * 100, 2)
            return {"ok": True, "symbol": sig["symbol"], "price": snap.get("price"),
                    "change_percent": snap.get("change_percent"), "score": sig["score"],
                    "bias": sig["bias"], "direction": sig["direction"],
                    "confidence": sig["confidence"], "quality": quality,
                    "regime": sig["regime"]["regime"], "trend": (snap.get("trend") or {}).get("trend"),
                    "rsi": snap.get("rsi14"), "atr_percent": (snap.get("atr") or {}).get("percent"),
                    "adx": (snap.get("adx") or {}).get("value"),
                    "patterns": [p["pattern"] for p in (snap.get("candle_patterns") or [])[:2]],
                    "top_driver": (sig["top_drivers"][0]["reason"] if sig["top_drivers"] else "")}
        except Exception as exc:
            return {"symbol": text, "ok": False, "error": f"{type(exc).__name__}: {exc}"}

    rows = [r for r in await net.gather(*(one(s) for s in wanted), timeout=120)
            if isinstance(r, dict)]
    usable = [r for r in rows if r.get("ok")]
    filtered = [r for r in usable if r["confidence"] >= min_confidence
                and (direction == "any" or r["direction"] == direction)]
    ranked = sorted(filtered, key=lambda r: -r["quality"])
    return {"ok": True, "interval": interval, "scanned": len(rows), "usable": len(usable),
            "matches": len(ranked), "min_confidence": min_confidence, "direction": direction,
            "results": ranked, "failed": [r for r in rows if not r.get("ok")],
            "answer": (f"Scanned {len(usable)} markets on {interval}; "
                       f"{len(ranked)} pass the filter (confidence ≥ {min_confidence}"
                       + (f", {direction}" if direction != "any" else "") + "):\n"
                       + "\n".join(f"{i}. {r['symbol']} — {r['bias']} (score {r['score']:+.0f}, "
                                   f"conf {r['confidence']:.2f}, {r['regime']}, RSI {r['rsi']}, "
                                   f"ATR {r['atr_percent']}%)"
                                   for i, r in enumerate(ranked[:10], 1))
                       if ranked else
                       f"Scanned {len(usable)} markets — none pass a {min_confidence} confidence "
                       f"filter right now. Standing aside is a valid position."),
            "disclaimer": RISK_NOTE}


@tool(
    name="market.multi_timeframe",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Check whether several timeframes agree on direction before taking a trade",
    schema={"symbol": {"type": "string", "required": True},
            "timeframes": {"type": "array", "description": "default ['15m','1h','4h','1d']"}},
    risk="LOW",
    timeout=240,
)
async def market_multi_timeframe(ctx: ToolContext, symbol: str = "",
                                 timeframes: Optional[List[str]] = None,
                                 request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    tfs = timeframes or ["15m", "1h", "4h", "1d"]

    async def one(tf: str) -> Dict[str, Any]:
        snap = await _snapshot(text, tf, 300)
        if not snap.get("ok"):
            return {"timeframe": tf, "ok": False, "error": snap.get("error")}
        return {"timeframe": tf, "ok": True,
                "signal": sig_engine.build_signal(snap, symbol=snap.get("symbol", text), interval=tf)}

    results = [r for r in await net.gather(*(one(tf) for tf in tfs), timeout=120)
               if isinstance(r, dict) and r.get("ok")]
    if not results:
        return _bad("no timeframe produced data")
    mtf = sig_engine.multi_timeframe(text, {r["timeframe"]: r for r in results})
    mtf.update({"ok": True,
                "answer": f"{text}: " + ", ".join(
                    f"{r['timeframe']} {r['score']:+.0f} ({r['bias']})" for r in mtf["per_timeframe"])
                          + f" ⇒ overall {mtf['bias']} "
                          + ("(aligned)" if mtf["aligned"] else "(NOT aligned)")
                          + f". {mtf['action']}.",
                "disclaimer": RISK_NOTE})
    return mtf


@tool(
    name="market.levels",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="List support and resistance levels, pivot points, Fibonacci retracements and round numbers for a symbol",
    schema={"symbol": {"type": "string", "required": True}, "interval": {"type": "string", "default": "1h"},
            "pivot_type": {"type": "string", "description": "classic|fibonacci|woodie|camarilla"}},
    risk="LOW",
    timeout=120,
)
async def market_levels(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                        pivot_type: str = "classic", request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    snap = await _snapshot(text, interval, 300)
    if not snap.get("ok"):
        return snap
    levels = snap.get("levels") or {}
    pivots = snap.get("pivots") or {}
    if pivot_type != "classic":
        # recompute the pivots in the requested flavour from the last daily bar
        data = await data_feed.candles(text, interval, 2)
        tail = (data.get("candles") or [])[-1:]
        if tail:
            pivots = ind.pivot_points([c["high"] for c in tail], [c["low"] for c in tail],
                                      [c["close"] for c in tail], kind=pivot_type)
    out = {
        "ok": True, "symbol": snap.get("symbol", text), "interval": interval,
        "price": snap.get("price"), "supports": levels.get("supports"),
        "resistances": levels.get("resistances"), "nearest_support": levels.get("nearest_support"),
        "nearest_resistance": levels.get("nearest_resistance"), "pivots": pivots,
        "fibonacci": snap.get("fibonacci"), "round_levels": snap.get("round_levels"),
        "range": {"high": levels.get("range_high"), "low": levels.get("range_low")},
    }
    ns, nr = out["nearest_support"], out["nearest_resistance"]
    out["answer"] = (
        f"{out['symbol']} at {_fmt_price(out['price'], 5)}:\n"
        f"- Resistance: " + ", ".join(str(r["price"]) for r in (out["resistances"] or [])[:4]) + "\n"
        f"- Support: " + ", ".join(str(s["price"]) for s in (out["supports"] or [])[:4]) + "\n"
        f"- Nearest: R {nr['price'] if nr else 'n/a'} "
        f"({nr['distance_percent'] if nr else ''}%), S {ns['price'] if ns else 'n/a'} "
        f"({ns['distance_percent'] if ns else ''}%)\n"
        f"- Pivots: R1 {pivots.get('r1')} / P {pivots.get('pivot')} / S1 {pivots.get('s1')}\n"
        f"- Fibonacci golden pocket: {out['fibonacci'].get('golden_pocket')}"
    )
    return out


@tool(
    name="market.patterns",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Detect candlestick formations and chart patterns (double top/bottom, head & shoulders, triangles, breakouts)",
    schema={"symbol": {"type": "string", "required": True}, "interval": {"type": "string", "default": "1h"},
            "count": {"type": "integer", "default": 3}},
    risk="LOW",
    timeout=120,
)
async def market_patterns(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                          count: int = 3, request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    data = await data_feed.candles(text, interval, 300)
    if not data.get("ok"):
        return data
    candles = data["candles"]
    cp = ind.candle_patterns(candles, int(count))
    chart = ind.chart_patterns(candles)
    lines = [f"- **{p['pattern']}** ({p['bias']}, {p['strength']}, {p.get('when', '')}) — {p['meaning']}"
             for p in cp] + [f"- **{c['pattern']}** ({c.get('bias')}, {c.get('strength')}) — "
                             f"{c.get('meaning', '')}" for c in chart if c.get("pattern") != "insufficient data"]
    return {"ok": True, "symbol": data.get("symbol", text), "interval": interval,
            "candles": len(candles), "candle_patterns": cp, "chart_patterns": chart,
            "answer": (f"Patterns on {data.get('symbol', text)} ({interval}):\n" + "\n".join(lines))
                      if lines else f"No reliable pattern on {data.get('symbol')} ({interval}) — "
                                    f"the last {len(candles)} candles show no classic formation.",
            "note": "patterns are probabilities, not certainties — they only matter at a level "
                    "and with confirmation"}


@tool(
    name="market.volatility",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Measure volatility: ATR, historical volatility, expected move over a window, Bollinger bandwidth and squeeze state",
    schema={"symbol": {"type": "string", "required": True}, "interval": {"type": "string", "default": "1h"},
            "horizon_candles": {"type": "integer", "default": 1,
                                "description": "how many candles ahead to project the expected move"}},
    risk="LOW",
    timeout=120,
)
async def market_volatility(ctx: ToolContext, symbol: str = "", interval: str = "1h",
                            horizon_candles: int = 1, request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    snap = await _snapshot(text, interval, 300)
    if not snap.get("ok"):
        return snap
    price = snap.get("price") or 0
    hv = snap.get("volatility") or {}
    atr_data = snap.get("atr") or {}
    minutes = sig_engine._interval_minutes(interval)
    horizon = max(1, int(horizon_candles))
    per_period = hv.get("annualised_volatility_percent")
    scaled = None
    if per_period:
        # annualised → per-candle, then over the horizon
        bars_per_year = (365 * 24 * 60) / minutes if minutes < 1440 else 252
        scaled = per_period / 100 / math.sqrt(bars_per_year) * math.sqrt(horizon) * price
    atr_move = (atr_data.get("value") or 0) * math.sqrt(horizon)
    exp_move = max(scaled or 0, atr_move)
    return {
        "ok": True, "symbol": snap.get("symbol", text), "interval": interval, "price": price,
        "atr": atr_data, "historical_volatility": hv,
        "bollinger_bandwidth_percent": (snap.get("bollinger") or {}).get("bandwidth_percent"),
        "squeeze": snap.get("squeeze"),
        "horizon_candles": horizon, "horizon_minutes": horizon * minutes,
        "expected_move": round(exp_move, 6),
        "expected_move_percent": round(exp_move / price * 100, 4) if price else None,
        "expected_range": {"low": round(price - exp_move, 6), "high": round(price + exp_move, 6)},
        "two_sigma_range": {"low": round(price - 2 * exp_move, 6),
                            "high": round(price + 2 * exp_move, 6)},
        "answer": f"{snap.get('symbol', text)} volatility: ATR {atr_data.get('value')} "
                  f"({atr_data.get('percent')}% per candle), annualised HV "
                  f"{hv.get('annualised_volatility_percent')}% ({hv.get('interpretation')}). "
                  f"Expected move over {horizon} candle(s) (~{horizon * minutes} min): "
                  f"±{_fmt_price(exp_move, 6)} ⇒ range "
                  f"{_fmt_price(price - exp_move, 6)}–{_fmt_price(price + exp_move, 6)} "
                  f"(68% of the time; 95% inside ±{2 * exp_move:,.6f}).",
        "note": "these are statistical ranges from past volatility, not predictions",
    }


@tool(
    name="market.correlation",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Compute the correlation matrix between several markets to detect duplicated or hedged exposure",
    schema={"symbols": {"type": "array", "required": True, "description": "2-8 symbols"},
            "interval": {"type": "string", "default": "1d"}, "lookback": {"type": "integer", "default": 90}},
    risk="LOW",
    timeout=240,
)
async def market_correlation(ctx: ToolContext, symbols: Optional[List[str]] = None,
                             interval: str = "1d", lookback: int = 90,
                             request: str = "") -> Dict[str, Any]:
    wanted = symbols or []
    if not wanted:
        text = (request or ctx.user_text or "")
        wanted = [s.strip() for s in re.split(r"[,\s]+", text) if s.strip()][:6]
    wanted = wanted[:8]
    if len(wanted) < 2:
        return _bad("correlation needs at least two symbols, e.g. symbols=['EURUSD','GBPUSD']")
    series: Dict[str, List[float]] = {}
    for s in wanted:
        try:
            data = await data_feed.candles(s, interval, int(lookback))
            if data.get("ok") and data.get("candles"):
                series[data.get("symbol", s)] = [c["close"] for c in data["candles"]]
        except Exception as exc:
            log.debug("correlation fetch failed for %s: %s", s, exc)
    if len(series) < 2:
        return _bad("could not fetch enough data for a correlation matrix", got=list(series))
    names = list(series)
    matrix: List[Dict[str, Any]] = []
    strong: List[Dict[str, Any]] = []
    for i, a in enumerate(names):
        row = {"symbol": a, "correlations": {}}
        for b in names:
            c = ind.correlation(series[a], series[b]) if a != b else 1.0
            row["correlations"][b] = c
            if a < b and c is not None and abs(c) >= 0.7:
                strong.append({"pair": f"{a} / {b}", "correlation": c,
                               "meaning": ("they usually move together — holding both doubles the "
                                           "risk instead of diversifying" if c > 0 else
                                           "they usually move oppositely — one can hedge the other")})
        matrix.append(row)
    return {"ok": True, "interval": interval, "lookback": lookback, "symbols": names,
            "matrix": matrix, "strong_relationships": strong,
            "answer": "Correlation (" + interval + f", {lookback} bars):\n" + "\n".join(
                f"- {r['symbol']}: " + ", ".join(f"{k} {v:+.2f}" for k, v in r["correlations"].items()
                                                 if k != r["symbol"]) for r in matrix)
                      + ("\nWatch out: " + "; ".join(f"{s['pair']} ({s['correlation']:+.2f})"
                                                     for s in strong[:4]) if strong else
                         "\nNo pair is correlated above 0.7 — exposure is reasonably diversified."),
            "note": "correlation is measured on historical log returns and changes over time"}


@tool(
    name="market.sentiment",
    capability="research.web_search",
    agent="markets",
    device="cloud",
    description="Gauge market sentiment for an asset from live news headlines (scored positive/negative with sources)",
    schema={"symbol": {"type": "string", "required": True}, "limit": {"type": "integer", "default": 12}},
    risk="LOW",
    timeout=120,
)
async def market_sentiment(ctx: ToolContext, symbol: str = "", limit: int = 12,
                           request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    res = _resolve(text)
    label = res["symbol"].display if res.get("ok") else text
    queries = [f"{label} market news", f"{label} price forecast"]
    articles: List[Dict[str, Any]] = []
    for q in queries[:2]:
        try:
            articles += await net.news_search(q, int(limit))
        except Exception as exc:
            log.debug("sentiment news failed: %s", exc)
    seen, unique = set(), []
    for a in articles:
        key = (a.get("title") or "").lower()[:60]
        if key and key not in seen:
            seen.add(key)
            unique.append(a)
    unique = unique[: int(limit)]
    if not unique:
        return _bad(f"no news found for {label} — sentiment unavailable", symbol=label)
    headlines = "\n".join(f"- [{a.get('source') or net.domain_of(a.get('url', ''))}] "
                          f"{a.get('title')} ({a.get('published') or 'no date'})" for a in unique)
    lexicon = _lexicon_score(" ".join(a.get("title") or "" for a in unique))
    lex_note = (
        f"Keyword sentiment over {len(unique)} live headlines for {label}: "
        f"{lexicon['score']:+.0f}/100 "
        f"(bullish words: {', '.join(lexicon.get('bullish', [])[:6]) or 'none'}; "
        f"bearish words: {', '.join(lexicon.get('bearish', [])[:6]) or 'none'}). "
        + ("Headlines lean positive, which usually supports risk appetite for this asset — but "
           "keyword scoring cannot read context, so treat it as a tilt, not a forecast."
           if lexicon["score"] > 10 else
           "Headlines lean negative, which usually pressures this asset — but keyword scoring "
           "cannot read context, so treat it as a tilt, not a forecast."
           if lexicon["score"] < -10 else
           "Headlines are mixed; there is no clear sentiment edge to trade. "
           "No language model is configured, so SAM cannot read the articles in depth — "
           "add a model key to .env for a full news interpretation.")
    )
    analysis = await _llm(
        f"Asset: {label}\nHeadlines:\n{headlines}\n\n"
        "Score the sentiment of these headlines for this asset from -100 (very bearish) to +100 "
        "(very bullish). Reply in exactly this format:\n"
        "SCORE: <number>\nDRIVERS: <one line>\nRISKS: <one line>\nEVENTS: <upcoming catalysts "
        "mentioned, or 'none'>\nDo not invent news that is not in the list.",
        role="reasoning", max_tokens=400, fallback=lex_note)
    score = None
    m = re.search(r"SCORE:\s*(-?\d+(?:\.\d+)?)", analysis or "", re.I)
    if m:
        score = max(-100.0, min(100.0, float(m.group(1))))
    return {"ok": True, "symbol": label, "headlines": unique, "count": len(unique),
            "model_score": score, "lexicon_score": lexicon["score"],
            "lexicon_words": lexicon, "analysis": analysis,
            "agreement": ("both methods agree on direction"
                          if score is not None and (score > 10) == (lexicon["score"] > 10)
                          and abs(score) > 10 and abs(lexicon["score"]) > 5 else
                          "the two methods disagree — treat sentiment as unclear"),
            "answer": f"{label} news sentiment: model {score if score is not None else 'n/a'}/100, "
                      f"lexicon {lexicon['score']:+.0f}/100 over {len(unique)} headlines.\n"
                      f"{(analysis or '').strip()[:600]}",
            "note": "sentiment from headlines is a weak, lagging signal — never a trade reason on "
                    "its own", "disclaimer": RISK_NOTE}


def _lexicon_score(text: str) -> Dict[str, Any]:
    pos = {"surge", "surges", "rally", "rallies", "gain", "gains", "rise", "rises", "jump",
           "jumps", "soar", "soars", "bullish", "record high", "upgrade", "beat", "beats",
           "strong", "rebound", "recovery", "optimis", "optimisim", "buy", "bought", "inflow",
           "high", "higher", "boost", "breakout", "growth", "profit"}
    neg = {"plunge", "plunges", "crash", "crashes", "fall", "falls", "drop", "drops", "slump",
           "slumps", "bearish", "record low", "downgrade", "miss", "misses", "weak", "selloff",
           "sell-off", "fear", "risk-off", "loss", "losses", "cut", "warning", "default",
           "inflation", "recession", "outflow", "decline", "lower", "tumble", "sink"}
    low = text.lower()
    p = sum(1 for w in pos if w in low)
    n = sum(1 for w in neg if w in low)
    total = p + n
    score = round((p - n) / total * 100, 2) if total else 0.0
    return {"score": score, "positive_hits": p, "negative_hits": n,
            "label": ("positive" if score > 20 else "negative" if score < -20 else "mixed")}


@tool(
    name="market.compare",
    capability="market.analysis",
    agent="markets",
    device="cloud",
    description="Compare two or more markets on return, volatility, drawdown, trend and correlation",
    schema={"symbols": {"type": "array", "required": True}, "interval": {"type": "string", "default": "1d"},
            "lookback": {"type": "integer", "default": 90}},
    risk="LOW",
    timeout=240,
)
async def market_compare(ctx: ToolContext, symbols: Optional[List[str]] = None,
                         interval: str = "1d", lookback: int = 90, request: str = "") -> Dict[str, Any]:
    wanted = (symbols or [])[:5]
    if len(wanted) < 2:
        return _bad("give at least two symbols to compare")
    rows: List[Dict[str, Any]] = []
    closes: Dict[str, List[float]] = {}
    for s in wanted:
        try:
            data = await data_feed.candles(s, interval, int(lookback))
            if not data.get("ok"):
                rows.append({"symbol": s, "ok": False, "error": data.get("error")})
                continue
            snap = ind.full_snapshot(data["candles"], symbol=data.get("symbol", s),
                                     interval=interval)
            if not snap.get("ok"):
                rows.append({"symbol": s, "ok": False, "error": snap.get("error")})
                continue
            cs = [c["close"] for c in data["candles"]]
            closes[snap.get("symbol", s)] = cs
            peak, max_dd = cs[0] if cs else 0, 0.0
            for v in cs:
                peak = max(peak, v)
                max_dd = max(max_dd, (peak - v) / peak * 100) if peak else 0
            rows.append({"ok": True, "symbol": snap.get("symbol", s),
                         "asset_class": snap.get("feed_meta", {}).get("instrument_type", ""),
                         "price": snap.get("price"),
                         "return_percent": round((cs[-1] / cs[0] - 1) * 100, 3) if cs and cs[0] else None,
                         "volatility_percent": (snap.get("volatility") or {}).get(
                             "annualised_volatility_percent"),
                         "max_drawdown_percent": round(max_dd, 3),
                         "trend": (snap.get("trend") or {}).get("trend"),
                         "adx": (snap.get("adx") or {}).get("value"),
                         "rsi": snap.get("rsi14"),
                         "atr_percent": (snap.get("atr") or {}).get("percent"),
                         "score": None})
        except Exception as exc:
            rows.append({"symbol": s, "ok": False, "error": f"{type(exc).__name__}: {exc}"})
    names = [k for k in closes]
    corr = {}
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            corr[f"{a}/{b}"] = ind.correlation(closes[a], closes[b])
    good = [r for r in rows if r.get("ok")]
    if not good:
        return _bad("no data for any symbol", rows=rows)
    best_ret = max(good, key=lambda r: r.get("return_percent") or -1e9)
    lowest_vol = min(good, key=lambda r: r.get("volatility_percent") or 1e9)
    best_risk_adj = max(good, key=lambda r: (r.get("return_percent") or 0) /
                        max(r.get("volatility_percent") or 1, 0.001))
    md = ["| Symbol | Price | Return | Volatility | Max DD | Trend | ADX | RSI |",
          "|---|---|---|---|---|---|---|---|"]
    for r in good:
        md.append(f"| {r['symbol']} | {_fmt_price(r['price'], 4)} | {r['return_percent']:+.2f}% | "
                  f"{r['volatility_percent']}% | {r['max_drawdown_percent']:.2f}% | {r['trend']} | "
                  f"{r['adx']} | {r['rsi']} |")
    return {"ok": True, "interval": interval, "lookback": lookback, "rows": rows,
            "correlations": corr, "best_return": best_ret["symbol"],
            "lowest_volatility": lowest_vol["symbol"],
            "best_risk_adjusted": best_risk_adj["symbol"],
            "table": "\n".join(md),
            "answer": f"Comparison over {lookback} {interval} bars:\n" + "\n".join(md)
                      + f"\n\nBest return: {best_ret['symbol']} ({best_ret['return_percent']:+.2f}%). "
                        f"Lowest volatility: {lowest_vol['symbol']}. "
                        f"Best risk-adjusted: {best_risk_adj['symbol']}. "
                        f"Correlations: {corr}.",
            "disclaimer": RISK_NOTE}


@tool(
    name="market.calendar",
    capability="research.web_search",
    agent="markets",
    device="cloud",
    description="Find market-moving news and risk events for a currency, asset or economy from live headlines",
    schema={"topic": {"type": "string", "required": True, "description": "e.g. 'USD', 'RBI rate decision', 'gold'"},
            "limit": {"type": "integer", "default": 10}},
    risk="LOW",
    timeout=90,
)
async def market_calendar(ctx: ToolContext, topic: str = "", limit: int = 10,
                          request: str = "") -> Dict[str, Any]:
    text = (topic or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market, currency or event?")
    queries = [f"{text} economic calendar", f"{text} central bank rate decision",
               f"{text} market news this week"]
    articles: List[Dict[str, Any]] = []
    for q in queries:
        try:
            articles += await net.news_search(q, 6)
        except Exception as exc:
            log.debug("calendar news failed: %s", exc)
    seen, unique = set(), []
    for a in articles:
        k = (a.get("title") or "").lower()[:70]
        if k and k not in seen:
            seen.add(k)
            unique.append(a)
    unique = unique[: max(int(limit), 6)]
    if not unique:
        return _bad(f"no news found for '{text}' — cannot build a risk calendar",
                    note="a structured economic calendar (with impact ratings and exact times) "
                         "needs a keyed provider; add NEWS_API_KEY or FOREX_FACTORY credentials")
    digest = await _llm(
        f"Topic: {text}\nHeadlines:\n" + "\n".join(f"- {a.get('title')} "
                                                   f"({a.get('published') or 'no date'})"
                                                   for a in unique) +
        "\n\nList the market risk events implied here. For each: EVENT, WHEN (or 'unknown'), "
        "IMPACT (high/medium/low), LIKELY EFFECT on the topic, HOW TO TRADE AROUND IT. "
        "Only use the headlines above; say 'unknown' when the date is not given. Max 6 events.",
        role="reasoning", max_tokens=700,
        fallback=("Risk events in the live headlines for " + text + " (no language model is "
                  "configured, so this is the raw digest — SAM will not guess impact ratings):\n"
                  + "\n".join(f"- {a.get('title')} — {a.get('published') or 'date unknown'} "
                               f"[{a.get('source') or net.domain_of(a.get('url', ''))}]"
                               for a in unique)
                  + "\n\nHow to use this: check the exact release time on your broker's "
                    "economic calendar, then either stand aside through the print or widen the "
                    "stop to more than 2x ATR. Spreads widen and slippage spikes in the minutes "
                    "around high-impact releases."))
    return {"ok": True, "topic": text, "headlines": unique, "count": len(unique),
            "digest": digest, "answer": digest or "\n".join(f"- {a.get('title')}" for a in unique),
            "note": "always check the exact release time with your broker's calendar before "
                    "holding a position through a high-impact event", "disclaimer": RISK_NOTE}


# ===========================================================================
# 3. RISK
# ===========================================================================
@tool(
    name="market.risk",
    capability="market.analysis",
    agent="markets",
    device="both",
    description="Trading risk maths: position size, pip value, risk:reward, Kelly, risk of ruin, drawdown recovery, margin, portfolio risk, expectancy, stake plan, martingale check",
    schema={"operation": {"type": "string", "required": True,
                          "description": "position_size|pip_value|risk_reward|kelly|ruin|drawdown|margin|portfolio|expectancy|stake_plan|martingale"},
            "params": {"type": "object", "description": "operation-specific numbers"}},
    risk="LOW",
    timeout=45,
)
async def market_risk(ctx: ToolContext, operation: str = "", params: Optional[Dict[str, Any]] = None,
                      request: str = "") -> Dict[str, Any]:
    op = (operation or "").strip().lower()
    p = dict(params or {})
    text = (request or ctx.user_text or "").lower()
    if not op:
        for k in ("position_size", "pip_value", "risk_reward", "kelly", "ruin", "drawdown",
                  "margin", "portfolio", "expectancy", "stake_plan", "martingale"):
            if k.replace("_", " ") in text or k in text:
                op = k
                break
    if not op:
        return _bad("which risk calculation? position_size, pip_value, risk_reward, kelly, ruin, "
                    "drawdown, margin, portfolio, expectancy, stake_plan or martingale")
    # allow flat kwargs too
    for k, v in list(ctx.params.items()):
        if k not in p and isinstance(v, (int, float, str, list)):
            p[k] = v

    def num(key: str, default: float = 0.0) -> float:
        try:
            return float(p.get(key, default))
        except (TypeError, ValueError):
            return float(default)

    try:
        if op == "position_size":
            entry = num("entry") or num("price")
            stop = num("stop") or num("stop_loss")
            if not entry or not stop:
                return _bad("position_size needs entry and stop prices "
                            "(plus balance and risk_percent)")
            out = risk_math.position_size(
                balance=num("balance", getattr(settings, "market_paper_balance", 10000)) or 10000,
                risk_percent=num("risk_percent", getattr(settings, "market_risk_per_trade", 1.0)) or 1.0,
                entry=entry, stop=stop, account_currency=str(p.get("account_currency", "USD")),
                pair_quote=str(p.get("pair_quote", p.get("quote", "USD"))),
                pair_type=str(p.get("pair_type", "forex")),
                quote_to_account=num("quote_to_account", 1.0) or 1.0,
                contract_size=num("contract_size", 1.0) or 1.0,
                max_leverage=num("max_leverage", 0))
            if out.get("ok"):
                out["answer"] = (
                    f"Risking {out['risk_amount']} ({out.get('risk_percent')}%) with a "
                    f"{out.get('stop_pips', out.get('stop_distance'))} stop ⇒ "
                    f"{out['units']:,.2f} units ({out.get('lots')} standard lots, "
                    f"{out.get('micro_lots', out.get('contracts'))} micro/contracts). "
                    f"Notional {out['notional_account_ccy']:,.2f}."
                    + (f" {out['sanity'][0]}" if out.get("sanity") else ""))
            return out
        if op == "pip_value":
            return {**risk_math.pip_value(str(p.get("pair", "EURUSD")), num("lots", 1.0) or 1.0,
                                          num("quote_to_account", 1.0) or 1.0),
                    "ok": True,
                    "answer": f"{p.get('pair', 'EURUSD')}: 1 pip on {num('lots', 1) or 1} lot(s) = "
                              f"{risk_math.pip_value(str(p.get('pair', 'EURUSD')), num('lots', 1.0) or 1.0)['pip_value_account_ccy']} "
                              f"in the account currency"}
        if op == "risk_reward":
            targets = p.get("targets") or ([p["target"]] if p.get("target") else [])
            if not targets:
                return _bad("risk_reward needs entry, stop and at least one target")
            out = risk_math.risk_reward(num("entry"), num("stop"), _nums(targets))
            if out.get("ok"):
                out["answer"] = (f"Entry {out['entry']} stop {out['stop']} "
                                 f"({out['stop_distance']} risk): "
                                 + ", ".join(f"T{t['target_index']} {t['price']} = {t['r_multiple']}R "
                                             f"(break-even win rate {t['break_even_win_rate_percent']}%)"
                                             for t in out["targets"])
                                 + f". {out['verdict']}")
            return out
        if op == "kelly":
            out = risk_math.kelly(num("win_rate"), num("payoff", 1.0) or 1.0,
                                  num("fraction", 0.25) or 0.25)
            if out.get("ok"):
                out["answer"] = out["interpretation"]
            return out
        if op == "ruin":
            out = risk_math.risk_of_ruin(num("win_rate"), num("risk_per_trade", 1.0) or 1.0,
                                         num("payoff", 1.0) or 1.0,
                                         num("ruin_threshold", 50.0) or 50.0)
            if out.get("ok"):
                out["answer"] = (f"At {out['win_rate_percent']}% wins risking "
                                 f"{out['risk_per_trade_percent']}% per trade, the chance of losing "
                                 f"{num('ruin_threshold', 50) or 50}% of the account is "
                                 f"{out['risk_of_ruin_percent']}%. It takes "
                                 f"{out['consecutive_losses_to_threshold']} losses in a row "
                                 f"({out['probability_of_that_streak_percent']}% likely). "
                                 f"{out['verdict']}")
            return out
        if op == "drawdown":
            out = risk_math.drawdown_math(num("drawdown_percent", num("drawdown")))
            if out.get("ok"):
                out["answer"] = out["verdict"]
            return out
        if op == "margin":
            out = risk_math.margin_required(num("notional"), num("leverage", 30) or 30)
            if out.get("ok"):
                out["answer"] = (f"Notional {out['notional']:,.2f} at {out['leverage']}:1 needs "
                                 f"{out['required_margin']:,.2f} margin. {out['note']}.")
            return out
        if op == "portfolio":
            positions = p.get("positions") or []
            if not positions:
                return _bad("portfolio needs positions=[{symbol,direction,units,entry,stop}]")
            out = risk_math.portfolio_risk(positions,
                                           num("balance", getattr(settings, "market_paper_balance",
                                                                  10000)) or 10000,
                                           p.get("correlations"))
            out["answer"] = (f"{out['count']} open positions risk {out['total_risk']:,.2f} "
                             f"({out['total_risk_percent']}% of the account). {out['verdict']}"
                             + (f" {out['correlation_note']}" if out["correlation_note"] else ""))
            return out
        if op == "expectancy":
            out = risk_math.expectancy(num("win_rate"), num("average_win"), num("average_loss"),
                                       int(num("trades", 100)) or 100)
            out["answer"] = (f"Win rate {out['win_rate_percent']}%, payoff {out['payoff_ratio']}: "
                             f"expectancy {out['expectancy_per_trade']} per trade "
                             f"({out['expectancy_over_n_trades']} over {out['trades']} trades). "
                             f"{out['verdict']}")
            return out
        if op == "stake_plan":
            out = risk_math.stake_plan(num("balance", getattr(settings, "market_paper_balance",
                                                             10000)) or 10000,
                                       num("risk_percent", getattr(settings, "market_risk_per_trade",
                                                                   1.0)) or 1.0,
                                       num("daily_loss_limit_percent", 3.0) or 3.0,
                                       int(num("max_trades", 5)) or 5,
                                       num("payout_percent", 80) or 80)
            out["answer"] = (f"Stake {out['stake_per_trade']:,.2f} per trade, stop after "
                             f"{out['daily_loss_limit']:,.2f} of losses "
                             f"({out['consecutive_losses_to_daily_limit']} consecutive losses), "
                             f"max {out['max_trades']} trades a session.")
            return out
        if op == "martingale":
            out = risk_math.martingale_check(num("balance", 1000) or 1000,
                                             num("base_stake", 10) or 10,
                                             num("payout_percent", 80) or 80,
                                             int(num("steps", 8)) or 8)
            out["answer"] = out["verdict"]
            out["warning"] = sig_engine.BINARY_WARNING
            return out
        return _bad(f"unknown risk operation '{op}'")
    except Exception as exc:
        return _bad(f"{op} failed: {type(exc).__name__}: {exc}", operation=op)


# ===========================================================================
# 4. BACKTEST
# ===========================================================================
@tool(
    name="market.backtest",
    capability="market.backtest",
    agent="markets",
    device="cloud",
    description="Backtest a trading rule on historical candles (ma_cross, rsi_reversion, bollinger_breakout, macd_cross, donchian, psar_flip, atr_trailing, binary_direction) with costs, drawdown, Sharpe and walk-forward folds",
    schema={"symbol": {"type": "string", "required": True},
            "strategy": {"type": "string", "default": "ma_cross"},
            "interval": {"type": "string", "default": "1h"},
            "limit": {"type": "integer", "default": 800},
            "params": {"type": "object", "description": "strategy parameters, e.g. {'fast':9,'slow':21}"},
            "capital": {"type": "number", "default": 10000},
            "commission_percent": {"type": "number", "default": 0.0},
            "slippage_percent": {"type": "number", "default": 0.02},
            "walk_forward": {"type": "boolean", "default": False},
            "expiry_candles": {"type": "integer", "default": 5,
                               "description": "for strategy=binary_direction"}},
    risk="LOW",
    timeout=300,
)
async def market_backtest(ctx: ToolContext, symbol: str = "", strategy: str = "ma_cross",
                          interval: str = "1h", limit: int = 800,
                          params: Optional[Dict[str, Any]] = None, capital: float = 10000.0,
                          commission_percent: float = 0.0, slippage_percent: float = 0.02,
                          walk_forward: bool = False, expiry_candles: int = 5,
                          payout_percent: float = 80.0, stake: float = 100.0,
                          request: str = "") -> Dict[str, Any]:
    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market should I backtest?")
    if strategy not in bt.STRATEGIES:
        return _bad(f"unknown strategy '{strategy}'. Available: {', '.join(bt.STRATEGIES)}")
    try:
        data = await data_feed.candles(text, interval, int(limit))
    except Exception as exc:
        return _bad(f"backtest data fetch failed: {type(exc).__name__}: {exc}")
    if not data.get("ok"):
        return data
    candles = data["candles"]
    if len(candles) < 60:
        return _bad(f"only {len(candles)} candles — need at least 60 for a meaningful backtest",
                    symbol=data.get("symbol"))
    t0 = time.perf_counter()
    if strategy == "binary_direction":
        res = bt.binary_backtest(candles, expiry_candles=int(expiry_candles), strategy=strategy,
                                 params=params, payout_percent=float(payout_percent),
                                 stake=float(stake), symbol=data.get("symbol", text),
                                 interval=interval)
        res["candles_used"] = len(candles)
        res["took_ms"] = int((time.perf_counter() - t0) * 1000)
        res["answer"] = (f"Binary backtest on {res.get('symbol', text)} ({interval}, "
                         f"{len(candles)} bars, {expiry_candles}-bar expiry, "
                         f"{payout_percent:g}% payout): {res.get('signals')} signals, "
                         f"win rate {res.get('win_rate_percent')}% vs break-even "
                         f"{res.get('break_even_win_rate_percent')}% ⇒ "
                         f"net {res.get('net_profit')} on {stake} stakes. {res.get('verdict')}")
        if walk_forward:
            res["walk_forward"] = _binary_walk_forward(candles, strategy, params, expiry_candles,
                                                       payout_percent, stake)
        return res

    res = bt.run(candles, strategy, params=params, capital=float(capital),
                 commission_percent=float(commission_percent),
                 slippage_percent=float(slippage_percent),
                 symbol=data.get("symbol", text), interval=interval)
    if walk_forward and res.get("ok"):
        res["walk_forward"] = await asyncio.get_event_loop().run_in_executor(
            None, lambda: bt.walk_forward(candles, strategy, params=params, capital=capital,
                                          symbol=data.get("symbol", text), interval=interval))
        wf = res["walk_forward"]
        res["answer"] += (f"\nWalk-forward: profitable in {wf.get('profitable_folds')}/"
                          f"{wf.get('fold_count')} periods ({wf.get('consistency_percent')}%) — "
                          f"{wf.get('verdict')}")
    res["candles_used"] = len(candles)
    res["took_ms"] = int((time.perf_counter() - t0) * 1000)
    return res


def _binary_walk_forward(candles: List[Dict[str, Any]], strategy: str,
                         params: Optional[Dict[str, Any]], expiry: int, payout: float,
                         stake: float) -> Dict[str, Any]:
    folds = 4
    if len(candles) < folds * (expiry + 40):
        return {"ok": False, "error": "not enough candles for walk-forward"}
    size = len(candles) // folds
    rows = []
    for f in range(folds):
        chunk = candles[f * size:(f + 1) * size] if f < folds - 1 else candles[f * size:]
        r = bt.binary_backtest(chunk, expiry_candles=expiry, strategy=strategy, params=params,
                               payout_percent=payout, stake=stake)
        rows.append({"fold": f + 1, "candles": len(chunk), "signals": r.get("signals"),
                     "win_rate_percent": r.get("win_rate_percent"),
                     "break_even_percent": r.get("break_even_win_rate_percent"),
                     "net_profit": r.get("net_profit"), "ok": r.get("ok", False)})
    profitable = [r for r in rows if (r.get("net_profit") or 0) > 0]
    return {"ok": True, "folds": rows, "fold_count": folds,
            "profitable_folds": len(profitable),
            "consistency_percent": round(len(profitable) / len(rows) * 100, 1) if rows else 0,
            "verdict": (f"the rule was profitable in {len(profitable)}/{len(rows)} periods"
                        + (" — consistent enough to paper trade"
                           if len(profitable) / len(rows) >= 0.75 else
                           " — inconsistent; treat any single good period as luck"))}


# ===========================================================================
# 5. JOURNAL
# ===========================================================================
@tool(
    name="market.journal.add",
    capability="market.journal",
    agent="markets",
    device="pc",
    description="Add a trade (planned, open or closed) to the market journal",
    schema={"symbol": {"type": "string", "required": True}, "direction": {"type": "string", "default": "long"},
            "entry": {"type": "number"}, "stop": {"type": "number"}, "units": {"type": "number"},
            "product": {"type": "string", "description": "spot|binary|cfd|paper"},
            "strategy": {"type": "string"}, "notes": {"type": "string"}},
    risk="LOW",
    timeout=45,
)
async def market_journal_add(ctx: ToolContext, symbol: str = "", direction: str = "long",
                             entry: Optional[float] = None, stop: Optional[float] = None,
                             units: float = 0.0, stake: float = 0.0, product: str = "spot",
                             asset_class: str = "forex", status: str = "planned",
                             timeframe: str = "1h", strategy: str = "", notes: str = "",
                             targets: Optional[List[float]] = None, tags: str = "",
                             expiry_minutes: int = 0, payout_percent: float = 0.0,
                             request: str = "") -> Dict[str, Any]:
    from backend.app.markets.journal import journal

    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which symbol?")
    res = _resolve(text)
    sym = res.get("symbol")
    try:
        row = await journal.add(symbol=sym.display if res.get("ok") else text.upper(),
                                direction=direction, product=product,
                                asset_class=sym.asset_class if res.get("ok") else asset_class,
                                status=status, timeframe=timeframe, strategy=strategy,
                                entry=entry, stop=stop, units=units, stake=stake,
                                targets=targets, notes=notes, tags=tags,
                                expiry_minutes=expiry_minutes, payout_percent=payout_percent)
    except Exception as exc:
        return _bad(f"journal add failed: {type(exc).__name__}: {exc}")
    return {"ok": True, "trade": row, "id": row.get("id"),
            "answer": f"Journalled {row['symbol']} {row['direction']} @ {row.get('entry')} "
                      f"(id {row.get('id')}, status {row['status']})."}


@tool(
    name="market.journal.list",
    capability="market.journal",
    agent="markets",
    device="pc",
    description="List journal trades, filtered by symbol, status, product or result",
    schema={"symbol": {"type": "string"}, "status": {"type": "string"},
            "product": {"type": "string"}, "limit": {"type": "integer", "default": 25},
            "days": {"type": "integer"}},
    risk="LOW",
    timeout=45,
)
async def market_journal_list(ctx: ToolContext, symbol: str = "", status: str = "",
                              product: str = "", result: str = "", limit: int = 25,
                              days: Optional[int] = None) -> Dict[str, Any]:
    from backend.app.markets.journal import journal

    try:
        data = await journal.list(symbol=symbol, status=status, product=product, result=result,
                                  limit=int(limit), days=days)
    except Exception as exc:
        return _bad(f"journal list failed: {type(exc).__name__}: {exc}")
    trades = data.get("trades") or []
    data["answer"] = (f"{data['count']} journal trades:\n" + "\n".join(
        f"- #{t['id']} {t['symbol']} {t['direction']} {t['product']} [{t['status']}"
        f"{'/' + t['result'] if t['result'] else ''}] entry {t.get('entry')} "
        f"exit {t.get('exit')} P&L {t.get('pnl')}" for t in trades[:15])) if trades else \
        "The journal is empty — add a trade with market.journal.add, or create a plan with " \
        "market.forex_plan (SAM journals every plan automatically)."
    return data


@tool(
    name="market.journal.close",
    capability="market.journal",
    agent="markets",
    device="pc",
    description="Close a journal trade with its exit price and compute the P&L, R multiple and result",
    schema={"trade_id": {"type": "integer", "required": True}, "exit_price": {"type": "number", "required": True},
            "result": {"type": "string", "description": "win|loss|tie (auto for non-binary)"},
            "fees": {"type": "number"}, "review": {"type": "string"}},
    risk="LOW",
    timeout=45,
)
async def market_journal_close(ctx: ToolContext, trade_id: Optional[int] = None,
                               exit_price: float = 0.0, exit: Optional[float] = None,
                               price: Optional[float] = None, at: Optional[float] = None,
                               symbol: str = "", result: str = "", fees: float = 0.0,
                               notes: str = "", review: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.markets.journal import journal

    exit_price = exit_price or exit or price or at or 0.0
    body = request or ctx.user_text or ""
    if trade_id is None:
        # "close my EURUSD trade" / "close the last journal trade"
        listed = await journal.list(limit=40)
        rows = [r for r in (listed.get("trades") or []) if r.get("status") in ("planned", "open")]
        want = (symbol or body).lower()
        if want:
            hits = [r for r in rows if want.split()[0] in (r.get("symbol") or "").lower()]
            rows = hits or rows
        if len(rows) == 1:
            trade_id = rows[0]["id"]
        elif len(rows) > 1:
            return _bad(f"{len(rows)} journal trades are still open/planned: "
                        + ", ".join(f"#{r['id']} {r['symbol']} {r['direction']}" for r in rows[:6])
                        + " — which id should I close?")
    if trade_id is None:
        return _bad("which trade id? (use market.journal.list to find it)")
    if not exit_price:
        # no price given → mark it at the current market price and say so
        got = await journal.get(int(trade_id))
        row = (got.get("trade") or {}) if isinstance(got, dict) else {}
        sym_text = row.get("symbol") or ""
        if sym_text:
            q = await data_feed.quote(data_feed.resolve_symbol(sym_text))
            if q.get("ok"):
                exit_price = float(q["price"])
                notes = (notes + " " if notes else "") + "closed at the live market price"
        if not exit_price:
            return _bad("what was the exit price? (or pass exit_price and I will use the live quote)")
    try:
        out = await journal.close(int(trade_id), exit_price=float(exit_price), result=result,
                                  fees=float(fees), notes=notes, review=review)
    except Exception as exc:
        return _bad(f"journal close failed: {type(exc).__name__}: {exc}")
    if not out.get("ok"):
        return out
    t = out["trade"]
    out["answer"] = (f"Closed trade #{t['id']} {t['symbol']} {t['direction']} at {t['exit']}: "
                     f"P&L {t['pnl']:+} ({t['pnl_percent']}%), result {t['result']}"
                     + (f", {t['r_multiple']}R" if t.get("r_multiple") else "") + ".")
    return out


@tool(
    name="market.journal.stats",
    capability="market.journal",
    agent="markets",
    device="pc",
    description="Journal statistics: win rate, profit factor, expectancy, streaks, per-symbol and per-strategy breakdown, plus the lessons the data shows",
    schema={"days": {"type": "integer", "description": "limit to the last N days"},
            "symbol": {"type": "string"}, "product": {"type": "string"}},
    risk="LOW",
    timeout=45,
)
async def market_journal_stats(ctx: ToolContext, days: Optional[int] = None, symbol: str = "",
                               product: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.markets.journal import journal

    text = (request or ctx.user_text or "").lower()
    if not days:
        m = re.search(r"(last|past)\s+(\d+)\s*(day|week|month)s?", text)
        if m:
            days = int(m.group(2)) * {"day": 1, "week": 7, "month": 30}[m.group(3)]
    try:
        stats = await journal.stats(days=days, symbol=symbol, product=product)
    except Exception as exc:
        return _bad(f"journal stats failed: {type(exc).__name__}: {exc}")
    if not stats.get("closed_trades"):
        return stats
    def _bucket_line(bucket: Optional[Dict[str, Any]]) -> str:
        if not bucket:
            return "n/a"
        return ", ".join(f"{k} {v['trades']}t {v['pnl']:+,.0f} ({v['win_rate_percent']:.0f}% win)"
                         for k, v in sorted(bucket.items(),
                                            key=lambda kv: -abs(kv[1].get("pnl") or 0))[:5])

    def fmt(v: Any, suffix: str = "", places: int = 2) -> str:
        """Render a statistic, saying 'n/a' instead of printing None."""
        if v is None:
            return "n/a"
        if isinstance(v, float):
            return f"{v:.{places}f}{suffix}"
        return f"{v}{suffix}"

    def signed(v: Any) -> str:
        return "n/a" if v is None else f"{float(v):+,.2f}"

    hc = stats.get("high_confidence_trades") or {}
    hc_line = ("none recorded" if not hc.get("count") else
               f"{hc.get('count')} trade(s), win rate "
               f"{fmt(hc.get('win_rate_percent'), '%')}")
    stats["answer"] = (
        f"Journal ({stats['closed_trades']} closed trades"
        + (f", last {days} days" if days else "") + f"):\n"
        f"- Win rate {fmt(stats['win_rate_percent'], '%')} "
        f"({stats['wins']}W / {stats['losses']}L"
        + (f" / {stats['ties']}T" if stats.get("ties") else "") + ")\n"
        f"- Net P&L {signed(stats['net_pnl'])} · gross {signed(stats.get('gross_profit'))} won / "
        f"{signed(stats.get('gross_loss'))} lost · profit factor {fmt(stats['profit_factor'])}\n"
        f"- Expectancy {signed(stats['expectancy_per_trade'])}/trade · payoff "
        f"{fmt(stats['payoff_ratio'])} · average R {fmt(stats['average_r_multiple'])}R\n"
        f"- Best {signed(stats['best_trade'])} · worst {signed(stats['worst_trade'])} · "
        f"longest win streak {stats['longest_win_streak']} · longest loss streak "
        f"{stats['longest_loss_streak']}\n"
        f"- By product: " + _bucket_line(stats.get("by_product")) + "\n"
        f"- By direction: " + _bucket_line(stats.get("by_direction")) + "\n"
        f"- By symbol: " + _bucket_line(stats.get("by_symbol")) + "\n"
        f"- By strategy: " + _bucket_line(stats.get("by_strategy")) + "\n"
        f"- High-confidence (≥0.6) trades: {hc_line}\n"
        f"- Low-confidence (<0.45) trades: " + ("none recorded" if not
                                               (stats.get("low_confidence_trades") or {}).get("count")
                                               else f"{stats['low_confidence_trades']['count']} "
                                                    f"trade(s), win rate "
                                                    f"{fmt(stats['low_confidence_trades'].get('win_rate_percent'), '%')}")
        + "\nLessons:\n" + "".join(f"- {l}\n" for l in stats["lessons"]))
    return stats


@tool(
    name="market.journal.review",
    capability="market.journal",
    agent="markets",
    device="pc",
    description="Attach a review/lesson and tags to a journal trade (the habit that actually improves results)",
    schema={"trade_id": {"type": "integer", "required": True}, "review": {"type": "string", "required": True},
            "tags": {"type": "string", "description": "comma separated, e.g. 'revenge-trade,news'"}},
    risk="LOW",
    timeout=45,
)
async def market_journal_review(ctx: ToolContext, trade_id: Optional[int] = None, review: str = "",
                                text: str = "", notes: str = "", comment: str = "",
                                tags: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.markets.journal import journal

    review = review or text or notes or comment or request or ctx.user_text or ""
    if trade_id is None:
        listed = await journal.list(limit=10)
        rows = listed.get("trades") or []
        if rows:
            trade_id = rows[0]["id"]          # the most recent journal entry
    if trade_id is None or not review:
        return _bad("need a trade_id (from market.journal.list) and the review text")
    out = await journal.review(int(trade_id), review, tags)
    if out.get("ok"):
        out["answer"] = f"Review saved on trade #{trade_id}."
    return out


# ===========================================================================
# 6. ALERTS
# ===========================================================================
@tool(
    name="market.alert.set",
    capability="market.alerts",
    agent="markets",
    device="both",
    description="Create a price or indicator alert (above, below, cross, percent change, RSI, ATR spike) that SAM watches in the background and notifies you about",
    schema={"symbol": {"type": "string", "required": True},
            "condition": {"type": "string", "description": "above|below|cross_up|cross_down|percent_change|rsi_above|rsi_below|atr_spike|signal_flip"},
            "threshold": {"type": "number", "required": True},
            "timeframe": {"type": "string", "default": "1h"},
            "message": {"type": "string"}, "channel": {"type": "string", "default": "desktop"},
            "once": {"type": "boolean", "default": True}},
    risk="LOW",
    timeout=45,
)
async def market_alert_set(ctx: ToolContext, symbol: str = "", condition: str = "above",
                           threshold: float = 0.0, timeframe: str = "1h", message: str = "",
                           channel: str = "desktop", once: bool = True,
                           cooldown_minutes: int = 60, request: str = "") -> Dict[str, Any]:
    from backend.app.markets.journal import alerts

    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which symbol should I watch?")
    res = _resolve(text)
    sym = res.get("symbol")
    label = sym.display if res.get("ok") else text.upper()
    body = (request or ctx.user_text or "").lower()
    if not threshold:
        nums = re.findall(r"\d+(?:\.\d+)?", body)
        if nums:
            threshold = float(nums[-1])
    if condition == "above" and any(k in body for k in ("below", "under", "drops", "falls", "dips")):
        condition = "below"
    if not threshold:
        return _bad("at which price/level should the alert fire? (threshold)")
    try:
        out = await alerts.add(symbol=label, condition=condition, threshold=float(threshold),
                               timeframe=timeframe, message=message, channel=channel, once=once,
                               cooldown_minutes=int(cooldown_minutes))
    except Exception as exc:
        return _bad(f"could not create the alert: {type(exc).__name__}: {exc}")
    if not out.get("ok"):
        return out
    a = out["alert"]
    out["answer"] = (f"Watching {label}: I'll notify you when it goes {condition} {threshold} "
                     f"(checked every {settings.market_alert_poll_seconds}s on the {timeframe} "
                     f"timeframe, alert id {a['id']}).")
    out["poller"] = alert_poller_status()
    return out


@tool(
    name="market.alert.list",
    capability="market.alerts",
    agent="markets",
    device="both",
    description="List market alerts and the poller status",
    schema={"symbol": {"type": "string"}, "enabled_only": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=30,
)
async def market_alert_list(ctx: ToolContext, symbol: str = "", enabled_only: bool = False,
                            check_now: bool = False) -> Dict[str, Any]:
    from backend.app.markets.journal import alerts

    rows = await alerts.list(enabled_only=enabled_only, symbol=symbol)
    out: Dict[str, Any] = {"ok": True, "count": len(rows), "alerts": rows,
                           "poller": alert_poller_status()}
    if check_now:
        from backend.app.markets.alerts import alert_poller

        out["check"] = await alert_poller.check_once()
    out["answer"] = (f"{len(rows)} alert(s):\n" + "\n".join(
        f"- #{a['id']} {a['symbol']} {a['condition']} {a['threshold']} "
        f"[{'on' if a['enabled'] else 'off'}] fired {a['triggered_count']}×" for a in rows)) \
        if rows else "No market alerts yet — create one with market.alert.set."
    return out


@tool(
    name="market.alert.remove",
    capability="market.alerts",
    agent="markets",
    device="both",
    description="Delete or disable a market alert",
    schema={"alert_id": {"type": "integer", "required": True},
            "disable_only": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=30,
)
async def market_alert_remove(ctx: ToolContext, alert_id: Optional[int] = None,
                              disable_only: bool = False) -> Dict[str, Any]:
    from backend.app.markets.journal import alerts

    if alert_id is None:
        return _bad("which alert id?")
    if disable_only:
        out = await alerts.toggle(int(alert_id), False)
        out["answer"] = f"Alert #{alert_id} disabled." if out.get("ok") else out.get("error")
        return out
    out = await alerts.remove(int(alert_id))
    out["answer"] = f"Alert #{alert_id} removed." if out.get("ok") else out.get("error")
    return out


@tool(
    name="market.alert.check",
    capability="market.alerts",
    agent="markets",
    device="both",
    description="Check all enabled market alerts right now instead of waiting for the poller",
    risk="LOW",
    timeout=120,
)
async def market_alert_check(ctx: ToolContext) -> Dict[str, Any]:
    from backend.app.markets.alerts import alert_poller

    try:
        result = await alert_poller.check_once()
    except Exception as exc:
        return _bad(f"alert check failed: {type(exc).__name__}: {exc}")
    result["answer"] = (f"Checked {result.get('alerts', 0)} alert(s) over "
                        f"{result.get('symbols', 0)} symbol(s): {result.get('hits', 0)} triggered."
                        + ("\n" + "\n".join(f"- {h['message']} (now {h['price']})"
                                            for h in result.get("triggered", []))
                           if result.get("hits") else ""))
    return result


# ===========================================================================
# 7. PAPER TRADING
# ===========================================================================
@tool(
    name="market.paper.trade",
    capability="market.paper_trading",
    agent="markets",
    device="pc",
    description="Open a VIRTUAL (paper) position in SAM's simulated account to test a strategy without real money. No order is ever sent to a broker.",
    schema={"symbol": {"type": "string", "required": True}, "direction": {"type": "string", "required": True,
                                                                          "description": "long|short"},
            "entry": {"type": "number", "description": "empty = current market price"},
            "units": {"type": "number", "description": "empty = sized from risk_percent and stop"},
            "stop": {"type": "number"}, "risk_percent": {"type": "number", "default": 1.0},
            "targets": {"type": "array"}, "notes": {"type": "string"}},
    risk="MEDIUM",
    confirm=True,
    timeout=120,
)
async def market_paper_trade(ctx: ToolContext, symbol: str = "", direction: str = "long",
                             entry: Optional[float] = None, units: Optional[float] = None,
                             stop: Optional[float] = None, risk_percent: float = 1.0,
                             targets: Optional[List[float]] = None, notes: str = "",
                             request: str = "") -> Dict[str, Any]:
    from backend.app.markets.journal import paper_broker

    text = (symbol or request or ctx.user_text or "").strip()
    if not text:
        return _bad("which market?")
    body = (request or ctx.user_text or "").lower()
    if not direction or direction == "long":
        if any(k in body for k in ("short", "sell", "down", "put", "bearish")):
            direction = "short"
    res = _resolve(text)
    if not res.get("ok"):
        return res
    sym = res["symbol"]
    price = float(entry) if entry else None
    if price is None:
        q = await data_feed.quote(sym)
        if not q.get("ok"):
            return _bad(f"could not get a price for {sym.display}: {q.get('error')}")
        price = float(q["price"])
    acct = await paper_broker.account(currency="USD",
                                      starting=float(getattr(settings, "market_paper_balance",
                                                             10000) or 10000))
    balance = acct["account"]["balance"]
    if units is None:
        if stop:
            sizing = risk_math.position_size(balance=balance, risk_percent=float(risk_percent),
                                             entry=price, stop=float(stop),
                                             pair_type="forex" if sym.asset_class == "forex" else "asset")
            units = sizing.get("units") or 0
        else:
            units = (balance * float(risk_percent) / 100) / price * 10   # 10× notional of risk
        if not units:
            return _bad("could not size the position — pass units, or a stop with risk_percent")
    try:
        out = await paper_broker.open(symbol=sym.display, direction=direction, units=float(units),
                                      entry=price, stop=float(stop) if stop else None,
                                      targets=_nums(targets),
                                      asset_class=sym.asset_class, notes=notes)
    except Exception as exc:
        return _bad(f"paper trade failed: {type(exc).__name__}: {exc}")
    if not out.get("ok"):
        return out
    pos = out["position"]
    out["account"] = acct["account"]
    out["answer"] = (f"PAPER position #{pos['id']} opened: {direction.upper()} "
                     f"{pos['units']:,.4f} {sym.display} @ {pos['entry']}"
                     + (f", stop {pos['stop']}" if pos.get("stop") else "")
                     + (f", targets {pos['targets']}" if pos.get("targets") else "")
                     + f". Virtual balance {acct['account']['balance']:,.2f} "
                       f"{acct['account']['currency']}. No real order was placed.")
    return out


@tool(
    name="market.paper.close",
    capability="market.paper_trading",
    agent="markets",
    device="pc",
    description="Close a virtual (paper) position at a price and book the simulated P&L",
    schema={"position_id": {"type": "integer", "required": True},
            "exit_price": {"type": "number", "description": "empty = current market price"},
            "notes": {"type": "string"}},
    risk="MEDIUM",
    confirm=True,
    timeout=120,
)
async def market_paper_close(ctx: ToolContext, position_id: Optional[int] = None,
                             exit_price: Optional[float] = None, exit: Optional[float] = None,
                             price: Optional[float] = None, symbol: str = "",
                             notes: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.markets.journal import paper_broker

    exit_price = exit_price or exit or price
    text = (symbol or request or ctx.user_text or "").strip()
    if position_id is None and text:
        # let the user close by name: "close my EURUSD paper trade"
        positions = await paper_broker.positions()
        rows = positions.get("positions") or []
        want = text.lower().replace("/", "").replace(" ", "")
        match = [r for r in rows
                 if want in (r.get("symbol") or "").lower().replace("/", "").replace(" ", "")]
        if len(match) == 1:
            position_id = match[0]["id"]
        elif len(match) > 1:
            return _bad(f"{len(match)} open paper positions match '{text}': "
                        + ", ".join(f"#{r['id']} {r['symbol']} {r['direction']}" for r in match)
                        + " — tell me which id to close")
    if position_id is None:
        open_now = await paper_broker.positions()
        rows = open_now.get("positions") or []
        if not rows:
            return _bad("there are no open paper positions to close")
        return _bad("which paper position? open now: "
                    + ", ".join(f"#{r['id']} {r['symbol']} {r['direction']} @ {r['entry']}"
                                for r in rows))
    price = float(exit_price) if exit_price else None
    if price is None:
        positions = await paper_broker.positions()
        row = next((p for p in positions.get("positions", []) if p["id"] == int(position_id)), None)
        if not row:
            return _bad(f"no open paper position {position_id}")
        q = await data_feed.quote(data_feed.resolve_symbol(row["symbol"]))
        if not q.get("ok"):
            return _bad(f"could not price {row['symbol']}: {q.get('error')}")
        price = float(q["price"])
    out = await paper_broker.close(int(position_id), price, notes=notes)
    if not out.get("ok"):
        return out
    pos, acct = out["position"], out["account"]
    out["answer"] = (f"Closed paper position #{pos['id']} {pos['symbol']} at {price}: "
                     f"P&L {pos['pnl']:+,.4f}. Virtual balance now "
                     f"{acct['balance']:,.2f} {acct['currency']} "
                     f"({acct['return_percent']:+.2f}% overall, "
                     f"{acct['wins']}W/{acct['losses']}L).")
    return out


@tool(
    name="market.paper.portfolio",
    capability="market.paper_trading",
    agent="markets",
    device="pc",
    description="Show the virtual (paper) trading account: balance, open positions with live mark-to-market P&L, and history",
    schema={"status": {"type": "string", "default": "open", "description": "open|closed|all"}},
    risk="LOW",
    timeout=120,
)
async def market_paper_portfolio(ctx: ToolContext, status: str = "open") -> Dict[str, Any]:
    from backend.app.markets.journal import paper_broker

    data = await paper_broker.positions(status=status)
    positions = data.get("positions") or []
    account = data.get("account") or {}
    # mark to market
    marks = []
    for p in positions:
        if p["status"] != "open":
            continue
        try:
            q = await data_feed.quote(data_feed.resolve_symbol(p["symbol"]))
            price = q.get("price")
        except Exception:
            price = None
        if price:
            direction = 1 if p["direction"] in ("long", "up") else -1
            unrealised = direction * (float(price) - p["entry"]) * p["units"]
            marks.append({**p, "current_price": price, "unrealised_pnl": round(unrealised, 4),
                          "unrealised_percent": round(unrealised / (p["entry"] * p["units"]) * 100, 4)
                          if p["entry"] * p["units"] else None,
                          "distance_to_stop_percent": round((float(price) - (p.get("stop") or 0)) /
                                                            float(price) * 100, 3)
                          if p.get("stop") else None})
        else:
            marks.append({**p, "current_price": None, "unrealised_pnl": None,
                          "note": "no live price available"})
    equity = (account.get("balance") or 0) + sum(m.get("unrealised_pnl") or 0 for m in marks)
    total_risk = sum(m.get("risk_amount") or 0 for m in marks)
    return {"ok": True, "virtual": True, "account": account, "positions": marks,
            "count": len(marks), "equity_with_unrealised": round(equity, 4),
            "total_open_risk": round(total_risk, 4),
            "open_risk_percent": round(total_risk / account.get("balance", 1) * 100, 3)
            if account.get("balance") else None,
            "answer": (f"Paper account: {account.get('balance'):,.2f} {account.get('currency')} "
                       f"({account.get('return_percent'):+.2f}%, "
                       f"{account.get('win_rate_percent')}% win rate over "
                       f"{account.get('trades_closed')} closed trades). "
                       f"{len(marks)} open position(s), equity with unrealised "
                       f"{equity:,.2f}, open risk {total_risk:,.2f}."
                       + ("\n" + "\n".join(
                           f"- #{m['id']} {m['symbol']} {m['direction']} {m['units']:,.4f} @ "
                           f"{m['entry']} → now {m.get('current_price')} "
                           f"({(m.get('unrealised_pnl') or 0):+,.2f})" for m in marks)
                          if marks else "")),
            "note": "this is a simulation — no real money, no broker, no order"}


@tool(
    name="market.paper.reset",
    capability="market.paper_trading",
    agent="markets",
    device="pc",
    description="Reset the virtual paper account to a fresh balance and close all simulated positions",
    schema={"starting_balance": {"type": "number", "default": 10000}, "currency": {"type": "string", "default": "USD"}},
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def market_paper_reset(ctx: ToolContext, starting_balance: float = 10000.0,
                             currency: str = "USD") -> Dict[str, Any]:
    from backend.app.markets.journal import paper_broker

    out = await paper_broker.reset(float(starting_balance), currency)
    out["answer"] = (f"Paper account reset to {starting_balance:,.2f} {currency}; "
                     f"all simulated positions closed. The journal keeps its history.")
    return out


# ===========================================================================
# 8. EDUCATION / POLICY / STATUS
# ===========================================================================
@tool(
    name="market.explain",
    capability="market.analysis",
    agent="markets",
    device="both",
    description="Explain a trading concept, indicator or product in plain language (RSI, MACD, ATR, pip, lot, leverage, binary options, spread, slippage, Kelly, drawdown, hedging, carry trade…)",
    schema={"topic": {"type": "string", "required": True},
            "level": {"type": "string", "description": "beginner|intermediate|advanced"},
            "with_example": {"type": "boolean", "default": True}},
    risk="LOW",
    timeout=90,
)
async def market_explain(ctx: ToolContext, topic: str = "", level: str = "beginner",
                         with_example: bool = True, request: str = "") -> Dict[str, Any]:
    text = (topic or request or ctx.user_text or "").strip()
    text = re.sub(r"^(explain|what\s+(is|are)|tell\s+me\s+about|define)\s+", "", text, flags=re.I).strip(" ?.")
    if not text:
        return _bad("which concept should I explain?")
    offline = _OFFLINE_GLOSSARY.get(text.lower().replace(" ", "_"))
    if offline is None:
        offline = next((v for k, v in _OFFLINE_GLOSSARY.items()
                        if k.replace("_", " ") in text.lower() or text.lower() in k.replace("_", " ")),
                       None)
    level_hint = {"beginner": "explain to a complete beginner, no jargon without defining it",
                  "intermediate": "assume the reader knows basic charting",
                  "advanced": "assume a working trader; include the maths and the failure modes"
                  }.get(level, "explain clearly")
    prompt = (
        f"Explain '{text}' for trading. {level_hint}. "
        + ("Include a concrete numeric example." if with_example else "") +
        "\nStructure: WHAT IT IS · WHY IT MATTERS · HOW TO USE IT · COMMON MISTAKE · "
        "ONE-SENTENCE TAKEAWAY. Be accurate and brief. If the topic is a product that is banned or "
        "restricted in some countries (for example binary options), say so plainly."
    )
    answer = await _llm(prompt, system="You are SAM's Market Analyzer, a precise trading educator. "
                                       "You never promise profits and you always mention risk.",
                        role="reasoning", max_tokens=800,
                        fallback=(offline or {}).get("text", ""))
    if not answer:
        answer = (offline or {}).get("text", "")
    if not answer:
        return _bad(f"no model available to explain '{text}' and it is not in SAM's offline glossary")
    warning = ""
    if "binary" in text.lower():
        warning = sig_engine.BINARY_WARNING
    elif any(k in text.lower() for k in ("leverage", "margin", "cfd", "forex")):
        warning = sig_engine.FOREX_WARNING
    out = {"ok": True, "topic": text, "level": level, "explanation": answer,
           "answer": answer + (("\n\n" + warning) if warning else ""),
           "offline_definition": offline, "warning": warning or None,
           "related": (offline or {}).get("related", [])}
    return out


_OFFLINE_GLOSSARY: Dict[str, Dict[str, Any]] = {
    "pip": {"text": "A pip is the standard unit of price movement in forex: 0.0001 for most pairs, "
                    "0.01 for JPY pairs. EURUSD moving 1.0850 → 1.0860 is 10 pips. Pip value on one "
                    "standard lot (100,000 units) is about $10 per pip for USD-quoted pairs.",
            "related": ["lot", "pip_value", "spread"]},
    "lot": {"text": "A lot is a position size: standard = 100,000 units, mini = 10,000, "
                    "micro = 1,000. One standard lot of EURUSD moves roughly $10 per pip.",
            "related": ["pip", "leverage", "position_size"]},
    "leverage": {"text": "Leverage lets you control a large notional with a small margin: 30:1 means "
                      "$1,000 controls $30,000. It multiplies losses exactly as much as gains — a "
                      "3.3% adverse move wipes the margin at 30:1. Leverage is why stops are "
                      "non-optional.", "related": ["margin", "position_size", "risk_of_ruin"]},
    "spread": {"text": "The spread is the difference between the bid and ask price — your cost of "
                    "entry. On a 60-second binary or a scalping strategy the spread can be a large "
                    "share of the expected move, which is why short-expiry trading usually loses.",
            "related": ["slippage", "pip"]},
    "slippage": {"text": "Slippage is the difference between the price you requested and the price "
                      "you got, caused by latency or a gap. Backtests should include it, otherwise "
                      "they overstate the edge.", "related": ["spread", "backtest"]},
    "rsi": {"text": "The Relative Strength Index measures the speed of recent gains vs losses on a "
                   "0–100 scale (14 periods is standard). Above 70 is called overbought, below 30 "
                   "oversold — but in a strong trend RSI can stay overbought for a long time, so it "
                   "works best as a range signal or as a divergence detector.",
            "related": ["divergence", "stochastic", "macd"]},
    "macd": {"text": "MACD is the difference between a 12- and 26-period EMA, plotted against its "
                    "9-period signal line. A cross up is bullish momentum; the histogram shows "
                    "whether that momentum is accelerating.", "related": ["ema", "rsi"]},
    "atr": {"text": "Average True Range is the average size of a candle's range over N periods — a "
                   "measure of volatility, not direction. Traders use it to place stops that adapt "
                   "to the market (e.g. 1.5×ATR) and to compute the expected move.",
            "related": ["volatility", "stop_loss", "position_size"]},
    "adx": {"text": "The Average Directional Index measures trend *strength* from 0 to 100, ignoring "
                   "direction. Below 20 means ranging, 25+ means a real trend, 40+ is strong. +DI "
                   "above −DI points up.", "related": ["regime", "dmi"]},
    "binary_option": {"text": "A binary option pays a fixed amount if a condition is met at expiry "
                              "(price above/below a level) and nothing otherwise. With an 80% "
                              "payout you must win 55.6% of trades to break even. Banned for retail "
                              "in the EU/UK; RBI and SEBI warn that Indian residents trading them on "
                              "overseas platforms are breaking FEMA rules.",
            "related": ["payout", "break_even", "risk_of_ruin"]},
    "kelly": {"text": "The Kelly criterion sizes a bet to maximise long-run growth: f = p − q/b, "
                   "where p is win probability, q = 1−p and b is the win/loss ratio. Full Kelly is "
                   "too volatile for trading; quarter-Kelly is the common practical choice, and "
                   "negative Kelly means do not trade.", "related": ["expectancy", "position_size"]},
    "drawdown": {"text": "Drawdown is the fall from an equity peak to a trough. Recovery is "
                      "asymmetric: −20% needs +25%, −50% needs +100%. Controlling drawdown is the "
                      "primary job of risk management.", "related": ["risk_of_ruin", "position_size"]},
    "risk_of_ruin": {"text": "The probability that a losing streak takes the account below a "
                          "threshold. It falls sharply as risk-per-trade falls: at 1% risk a "
                          "10-loss streak costs ~10%, at 10% risk it costs ~65%.",
            "related": ["kelly", "drawdown", "stake_plan"]},
    "support_and_resistance": {"text": "Support is a price area where buying has repeatedly appeared; "
                                      "resistance where selling has. Levels are zones, not lines, and "
                                      "gain weight from the number of touches and the volume traded "
                                      "there.", "related": ["pivot_points", "fibonacci", "levels"]},
    "fibonacci_retracement": {"text": "Retracement levels (23.6%, 38.2%, 50%, 61.8%, 78.6%) are drawn "
                                     "between a swing high and low. The 50–61.8% area ('golden "
                                     "pocket') is where pullbacks often find buyers in an uptrend.",
            "related": ["support_and_resistance", "trend"]},
    "bollinger_bands": {"text": "A 20-period moving average with bands ±2 standard deviations. "
                                "Narrow bands (a 'squeeze') mean low volatility and often precede an "
                                "expansion; %B tells you where price sits inside the bands.",
            "related": ["squeeze", "volatility", "mean_reversion"]},
    "vwap": {"text": "Volume-weighted average price is the session's fair value by volume. Institutions "
                   "use it as an execution benchmark: above VWAP is bullish intraday, below is "
                   "bearish.", "related": ["obv", "intraday"]},
    "divergence": {"text": "Divergence is when price makes a new extreme but an oscillator does not. "
                          "Regular divergence hints at reversal; hidden divergence hints at trend "
                          "continuation. It is a warning, not a trigger.",
            "related": ["rsi", "macd", "reversal"]},
    "carry_trade": {"text": "Borrowing a low-yield currency to buy a high-yield one and collecting the "
                          "interest differential. It profits slowly and loses fast when risk appetite "
                          "flips — the classic 'picking up pennies in front of a steamroller'.",
            "related": ["swap", "interest_rate_differential"]},
    "hedging": {"text": "Taking an offsetting position to reduce risk (for example long EURUSD and "
                       "long USDCHF, which are negatively correlated). Hedging lowers variance; it "
                       "also lowers expected return and doubles the spread cost.",
            "related": ["correlation", "portfolio_risk"]},
    "expectancy": {"text": "Expectancy = (win% × average win) − (loss% × average loss). It is the "
                          "single number that tells you whether a system is worth trading; positive "
                          "expectancy with a survivable drawdown is the whole game.",
            "related": ["profit_factor", "kelly"]},
    "profit_factor": {"text": "Gross profit divided by gross loss. Above 1.5 is decent for a retail "
                              "system, above 2 is strong, and anything below 1 loses money before "
                              "costs.", "related": ["expectancy", "backtest"]},
    "margin": {"text": "Margin is the deposit a broker holds to keep a leveraged position open. When "
                   "losses eat it, you get a margin call, then automatic liquidation.",
            "related": ["leverage", "risk_of_ruin"]},
    "position_size": {"text": "Position size = risk amount ÷ stop distance. Decide the risk first "
                              "(usually 0.5–2% of the account), place the stop where the idea is "
                              "wrong, and let the size fall out of the maths.",
            "related": ["stop_loss", "risk_of_ruin", "pip_value"]},
}


@tool(
    name="market.broker.status",
    capability="market.data.read",
    agent="markets",
    device="pc",
    description="Report SAM's broker/live-trading policy: whether live execution is even possible, and what is connected",
    risk="LOW",
    timeout=30,
)
async def market_broker_status(ctx: ToolContext) -> Dict[str, Any]:
    allow_live = bool(getattr(settings, "market_allow_live_trading", False))
    connected = []
    for name, key in (("metatrader", getattr(settings, "market_mt_bridge_url", "")),
                      ("broker_api", getattr(settings, "market_broker_api_key", ""))):
        if key:
            connected.append(name)
    return {
        "ok": True,
        "live_trading_allowed": allow_live,
        "connected_brokers": connected,
        "paper_trading": True,
        "policy": [
            "SAM never places a real order by itself.",
            "Live execution requires MARKET_ALLOW_LIVE_TRADING=true in .env AND an explicitly "
            "configured broker bridge AND per-order confirmation from the user.",
            "Even then, order placement is performed by the broker's own client/API under the "
            "user's credentials and the user's responsibility — SAM does not bypass broker "
            "authentication, KYC, or any trading restriction.",
            "Binary-options execution is never automated: it is prohibited for retail traders in "
            "the EU/UK and flagged as illegal for Indian residents under FEMA by RBI/SEBI.",
        ],
        "answer": ("Live trading is DISABLED by configuration. SAM is in analysis + paper-trading "
                   "mode." if not allow_live else
                   f"Live trading is enabled in .env; connected bridges: {connected or 'none'}. "
                   f"Every order still needs your explicit confirmation."),
        "warning": sig_engine.FOREX_WARNING,
    }


@tool(
    name="market.status",
    capability="market.data.read",
    agent="markets",
    device="pc",
    description="Market Analyzer brain status: configuration, feed health, alert poller, paper account and journal size",
    risk="LOW",
    timeout=90,
)
async def market_status(ctx: ToolContext, deep: bool = False) -> Dict[str, Any]:
    from backend.app.markets.journal import alerts as alert_store
    from backend.app.markets.journal import journal, paper_broker

    acct = await paper_broker.account()
    stats = await journal.stats()
    alert_rows = await alert_store.list()
    out: Dict[str, Any] = {
        "ok": True,
        "brain": "markets",
        "enabled": bool(getattr(settings, "market_enabled", True)),
        "config": {
            "data_provider": getattr(settings, "market_data_provider", "auto"),
            "default_timeframe": getattr(settings, "market_default_timeframe", "1h"),
            "watchlist": [s.strip() for s in re.split(
                r"[,\s]+", getattr(settings, "market_watchlist", "")) if s.strip()],
            "risk_per_trade_percent": getattr(settings, "market_risk_per_trade", 1.0),
            "max_risk_per_trade_percent": getattr(settings, "market_max_risk_per_trade", 5.0),
            "paper_balance": getattr(settings, "market_paper_balance", 10000),
            "alerts_enabled": getattr(settings, "market_alerts_enabled", True),
            "alert_poll_seconds": getattr(settings, "market_alert_poll_seconds", 120),
            "live_trading_allowed": bool(getattr(settings, "market_allow_live_trading", False)),
        },
        "alert_poller": alert_poller_status(),
        "alerts": {"total": len(alert_rows), "enabled": sum(1 for a in alert_rows if a["enabled"]),
                   "triggered": sum(a["triggered_count"] for a in alert_rows)},
        "paper_account": acct.get("account"),
        "journal": {"closed_trades": stats.get("closed_trades", 0),
                    "win_rate_percent": stats.get("win_rate_percent"),
                    "net_pnl": stats.get("net_pnl"), "profit_factor": stats.get("profit_factor")},
        "tools": len([t for t in __import__("backend.app.tools.registry", fromlist=["registry"])
                      .registry.all() if t.agent == "markets"]),
        "capabilities": ["market.data.read", "market.analysis", "market.backtest",
                         "market.alerts", "market.journal", "market.paper_trading",
                         "market.live_trading (disabled)"],
        "policy": ["analysis and paper trading only — no real orders",
                   "every signal shows its reasons, conflicts and confidence",
                   "binary-options output always carries the regulatory warning",
                   "no profit is ever promised or implied"],
        "warnings": [sig_engine.FOREX_WARNING, sig_engine.BINARY_WARNING],
    }
    if deep:
        out["feeds"] = await data_feed.feed_health()
    out["answer"] = (
        f"Market Analyzer: {'enabled' if out['enabled'] else 'DISABLED'}, "
        f"{out['tools']} tools, watchlist {len(out['config']['watchlist'])} symbols, "
        f"{out['alerts']['enabled']} active alerts (poller "
        f"{'running' if out['alert_poller'].get('running') else 'stopped'}), "
        f"paper account {acct['account']['balance']:,.2f} "
        f"({acct['account']['return_percent']:+.2f}%), "
        f"journal {stats.get('closed_trades', 0)} closed trades. "
        f"Live trading: {'ENABLED' if out['config']['live_trading_allowed'] else 'disabled by policy'}."
    )
    return out
