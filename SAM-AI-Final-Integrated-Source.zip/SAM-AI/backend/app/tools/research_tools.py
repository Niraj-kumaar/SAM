"""
backend.app.tools.research_tools
================================

The Research Agent::

    Question -> Search -> Multiple Sources -> Read -> Compare -> Cross-check
             -> Extract -> Summarise -> Cite

Search backends (used in this order, first one that works wins)
--------------------------------------------------------------
1. **DuckDuckGo HTML/lite** — no API key, no tracking, works out of the box.
2. **Wikipedia REST** — authoritative summaries for encyclopedic questions.
3. **Brave / Tavily / Serper / Bing** — if the user adds a key to ``.env``.
4. **Browser Agent** — full rendering for pages that need JavaScript.

The output always separates **verified**, **uncertain**, **conflicting** and
**possibly outdated** information, and every claim carries a citation.
"""

from __future__ import annotations

import asyncio
import hashlib
import html as html_lib
import json
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, quote_plus, unquote, urljoin, urlparse

import httpx

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.research")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 SAM/1.0")
TIMEOUT = 25.0


@dataclass
class Source:
    url: str
    title: str = ""
    snippet: str = ""
    text: str = ""
    domain: str = ""
    published: str = ""
    engine: str = ""
    score: float = 0.0
    fetched: bool = False
    fetch_error: str = ""
    words: int = 0
    trust: float = 0.5

    def to_dict(self, *, with_text: bool = False) -> Dict[str, Any]:
        d = {
            "url": self.url, "title": self.title, "snippet": self.snippet[:600],
            "domain": self.domain, "published": self.published, "engine": self.engine,
            "score": round(self.score, 3), "fetched": self.fetched, "words": self.words,
            "trust": round(self.trust, 2),
        }
        if with_text:
            d["text"] = self.text[:20000]
        return d


# ---------------------------------------------------------------------------
# Domain trust heuristics
# ---------------------------------------------------------------------------
HIGH_TRUST = {
    "wikipedia.org", "britannica.com", "nature.com", "science.org", "nih.gov", "who.int",
    "un.org", "imf.org", "worldbank.org", "ieee.org", "acm.org", "arxiv.org", "nasa.gov",
    "gov.uk", "europa.eu", "rbi.org.in", "india.gov.in", "data.gov.in", "pib.gov.in",
    "mayoclinic.org", "cdc.gov", "nature.com", "sciencedirect.com", "springer.com",
    "reuters.com", "apnews.com", "bbc.com", "bbc.co.uk", "economist.com", "ft.com",
    "developer.mozilla.org", "docs.python.org", "microsoft.com", "google.com",
    "apple.com", "kernel.org", "ietf.org", "w3.org", "stackoverflow.com",
}
LOW_TRUST = {"pinterest.", "quora.com", "reddit.com", "facebook.com", "x.com", "twitter.com",
             "instagram.com", "tiktok.com", "medium.com", "blogspot.", "wordpress.com"}


def trust_score(url: str) -> float:
    domain = urlparse(url).netloc.lower().removeprefix("www.")
    score = 0.5
    if any(domain == d or domain.endswith("." + d) for d in HIGH_TRUST):
        score = 0.9
    if domain.endswith((".gov", ".edu", ".ac.uk", ".int", ".mil")):
        score = 0.92
    if any(d in domain for d in LOW_TRUST):
        score = 0.3
    if "blog" in domain or "forum" in domain:
        score -= 0.1
    return round(max(0.05, min(1.0, score)), 2)


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------
def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        timeout=TIMEOUT,
        follow_redirects=True,
        headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9,hi;q=0.8,kn;q=0.7",
                 "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8"},
    )


def strip_html(html: str) -> str:
    from backend.app.browser.engine import readable_text

    return readable_text(html)


# ---------------------------------------------------------------------------
# Search backends
# ---------------------------------------------------------------------------
async def search_duckduckgo(query: str, limit: int = 10) -> List[Source]:
    """DuckDuckGo HTML endpoint — keyless and reliable."""
    out: List[Source] = []
    async with _client() as client:
        for endpoint, parse in (
            ("https://html.duckduckgo.com/html/", _parse_ddg_html),
            ("https://lite.duckduckgo.com/lite/", _parse_ddg_html),
        ):
            try:
                r = await client.post(endpoint, data={"q": query, "kl": "us-en"},
                                      headers={"Referer": "https://duckduckgo.com/"})
                if r.status_code >= 400:
                    continue
                out = parse(r.text, limit)
                if out:
                    for s in out:
                        s.engine = "duckduckgo"
                    break
            except Exception as exc:
                log.debug("ddg %s failed: %s", endpoint, exc)
                continue

        # DDG instant answer API (adds a definition/abstract when available)
        try:
            r = await client.get("https://api.duckduckgo.com/",
                                 params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1})
            if r.status_code == 200:
                data = r.json()
                abstract = data.get("AbstractText") or ""
                if abstract:
                    out.insert(0, Source(
                        url=data.get("AbstractURL") or f"https://duckduckgo.com/?q={quote_plus(query)}",
                        title=data.get("Heading") or query, snippet=abstract, text=abstract,
                        engine="duckduckgo-instant", fetched=True, words=len(abstract.split()),
                        trust=trust_score(data.get("AbstractURL") or "duckduckgo.com"), score=1.2,
                    ))
                for topic in (data.get("RelatedTopics") or [])[:6]:
                    if isinstance(topic, dict) and topic.get("FirstURL"):
                        out.append(Source(url=topic["FirstURL"], title=topic.get("Text", "")[:120],
                                          snippet=topic.get("Text", ""), engine="duckduckgo-related",
                                          trust=trust_score(topic["FirstURL"])))
        except Exception as exc:
            log.debug("ddg instant answer failed: %s", exc)
    return out[:limit]


def _parse_ddg_html(html: str, limit: int) -> List[Source]:
    results: List[Source] = []
    # result links look like: <a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=...">
    for m in re.finditer(
        r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', html, re.S
    ):
        href, title = m.group(1), m.group(2)
        url = _unwrap_ddg(href)
        if not url:
            continue
        results.append(Source(url=url, title=_clean(title)))
        if len(results) >= limit:
            break
    # snippets follow in <a class="result__snippet" ...>
    snippets = [_clean(s) for s in re.findall(
        r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>', html, re.S)]
    if not snippets:
        snippets = [_clean(s) for s in re.findall(
            r'class="result__snippet"[^>]*>(.*?)<', html, re.S)]
    for i, res in enumerate(results):
        if i < len(snippets):
            res.snippet = snippets[i]
        res.domain = urlparse(res.url).netloc
        res.trust = trust_score(res.url)
    return results


def _unwrap_ddg(href: str) -> str:
    href = html_lib.unescape(href)
    if href.startswith("//"):
        href = "https:" + href
    if "duckduckgo.com/l/" in href or "uddg=" in href:
        qs = parse_qs(urlparse(href).query)
        if "uddg" in qs:
            return unquote(qs["uddg"][0])
    if href.startswith("http"):
        return href
    return ""


async def search_wikipedia(query: str, limit: int = 3) -> List[Source]:
    out: List[Source] = []
    async with _client() as client:
        try:
            r = await client.get("https://en.wikipedia.org/w/api.php", params={
                "action": "query", "list": "search", "srsearch": query, "srlimit": limit,
                "format": "json", "utf8": 1,
            })
            if r.status_code != 200:
                return out
            for hit in r.json().get("query", {}).get("search", []):
                title = hit.get("title", "")
                url = f"https://en.wikipedia.org/wiki/{quote_plus(title.replace(' ', '_'))}"
                out.append(Source(
                    url=url, title=title,
                    snippet=_clean(hit.get("snippet", "")),
                    domain="en.wikipedia.org", engine="wikipedia",
                    published=str(hit.get("timestamp", ""))[:10], trust=0.9, score=1.1,
                ))
        except Exception as exc:
            log.debug("wikipedia search failed: %s", exc)
    return out


async def search_brave(query: str, limit: int = 10, key: str = "") -> List[Source]:
    if not key:
        return []
    async with _client() as client:
        try:
            r = await client.get("https://api.search.brave.com/res/v1/web/search",
                                 params={"q": query, "count": limit},
                                 headers={"X-Subscription-Token": key, "Accept": "application/json"})
            if r.status_code != 200:
                return []
            data = r.json()
            out = []
            for item in data.get("web", {}).get("results", []):
                out.append(Source(url=item.get("url", ""), title=item.get("title", ""),
                                  snippet=item.get("description", ""),
                                  published=item.get("page_age", "") or "",
                                  domain=urlparse(item.get("url", "")).netloc,
                                  engine="brave", trust=trust_score(item.get("url", ""))))
            return out
        except Exception as exc:
            log.debug("brave search failed: %s", exc)
            return []


async def search_tavily(query: str, limit: int = 8, key: str = "") -> List[Source]:
    if not key:
        return []
    async with _client() as client:
        try:
            r = await client.post("https://api.tavily.com/search", json={
                "api_key": key, "query": query, "max_results": limit,
                "search_depth": "advanced", "include_answer": True,
            })
            if r.status_code != 200:
                return []
            data = r.json()
            out = []
            for item in data.get("results", []):
                out.append(Source(url=item.get("url", ""), title=item.get("title", ""),
                                  snippet=item.get("content", "")[:600],
                                  text=item.get("content", ""), fetched=True,
                                  words=len((item.get("content") or "").split()),
                                  domain=urlparse(item.get("url", "")).netloc,
                                  engine="tavily", score=float(item.get("score") or 0),
                                  trust=trust_score(item.get("url", ""))))
            return out
        except Exception as exc:
            log.debug("tavily search failed: %s", exc)
            return []


async def search_bing(query: str, limit: int = 10, key: str = "") -> List[Source]:
    if not key:
        return []
    async with _client() as client:
        try:
            r = await client.get("https://api.bing.microsoft.com/v7.0/search",
                                 params={"q": query, "count": limit, "mkt": "en-IN"},
                                 headers={"Ocp-Apim-Subscription-Key": key})
            if r.status_code != 200:
                return []
            out = []
            for item in r.json().get("webPages", {}).get("value", []):
                out.append(Source(url=item.get("url", ""), title=item.get("name", ""),
                                  snippet=item.get("snippet", ""), engine="bing",
                                  domain=urlparse(item.get("url", "")).netloc,
                                  trust=trust_score(item.get("url", ""))))
            return out
        except Exception as exc:
            log.debug("bing search failed: %s", exc)
            return []


async def search_arxiv(query: str, limit: int = 5) -> List[Source]:
    async with _client() as client:
        try:
            r = await client.get("http://export.arxiv.org/api/query", params={
                "search_query": f"all:{query}", "start": 0, "max_results": limit,
            })
            if r.status_code != 200:
                return []
            out = []
            for m in re.finditer(
                r"<entry>(.*?)</entry>", r.text, re.S
            ):
                block = m.group(1)
                def grab(tag: str) -> str:
                    mm = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", block, re.S)
                    return _clean(mm.group(1)) if mm else ""
                url = grab("id")
                if url:
                    out.append(Source(url=url, title=grab("title"), snippet=grab("summary")[:600],
                                      published=grab("published")[:10], engine="arxiv",
                                      domain="arxiv.org", trust=0.95))
            return out
        except Exception as exc:
            log.debug("arxiv failed: %s", exc)
            return []


async def search_news(query: str, limit: int = 8, key: str = "") -> List[Source]:
    if not key:
        return await search_duckduckgo(f"{query} news", limit)
    async with _client() as client:
        try:
            r = await client.get("https://newsapi.org/v2/everything",
                                 params={"q": query, "pageSize": limit, "sortBy": "publishedAt",
                                         "apiKey": key, "language": "en"})
            if r.status_code != 200:
                return []
            out = []
            for item in r.json().get("articles", []):
                out.append(Source(url=item.get("url", ""), title=item.get("title", ""),
                                  snippet=item.get("description", "") or "",
                                  published=(item.get("publishedAt") or "")[:10],
                                  domain=urlparse(item.get("url", "")).netloc,
                                  engine="newsapi", trust=trust_score(item.get("url", ""))))
            return out
        except Exception as exc:
            log.debug("newsapi failed: %s", exc)
            return []


async def run_search(query: str, limit: int = 10, engines: Optional[List[str]] = None) -> List[Source]:
    """Try every configured backend and merge + de-duplicate the results."""
    if not settings.web_enabled:
        return []
    engines = engines or ["duckduckgo", "wikipedia"]
    tasks = []
    if "duckduckgo" in engines:
        tasks.append(search_duckduckgo(query, limit))
    if "wikipedia" in engines:
        tasks.append(search_wikipedia(query, min(3, limit)))
    if "brave" in engines:
        tasks.append(search_brave(query, limit, settings.__dict__.get("brave_api_key", "")))
    if "tavily" in engines:
        tasks.append(search_tavily(query, limit, settings.__dict__.get("tavily_api_key", "")))
    if "bing" in engines:
        tasks.append(search_bing(query, limit, settings.__dict__.get("bing_api_key", "")))
    if "arxiv" in engines or re.search(r"\b(paper|arxiv|study|research)\b", query, re.I):
        tasks.append(search_arxiv(query, 4))
    if "news" in engines or re.search(r"\b(news|latest|today|breaking)\b", query, re.I):
        tasks.append(search_news(query, limit))

    results = await asyncio.gather(*tasks, return_exceptions=True)
    merged: Dict[str, Source] = {}
    for res in results:
        if isinstance(res, BaseException) or not res:
            continue
        for s in res:
            if not s.url or not s.url.startswith("http"):
                continue
            key = re.sub(r"[#?].*$", "", s.url).rstrip("/").lower()
            if key in merged:
                merged[key].score += 0.15          # appearing twice is a signal
                if not merged[key].snippet and s.snippet:
                    merged[key].snippet = s.snippet
            else:
                merged[key] = s

    out = list(merged.values())
    for i, s in enumerate(out):
        s.score += max(0.0, 1.0 - i * 0.05)        # rank position
        s.score += s.trust * 0.4
        if s.published:
            s.score += 0.1
    out.sort(key=lambda s: s.score, reverse=True)
    return out[:limit]


# ---------------------------------------------------------------------------
# Fetching
# ---------------------------------------------------------------------------
BLOCKED_FETCH_DOMAINS = ("localhost", "127.0.0.1", "0.0.0.0", "169.254.", "metadata.google",
                         "100.100.100.200")


async def fetch_page(url: str, *, max_chars: int = 60_000, extract_main: bool = True) -> Source:
    src = Source(url=url, domain=urlparse(url).netloc, trust=trust_score(url))
    if not settings.web_enabled:
        src.fetch_error = "web access is disabled by Privacy Mode"
        return src
    if any(b in url.lower() for b in BLOCKED_FETCH_DOMAINS):
        src.fetch_error = "refusing to fetch a local/internal address"
        return src
    try:
        async with _client() as client:
            r = await client.get(url)
            if r.status_code >= 400:
                src.fetch_error = f"HTTP {r.status_code}"
                return src
            ctype = r.headers.get("content-type", "")
            body = r.text
            if "html" in ctype or body.lstrip().startswith("<"):
                title_m = re.search(r"<title[^>]*>(.*?)</title>", body, re.S | re.I)
                src.title = _clean(title_m.group(1)) if title_m else ""
                desc_m = re.search(
                    r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']',
                    body, re.S | re.I)
                if desc_m:
                    src.snippet = _clean(desc_m.group(1))[:600]
                text = strip_html(body)
                if extract_main:
                    text = _main_content(body, text)
                src.text = text[:max_chars]
            elif "json" in ctype:
                src.text = json.dumps(_safe_json(body), indent=2)[:max_chars]
                src.title = url.rsplit("/", 1)[-1][:120]
            else:
                src.text = body[:max_chars]
            src.words = len(src.text.split())
            src.fetched = src.words > 20
            if not src.fetched:
                src.fetch_error = src.fetch_error or "page produced no readable text"
    except httpx.TimeoutException:
        src.fetch_error = "timeout"
    except Exception as exc:
        src.fetch_error = str(exc)[:200]
    return src


def _safe_json(text: str) -> Any:
    try:
        return json.loads(text)
    except Exception:
        return {"raw": text[:2000]}


def _main_content(html: str, full_text: str) -> str:
    """Cheap readability: prefer <article>/<main>, else the densest text block."""
    for tag in ("article", "main"):
        m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", html, re.S | re.I)
        if m:
            candidate = strip_html(m.group(1))
            if len(candidate) > 300:
                return candidate
    # fall back: drop obvious nav/footer noise from the full text
    lines = [l.strip() for l in full_text.splitlines()]
    kept: List[str] = []
    for line in lines:
        if not line:
            kept.append("")
            continue
        if len(line) < 40 and re.match(r"^(home|about|contact|menu|login|sign (in|up)|"
                                       r"subscribe|newsletter|cookie|privacy|terms|"
                                       r"advertisement|related|share|follow us)\b", line, re.I):
            continue
        kept.append(line)
    text = "\n".join(kept)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text if len(text) > 200 else full_text


async def fetch_many(sources: List[Source], *, concurrency: int = 5,
                     max_chars: int = 40_000) -> List[Source]:
    sem = asyncio.Semaphore(concurrency)

    async def one(src: Source) -> Source:
        async with sem:
            fetched = await fetch_page(src.url, max_chars=max_chars)
            # keep the search metadata, add the fetched body
            src.text = fetched.text
            src.words = fetched.words
            src.fetched = fetched.fetched
            src.fetch_error = fetched.fetch_error
            src.title = src.title or fetched.title
            src.snippet = src.snippet or fetched.snippet
            return src

    return list(await asyncio.gather(*[one(s) for s in sources], return_exceptions=False))


def _clean(text: str) -> str:
    text = html_lib.unescape(text or "")
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


# ===========================================================================
# TOOLS
# ===========================================================================
@tool(
    name="research.search",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Search the web across several engines and return ranked sources",
    schema={"query": {"type": "string", "required": True}, "limit": {"type": "integer"}},
    risk="LOW",
    timeout=90,
)
async def research_search(ctx: ToolContext, query: str = "", limit: int = 8,
                          engines: Optional[List[str]] = None, request: str = "") -> Dict[str, Any]:
    q = (query or request or "").strip()
    if not q:
        return {"ok": False, "error": "no search query"}
    if not settings.web_enabled:
        return {"ok": False, "blocked": True,
                "error": "web search is disabled (PRIVACY_EXTERNAL_WEB=true)"}
    t0 = time.time()
    results = await run_search(q, limit=int(limit), engines=engines)
    if not results:
        return {"ok": False, "query": q, "sources": [],
                "error": "no search backend returned results (check internet access)"}
    return {
        "ok": True, "query": q, "count": len(results),
        "duration_ms": int((time.time() - t0) * 1000),
        "sources": [s.to_dict() for s in results],
        "top_domains": sorted({s.domain for s in results}),
    }


@tool(
    name="research.read",
    capability="research.fetch_page",
    agent="research",
    device="cloud",
    description="Fetch and read one or more web pages, extracting the main text",
    risk="LOW",
    timeout=120,
)
async def research_read(ctx: ToolContext, url: str = "", urls: Optional[List[str]] = None,
                        max_chars: int = 30_000) -> Dict[str, Any]:
    targets = urls or ([url] if url else [])
    if not targets:
        # read whatever the previous search step found
        prior = ctx.prior("search sources", "research.search")
        if isinstance(prior, dict) and prior.get("sources"):
            targets = [s["url"] for s in prior["sources"][:4]]
    if not targets:
        return {"ok": False, "error": "no URL to read"}

    sources = [Source(url=u) for u in targets[:8]]
    fetched = await fetch_many(sources, max_chars=int(max_chars))
    ok = [s for s in fetched if s.fetched]
    return {
        "ok": bool(ok), "requested": len(targets), "fetched": len(ok),
        "pages": [s.to_dict(with_text=True) for s in fetched],
        "errors": [{"url": s.url, "error": s.fetch_error} for s in fetched if not s.fetched],
        "total_words": sum(s.words for s in ok),
    }


@tool(
    name="research.compare",
    capability="research.fetch_page",
    agent="reasoning",
    device="cloud",
    description="Cross-check several sources: agree / conflict / unverified / outdated",
    risk="LOW",
    timeout=120,
)
async def research_compare(ctx: ToolContext, claim: str = "", request: str = "") -> Dict[str, Any]:
    question = claim or request or ctx.user_text
    prior = _collect_prior_sources(ctx)
    if not prior:
        return {"ok": False, "error": "nothing to compare — run research.search/read first",
                "question": question}

    from backend.app.models.router import router

    corpus = "\n\n".join(
        f"[SOURCE {i + 1}] {s['title']}\n{s['url']}\n{s.get('text') or s.get('snippet', '')}"[:6000]
        for i, s in enumerate(prior[:6])
    )[:24000]

    prompt = f"""You are SAM's Research Brain cross-checking sources.

QUESTION / CLAIM:
{question}

SOURCES:
{corpus}

Compare them and answer in this exact JSON shape:
{{
  "verified":   [{{"fact": "...", "sources": [1,3], "confidence": 0.9}}],
  "conflicting":[{{"fact": "...", "positions": {{"1": "...", "2": "..."}}, "note": "..."}}],
  "uncertain":  [{{"fact": "...", "why": "..."}}],
  "outdated":   [{{"fact": "...", "as_of": "...", "note": "..."}}],
  "answer":     "a 3-6 sentence direct answer to the question",
  "best_source": 1
}}
Use only information present in the sources. Source numbers are 1-based."""

    data = await router.ask_json(prompt, role="reasoning", default=None)
    if not isinstance(data, dict):
        return {"ok": False, "error": "the model did not return a usable comparison",
                "sources": [s["url"] for s in prior]}

    indexed = {i + 1: s for i, s in enumerate(prior[:6])}

    def with_urls(items: Any) -> List[Dict[str, Any]]:
        out = []
        for it in items if isinstance(items, list) else []:
            if not isinstance(it, dict):
                continue
            d = dict(it)
            d["urls"] = [indexed[n]["url"] for n in d.pop("sources", [])
                         if isinstance(n, int) and n in indexed]
            out.append(d)
        return out

    return {
        "ok": True,
        "question": question,
        "answer": data.get("answer", ""),
        "verified": with_urls(data.get("verified")),
        "conflicting": data.get("conflicting") or [],
        "uncertain": data.get("uncertain") or [],
        "outdated": data.get("outdated") or [],
        "source_count": len(prior),
        "sources": [s["url"] for s in prior],
        "best_source": indexed.get(data.get("best_source"), {}).get("url", ""),
    }


def _collect_prior_sources(ctx: ToolContext) -> List[Dict[str, Any]]:
    """Pull sources produced by earlier steps in the same task."""
    out: List[Dict[str, Any]] = []
    seen = set()

    def add(items: Any) -> None:
        for s in items if isinstance(items, list) else []:
            if not isinstance(s, dict):
                continue
            url = s.get("url")
            if not url or url in seen:
                continue
            seen.add(url)
            out.append(s)

    for value in (ctx.outputs or {}).values():
        if not isinstance(value, dict):
            continue
        inner = value.get("value") if isinstance(value.get("value"), dict) else value
        if isinstance(inner, dict):
            add(inner.get("sources"))
            for page in inner.get("pages") or []:
                if isinstance(page, dict):
                    add([page])
    add(ctx.params.get("sources"))
    return out


@tool(
    name="research.summarise",
    capability="research.fetch_page",
    agent="writing",
    device="cloud",
    description="Write a cited summary of the research gathered so far",
    risk="LOW",
    timeout=150,
)
async def research_summarise(ctx: ToolContext, question: str = "", request: str = "",
                             citations: bool = True, max_words: int = 500) -> Dict[str, Any]:
    q = question or request or ctx.user_text
    sources = _collect_prior_sources(ctx)

    # browser-produced content counts too
    for value in (ctx.outputs or {}).values():
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict) and inner.get("text") and inner.get("url"):
                sources.append({"url": inner["url"], "title": inner.get("title", ""),
                                "text": inner["text"]})
    if not sources:
        url = ctx.params.get("url")
        if url:
            fetched = await fetch_page(url)
            sources = [fetched.to_dict(with_text=True)]
    if not sources:
        return {"ok": False, "error": "no material to summarise"}

    from backend.app.models.router import router

    corpus = "\n\n".join(
        f"[{i + 1}] {s.get('title', '')} — {s.get('url', '')}\n"
        f"{(s.get('text') or s.get('snippet') or '')[:5000]}"
        for i, s in enumerate(sources[:8])
    )[:28000]

    style = ctx.meta.get("voice_mode") or "standard"
    prompt = f"""You are SAM's Writing Brain. Write a clear, well-structured answer.

QUESTION:
{q}

SOURCES (numbered):
{corpus}

RULES:
- Use only the sources above. Never invent facts.
- {'Cite inline as [1], [2] after each factual claim.' if citations else 'No inline citations.'}
- At most {max_words} words. Use Markdown with short sections and bullets where helpful.
- Say explicitly when sources disagree or when something could not be verified.
- If a fact looks time-sensitive, mention the date it came from.
"""
    res = await router.ask(prompt, role="primary", max_tokens=1600, temperature=0.25)
    summary = res.text.strip()

    used = sources[:8]
    if citations:
        summary += "\n\n**Sources**\n" + "\n".join(
            f"{i + 1}. [{s.get('title') or urlparse(s.get('url', '')).netloc}]({s.get('url')})"
            for i, s in enumerate(used) if s.get("url")
        )
    return {
        "ok": True, "question": q, "summary": summary, "model": res.model,
        "provider": res.provider, "source_count": len(used),
        "sources": [{"url": s.get("url"), "title": s.get("title"), "trust": s.get("trust")}
                    for s in used],
        "citations": citations, "word_count": len(summary.split()),
    }


@tool(
    name="research.deep",
    capability="research.web_search",
    agent="research",
    device="cloud",
    description="Full research pipeline: search -> read -> compare -> summarise with citations",
    risk="LOW",
    timeout=300,
)
async def research_deep(ctx: ToolContext, question: str = "", request: str = "",
                        depth: str = "standard", max_sources: int = 8) -> Dict[str, Any]:
    q = question or request or ctx.user_text
    if not q:
        return {"ok": False, "error": "no research question"}
    limits = {"quick": 4, "standard": 8, "deep": 14}.get(depth, 8)
    limits = min(limits, int(max_sources))

    t0 = time.time()
    searched = await research_search(ctx, query=q, limit=limits + 4)
    if not searched.get("ok"):
        return searched
    sources = searched["sources"][:limits]

    read = await research_read(ctx, urls=[s["url"] for s in sources[: limits]],
                               max_chars=25_000)
    pages = read.get("pages") or []

    sub_ctx = ToolContext(
        task_id=ctx.task_id, step_id=ctx.step_id, agent="research", device="cloud",
        user_text=q, params={}, outputs={"read": {"value": {"pages": pages, "sources": sources}}},
        language=ctx.language, meta=ctx.meta,
    )
    compared = await research_compare(sub_ctx, claim=q)
    summarised = await research_summarise(sub_ctx, question=q, citations=True,
                                          max_words=400 if depth == "quick" else 700)

    return {
        "ok": bool(summarised.get("ok")),
        "question": q, "depth": depth,
        "summary": summarised.get("summary", ""),
        "verified": compared.get("verified", []),
        "conflicting": compared.get("conflicting", []),
        "uncertain": compared.get("uncertain", []),
        "outdated": compared.get("outdated", []),
        "sources": summarised.get("sources", sources),
        "pages_read": read.get("fetched", 0),
        "duration_ms": int((time.time() - t0) * 1000),
    }


@tool(
    name="research.fetch",
    capability="research.fetch_page",
    agent="research",
    device="cloud",
    description="Fetch one URL and return its readable text",
    risk="LOW",
    timeout=60,
)
async def research_fetch(ctx: ToolContext, url: str = "", max_chars: int = 40_000) -> Dict[str, Any]:
    if not url:
        return {"ok": False, "error": "no URL given"}
    src = await fetch_page(url, max_chars=int(max_chars))
    return {"ok": src.fetched, **src.to_dict(with_text=True)}


@tool(
    name="core.translate",
    capability="ai.chat",
    agent="communication",
    device="cloud",
    description="Translate text between languages, handling code-mixed speech",
    risk="LOW",
    timeout=60,
)
async def translate_tool(ctx: ToolContext, text: str = "", target: str = "",
                         request: str = "") -> Dict[str, Any]:
    from backend.app.models.router import router
    from backend.app.providers.heuristic import detect_language

    payload = text or request or ctx.user_text
    if not payload:
        return {"ok": False, "error": "nothing to translate"}
    target = _detect_target_language(target or payload) or "en"
    source = detect_language(payload)
    body = re.sub(rf"\b(translate|translation)\b.*?\b(in|to|into)\s+\w+\s*", "", payload,
                  flags=re.I).strip() or payload
    result = await router.translate(body, target)
    return {"ok": True, "source": source, "target": target, "input": body,
            "translation": result, "model_used": "router"}


def _detect_target_language(text: str) -> Optional[str]:
    names = {
        "english": "en", "hindi": "hi", "kannada": "kn", "tamil": "ta", "telugu": "te",
        "malayalam": "ml", "marathi": "mr", "bengali": "bn", "gujarati": "gu",
        "punjabi": "pa", "urdu": "ur", "arabic": "ar", "french": "fr", "german": "de",
        "spanish": "es", "portuguese": "pt", "japanese": "ja", "korean": "ko",
        "chinese": "zh", "mandarin": "zh", "russian": "ru", "italian": "it",
    }
    low = text.lower()
    for name, code in names.items():
        if re.search(rf"\b(in|to|into)\s+{name}\b", low) or re.search(rf"\b{name}\b", low):
            return code
    return None
