"""
backend.app.tools.terminal_tools
================================

Controlled terminal access::

    SAM -> Command Planner -> Security/Risk Engine -> Terminal -> Output -> Verification

Supported shells
----------------
Windows      PowerShell 7 (``pwsh``) -> Windows PowerShell -> ``cmd.exe``
macOS/Linux  ``$SHELL`` -> ``bash`` -> ``sh``

Supported toolchains (per the spec)
-----------------------------------
PowerShell · cmd · Python · Git · Node.js · npm/pnpm/yarn · pip/uv · cargo ·
go · docker · kubectl · package managers · build tools

Safety
------
* Every command is scored by the Risk Engine before it runs.
* A block-list stops the worst offenders even in permissive mode.
* Output is truncated, and the working directory is constrained to an
  allowed root unless the user grants more.
* ``pc.terminal.run`` is **not granted by default** — the user enables it in
  the Security Center.
"""

from __future__ import annotations

import asyncio
import os
import platform
import re
import shlex
import shutil
import time
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.security.risk_engine import risk_engine
from backend.app.tools.registry import ToolContext, registry, tool
from backend.app.tools.system_tools import IS_LINUX, IS_MAC, IS_WINDOWS, _run

log = get_logger("tools.terminal")

MAX_OUTPUT_CHARS = 200_000

# ---------------------------------------------------------------------------
# Absolute block-list: never executed, even with the permission granted.
# The user must run these themselves if they really want to.
# ---------------------------------------------------------------------------
BLOCKED_PATTERNS: List[Tuple[str, str]] = [
    (r"\bmkfs(\.\w+)?\b", "formats a filesystem"),
    (r"\bdd\b.*\bof=/dev/(sd|nvme|hd|disk)", "raw-writes to a disk device"),
    (r">\s*/dev/(sd|nvme|hd|disk)", "raw-writes to a disk device"),
    (r"\bformat\s+[a-zA-Z]:\s*/q", "formats a drive"),
    (r"\brm\s+-[rf]{1,2}\s+/(?:\s|$)", "recursive delete of the filesystem root"),
    (r"\brm\s+-[rf]{1,2}\s+~(?:/|\s|$)", "recursive delete of the home directory"),
    (r"\brd\s+/s\s+/q\s+[a-zA-Z]:\\(?:\s|$)", "recursive delete of a drive root"),
    (r"\bdel\s+/[fsq]+\s+[a-zA-Z]:\\(?:\s|$)", "recursive delete of a drive root"),
    (r":\(\)\s*\{.*\};\s*:", "fork bomb"),
    (r"\bshutdown\b.*\b(/f|now|-h\s+now)\b.*\b/t\s*0\b", "immediate forced shutdown"),
    (r"\bcurl\b[^|]*\|\s*(sudo\s+)?(ba)?sh\b", "pipes a remote script straight into a shell"),
    (r"\bwget\b[^|]*\|\s*(sudo\s+)?(ba)?sh\b", "pipes a remote script straight into a shell"),
    (r"\biex\s*\(\s*\(?\s*new-object\s+net\.webclient", "downloads and executes remote code"),
    (r"\bInvoke-Expression\b.*\bDownloadString\b", "downloads and executes remote code"),
    (r"\bchmod\s+-R\s+777\s+/", "opens the whole filesystem to everyone"),
    (r"\bicacls\s+[a-zA-Z]:\\\s*/grant\s+Everyone", "grants Everyone access to a drive"),
    (r"\breg\s+delete\s+HKLM\\(SYSTEM|SOFTWARE)\\?\s*/f\s*$", "deletes a root registry hive key"),
    (r"\bvssadmin\s+delete\s+shadows\s*/all", "destroys all volume shadow copies"),
    (r"\bbcdedit\b.*\{/default\}.*delete", "damages the boot configuration"),
    (r"\bgit\s+push\b.*--force.*\b(main|master)\b.*--delete", "force-deletes the main branch"),
    (r"\bnpm\s+publish\b", "publishes a package publicly"),
    (r"\btwilio\b|\bsendgrid\b.*\bsend\b", "sends paid communication"),
]


def is_blocked(command: str) -> Optional[str]:
    for pattern, reason in BLOCKED_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            return reason
    return None


# ---------------------------------------------------------------------------
# Shell detection
# ---------------------------------------------------------------------------
def default_shell() -> Tuple[List[str], str]:
    """Return ``(argv_prefix, label)`` for the best available shell."""
    if IS_WINDOWS:
        for exe, label in (("pwsh", "pwsh"), ("powershell", "powershell")):
            path = shutil.which(exe)
            if path:
                return [path, "-NoProfile", "-NonInteractive", "-Command"], label
        return ["cmd.exe", "/c"], "cmd"
    shell = os.environ.get("SHELL") or shutil.which("bash") or shutil.which("sh") or "/bin/sh"
    return [shell, "-c"], os.path.basename(shell)


def _safe_cwd(cwd: Optional[str]) -> Tuple[str, Optional[str]]:
    """Constrain the working directory to an allowed root."""
    from pathlib import Path

    base = Path(cwd).expanduser() if cwd else Path.cwd()
    try:
        base = base.resolve()
    except Exception:
        base = Path.cwd()
    if not base.is_dir():
        return str(Path.cwd()), f"{base} is not a directory — using {Path.cwd()}"
    roots = settings.allowed_roots or []
    if settings.files_enabled and roots:
        if any(base == r or r in base.parents or base in r.parents for r in roots):
            return str(base), None
        # allow the project directory too, so SAM can build things
        if str(settings.sam_data_dir.parent) in str(base):
            return str(base), None
        return str(base), (
            f"warning: {base} is outside the configured FILES_ALLOWED_ROOTS "
            f"({', '.join(str(r) for r in roots)})"
        )
    return str(base), None


# ===========================================================================
# TOOLS
# ===========================================================================
@tool(
    name="pc.terminal",
    capability="pc.terminal.run",
    agent="pc",
    device="pc",
    description="Run a shell command (PowerShell / cmd / bash) and return its output",
    schema={"command": {"type": "string", "required": True}, "cwd": {"type": "string"},
            "timeout": {"type": "integer"}},
    risk="HIGH",
    confirm=True,
    timeout=600,
)
async def terminal_run(ctx: ToolContext, command: str = "", cwd: str = "",
                       timeout: int = 120, env: Optional[Dict[str, str]] = None,
                       allow_blocked: bool = False) -> Dict[str, Any]:
    command = (command or "").strip()
    if not command:
        return {"ok": False, "error": "no command was given"}
    if not settings.pc_terminal_enabled:
        return {"ok": False, "error": "terminal access is disabled (PC_TERMINAL_ENABLED=false)"}

    # ---- hard block-list -------------------------------------------------
    blocked_reason = is_blocked(command)
    if blocked_reason and not allow_blocked:
        return {
            "ok": False,
            "blocked": True,
            "error": f"SAM will not run this command: it {blocked_reason}.",
            "command": command,
            "hint": "run it yourself in your own terminal if you are certain",
        }

    # ---- risk pre-flight (the guard also scores this, but we surface it) ---
    assessment = risk_engine.assess(capability="pc.terminal.run", action="terminal",
                                    target=command, params={"cwd": cwd})

    workdir, warn = _safe_cwd(cwd)
    shell_argv, shell_label = default_shell()
    full = shell_argv + [command]

    started = time.time()
    try:
        proc = await asyncio.create_subprocess_exec(
            *full,
            cwd=workdir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env={**os.environ, **(env or {})},
        )
    except FileNotFoundError as exc:
        return {"ok": False, "error": f"shell not found: {exc}", "shell": shell_label}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "shell": shell_label}

    try:
        out_b, err_b = await asyncio.wait_for(proc.communicate(), timeout=min(timeout, 1800))
    except asyncio.TimeoutError:
        try:
            proc.kill()
            await proc.wait()
        except Exception:
            pass
        return {"ok": False, "error": f"command timed out after {timeout}s", "command": command,
                "shell": shell_label, "cwd": workdir, "timed_out": True}

    stdout = (out_b or b"").decode(errors="replace")
    stderr = (err_b or b"").decode(errors="replace")
    truncated = False
    if len(stdout) > MAX_OUTPUT_CHARS:
        stdout = stdout[:MAX_OUTPUT_CHARS] + f"\n... [truncated {len(stdout) - MAX_OUTPUT_CHARS} chars]"
        truncated = True
    if len(stderr) > MAX_OUTPUT_CHARS // 2:
        stderr = stderr[: MAX_OUTPUT_CHARS // 2] + "\n... [truncated]"
        truncated = True

    result = {
        "ok": proc.returncode == 0,
        "returncode": proc.returncode,
        "command": command,
        "shell": shell_label,
        "cwd": workdir,
        "stdout": stdout.strip(),
        "stderr": stderr.strip(),
        "duration_ms": int((time.time() - started) * 1000),
        "risk": assessment.level.value,
        "risk_score": assessment.score,
        "truncated": truncated,
    }
    if warn:
        result["warning"] = warn
    if proc.returncode != 0:
        result["error"] = (stderr.strip() or f"exit code {proc.returncode}")[:600]
    return result


@tool(
    name="pc.terminal.script",
    capability="pc.terminal.run",
    agent="pc",
    device="pc",
    description="Write a script file and execute it (multi-line PowerShell/bash/Python)",
    risk="HIGH",
    confirm=True,
    timeout=600,
)
async def terminal_script(ctx: ToolContext, script: str = "", language: str = "auto",
                          cwd: str = "", timeout: int = 300) -> Dict[str, Any]:
    from pathlib import Path

    script = script or ""
    if not script.strip():
        return {"ok": False, "error": "empty script"}

    lang = (language or "auto").lower()
    if lang == "auto":
        head = script.strip().splitlines()[0].lower()
        if head.startswith("#!"):
            lang = "python" if "python" in head else "bash"
        elif re.search(r"\b(Write-Host|Get-ChildItem|\$env:|Add-Type)\b", script):
            lang = "powershell"
        elif re.search(r"^\s*(def |import |print\(|from )", script, re.M):
            lang = "python"
        else:
            lang = "bash" if not IS_WINDOWS else "powershell"

    tmp_dir = settings.sam_data_dir / "cache" / "scripts"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    stamp = int(time.time() * 1000)

    if lang == "python":
        path = tmp_dir / f"sam_{stamp}.py"
        path.write_text(script, encoding="utf-8")
        exe = shutil.which("python3") or shutil.which("python") or "python"
        cmd = f"{shlex.quote(exe) if not IS_WINDOWS else exe} {str(path)}"
    elif lang in ("powershell", "pwsh"):
        path = tmp_dir / f"sam_{stamp}.ps1"
        path.write_text(script, encoding="utf-8")
        exe = shutil.which("pwsh") or shutil.which("powershell")
        if not exe:
            return {"ok": False, "error": "PowerShell is not installed"}
        cmd = f'"{exe}" -NoProfile -ExecutionPolicy Bypass -File "{path}"'
    elif lang in ("node", "javascript", "js"):
        path = tmp_dir / f"sam_{stamp}.js"
        path.write_text(script, encoding="utf-8")
        exe = shutil.which("node")
        if not exe:
            return {"ok": False, "error": "node is not installed"}
        cmd = f'"{exe}" "{path}"'
    else:
        path = tmp_dir / f"sam_{stamp}.sh"
        path.write_text("#!/usr/bin/env bash\nset -euo pipefail\n" + script, encoding="utf-8")
        path.chmod(0o755)
        cmd = f'bash "{path}"'

    blocked = is_blocked(script)
    if blocked:
        return {"ok": False, "blocked": True, "error": f"script refused: it {blocked}"}

    res = await terminal_run(ctx, command=cmd, cwd=cwd, timeout=timeout)
    res["language"] = lang
    res["script_path"] = str(path)
    return res


@tool(
    name="pc.dev.detect",
    capability="pc.dev.tools",
    agent="coding",
    device="pc",
    description="Detect which development toolchains are installed and their versions",
    risk="LOW",
    timeout=90,
)
async def detect_toolchains(ctx: ToolContext) -> Dict[str, Any]:
    checks: List[Tuple[str, List[str], str]] = [
        ("python", ["python", "--version"], r"Python ([\d.]+)"),
        ("pip", ["pip", "--version"], r"pip ([\d.]+)"),
        ("node", ["node", "--version"], r"v?([\d.]+)"),
        ("npm", ["npm", "--version"], r"([\d.]+)"),
        ("yarn", ["yarn", "--version"], r"([\d.]+)"),
        ("pnpm", ["pnpm", "--version"], r"([\d.]+)"),
        ("git", ["git", "--version"], r"git version ([\d.]+)"),
        ("java", ["java", "-version"], r'version "([\d._]+)"'),
        ("javac", ["javac", "-version"], r"javac ([\d._]+)"),
        ("gradle", ["gradle", "--version"], r"Gradle ([\d.]+)"),
        ("dotnet", ["dotnet", "--version"], r"([\d.]+)"),
        ("go", ["go", "version"], r"go([\d.]+)"),
        ("rustc", ["rustc", "--version"], r"rustc ([\d.]+)"),
        ("cargo", ["cargo", "--version"], r"cargo ([\d.]+)"),
        ("docker", ["docker", "--version"], r"version ([\d.,\s\w-]+)"),
        ("kubectl", ["kubectl", "version", "--client", "--short"], r"v?([\d.]+)"),
        ("adb", ["adb", "--version"], r"Android Debug Bridge version ([\d.]+)"),
        ("code", ["code", "--version"], r"([\d.]+)"),
        ("ollama", ["ollama", "--version"], r"version ([\d.]+)"),
        ("tesseract", ["tesseract", "--version"], r"v?([\d.]+)"),
        ("ffmpeg", ["ffmpeg", "-version"], r"version ([\d.]+)"),
        ("cmake", ["cmake", "--version"], r"version ([\d.]+)"),
        ("gcc", ["gcc", "--version"], r"([\d.]+)"),
    ]
    found: Dict[str, Any] = {}
    missing: List[str] = []
    for name, argv, pattern in checks:
        exe = shutil.which(argv[0])
        if not exe:
            missing.append(name)
            continue
        try:
            proc = await asyncio.create_subprocess_exec(
                *([exe] + argv[1:]), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT
            )
            out_b, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
            out = out_b.decode(errors="replace").strip().splitlines()
            head = out[0] if out else ""
            m = re.search(pattern, head)
            found[name] = {"path": exe, "version": (m.group(1) if m else head)[:60]}
        except Exception as exc:
            found[name] = {"path": exe, "version": None, "error": str(exc)[:120]}

    # package managers / extras
    if IS_WINDOWS:
        for name in ("winget", "choco", "scoop"):
            if shutil.which(name):
                found[name] = {"path": shutil.which(name), "version": "installed"}
    return {"ok": True, "installed": found, "missing": missing,
            "platform": platform.system(), "shell": default_shell()[1]}


@tool(
    name="coding.git",
    capability="coding.git",
    agent="coding",
    device="pc",
    description="Run a git command inside a repository",
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def git(ctx: ToolContext, args: str = "status", cwd: str = "") -> Dict[str, Any]:
    args = (args or "").strip()
    if not args:
        return {"ok": False, "error": "no git arguments"}
    if not shutil.which("git"):
        return {"ok": False, "error": "git is not installed"}

    dangerous = re.search(r"(push\s+.*--force|reset\s+--hard|clean\s+-[fdx]+|rebase\s+.*--onto|"
                          r"branch\s+-D|filter-branch|push\s+.*--delete)", args)
    if dangerous:
        assessment = risk_engine.assess(capability="coding.git", action="git", target=args)
        if assessment.level.value in ("HIGH", "CRITICAL"):
            return {"ok": False, "blocked": True,
                    "error": f"git '{args}' is destructive — {assessment.reasons[0] if assessment.reasons else 'high risk'}",
                    "risk": assessment.level.value}

    try:
        argv = ["git"] + shlex.split(args)
    except ValueError as exc:
        return {"ok": False, "error": f"could not parse git arguments: {exc}"}

    workdir, warn = _safe_cwd(cwd)
    r = await _run(argv, timeout=180)
    r["cwd"] = workdir
    if warn:
        r["warning"] = warn
    r["args"] = args
    return r


@tool(
    name="coding.execute",
    capability="coding.execute",
    agent="coding",
    device="pc",
    description="Execute a code snippet in python / node / bash and return the output",
    risk="HIGH",
    confirm=True,
    timeout=300,
)
async def execute_code(ctx: ToolContext, code: str = "", language: str = "python",
                       cwd: str = "") -> Dict[str, Any]:
    return await terminal_script(ctx, script=code, language=language, cwd=cwd, timeout=300)
