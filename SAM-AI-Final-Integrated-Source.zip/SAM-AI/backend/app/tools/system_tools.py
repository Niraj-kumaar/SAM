"""
backend.app.tools.system_tools
==============================

Windows/Linux/macOS system layer: telemetry, processes, services, power,
audio, brightness, clipboard and notifications.

Every tool goes through :func:`backend.app.core.guard.guard` (via the
registry), so permission + risk + confirmation + audit are always enforced.

Windows-specific calls are made through ``ctypes``/``subprocess`` so SAM has no
hard dependency on ``pywin32`` — but if ``pywin32``/``pywinauto`` are installed
they are used for richer UI Automation (see ``pc/ui_automation.py``).
"""

from __future__ import annotations

import asyncio
import os
import platform
import shutil
import socket
import subprocess
import time
from typing import Any, Dict, List, Optional

import psutil

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.system")

IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"
IS_LINUX = platform.system() == "Linux"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
async def _run(cmd: List[str] | str, timeout: int = 30, shell: bool = False) -> Dict[str, Any]:
    """Run a subprocess without blocking the event loop."""
    try:
        if shell:
            proc = await asyncio.create_subprocess_shell(
                str(cmd), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
        else:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return {
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "stdout": out.decode(errors="replace").strip(),
            "stderr": err.decode(errors="replace").strip(),
        }
    except asyncio.TimeoutError:
        return {"ok": False, "error": f"timeout after {timeout}s", "stdout": "", "stderr": ""}
    except FileNotFoundError as exc:
        return {"ok": False, "error": f"command not found: {exc}", "stdout": "", "stderr": ""}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "stdout": "", "stderr": ""}


def _battery() -> Optional[Dict[str, Any]]:
    try:
        b = psutil.sensors_battery()
    except Exception:
        b = None
    if b is None:
        return None
    return {
        "percent": round(b.percent, 1),
        "power_plugged": bool(b.power_plugged),
        "seconds_left": None if b.secsleft in (psutil.POWER_TIME_UNLIMITED, psutil.POWER_TIME_UNKNOWN)
        else int(b.secsleft),
        "source": "AC" if b.power_plugged else "Battery",
    }


def _disks() -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    try:
        for part in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(part.mountpoint)
                out.append({
                    "device": part.device, "mountpoint": part.mountpoint,
                    "fstype": part.fstype,
                    "total_gb": round(usage.total / 1024**3, 1),
                    "used_gb": round(usage.used / 1024**3, 1),
                    "free_gb": round(usage.free / 1024**3, 1),
                    "percent": round(usage.percent, 1),
                })
            except (PermissionError, OSError):
                continue
    except Exception as exc:
        log.debug("disk scan failed: %s", exc)
    return out


def _network() -> Dict[str, Any]:
    info: Dict[str, Any] = {"hostname": socket.gethostname(), "interfaces": []}
    try:
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        counters = psutil.net_io_counters()
        for name, alist in addrs.items():
            entry: Dict[str, Any] = {"name": name, "addresses": []}
            st = stats.get(name)
            if st:
                entry["up"] = bool(st.isup)
                entry["speed_mbps"] = st.speed
            for a in alist:
                if a.family.name in ("AF_INET", "AF_INET6"):
                    entry["addresses"].append({"family": a.family.name, "address": a.address})
            info["interfaces"].append(entry)
        if counters:
            info["bytes_sent"] = counters.bytes_sent
            info["bytes_recv"] = counters.bytes_recv
        # public-ish check without leaving the machine when privacy mode is on
        info["internet"] = None
    except Exception as exc:
        log.debug("network scan failed: %s", exc)
    return info


# ===========================================================================
# TELEMETRY
# ===========================================================================
@tool(
    name="pc.system_info",
    capability="pc.system.info",
    agent="pc",
    device="pc",
    description="Read CPU, RAM, disk, battery, network, display and OS state",
    risk="LOW",
    confirm=False,
    timeout=30,
)
async def system_info(ctx: ToolContext, section: str = "all") -> Dict[str, Any]:
    """Collect machine telemetry. ``section`` narrows the payload."""
    cpu_freq = None
    try:
        f = psutil.cpu_freq()
        cpu_freq = {"current_mhz": round(f.current, 0), "min_mhz": f.min, "max_mhz": f.max} if f else None
    except Exception:
        pass

    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    boot = psutil.boot_time()

    data: Dict[str, Any] = {
        "os": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor() or platform.machine(),
            "node": platform.node(),
            "python": platform.python_version(),
        },
        "cpu": {
            "percent": psutil.cpu_percent(interval=0.4),
            "per_core": psutil.cpu_percent(interval=0.0, percpu=True),
            "cores_logical": psutil.cpu_count(logical=True),
            "cores_physical": psutil.cpu_count(logical=False),
            "load_avg": list(os.getloadavg()) if hasattr(os, "getloadavg") else None,
            "freq": cpu_freq,
        },
        "ram": {
            "percent": vm.percent,
            "total_gb": round(vm.total / 1024**3, 2),
            "used_gb": round(vm.used / 1024**3, 2),
            "available_gb": round(vm.available / 1024**3, 2),
            "swap_percent": swap.percent,
        },
        "uptime_seconds": int(time.time() - boot),
        "boot_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(boot)),
        "processes": len(psutil.pids()),
    }

    if section in ("all", "disk", "storage"):
        data["disks"] = _disks()
    if section in ("all", "battery", "power"):
        data["battery"] = _battery()
    if section in ("all", "network"):
        data["network"] = _network()
    if section in ("all", "display"):
        data["displays"] = await _display_info()
    if section in ("all", "audio"):
        data["audio"] = await _audio_devices()
    if section in ("all", "bluetooth"):
        data["bluetooth"] = await _bluetooth_status()

    return data


async def _display_info() -> List[Dict[str, Any]]:
    if IS_WINDOWS:
        try:
            import ctypes

            user32 = ctypes.windll.user32  # type: ignore[attr-defined]
            shcore = ctypes.windll.shcore  # type: ignore[attr-defined]
            w, h = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
            monitors = user32.GetSystemMetrics(80)
            dpi = 0
            try:
                shcore.GetScaleFactorForDevice(0, ctypes.byref(ctypes.c_uint(dpi)))
            except Exception:
                pass
            return [{"index": i, "width": w if i == 0 else None, "height": h if i == 0 else None,
                     "primary": i == 0, "count": monitors} for i in range(max(1, monitors))]
        except Exception as exc:
            return [{"error": str(exc)}]
    if IS_MAC:
        r = await _run(["system_profiler", "SPDisplaysDataType", "-json"])
        if r.get("ok"):
            import json as _json
            try:
                d = _json.loads(r["stdout"])
                out = []
                for gpu in d.get("SPDisplaysDataType", []):
                    for disp in gpu.get("spdisplays_ndrvs", []):
                        out.append({"name": disp.get("_name"), "resolution": disp.get("_spdisplays_resolution"),
                                    "main": disp.get("spdisplays_main") == "spdisplays_yes"})
                return out
            except Exception:
                pass
    try:
        r = await _run("xrandr --query", shell=True)
        if r.get("ok"):
            out = []
            for line in r["stdout"].splitlines():
                if " connected" in line:
                    parts = line.split()
                    out.append({"name": parts[0], "primary": "primary" in line,
                                "resolution": next((p for p in parts if "x" in p), "")})
            return out
    except Exception:
        pass
    return [{"note": "display enumeration is not supported on this platform"}]


async def _audio_devices() -> Dict[str, Any]:
    if IS_WINDOWS:
        r = await _run(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_SoundDevice | Select-Object Name,Status,StatusInfo | ConvertTo-Json"],
            timeout=25,
        )
        if r.get("ok") and r["stdout"]:
            import json as _json
            try:
                d = _json.loads(r["stdout"])
                return {"devices": d if isinstance(d, list) else [d]}
            except Exception:
                pass
    try:
        import sounddevice as sd  # type: ignore

        devs = sd.query_devices()
        return {"devices": [{"index": i, "name": d["name"], "in": d["max_input_channels"],
                             "out": d["max_output_channels"]} for i, d in enumerate(devs)]}
    except Exception:
        return {"devices": [], "note": "no audio enumeration backend available"}


async def _bluetooth_status() -> Dict[str, Any]:
    if IS_WINDOWS:
        r = await _run(
            ["powershell", "-NoProfile", "-Command",
             "Get-PnpDevice -Class Bluetooth -ErrorAction SilentlyContinue | "
             "Select-Object FriendlyName,Status | ConvertTo-Json"], timeout=25)
        if r.get("ok") and r["stdout"]:
            import json as _json
            try:
                d = _json.loads(r["stdout"])
                items = d if isinstance(d, list) else [d]
                return {"enabled": any(i.get("Status") == "OK" for i in items), "devices": items}
            except Exception:
                pass
    r = await _run(["bluetoothctl", "--timeout", "2", "show"], timeout=10)
    if r.get("ok"):
        return {"enabled": "Powered: yes" in r["stdout"], "raw": r["stdout"][:800]}
    return {"enabled": None, "note": "bluetooth status unavailable on this platform"}


# ===========================================================================
# PROCESSES
# ===========================================================================
@tool(
    name="pc.processes.list",
    capability="pc.system.processes",
    agent="pc",
    device="pc",
    description="List running processes with CPU and memory usage",
    risk="LOW",
    timeout=30,
)
async def list_processes(ctx: ToolContext, limit: int = 40, sort_by: str = "memory",
                         search: str = "") -> Dict[str, Any]:
    key = {"memory": "memory_percent", "cpu": "cpu_percent", "name": "name"}.get(sort_by, "memory_percent")
    procs: List[Dict[str, Any]] = []
    for p in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_percent",
                                  "status", "create_time", "exe"]):
        try:
            info = p.info
            name = (info.get("name") or "").lower()
            if search and search.lower() not in name and search.lower() not in (info.get("exe") or "").lower():
                continue
            procs.append({
                "pid": info["pid"], "name": info.get("name"), "user": info.get("username"),
                "cpu_percent": round(info.get("cpu_percent") or 0, 1),
                "memory_percent": round(info.get("memory_percent") or 0, 2),
                "status": info.get("status"),
                "started": time.strftime("%H:%M:%S", time.localtime(info.get("create_time") or 0)),
                "exe": info.get("exe"),
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    procs.sort(key=lambda d: d.get(key) or 0, reverse=(key != "name"))
    return {"total": len(procs), "sort_by": sort_by, "processes": procs[:limit]}


@tool(
    name="pc.processes.kill",
    capability="pc.system.processes",
    agent="pc",
    device="pc",
    description="Terminate a running process by PID or name",
    risk="HIGH",
    confirm=True,
    timeout=30,
)
async def kill_process(ctx: ToolContext, pid: Optional[int] = None, name: str = "") -> Dict[str, Any]:
    targets: List[psutil.Process] = []
    if pid:
        try:
            targets = [psutil.Process(pid)]
        except psutil.NoSuchProcess:
            return {"ok": False, "error": f"no process with pid {pid}"}
    elif name:
        for p in psutil.process_iter(["name"]):
            try:
                if (p.info.get("name") or "").lower() == name.lower():
                    targets.append(p)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    if not targets:
        return {"ok": False, "error": f"no process matched {name or pid}"}

    killed, failed = [], []
    for p in targets:
        try:
            pname = p.name()
            p.terminate()
            try:
                p.wait(timeout=3)
            except psutil.TimeoutExpired:
                p.kill()
            killed.append({"pid": p.pid, "name": pname})
        except Exception as exc:
            failed.append({"pid": p.pid, "error": str(exc)})
    return {"ok": not failed, "killed": killed, "failed": failed}


@tool(
    name="pc.services.list",
    capability="pc.system.services",
    agent="pc",
    device="pc",
    description="List system services (Windows services / systemd units)",
    risk="LOW",
    timeout=45,
    platform=None,
)
async def list_services(ctx: ToolContext, search: str = "", limit: int = 60) -> Dict[str, Any]:
    if IS_WINDOWS:
        r = await _run(
            ["powershell", "-NoProfile", "-Command",
             "Get-Service | Select-Object Name,DisplayName,Status | ConvertTo-Json -Compress"], timeout=45)
    else:
        r = await _run("systemctl list-units --type=service --all --no-legend --plain", shell=True, timeout=45)

    services: List[Dict[str, Any]] = []
    if IS_WINDOWS and r.get("ok") and r["stdout"]:
        import json as _json
        try:
            data = _json.loads(r["stdout"])
            for s in data if isinstance(data, list) else [data]:
                services.append({"name": s.get("Name"), "display_name": s.get("DisplayName"),
                                 "status": s.get("Status")})
        except Exception:
            pass
    elif r.get("ok"):
        for line in r["stdout"].splitlines():
            parts = line.split()
            if len(parts) >= 4:
                services.append({"name": parts[0], "status": parts[3], "sub": parts[2] if len(parts) > 2 else ""})

    if search:
        services = [s for s in services if search.lower() in json_dumps(s).lower()]
    return {"total": len(services), "services": services[:limit], "platform": platform.system()}


def json_dumps(obj: Any) -> str:
    import json
    return json.dumps(obj, default=str)


# ===========================================================================
# POWER CONTROL  (gated by PC_POWER_CONTROL_ENABLED + explicit confirmation)
# ===========================================================================
def _power_command(action: str) -> Optional[List[str] | str]:
    if IS_WINDOWS:
        return {
            "lock": "rundll32.exe user32.dll,LockWorkStation",
            "sleep": "rundll32.exe powrprof.dll,SetSuspendState 0,1,0",
            "restart": "shutdown /r /t 5 /c \"SAM: restarting in 5 seconds\"",
            "shutdown": "shutdown /s /t 5 /c \"SAM: shutting down in 5 seconds\"",
            "signout": "shutdown /l",
        }.get(action)
    if IS_MAC:
        return {
            "lock": ["/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession", "-suspend"],
            "sleep": ["pmset", "sleepnow"],
            "restart": ["osascript", "-e", 'tell app "System Events" to restart'],
            "shutdown": ["osascript", "-e", 'tell app "System Events" to shut down'],
            "signout": ["osascript", "-e", 'tell app "System Events" to log out'],
        }.get(action)
    return {
        "lock": "loginctl lock-session || xdg-screensaver lock || xset dpms force off",
        "sleep": "systemctl suspend",
        "restart": "shutdown -r +1 'SAM: restarting'",
        "shutdown": "shutdown -h +1 'SAM: shutting down'",
        "signout": "loginctl terminate-user $USER",
    }.get(action)


def _make_power_tool(action: str, risk: str, description: str):
    async def _impl(ctx: ToolContext, delay_seconds: int = 5) -> Dict[str, Any]:
        cmd = _power_command(action)
        if cmd is None:
            return {"ok": False, "error": f"power action '{action}' is unsupported on {platform.system()}"}
        if isinstance(cmd, str):
            if action in ("restart", "shutdown") and IS_WINDOWS:
                cmd = cmd.replace("/t 5", f"/t {max(0, int(delay_seconds))}")
            res = await _run(cmd, shell=True, timeout=30)
        else:
            res = await _run(cmd, timeout=30)
        res["action"] = action
        res["command"] = cmd
        return res

    registry.register(
        __import__("backend.app.tools.registry", fromlist=["Tool"]).Tool(
            name=f"pc.power_{action}",
            fn=_impl,
            capability=f"pc.power.{action}",
            agent="pc",
            device="pc",
            description=description,
            schema={"delay_seconds": {"type": "integer", "default": 5}},
            risk=risk,
            confirm=True,
            timeout=60,
        )
    )
    return _impl


power_lock = _make_power_tool("lock", "MEDIUM", "Lock the workstation")
power_sleep = _make_power_tool("sleep", "MEDIUM", "Put the machine to sleep")
power_restart = _make_power_tool("restart", "HIGH", "Restart the machine")
power_shutdown = _make_power_tool("shutdown", "HIGH", "Shut the machine down")
power_signout = _make_power_tool("signout", "HIGH", "Sign the current user out")


# ===========================================================================
# AUDIO / VOLUME
# ===========================================================================
# Core Audio COM wrapper compiled on the fly so SAM needs no pywin32 install.
_WIN_AUDIO_TYPEDEF = r"""
using System;using System.Runtime.InteropServices;
[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
  int f();int g();int h();int i();
  int SetMasterVolumeLevelScalar(float fLevel,System.Guid g);
  int j();int GetMasterVolumeLevelScalar(out float fLevel);
  int k();int SetMute([MarshalAs(UnmanagedType.Bool)]bool bMute,System.Guid g);
  int GetMute(out bool bMute);
}
[Guid("D666063F-1587-4E43-81F1-B948E807363F"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice { int Activate(ref System.Guid id,int ctx,System.IntPtr p,[MarshalAs(UnmanagedType.IUnknown)]out object o); }
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator { int f();int GetDefaultAudioEndpoint(int dataFlow,int role,out IMMDevice endpoint); }
[ComImport,Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]class MMDeviceEnumeratorComObject {}
public class Audio {
  static IAudioEndpointVolume Ep(){
    var e=(IMMDeviceEnumerator)(new MMDeviceEnumeratorComObject());
    IMMDevice dev;e.GetDefaultAudioEndpoint(0,1,out dev);
    object o;var iid=typeof(IAudioEndpointVolume).GUID;dev.Activate(ref iid,1,IntPtr.Zero,out o);
    return (IAudioEndpointVolume)o;}
  public static float Get(){float v;Ep().GetMasterVolumeLevelScalar(out v);return v;}
  public static bool Muted(){bool m;Ep().GetMute(out m);return m;}
  public static void Set(float v){Ep().SetMasterVolumeLevelScalar(v,System.Guid.Empty);}
  public static void Mute(bool m){Ep().SetMute(m,System.Guid.Empty);}
}
"""


def _win_volume_ps(percent: Optional[int], mute: Optional[bool],
                   delta: Optional[int] = None) -> str:
    """Same script, built with real newlines (used for execution)."""
    actions: List[str] = ["$before = [Audio]::Get()", "$beforeMuted = [Audio]::Muted()"]
    if percent is not None:
        actions.append(f"[Audio]::Set({max(0, min(100, int(percent)))})")
    elif delta is not None:
        actions.append("$c = [Audio]::Get()")
        actions.append(f"[Audio]::Set([Math]::Max(0, [Math]::Min(100, $c + ({delta})))")
    if mute is not None:
        actions.append(f"[Audio]::Mute(${ 'true' if mute else 'false' })".replace("$ true", "$true").replace("$ false", "$false"))
    actions.append(
        "[pscustomobject]@{ before = $before; after = [Audio]::Get(); "
        "mutedBefore = $beforeMuted; muted = [Audio]::Muted() } | ConvertTo-Json -Compress"
    )
    return "Add-Type -TypeDefinition @'\n" + _WIN_AUDIO_TYPEDEF + "\n'@\n" + "\n".join(actions)


@tool(
    name="pc.volume",
    capability="pc.settings.write",
    agent="pc",
    device="pc",
    description="Get or set the system master volume, or mute/unmute",
    risk="LOW",
    confirm=False,
    timeout=30,
)
async def volume(ctx: ToolContext, percent: Optional[int] = None, mute: Optional[bool] = None,
                 request: str = "") -> Dict[str, Any]:
    delta: Optional[int] = None

    # --- derive intent from natural language when nothing explicit was given
    if percent is None and mute is None and request:
        low = request.lower()
        import re as _re

        m = _re.search(r"(\d{1,3})\s*(?:%|percent)?", low)
        if m and 0 <= int(m.group(1)) <= 100:
            percent = int(m.group(1))
        elif "unmute" in low:
            mute = False
        elif "mute" in low:
            mute = True
        elif any(w in low for w in ("louder", "increase", "turn up", "volume up", "higher")):
            delta = 10
        elif any(w in low for w in ("quieter", "decrease", "turn down", "volume down", "lower")):
            delta = -10

    if IS_WINDOWS:
        script = _win_volume_ps(percent, mute, delta)
        r = await _run(["powershell", "-NoProfile", "-Command", script], timeout=30)
        if r.get("ok") and r.get("stdout"):
            import json as _json
            try:
                data = _json.loads(r["stdout"])
                data.update({"ok": True, "platform": "windows", "requested":
                             {"percent": percent, "mute": mute, "delta": delta}})
                return data
            except Exception:
                return {"ok": True, "platform": "windows", "raw": r["stdout"][:200]}
        return {"ok": False, "platform": "windows",
                "error": (r.get("stderr") or r.get("error") or "volume control failed")[:400]}

    # --- Linux (ALSA/PulseAudio) ----------------------------------------
    if delta is not None:
        cmd = f"amixer -D pulse sset Master {abs(delta)}%{'+' if delta > 0 else '-'}"
    elif percent is not None:
        cmd = f"amixer -D pulse sset Master {max(0, min(100, percent))}%"
    elif mute is not None:
        cmd = f"amixer -D pulse sset Master {'mute' if mute else 'unmute'}"
    else:
        cmd = "amixer -D pulse sget Master"
    r = await _run(cmd, shell=True, timeout=15)
    if not r.get("ok") and IS_MAC:
        target = 50 if percent is None else max(0, min(100, percent))
        r = await _run(["osascript", "-e", f"set volume output volume {target}"], timeout=15)

    import re as _re2

    m = _re2.search(r"\[(\d+)%\]", r.get("stdout", "") or "")
    return {"ok": bool(r.get("ok")), "platform": platform.system().lower(),
            "percent": int(m.group(1)) if m else percent,
            "requested": {"percent": percent, "mute": mute, "delta": delta},
            "error": None if r.get("ok") else (r.get("error") or r.get("stderr") or "")[:300]}


@tool(
    name="pc.brightness",
    capability="pc.settings.write",
    agent="pc",
    device="pc",
    description="Get or set display brightness where the OS allows it",
    risk="LOW",
    timeout=30,
)
async def brightness(ctx: ToolContext, percent: Optional[int] = None, request: str = "") -> Dict[str, Any]:
    if percent is None and request:
        low = request.lower()
        import re as _re

        m = _re.search(r"(\d{1,3})\s*(%|percent)?", low)
        if m:
            percent = max(0, min(100, int(m.group(1))))
        elif "brighter" in low or "increase" in low or "up" in low:
            percent = -1
        elif "dim" in low or "decrease" in low or "down" in low or "lower" in low:
            percent = -2

    if IS_WINDOWS:
        ps = """
try {
  $b = (Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -ErrorAction Stop)
  $cur = $b.CurrentBrightness
} catch { $cur = $null }
[pscustomobject]@{current=$cur} | ConvertTo-Json -Compress
"""
        r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=25)
        current = None
        if r.get("ok") and r["stdout"]:
            import json as _json
            try:
                current = _json.loads(r["stdout"]).get("current")
            except Exception:
                pass
        if percent is not None and current is not None:
            target = current + (10 if percent == -1 else -10 if percent == -2 else percent) - current
            target = max(0, min(100, target))
            set_ps = (
                f"$m = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods;"
                f"Invoke-CimMethod -InputObject $m -MethodName WmiSetBrightness "
                f"-Arguments @{{Timeout=1;Brightness={target}}}"
            )
            r2 = await _run(["powershell", "-NoProfile", "-Command", set_ps], timeout=25)
            return {"ok": bool(r2.get("ok")), "before": current, "target": target,
                    "error": r2.get("stderr") or None,
                    "note": "many desktop monitors do not support WMI brightness"}
        return {"ok": current is not None, "current": current,
                "note": "brightness is read-only here, or the display does not expose WMI brightness"}

    r = await _run("brightnessctl --json get", shell=True, timeout=10)
    if r.get("ok"):
        import json as _json
        try:
            d = _json.loads(r["stdout"])
            cur = int(d.get("actual", 0)) / max(1, int(d.get("max", 100))) * 100
            if percent is not None:
                target = max(0, min(100, cur + (10 if percent == -1 else -10 if percent == -2 else percent - cur)))
                await _run(f"brightnessctl set {int(target)}%", shell=True, timeout=10)
                return {"ok": True, "before": round(cur, 1), "after": round(target, 1)}
            return {"ok": True, "current": round(cur, 1)}
        except Exception:
            pass
    return {"ok": False, "error": "no supported brightness interface found"}


# ===========================================================================
# CLIPBOARD
# ===========================================================================
@tool(
    name="pc.clipboard.read",
    capability="pc.clipboard.read",
    agent="pc",
    device="pc",
    description="Read the current clipboard text",
    risk="MEDIUM",
    confirm=True,
    timeout=15,
)
async def clipboard_read(ctx: ToolContext) -> Dict[str, Any]:
    if IS_WINDOWS:
        r = await _run(["powershell", "-NoProfile", "-Command", "Get-Clipboard -Raw"], timeout=10)
    elif IS_MAC:
        r = await _run(["pbpaste"], timeout=10)
    else:
        r = await _run("wl-paste --no-newline 2>/dev/null || xclip -selection clipboard -o 2>/dev/null",
                       shell=True, timeout=10)
    text = r.get("stdout", "") or ""
    return {"ok": bool(r.get("ok")), "text": text[:8000], "length": len(text),
            "sensitive_looking": _looks_sensitive(text)}


def _looks_sensitive(text: str) -> bool:
    import re

    if not text:
        return False
    return bool(
        re.search(r"(?i)(password|passwd|secret|api[_-]?key|token|BEGIN [A-Z ]*PRIVATE KEY)", text)
        or re.search(r"\b[A-Za-z0-9+/]{40,}={0,2}\b", text)
        or re.search(r"\b\d{12,19}\b", text)
    )


@tool(
    name="pc.clipboard.write",
    capability="pc.clipboard.write",
    agent="pc",
    device="pc",
    description="Write text to the clipboard",
    risk="LOW",
    timeout=15,
)
async def clipboard_write(ctx: ToolContext, text: str = "") -> Dict[str, Any]:
    if not text:
        return {"ok": False, "error": "nothing to write"}
    if IS_WINDOWS:
        r = await _run(["powershell", "-NoProfile", "-Command", f"Set-Clipboard -Value {_ps_quote(text)}"],
                       timeout=10)
    elif IS_MAC:
        proc = await asyncio.create_subprocess_exec("pbcopy", stdin=asyncio.subprocess.PIPE)
        await proc.communicate(text.encode())
        r = {"ok": proc.returncode == 0, "stdout": "", "stderr": ""}
    else:
        proc = await asyncio.create_subprocess_shell(
            "wl-copy 2>/dev/null || xclip -selection clipboard 2>/dev/null || xsel -b 2>/dev/null",
            stdin=asyncio.subprocess.PIPE,
        )
        await proc.communicate(text.encode())
        r = {"ok": proc.returncode == 0, "stdout": "", "stderr": ""}
    return {"ok": bool(r.get("ok")), "length": len(text), "error": r.get("stderr") or None}


def _ps_quote(text: str) -> str:
    return "'" + text.replace("'", "''") + "'"


# ===========================================================================
# NOTIFICATIONS (toast / notify-send / osascript)
# ===========================================================================
@tool(
    name="pc.notify",
    capability="pc.settings.read",
    agent="pc",
    device="pc",
    description="Show a desktop notification",
    risk="LOW",
    timeout=20,
)
async def notify(ctx: ToolContext, title: str = "SAM", body: str = "", sound: bool = False) -> Dict[str, Any]:
    body = (body or "").replace('"', "'")[:400]
    title = (title or "SAM").replace('"', "'")[:120]
    if IS_WINDOWS:
        ps = f"""
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$texts = $template.GetElementsByTagName('text')
$texts.Item(0).AppendChild($template.CreateTextNode('{title}')) | Out-Null
$texts.Item(1).AppendChild($template.CreateTextNode('{body}')) | Out-Null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('SAM').Show($toast)
"""
        r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=20)
        if not r.get("ok"):  # fallback: message box-free balloon via msg
            r = await _run(f'msg * "{title}: {body}"', shell=True, timeout=15)
        return {"ok": bool(r.get("ok")), "channel": "windows-toast", "error": r.get("stderr") or None}
    if IS_MAC:
        r = await _run(["osascript", "-e", f'display notification "{body}" with title "{title}"'], timeout=15)
        return {"ok": bool(r.get("ok")), "channel": "macos-notification"}
    for cmd in (
        ["notify-send", title, body],
        ["gdbus", "call", "--session", "--dest", "org.freedesktop.Notifications",
         "--object-path", "/org/freedesktop/Notifications", "--method",
         "org.freedesktop.Notifications.Notify", "SAM", "0", "", title, body, "[]", "{}", "5000"],
    ):
        r = await _run(cmd, timeout=15)
        if r.get("ok"):
            return {"ok": True, "channel": cmd[0]}
    return {"ok": False, "error": "no desktop notification backend available"}


# ===========================================================================
# ENVIRONMENT / SETTINGS
# ===========================================================================
@tool(
    name="pc.env.read",
    capability="pc.system.info",
    agent="pc",
    device="pc",
    description="Read environment variables (values of secrets are masked)",
    risk="LOW",
    timeout=15,
)
async def env_read(ctx: ToolContext, pattern: str = "", mask: bool = True) -> Dict[str, Any]:
    out: Dict[str, str] = {}
    for k, v in sorted(os.environ.items()):
        if pattern and pattern.lower() not in k.lower():
            continue
        if mask and any(s in k.upper() for s in ("KEY", "SECRET", "TOKEN", "PASSWORD", "CREDENTIAL")):
            v = "***masked***" if v else ""
        out[k] = v
    return {"ok": True, "count": len(out), "variables": out}


@tool(
    name="pc.installed_apps",
    capability="pc.apps.list",
    agent="pc",
    device="pc",
    description="List installed applications",
    risk="LOW",
    timeout=60,
)
async def installed_apps(ctx: ToolContext, search: str = "", limit: int = 100) -> Dict[str, Any]:
    apps: List[Dict[str, Any]] = []
    if IS_WINDOWS:
        ps = """
$paths = @(
 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',
 'HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',
 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*')
Get-ItemProperty $paths -ErrorAction SilentlyContinue |
  Where-Object { $_.DisplayName } |
  Select-Object DisplayName, DisplayVersion, Publisher, InstallLocation |
  ConvertTo-Json -Compress
"""
        r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=60)
        if r.get("ok") and r["stdout"]:
            import json as _json
            try:
                data = _json.loads(r["stdout"])
                for a in data if isinstance(data, list) else [data]:
                    apps.append({"name": a.get("DisplayName"), "version": a.get("DisplayVersion"),
                                 "publisher": a.get("Publisher"), "path": a.get("InstallLocation")})
            except Exception:
                pass
        # also add Start Menu shortcuts (much better for launching)
        for folder in (
            os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs"),
            os.path.expandvars(r"%ProgramData%\Microsoft\Windows\Start Menu\Programs"),
        ):
            for root, _dirs, files in os.walk(folder):
                for f in files:
                    if f.lower().endswith(".lnk"):
                        apps.append({"name": f[:-4], "path": os.path.join(root, f), "source": "start-menu"})
    elif IS_MAC:
        for d in ("/Applications", os.path.expanduser("~/Applications")):
            if os.path.isdir(d):
                for name in os.listdir(d):
                    if name.endswith(".app"):
                        apps.append({"name": name[:-4], "path": os.path.join(d, name)})
    else:
        for cmd in ("ls /usr/share/applications ~/.local/share/applications 2>/dev/null",):
            r = await _run(cmd, shell=True, timeout=20)
            for line in (r.get("stdout") or "").splitlines():
                if line.endswith(".desktop"):
                    apps.append({"name": line[:-8]})
        r = await _run("compgen -c", shell=True, timeout=20)
        seen = set()
        for line in (r.get("stdout") or "").splitlines():
            if line and line not in seen and "/" not in line:
                seen.add(line)
                apps.append({"name": line, "source": "PATH"})

    # de-duplicate by name
    uniq: Dict[str, Dict[str, Any]] = {}
    for a in apps:
        n = (a.get("name") or "").strip()
        if not n:
            continue
        if n.lower() not in uniq or (a.get("path") and not uniq[n.lower()].get("path")):
            uniq[n.lower()] = a
    result = sorted(uniq.values(), key=lambda d: (d.get("name") or "").lower())
    if search:
        result = [a for a in result if search.lower() in (a.get("name") or "").lower()]
    return {"ok": True, "total": len(result), "apps": result[:limit], "platform": platform.system()}


@tool(
    name="core.status",
    capability="ai.chat",
    agent="core",
    device="pc",
    description="Report SAM's own status, agents, tasks and model routing",
    risk="LOW",
    timeout=20,
)
async def sam_status(ctx: ToolContext) -> Dict[str, Any]:
    from backend.app.core.orchestrator import orchestrator
    from backend.app.core.task_store import task_store
    from backend.app.models.router import router

    st = orchestrator.status()
    st["task_counts"] = task_store.counts()
    st["router"] = router.status()
    st["time"] = time.strftime("%Y-%m-%d %H:%M:%S %Z")
    return st
