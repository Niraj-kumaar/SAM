"""
backend.app.tools.pc_tools
==========================

The Windows control layer: applications, windows, keyboard, mouse and screen
understanding.

Implementation strategy
-----------------------
1. **Cross-platform core.** App launch/close, window enumeration and window
   management work on Windows (PowerShell + Win32 via ctypes), macOS
   (``osascript``) and Linux (``wmctrl``/``xdotool`` when present).
2. **Windows-first input.** Keyboard and mouse use ``pyautogui``/``pywinauto``
   when installed; if they are missing, SAM falls back to PowerShell +
   ``SendKeys``/Win32 ``SendInput`` so the feature still works on a clean
   Windows install.
3. **Every call is guarded.** Keyboard/mouse/screen default to *not granted* and
   always require confirmation the first time.

Nothing here is invoked directly — always through ``registry.execute()``.
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import os
import platform
import re
import shutil
import subprocess
import time
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, registry, tool
from backend.app.tools.system_tools import IS_LINUX, IS_MAC, IS_WINDOWS, _run

log = get_logger("tools.pc")


# ---------------------------------------------------------------------------
# Application resolution
# ---------------------------------------------------------------------------
KNOWN_APPS: Dict[str, Dict[str, Any]] = {
    "chrome": {"win": "chrome.exe", "mac": "Google Chrome", "linux": ["google-chrome", "chromium", "chromium-browser"]},
    "edge": {"win": "msedge.exe", "mac": "Microsoft Edge", "linux": ["microsoft-edge"]},
    "firefox": {"win": "firefox.exe", "mac": "Firefox", "linux": ["firefox"]},
    "notepad": {"win": "notepad.exe", "mac": "TextEdit", "linux": ["gedit", "kate", "mousepad", "xed"]},
    "vscode": {"win": "code.cmd", "mac": "Visual Studio Code", "linux": ["code"]},
    "explorer": {"win": "explorer.exe", "mac": "Finder", "linux": ["nautilus", "dolphin", "thunar"]},
    "terminal": {"win": "wt.exe", "mac": "Terminal", "linux": ["gnome-terminal", "konsole", "xterm"]},
    "cmd": {"win": "cmd.exe", "mac": "Terminal", "linux": ["xterm"]},
    "powershell": {"win": "powershell.exe", "mac": "Terminal", "linux": ["pwsh"]},
    "word": {"win": "winword.exe", "mac": "Microsoft Word", "linux": ["libreoffice", "--writer"]},
    "excel": {"win": "excel.exe", "mac": "Microsoft Excel", "linux": ["libreoffice", "--calc"]},
    "powerpoint": {"win": "powerpnt.exe", "mac": "Microsoft PowerPoint", "linux": ["libreoffice", "--impress"]},
    "outlook": {"win": "outlook.exe", "mac": "Microsoft Outlook", "linux": ["thunderbird"]},
    "calculator": {"win": "calc.exe", "mac": "Calculator", "linux": ["gnome-calculator", "kcalc"]},
    "paint": {"win": "mspaint.exe", "mac": "Preview", "linux": ["gimp", "kolourpaint"]},
    "taskmgr": {"win": "taskmgr.exe", "mac": "Activity Monitor", "linux": ["gnome-system-monitor", "htop"]},
    "spotify": {"win": "spotify.exe", "mac": "Spotify", "linux": ["spotify"]},
    "settings": {"win": "ms-settings:", "mac": "System Settings", "linux": ["gnome-control-center"]},
    "photos": {"win": "ms-photos:", "mac": "Photos", "linux": ["eog", "gwenview"]},
    "store": {"win": "ms-windows-store:", "mac": "App Store", "linux": ["gnome-software"]},
}

ALIASES = {
    "code": "vscode", "visual studio code": "vscode", "vs code": "vscode",
    "google chrome": "chrome", "browser": "chrome", "microsoft edge": "edge",
    "file explorer": "explorer", "files": "explorer", "my computer": "explorer",
    "command prompt": "cmd", "shell": "terminal", "wt": "terminal",
    "ms word": "word", "microsoft word": "word", "ms excel": "excel",
    "microsoft excel": "excel", "spreadsheet": "excel", "slides": "powerpoint",
    "microsoft powerpoint": "powerpoint", "calc": "calculator", "task manager": "taskmgr",
    "mail": "outlook", "control panel": "settings", "text editor": "notepad",
}


def _resolve_app(name: str) -> Dict[str, Any]:
    """Map a spoken/written app name to platform launch information."""
    if not name:
        return {"resolved": None}
    key = name.strip().lower().removesuffix(".exe").removesuffix(".app")
    key = ALIASES.get(key, key)
    info = KNOWN_APPS.get(key)
    if info is None:
        # try a fuzzy match
        for k in KNOWN_APPS:
            if k in key or key in k:
                info = KNOWN_APPS[k]
                key = k
                break
    return {
        "resolved": key if info else None,
        "requested": name,
        "windows": (info or {}).get("win"),
        "macos": (info or {}).get("mac"),
        "linux": (info or {}).get("linux"),
    }


def _launch_target(info: Dict[str, Any]) -> Optional[Any]:
    if IS_WINDOWS:
        return info.get("windows")
    if IS_MAC:
        return info.get("macos")
    cands = info.get("linux") or []
    if isinstance(cands, list):
        for c in cands:
            if shutil.which(c):
                return c
    return None


# ===========================================================================
# APPLICATIONS
# ===========================================================================
@tool(
    name="pc.launch_app",
    capability="pc.apps.launch",
    agent="pc",
    device="pc",
    description="Launch a desktop application by name or executable path",
    schema={"app": {"type": "string", "required": True}, "args": {"type": "array"}},
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def launch_app(ctx: ToolContext, app: str = "", args: Optional[List[str]] = None,
                     request: str = "") -> Dict[str, Any]:
    target_name = app or request
    if not target_name:
        return {"ok": False, "error": "no application was specified"}

    info = _resolve_app(target_name)
    target = _launch_target(info)

    # a raw path or command that is not in our table
    if target is None:
        raw = target_name.strip()
        if os.path.isabs(raw) or raw.endswith((".exe", ".app", ".lnk", ".desktop")):
            target = raw
        else:
            which = shutil.which(raw.split()[0])
            if which:
                target = raw
            else:
                return {
                    "ok": False,
                    "error": f"could not resolve application '{target_name}'",
                    "hint": "give the executable name (notepad, chrome, code) or a full path",
                    "resolution": info,
                }

    args = args or []
    if IS_WINDOWS:
        if isinstance(target, str) and target.startswith("ms-"):          # settings URI
            r = await _run(f'start "" "{target}"', shell=True, timeout=20)
        elif isinstance(target, str) and target.endswith((".lnk", ".desktop")):
            r = await _run(f'start "" "{target}"', shell=True, timeout=20)
        else:
            quoted = " ".join(f'"{a}"' for a in args)
            r = await _run(f'start "" "{target}" {quoted}'.strip(), shell=True, timeout=20)
        ok = r.get("ok", False)
        if not ok:  # try Start-Process as a second chance
            r2 = await _run(
                ["powershell", "-NoProfile", "-Command",
                 f"Start-Process -FilePath '{target}'" + (f" -ArgumentList {json.dumps(args)}" if args else "")],
                timeout=25)
            ok = r2.get("ok", False)
            r = r2 if ok else r
    elif IS_MAC:
        r = await _run(["open", "-a", str(target)] + [str(a) for a in args], timeout=25)
        ok = r.get("ok", False)
    else:
        cmd = [str(target)] + [str(a) for a in args]
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                    start_new_session=True)
            ok, r = True, {"ok": True, "pid": proc.pid}
        except FileNotFoundError:
            ok, r = False, {"ok": False, "error": f"executable not found: {target}"}
        except Exception as exc:
            ok, r = False, {"ok": False, "error": str(exc)}

    # --- verification: did a matching process actually appear? -------------
    verified = False
    pid = None
    if ok:
        await asyncio.sleep(1.2)
        proc_name = _process_name_for(target, info)
        match = await _find_process(proc_name)
        verified = bool(match)
        pid = match[0]["pid"] if match else None

    return {
        "ok": bool(ok),
        "app": info.get("resolved") or target_name,
        "requested": target_name,
        "target": target,
        "platform": platform.system(),
        "verified": verified,
        "pid": pid,
        "args": args,
        "error": None if ok else (r.get("error") or r.get("stderr") or "launch failed")[:400],
    }


def _process_name_for(target: Any, info: Dict[str, Any]) -> str:
    if IS_WINDOWS and isinstance(target, str):
        base = os.path.basename(target)
        if base.endswith(".exe"):
            return base
        return (info.get("windows") or base).removesuffix(".exe")
    if isinstance(target, str):
        return os.path.basename(target).removesuffix(".app")
    return str(info.get("resolved") or "")


async def _find_process(name: str) -> List[Dict[str, Any]]:
    if not name:
        return []
    import psutil

    needle = name.lower().removesuffix(".exe")
    out = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            pname = (p.info.get("name") or "").lower()
            if needle and (pname == needle or pname.startswith(needle + ".") or needle in pname):
                out.append({"pid": p.info["pid"], "name": p.info["name"]})
        except Exception:
            continue
    return out


@tool(
    name="pc.close_app",
    capability="pc.apps.close",
    agent="pc",
    device="pc",
    description="Close an application gracefully (falls back to terminate)",
    schema={"app": {"type": "string", "required": True}, "force": {"type": "boolean"}},
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def close_app(ctx: ToolContext, app: str = "", force: bool = False,
                    request: str = "") -> Dict[str, Any]:
    import psutil

    info = _resolve_app(app or request)
    name = _process_name_for(_launch_target(info), info) or (app or request)
    needle = name.lower().removesuffix(".exe")
    if not needle:
        return {"ok": False, "error": "no application was specified"}

    targets = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            pname = (p.info.get("name") or "").lower()
            if pname.startswith(needle) or needle in pname:
                targets.append(p)
        except Exception:
            continue
    if not targets:
        return {"ok": False, "error": f"no running process matched '{name}'",
                "checked": needle}

    closed, failed = [], []
    for p in targets:
        try:
            pname, ppid = p.name(), p.pid
            if force:
                p.kill()
            else:
                if IS_WINDOWS:
                    await _run(["taskkill", "/PID", str(ppid)], timeout=15)
                else:
                    p.terminate()
                try:
                    p.wait(timeout=4)
                except Exception:
                    p.kill()
            closed.append({"pid": ppid, "name": pname})
        except Exception as exc:
            failed.append({"pid": p.pid, "error": str(exc)})

    await asyncio.sleep(0.6)
    still = await _find_process(needle)
    return {"ok": bool(closed) and not still, "closed": closed, "failed": failed,
            "still_running": still, "verified": not still}


@tool(
    name="pc.apps.running",
    capability="pc.apps.list",
    agent="pc",
    device="pc",
    description="List applications that currently have a visible window",
    risk="LOW",
    timeout=30,
)
async def running_apps(ctx: ToolContext) -> Dict[str, Any]:
    windows = await _list_windows()
    seen: Dict[str, Dict[str, Any]] = {}
    for w in windows.get("windows", []):
        title = w.get("title") or ""
        app = w.get("app") or title
        if not app:
            continue
        if app not in seen:
            seen[app] = {"app": app, "windows": 0, "titles": []}
        seen[app]["windows"] += 1
        if len(seen[app]["titles"]) < 3 and title:
            seen[app]["titles"].append(title)
    return {"ok": True, "count": len(seen), "apps": sorted(seen.values(), key=lambda d: -d["windows"]),
            "platform": platform.system()}


# ===========================================================================
# WINDOWS
# ===========================================================================
async def _list_windows() -> Dict[str, Any]:
    if IS_WINDOWS:
        ps = r"""
$sig = @'
using System;using System.Text;using System.Collections.Generic;using System.Runtime.InteropServices;
public class Win {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  public static List<string> Get() {
    var list = new List<string>();
    EnumWindows((h, l) => {
      if (!IsWindowVisible(h)) return true;
      int len = GetWindowTextLength(h); if (len == 0) return true;
      var sb = new StringBuilder(len + 1); GetWindowText(h, sb, sb.Capacity);
      uint pid; GetWindowThreadProcessId(h, out pid);
      list.Add(h.ToInt64() + "\u0001" + pid + "\u0001" + sb.ToString());
      return true;
    }, IntPtr.Zero);
    return list;
  }
}
'@
Add-Type -TypeDefinition $sig -Language CSharp
[Win]::Get() | ConvertTo-Json -Compress
"""
        r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=30)
        windows: List[Dict[str, Any]] = []
        if r.get("ok") and r.get("stdout"):
            try:
                data = json.loads(r["stdout"])
                for line in data if isinstance(data, list) else [data]:
                    parts = str(line).split("\x01")
                    if len(parts) == 3:
                        windows.append({"hwnd": int(parts[0]), "pid": int(parts[1]), "title": parts[2]})
            except Exception as exc:
                log.debug("window enumeration parse failed: %s", exc)
        _attach_process_names(windows)
        return {"ok": True, "count": len(windows), "windows": windows}

    if IS_MAC:
        script = ('tell application "System Events" to get name of every process '
                  'whose background only is false')
        r = await _run(["osascript", "-e", script], timeout=20)
        names = [n.strip() for n in (r.get("stdout") or "").split(",") if n.strip()]
        return {"ok": bool(r.get("ok")), "count": len(names),
                "windows": [{"title": n, "app": n} for n in names]}

    for cmd, parser in (
        ("wmctrl -l -p", "wmctrl"),
        ("xdotool search --onlyvisible --name '' getwindowname %@ 2>/dev/null", "xdotool"),
    ):
        r = await _run(cmd, shell=True, timeout=20)
        if r.get("ok") and r.get("stdout"):
            windows = []
            if parser == "wmctrl":
                for line in r["stdout"].splitlines():
                    parts = line.split(None, 3)
                    if len(parts) >= 4:
                        windows.append({"hwnd": int(parts[0], 16), "pid": int(parts[1]),
                                        "title": parts[3]})
            _attach_process_names(windows)
            return {"ok": True, "count": len(windows), "windows": windows}
    return {"ok": False, "count": 0, "windows": [],
            "error": "no window manager interface available (install wmctrl or xdotool)"}


def _attach_process_names(windows: List[Dict[str, Any]]) -> None:
    import psutil

    cache: Dict[int, str] = {}
    for w in windows:
        pid = w.get("pid")
        if not pid:
            continue
        if pid not in cache:
            try:
                cache[pid] = psutil.Process(pid).name()
            except Exception:
                cache[pid] = ""
        w["app"] = cache.get(pid, "")


@tool(
    name="pc.windows.list",
    capability="pc.windows.manage",
    agent="pc",
    device="pc",
    description="List open windows with their titles, PIDs and bounds",
    risk="LOW",
    timeout=30,
)
async def list_windows(ctx: ToolContext, search: str = "") -> Dict[str, Any]:
    data = await _list_windows()
    if search:
        s = search.lower()
        data["windows"] = [w for w in data["windows"]
                           if s in (w.get("title") or "").lower() or s in (w.get("app") or "").lower()]
        data["count"] = len(data["windows"])
    return data


@tool(
    name="pc.window_action",
    capability="pc.windows.manage",
    agent="pc",
    device="pc",
    description="Minimise, maximise, restore, focus, close, move, resize or snap a window",
    schema={"action": {"type": "string", "required": True}, "app": {"type": "string"},
            "title": {"type": "string"}, "x": {"type": "integer"}, "y": {"type": "integer"},
            "width": {"type": "integer"}, "height": {"type": "integer"}},
    risk="MEDIUM",
    confirm=True,
    timeout=30,
)
async def window_action(ctx: ToolContext, action: str = "focus", app: str = "", title: str = "",
                        x: Optional[int] = None, y: Optional[int] = None,
                        width: Optional[int] = None, height: Optional[int] = None,
                        request: str = "") -> Dict[str, Any]:
    action = (action or "focus").lower()
    valid = {"minimize", "minimise", "maximize", "maximise", "restore", "focus", "activate",
             "close", "move", "resize", "snap", "tile", "arrange"}
    if action not in valid:
        return {"ok": False, "error": f"unsupported window action '{action}'", "supported": sorted(valid)}
    action = {"minimise": "minimize", "maximise": "maximize", "activate": "focus"}.get(action, action)

    if not app and not title and request:
        resolved = _resolve_app(request)
        app = resolved.get("resolved") or ""
        title = request if not app else ""

    hwnd = await _find_window(app=app, title=title)
    if hwnd is None:
        return {"ok": False, "error": f"no window matched app='{app}' title='{title}'"}

    if IS_WINDOWS:
        cmds = {
            "minimize": "ShowWindow($h, 6)",
            "maximize": "ShowWindow($h, 3)",
            "restore": "ShowWindow($h, 9); SetForegroundWindow($h)",
            "focus": "SetForegroundWindow($h); ShowWindow($h, 5)",
            "close": "PostMessage($h, 0x0010, 0, 0)",
        }
        if action in cmds:
            ps = (
                "Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;"
                "public class W { [DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr h,int c);"
                " [DllImport(\"user32.dll\")] public static extern bool SetForegroundWindow(IntPtr h);"
                " [DllImport(\"user32.dll\")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);}' ;"
                f"$h = [IntPtr]{hwnd}; {cmds[action]} | Out-Null; 'ok'"
            )
            r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=20)
        elif action in ("move", "resize"):
            flags = "0x0040"  # SWP_SHOWWINDOW
            ps = (
                "Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;"
                "public class W { [DllImport(\"user32.dll\")] public static extern bool MoveWindow(IntPtr h,int x,int y,int w,int hh,bool r);}' ;"
                f"$h = [IntPtr]{hwnd}; [W]::MoveWindow($h, {x or 0}, {y or 0}, {width or 1280}, {height or 800}, $true)"
            )
            r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=20)
        elif action in ("snap", "tile", "arrange"):
            ps = (
                "Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;"
                "public class W { [DllImport(\"user32.dll\")] public static extern bool SetForegroundWindow(IntPtr h);"
                " [DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr h,int c);}' ;"
                f"$h = [IntPtr]{hwnd}; [W]::SetForegroundWindow($h); [W]::ShowWindow($h, 3)"
            )
            r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=20)
        else:
            r = {"ok": False, "error": "unhandled action"}
        ok = bool(r.get("ok"))
    elif IS_MAC:
        mapping = {"minimize": 'set miniaturized of window 1 to true',
                   "maximize": 'set zoomed of window 1 to true',
                   "focus": "set frontmost to true", "restore": "set miniaturized of window 1 to false",
                   "close": "close window 1"}
        body = mapping.get(action)
        if not body:
            return {"ok": False, "error": f"action '{action}' is not supported on macOS"}
        target_app = app or title
        script = f'tell application "{target_app}" to {body}'
        r = await _run(["osascript", "-e", script], timeout=20)
        ok = bool(r.get("ok"))
    else:
        wm = {"minimize": "0", "maximize": "1", "restore": "1", "focus": "activate", "close": "close"}
        if action in ("move", "resize"):
            geo = f"0,{x or 0},{y or 0},{width or 800},{height or 600}"
            r = await _run(f"wmctrl -i -r {hwnd} -e {geo}", shell=True, timeout=20)
        elif action in wm:
            arg = wm[action]
            r = await _run(f"wmctrl -i -r {hwnd} -b {'remove,hidden' if arg=='0' else 'add,maximized_vert,maximized_horz'}"
                           if action in ("minimize", "maximize", "restore")
                           else f"wmctrl -i -a {hwnd}", shell=True, timeout=20)
        else:
            r = {"ok": False, "error": "unhandled action"}
        ok = bool(r.get("ok"))

    # verify ---------------------------------------------------------------
    await asyncio.sleep(0.6)
    verified = None
    after = await _list_windows()
    still = any(w.get("hwnd") == hwnd for w in after.get("windows", []))
    if action == "close":
        verified = not still
    elif action in ("minimize", "maximize", "focus", "restore", "move", "resize", "snap"):
        verified = still

    return {"ok": ok, "action": action, "hwnd": hwnd, "app": app, "title": title,
            "verified": verified, "platform": platform.system(),
            "error": None if ok else (r.get("error") or r.get("stderr") or "window action failed")[:300]}


async def _find_window(app: str = "", title: str = "") -> Optional[int]:
    data = await _list_windows()
    windows = data.get("windows", [])
    if not windows:
        return None
    needle = (app or title or "").lower()
    if not needle:
        return windows[0].get("hwnd")
    resolved = _resolve_app(app).get("resolved") if app else None
    for w in windows:
        hay = f"{w.get('title','')} {w.get('app','')}".lower()
        if needle in hay or (resolved and resolved.lower() in hay):
            return w.get("hwnd")
    # partial / fuzzy
    for w in windows:
        hay = f"{w.get('title','')} {w.get('app','')}".lower()
        if any(tok in hay for tok in needle.split() if len(tok) > 3):
            return w.get("hwnd")
    return None


# ===========================================================================
# KEYBOARD
# ===========================================================================
SHORTCUT_MAP = {
    "copy": ["ctrl", "c"], "paste": ["ctrl", "v"], "cut": ["ctrl", "x"],
    "undo": ["ctrl", "z"], "redo": ["ctrl", "y"], "select all": ["ctrl", "a"],
    "save": ["ctrl", "s"], "print": ["ctrl", "p"], "find": ["ctrl", "f"],
    "new tab": ["ctrl", "t"], "close tab": ["ctrl", "w"], "reopen tab": ["ctrl", "shift", "t"],
    "next tab": ["ctrl", "tab"], "prev tab": ["ctrl", "shift", "tab"],
    "new window": ["ctrl", "n"], "refresh": ["f5"], "hard refresh": ["ctrl", "shift", "r"],
    "address bar": ["ctrl", "l"], "devtools": ["f12"], "fullscreen": ["f11"],
    "task manager": ["ctrl", "shift", "esc"], "switch app": ["alt", "tab"],
    "lock": ["win", "l"], "desktop": ["win", "d"], "explorer": ["win", "e"],
    "screenshot": ["win", "shift", "s"], "search": ["win", "s"], "settings": ["win", "i"],
    "emoji": ["win", "."], "snap left": ["win", "left"], "snap right": ["win", "right"],
    "home": ["home"], "end": ["end"], "page up": ["pageup"], "page down": ["pagedown"],
    "escape": ["esc"], "enter": ["enter"], "tab": ["tab"], "backspace": ["backspace"],
    "delete": ["delete"], "bold": ["ctrl", "b"], "italic": ["ctrl", "i"],
    "underline": ["ctrl", "u"],
}


def _parse_shortcut(spec: str) -> List[str]:
    s = spec.strip().lower()
    if s in SHORTCUT_MAP:
        return list(SHORTCUT_MAP[s])
    parts = [p.strip() for p in re.split(r"[+\-]| then ", s) if p.strip()]
    norm = []
    for p in parts:
        p = {"ctrl": "ctrl", "control": "ctrl", "ctl": "ctrl", "cmd": "cmd", "command": "cmd",
             "win": "win", "windows": "win", "super": "win", "alt": "alt", "option": "alt",
             "shift": "shift", "esc": "esc", "escape": "esc", "enter": "enter", "return": "enter",
             "space": "space", "tab": "tab", "del": "delete", "backspace": "backspace",
             "up": "up", "down": "down", "left": "left", "right": "right"}.get(p, p)
        norm.append(p)
    return norm


def _ps_sendkeys(keys: List[str], text: str = "") -> str:
    """PowerShell SendKeys script (fallback when pyautogui is unavailable)."""
    mapping = {"ctrl": "^", "alt": "%", "shift": "+", "win": "^{ESC}", "cmd": "^{ESC}",
               "enter": "{ENTER}", "esc": "{ESC}", "tab": "{TAB}", "space": " ",
               "delete": "{DELETE}", "backspace": "{BACKSPACE}", "up": "{UP}", "down": "{DOWN}",
               "left": "{LEFT}", "right": "{RIGHT}", "home": "{HOME}", "end": "{END}",
               "pageup": "{PGUP}", "pagedown": "{PGDN}"}
    seq = ""
    for k in keys:
        seq += mapping.get(k, k.upper() if len(k) == 1 else "{" + k.upper() + "}")
    if text:
        escaped = text.replace("{", "{{}").replace("}", "{}}").replace("+", "{+}").replace("^", "{^}")
        seq += escaped
    return ("Add-Type -AssemblyName System.Windows.Forms;"
            "[System.Windows.Forms.SendKeys]::SendWait('" + seq.replace("'", "''") + "')")


@tool(
    name="pc.keyboard",
    capability="pc.keyboard",
    agent="pc",
    device="pc",
    description="Type text, press keys or send a keyboard shortcut",
    schema={"text": {"type": "string"}, "keys": {"type": "array"}, "shortcut": {"type": "string"}},
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def keyboard(ctx: ToolContext, text: str = "", keys: Optional[List[str]] = None,
                   shortcut: str = "", interval: float = 0.02, app: str = "") -> Dict[str, Any]:
    if not (text or keys or shortcut):
        return {"ok": False, "error": "nothing to type: provide text, keys or shortcut"}

    # focus the target app first if one was given
    if app:
        hwnd = await _find_window(app=app)
        if hwnd:
            await window_action(ctx, action="focus", app=app)
            await asyncio.sleep(0.4)

    pressed = _parse_shortcut(shortcut) if shortcut else list(keys or [])

    # --- preferred path: pyautogui ---------------------------------------
    try:
        import pyautogui  # type: ignore

        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.02
        if pressed:
            pyautogui.hotkey(*pressed)
        if text:
            pyautogui.typewrite(text, interval=interval) if text.isascii() else _type_unicode(text)
        return {"ok": True, "engine": "pyautogui", "keys": pressed, "typed_chars": len(text),
                "shortcut": shortcut or None}
    except ImportError:
        pass
    except Exception as exc:
        log.warning("pyautogui keyboard failed: %s", exc)

    # --- Windows fallback: SendKeys ---------------------------------------
    if IS_WINDOWS:
        script = _ps_sendkeys(pressed, text)
        r = await _run(["powershell", "-NoProfile", "-Command", script], timeout=25)
        if r.get("ok"):
            return {"ok": True, "engine": "powershell-sendkeys", "keys": pressed,
                    "typed_chars": len(text), "shortcut": shortcut or None}
        return {"ok": False, "engine": "powershell-sendkeys",
                "error": (r.get("stderr") or r.get("error") or "SendKeys failed")[:300]}

    # --- Linux/macOS fallback: xdotool / osascript ------------------------
    if IS_LINUX and shutil.which("xdotool"):
        cmds = []
        if pressed:
            combo = "+".join({"ctrl": "ctrl", "win": "super", "cmd": "super", "alt": "alt",
                              "shift": "shift", "esc": "Escape", "enter": "Return",
                              "delete": "Delete", "backspace": "BackSpace",
                              "space": "space", "tab": "Tab"}.get(k, k) for k in pressed)
            cmds.append(f"xdotool key --clearmodifiers '{combo}'")
        if text:
            cmds.append(f"xdotool type --clearmodifiers --delay {int(interval * 1000)} {json.dumps(text)}")
        r = await _run(" ; ".join(cmds), shell=True, timeout=25)
        return {"ok": bool(r.get("ok")), "engine": "xdotool", "keys": pressed,
                "typed_chars": len(text), "error": None if r.get("ok") else r.get("error")}

    if IS_MAC:
        cmds = []
        if text:
            cmds += ["osascript", "-e", f'tell application "System Events" to keystroke {json.dumps(text)}']
        r = await _run(cmds, timeout=25) if cmds else {"ok": False, "error": "no keys"}
        return {"ok": bool(r.get("ok")), "engine": "osascript", "typed_chars": len(text)}

    return {"ok": False, "error": "no keyboard backend available — install pyautogui "
                                  "(pip install pyautogui) or xdotool"}


def _type_unicode(text: str) -> None:
    """Send non-ASCII text (Devanagari, Kannada, emoji) via the clipboard."""
    try:
        import pyautogui  # type: ignore

        import pyperclip  # type: ignore

        pyperclip.copy(text)
        pyautogui.hotkey("ctrl", "v")
    except Exception:
        # last resort: write to clipboard via OS then paste
        if IS_WINDOWS:
            subprocess.run(["powershell", "-NoProfile", "-Command", f"Set-Clipboard -Value {json.dumps(text)}"],
                           check=False, timeout=15)
        elif IS_MAC:
            subprocess.run(["pbcopy"], input=text.encode(), check=False, timeout=15)
        else:
            subprocess.run("wl-copy || xclip -selection clipboard", input=text.encode(),
                           shell=True, check=False, timeout=15)
        try:
            import pyautogui  # type: ignore

            pyautogui.hotkey("ctrl", "v")
        except Exception:
            pass


@tool(
    name="pc.clipboard.paste",
    capability="pc.keyboard",
    agent="pc",
    device="pc",
    description="Write text to the clipboard and paste it into the focused window",
    risk="MEDIUM",
    confirm=True,
    timeout=30,
)
async def clipboard_paste(ctx: ToolContext, text: str = "") -> Dict[str, Any]:
    if not text:
        return {"ok": False, "error": "nothing to paste"}
    wrote = await clipboard_write_tool(ctx, text=text)
    pasted = await keyboard(ctx, shortcut="paste")
    return {"ok": bool(wrote.get("ok") and pasted.get("ok")), "write": wrote, "paste": pasted,
            "length": len(text)}


# alias so the paste tool can reuse the clipboard writer
clipboard_write_tool = registry.get("pc.clipboard.write").fn  # type: ignore[union-attr]


# ===========================================================================
# MOUSE
# ===========================================================================
@tool(
    name="pc.mouse",
    capability="pc.mouse",
    agent="pc",
    device="pc",
    description="Move the cursor, click, double-click, right-click, drag or scroll",
    schema={"action": {"type": "string", "required": True}, "x": {"type": "integer"},
            "y": {"type": "integer"}, "button": {"type": "string"}, "clicks": {"type": "integer"},
            "amount": {"type": "integer"}, "to_x": {"type": "integer"}, "to_y": {"type": "integer"}},
    risk="MEDIUM",
    confirm=True,
    timeout=45,
)
async def mouse(ctx: ToolContext, action: str = "click", x: Optional[int] = None,
                y: Optional[int] = None, button: str = "left", clicks: int = 1,
                amount: int = 3, to_x: Optional[int] = None, to_y: Optional[int] = None,
                duration: float = 0.3) -> Dict[str, Any]:
    action = (action or "click").lower()
    valid = {"move", "click", "doubleclick", "double", "rightclick", "right", "drag", "scroll",
             "position", "down", "up"}
    if action not in valid:
        return {"ok": False, "error": f"unsupported mouse action '{action}'", "supported": sorted(valid)}

    try:
        import pyautogui  # type: ignore

        pyautogui.FAILSAFE = True
        if action == "position":
            px, py = pyautogui.position()
            return {"ok": True, "engine": "pyautogui", "x": px, "y": py}
        if x is not None and y is not None and action != "drag":
            pyautogui.moveTo(x, y, duration=0.15)
        if action in ("click", "doubleclick", "double", "rightclick", "right", "down", "up"):
            btn = "right" if action in ("rightclick", "right") else button
            n = 2 if action in ("doubleclick", "double") else clicks
            if action == "down":
                pyautogui.mouseDown(button=btn)
            elif action == "up":
                pyautogui.mouseUp(button=btn)
            else:
                pyautogui.click(x=x, y=y, clicks=n, button=btn, interval=0.05)
        elif action == "move":
            pyautogui.moveTo(x or 0, y or 0, duration=duration)
        elif action == "drag":
            if x is not None and y is not None:
                pyautogui.moveTo(x, y, duration=0.15)
            pyautogui.dragTo(to_x or 0, to_y or 0, duration=duration, button=button)
        elif action == "scroll":
            pyautogui.scroll(int(amount) * 100)
        px, py = pyautogui.position()
        return {"ok": True, "engine": "pyautogui", "action": action, "button": button,
                "clicks": clicks, "position": {"x": px, "y": py}}
    except ImportError:
        pass
    except Exception as exc:
        log.warning("pyautogui mouse failed: %s", exc)

    # --- fallbacks ---------------------------------------------------------
    if IS_LINUX and shutil.which("xdotool"):
        cmd = {
            "move": f"xdotool mousemove {x or 0} {y or 0}",
            "click": f"xdotool mousemove {x or 0} {y or 0} click {1 if button == 'left' else 3}",
            "doubleclick": f"xdotool mousemove {x or 0} {y or 0} click --repeat 2 {1 if button == 'left' else 3}",
            "rightclick": f"xdotool mousemove {x or 0} {y or 0} click 3",
            "scroll": f"xdotool click {4 if amount > 0 else 5}",
            "drag": f"xdotool mousemove {x or 0} {y or 0} mousedown 1 mousemove {to_x or 0} {to_y or 0} mouseup 1",
            "position": "xdotool getmouselocation",
        }.get(action)
        if not cmd:
            return {"ok": False, "error": f"action '{action}' unsupported by xdotool fallback"}
        r = await _run(cmd, shell=True, timeout=20)
        return {"ok": bool(r.get("ok")), "engine": "xdotool", "action": action,
                "raw": r.get("stdout", "")[:200]}

    if IS_WINDOWS:
        return {"ok": False, "engine": "none",
                "error": "mouse control on Windows needs pyautogui: pip install pyautogui"}

    return {"ok": False, "error": "no mouse backend available (install pyautogui or xdotool)"}


# ===========================================================================
# SCREEN CAPTURE + UNDERSTANDING
# ===========================================================================
@tool(
    name="pc.screenshot",
    capability="vision.screen_capture",
    agent="vision",
    device="pc",
    description="Capture the screen (or one window) and save it to data/cache",
    schema={"region": {"type": "string"}, "window": {"type": "string"},
            "analyze": {"type": "boolean"}},
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def screenshot(ctx: ToolContext, region: str = "full", window: str = "",
                     analyze: bool = True, question: str = "") -> Dict[str, Any]:
    if not settings.pc_screen_capture_enabled:
        return {"ok": False, "error": "screen capture is disabled (PC_SCREEN_CAPTURE_ENABLED=false)"}

    cache_dir = settings.sam_data_dir / "cache" / "screenshots"
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / f"screen_{int(time.time() * 1000)}.png"

    captured = False
    engine = "none"
    error = ""

    # 1. pyautogui / Pillow ImageGrab (cross-platform)
    try:
        import pyautogui  # type: ignore

        img = pyautogui.screenshot()
        img.save(path)
        captured, engine = True, "pyautogui"
    except Exception as exc:
        error = f"pyautogui: {exc}"

    # 2. Windows PowerShell + System.Drawing
    if not captured and IS_WINDOWS:
        ps = f"""
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
$b = [System.Windows.Forms.SystemInformation]::VirtualScreen
$bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size)
$bmp.Save('{str(path).replace(chr(92), '/')}')
$g.Dispose(); $bmp.Dispose(); 'ok'
"""
        r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=30)
        captured = r.get("ok", False) and path.exists()
        engine = "powershell-gdi" if captured else engine
        if not captured:
            error += f" | powershell: {r.get('stderr') or r.get('error')}"

    # 3. native CLIs
    if not captured:
        for cmd, name in (("screencapture -x {p}", "screencapture"),
                          ("gnome-screenshot -f {p}", "gnome-screenshot"),
                          ("import -window root {p}", "imagemagick"),
                          ("grim {p}", "grim"),
                          ("scrot {p}", "scrot")):
            if shutil.which(cmd.split()[0]):
                r = await _run(cmd.format(p=str(path)), shell=True, timeout=30)
                if r.get("ok") and path.exists():
                    captured, engine = True, name
                    break
                error += f" | {name}: {r.get('error') or r.get('stderr')}"

    if not captured or not path.exists():
        return {"ok": False, "error": f"screen capture failed. {error.strip(' |')[:400]}",
                "hint": "install Pillow + pyautogui, or a native screenshot tool"}

    size = path.stat().st_size
    result: Dict[str, Any] = {
        "ok": True, "engine": engine, "path": str(path), "bytes": size,
        "width": None, "height": None,
    }
    try:
        from PIL import Image

        with Image.open(path) as im:
            result["width"], result["height"] = im.size
    except Exception:
        pass

    # OCR -------------------------------------------------------------------
    ocr_text = await _ocr(path)
    if ocr_text:
        result["ocr_text"] = ocr_text[:8000]
        result["ocr_chars"] = len(ocr_text)

    # Vision model ----------------------------------------------------------
    if analyze:
        prompt = question or (
            "You are SAM's Vision Brain looking at a screenshot of the user's screen. "
            "Describe the layout, list every visible button/menu/dialog with its label and "
            "approximate position, note any error messages, and state what the user is "
            "currently doing. Be precise and structured."
        )
        try:
            from backend.app.models.router import router

            res = await router.vision(prompt, [str(path)])
            if res.ok and res.text:
                result["analysis"] = res.text
                result["vision_model"] = res.model
            else:
                result["analysis_error"] = res.error or "vision model unavailable"
        except Exception as exc:
            result["analysis_error"] = str(exc)

    return result


async def _ocr(path: Any) -> str:
    """Try Tesseract, then Windows OCR, then nothing."""
    try:
        import pytesseract  # type: ignore
        from PIL import Image

        with Image.open(path) as im:
            text = pytesseract.image_to_string(im)
        if text and text.strip():
            return text.strip()
    except Exception as exc:
        log.debug("tesseract OCR unavailable: %s", exc)
    return ""


@tool(
    name="pc.screen.understand",
    capability="vision.screen_capture",
    agent="vision",
    device="pc",
    description="Capture the screen and answer a specific question about it",
    risk="MEDIUM",
    confirm=True,
    timeout=90,
)
async def screen_understand(ctx: ToolContext, question: str = "What is on my screen right now?",
                            image_path: str = "") -> Dict[str, Any]:
    if image_path:
        from backend.app.models.router import router

        res = await router.vision(question, [image_path])
        return {"ok": res.ok, "answer": res.text, "model": res.model, "source": image_path,
                "error": res.error}
    shot = await screenshot(ctx, analyze=True, question=question)
    if not shot.get("ok"):
        return shot
    return {"ok": True, "answer": shot.get("analysis") or shot.get("ocr_text") or "",
            "screenshot": shot.get("path"), "ocr_available": bool(shot.get("ocr_text")),
            "vision_model": shot.get("vision_model")}


@tool(
    name="pc.ui.elements",
    capability="pc.ui_automation",
    agent="pc",
    device="pc",
    description="Inspect interactive UI elements in the focused window (UI Automation)",
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def ui_elements(ctx: ToolContext, app: str = "", depth: int = 4,
                      limit: int = 80) -> Dict[str, Any]:
    """
    Enumerate automation elements.

    Windows: tries ``pywinauto`` (UIA backend) first, then falls back to a
    PowerShell UI Automation walk. Linux: AT-SPI via ``accerciser``/``dogtail``
    is not assumed, so we return the window tree plus OCR-derived candidates.
    """
    hwnd = await _find_window(app=app) if app else None

    if IS_WINDOWS:
        try:
            from pywinauto import Desktop  # type: ignore

            desktop = Desktop(backend="uia")
            target = None
            if hwnd:
                target = desktop.window(handle=hwnd)
            else:
                windows = desktop.windows()
                target = windows[0] if windows else None
            if target is None:
                return {"ok": False, "error": "no top-level window found"}
            elements: List[Dict[str, Any]] = []

            def walk(ctrl, level: int = 0) -> None:
                if level > depth or len(elements) >= limit:
                    return
                try:
                    info = ctrl.element_info
                    elements.append({
                        "level": level,
                        "type": info.control_type,
                        "name": (info.name or "")[:120],
                        "automation_id": getattr(info, "automation_id", ""),
                        "class": getattr(info, "class_name", ""),
                        "rect": [int(v) for v in (info.rectangle.left, info.rectangle.top,
                                                  info.rectangle.right, info.rectangle.bottom)],
                        "enabled": bool(getattr(info, "is_enabled", lambda: True)()),
                        "clickable": info.control_type in ("Button", "MenuItem", "TabItem",
                                                           "CheckBox", "RadioButton", "Hyperlink",
                                                           "ListItem", "Edit"),
                    })
                except Exception:
                    return
                for child in (ctrl.children() or [])[:25]:
                    walk(child, level + 1)

            walk(target.wrapper_object() if hasattr(target, "wrapper_object") else target)
            return {"ok": True, "engine": "pywinauto-uia", "count": len(elements),
                    "elements": elements, "hwnd": hwnd}
        except ImportError:
            pass
        except Exception as exc:
            log.debug("pywinauto failed: %s", exc)

        ps = r"""
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$root = [System.Windows.Automation.AutomationElement]::RootElement
$cond = [System.Windows.Automation.Condition]::TrueCondition
$all = $root.FindAll([System.Windows.Automation.TreeScope]::Children, $cond)
$out = @()
foreach ($w in $all) {
  if (-not $w.Current.IsOffscreen) {
    $out += [pscustomobject]@{ name = $w.Current.Name; type = $w.Current.ControlType.ProgrammaticName; id = $w.Current.AutomationId }
  }
}
$out | Select-Object -First 80 | ConvertTo-Json -Compress
"""
        r = await _run(["powershell", "-NoProfile", "-Command", ps], timeout=45)
        if r.get("ok") and r.get("stdout"):
            try:
                data = json.loads(r["stdout"])
                items = data if isinstance(data, list) else [data]
                return {"ok": True, "engine": "powershell-uia", "count": len(items),
                        "elements": items, "hwnd": hwnd}
            except Exception:
                pass
        return {"ok": False, "engine": "none", "hwnd": hwnd,
                "error": "UI Automation unavailable — install pywinauto (pip install pywinauto)",
                "hint": "as a fallback use pc.screen.understand, which reads the screenshot with a vision model"}

    # non-Windows: window tree + OCR
    windows = await _list_windows()
    shot = await screenshot(ctx, analyze=False)
    return {"ok": True, "engine": "window-tree+ocr", "windows": windows.get("windows", [])[:limit],
            "ocr_text": shot.get("ocr_text", ""), "screenshot": shot.get("path"),
            "note": "structured UI Automation is Windows-only in this build; use the screenshot + OCR path"}
