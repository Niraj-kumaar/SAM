"""
backend.app.tools.vision_tools
==============================

The Vision Brain: image understanding, OCR, UI understanding and document
extraction from pictures.

Every tool works on files that already exist on disk or on a base64 data URI —
SAM never reaches for the camera or the screen unless the user asks for it
through ``pc.screenshot`` / ``vision.camera``.

Fallback chain for OCR: pytesseract → Windows.Media.Ocr via PowerShell →
router vision model → honest "cannot read this" answer. SAM never invents text
it could not see.
"""

from __future__ import annotations

import base64
import io
import os
import re
import shutil
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.files.file_ops import FileSecurityError, assert_allowed
from backend.app.tools.registry import ToolContext, tool

log = get_logger("tools.vision")

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff"}
MAX_IMAGE_BYTES = 25 * 1024 * 1024


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _resolve_image(path: str) -> Tuple[Optional[Path], Optional[str], Optional[str]]:
    """Return (local_path, data_uri, error)."""
    if not path:
        return None, None, "no image given"
    if path.startswith("data:"):
        return None, path, None
    if path.startswith(("http://", "https://")):
        return None, None, ("SAM does not fetch remote images for vision analysis — "
                            "download it first (files.download / browser.download)")
    try:
        p = assert_allowed(path)
    except FileSecurityError as exc:
        return None, None, str(exc)
    if not p.exists():
        return None, None, f"image not found: {p}"
    if p.suffix.lower() not in IMAGE_EXTS:
        return None, None, f"'{p.name}' does not look like an image ({p.suffix or 'no extension'})"
    if p.stat().st_size > MAX_IMAGE_BYTES:
        return None, None, f"image is too large ({p.stat().st_size // (1024 * 1024)} MB, max 25 MB)"
    return p, None, None


def _to_data_uri(p: Path) -> str:
    mime = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".webp": "image/webp", ".bmp": "image/bmp", ".gif": "image/gif",
            ".tif": "image/tiff", ".tiff": "image/tiff"}.get(p.suffix.lower(), "image/png")
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"


def _first_path_in(text: str) -> str:
    m = re.search(r"([A-Za-z]:[\\/][^\s'\"]+|~/[^\s'\"]+|/[^\s'\"]+|\./[^\s'\"]+|[\w\-./\\]+\.\w{2,5})",
                  text or "")
    return m.group(1) if m else ""


def _image_meta(p: Path) -> Dict[str, Any]:
    meta: Dict[str, Any] = {"path": str(p), "name": p.name, "bytes": p.stat().st_size,
                            "modified": time.strftime("%Y-%m-%d %H:%M:%S",
                                                      time.localtime(p.stat().st_mtime))}
    try:
        from PIL import Image

        with Image.open(p) as im:
            meta.update({"width": im.width, "height": im.height, "format": im.format,
                         "mode": im.mode, "megapixels": round(im.width * im.height / 1e6, 2)})
            exif = im.getexif()
            if exif:
                meta["exif"] = {str(k): str(v)[:80] for k, v in list(exif.items())[:12]}
    except Exception as exc:
        meta["pixel_error"] = str(exc)[:120]
    return meta


async def _vision(prompt: str, images: List[str]) -> Dict[str, Any]:
    from backend.app.models.router import router

    res = await router.vision(prompt, images, role="vision")
    if not res.ok:
        return {"ok": False, "error": res.error or "the vision model could not analyse the image",
                "model": res.model}
    return {"ok": True, "text": res.text, "model": res.model, "provider": res.provider,
            "latency_ms": res.latency_ms}


# ===========================================================================
# VISION ANALYSIS
# ===========================================================================
@tool(
    name="vision.analyse",
    capability="vision.image_analysis",
    agent="vision",
    device="pc",
    description="Describe and analyse an image: content, objects, text, people, mood, UI",
    schema={"path": {"type": "string"}, "question": {"type": "string"}},
    risk="LOW",
    timeout=240,
)
async def vision_analyse(ctx: ToolContext, path: str = "", image: str = "",
                         question: str = "", focus: str = "", request: str = "") -> Dict[str, Any]:
    source = path or image or _first_path_in(request or ctx.user_text)
    local, data_uri, error = _resolve_image(source)
    if error:
        return {"ok": False, "error": error, "blocked": "not found" not in error}
    uri = data_uri or _to_data_uri(local)
    meta = _image_meta(local) if local else {"source": "inline data uri"}

    ask = question or focus or ctx.user_text or ""
    prompt = (
        "You are SAM's Vision Brain. Describe exactly what is visible in this image.\n"
        + (f"\nThe user's specific question: {ask}\n" if ask and ask.lower() not in source.lower() else "")
        + "\nStructure your answer as:\n"
          "1. SUMMARY — one or two sentences.\n"
          "2. OBJECTS / PEOPLE — what is present, with positions (left/centre/right, "
          "foreground/background). Never name a real person.\n"
          "3. TEXT — transcribe any visible text exactly.\n"
          "4. COLOURS & STYLE — palette, lighting, composition.\n"
          "5. NOTES — anything ambiguous, cropped, blurry or that you cannot determine.\n"
          "If something is not visible, say so. Do not guess."
    )
    result = await _vision(prompt, [uri])
    if not result.get("ok"):
        # no vision model available: fall back to measurable facts only
        fallback = _offline_image_description(local, meta)
        fallback.update({"ok": True, "model": None, "generated_by": "sam-offline-heuristic",
                         "warning": result.get("error",
                                              "no vision model configured — only measurable facts reported")})
        return fallback
    result.update({"meta": meta, "source": str(local) if local else "(inline)",
                   "question": ask, "answer": result["text"]})
    return result


def _offline_image_description(local: Optional[Path], meta: Dict[str, Any]) -> Dict[str, Any]:
    """Report only what can be computed without a model — never invent content."""
    facts: List[str] = []
    palette: List[Dict[str, Any]] = []
    orientation = "unknown"
    if local:
        try:
            from PIL import Image

            with Image.open(local) as im:
                width, height = im.width, im.height
                orientation = "landscape" if width > height else (
                    "portrait" if height > width else "square")
                small = im.convert("RGB").resize((32, 32))
                pixels = list(small.getdata())
                avg = tuple(sum(c[i] for c in pixels) // len(pixels) for i in range(3))
                brightness = round(sum(avg) / (3 * 255) * 100)
                greys = [abs(r - g) + abs(g - b) + abs(r - b) for r, g, b in pixels]
                saturation = round(sum(greys) / len(greys) / 510 * 100)
                from collections import Counter

                quant = Counter((r // 32 * 32, g // 32 * 32, b // 32 * 32) for r, g, b in pixels)
                palette = [{"hex": "#%02x%02x%02x" % k, "share": round(v / len(pixels) * 100, 1)}
                           for k, v in quant.most_common(6)]
                facts += [
                    f"{width}×{height} px ({orientation}), {meta.get('format') or 'unknown format'}",
                    f"average brightness {brightness}%",
                    f"colour saturation {saturation}%",
                ]
                # edge density as a rough complexity measure
                grey = im.convert("L").resize((64, 64))
                data = list(grey.getdata())
                edges = sum(1 for i in range(1, len(data)) if abs(data[i] - data[i - 1]) > 24)
                facts.append(f"visual detail (edge density) {round(edges / len(data) * 100)}%")
        except Exception as exc:
            facts.append(f"could not read pixel data: {exc}")

    text = "## Image analysis (offline — no vision model)\n\n" + \
        "\n".join(f"- {f}" for f in facts) + \
        ("\n\nDominant colours: " + ", ".join(p["hex"] for p in palette) if palette else "") + \
        "\n\n**SAM cannot describe the image content without a vision model.** " \
        "Configure OPENAI_API_KEY, GOOGLE_API_KEY or a local llava model in Ollama, " \
        "then ask again."
    return {"text": text, "answer": text, "facts": facts, "palette": palette,
            "orientation": orientation, "meta": meta,
            "source": str(local) if local else "(inline)"}


@tool(
    name="vision.ocr",
    capability="vision.ocr",
    agent="vision",
    device="pc",
    description="Extract text from an image, screenshot, scan or photo of a document",
    schema={"path": {"type": "string"}},
    risk="LOW",
    timeout=240,
)
async def vision_ocr(ctx: ToolContext, path: str = "", image: str = "", language: str = "",
                     layout: bool = False, request: str = "") -> Dict[str, Any]:
    source = path or image or _first_path_in(request or ctx.user_text)
    local, data_uri, error = _resolve_image(source)
    if error:
        return {"ok": False, "error": error, "blocked": "not found" not in error}

    target = local or _materialise(data_uri)
    if target is None:
        return {"ok": False, "error": "could not prepare the image for OCR"}

    attempts: List[Dict[str, Any]] = []

    # 1. tesseract
    text, detail = await _ocr_tesseract(target, language)
    attempts.append({"engine": "tesseract", "chars": len(text), "detail": detail})
    if text and len(text.strip()) > 2:
        return _ocr_result(text, target, "tesseract", attempts, layout)

    # 2. Windows.Media.Ocr through PowerShell (no install needed on Windows 10+)
    if os.name == "nt":
        text, detail = await _ocr_windows(target)
        attempts.append({"engine": "windows.media.ocr", "chars": len(text), "detail": detail})
        if text and len(text.strip()) > 2:
            return _ocr_result(text, target, "windows.media.ocr", attempts, layout)

    # 3. vision model
    from backend.app.models.router import router

    uri = _to_data_uri(target)
    res = await router.vision(
        "Transcribe every piece of text visible in this image, exactly as written. "
        "Preserve line breaks, table columns and numbering. "
        "If there is no text at all, reply with the single word NONE.",
        [uri], role="vision",
    )
    attempts.append({"engine": f"vision:{res.model or res.provider}", "chars": len(res.text or ""),
                     "detail": res.error or "ok"})
    if res.ok and res.text and res.text.strip().upper() != "NONE":
        return _ocr_result(res.text, target, f"vision:{res.model}", attempts, layout)

    return {"ok": False, "text": "", "engine": None, "attempts": attempts,
            "path": str(target),
            "error": "no OCR engine could read text from this image",
            "hint": "install Tesseract (https://github.com/UB-Mannheim/tesseract/wiki) or "
                    "configure a vision model; make sure the image is not rotated or blurry"}


def _ocr_result(text: str, target: Path, engine: str, attempts: List[Dict[str, Any]],
                layout: bool) -> Dict[str, Any]:
    cleaned = text.replace("\r\n", "\n").strip()
    words = len(cleaned.split())
    structured: Dict[str, Any] = {}
    if layout:
        structured = {
            "lines": [ln for ln in cleaned.splitlines() if ln.strip()],
            "paragraphs": [p.strip() for p in re.split(r"\n\s*\n", cleaned) if p.strip()],
            "numbers": sorted(set(re.findall(r"\b\d[\d,]*(?:\.\d+)?\b", cleaned)))[:40],
            "emails": sorted(set(re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", cleaned)))[:20],
            "urls": sorted(set(re.findall(r"https?://[^\s\"')]+", cleaned)))[:20],
            "tables_detected": bool(re.search(r"\n\s*[|\t]", cleaned)),
        }
    return {"ok": True, "text": cleaned, "engine": engine, "path": str(target),
            "chars": len(cleaned), "words": words, "attempts": attempts, **structured,
            "answer": cleaned if words <= 60 else cleaned[:600] + " …",
            "verified": True}


async def _ocr_tesseract(path: Path, language: str = "") -> Tuple[str, str]:
    exe = shutil.which("tesseract")
    if not exe:
        return "", "tesseract is not installed or not on PATH"
    try:
        import pytesseract  # type: ignore

        from PIL import Image

        pytesseract.pytesseract.tesseract_cmd = exe
        kwargs: Dict[str, Any] = {}
        if language:
            kwargs["lang"] = language
        with Image.open(path) as im:
            return pytesseract.image_to_string(im, **kwargs), "ok"
    except ImportError:
        pass
    except Exception as exc:
        return "", f"pytesseract failed: {exc}"

    # CLI fallback
    from backend.app.tools.system_tools import _run

    cmd = [exe, str(path), "stdout"]
    if language:
        cmd += ["-l", language]
    res = await _run(cmd, timeout=120)
    if res.get("returncode") == 0 and res.get("stdout"):
        return res["stdout"], "ok (cli)"
    return "", res.get("stderr") or res.get("error") or "tesseract produced no output"


async def _ocr_windows(path: Path) -> Tuple[str, str]:
    script = f'''
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$path = "{path.as_posix().replace('/', chr(92))}"
$file = [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]::GetFileFromPathAsync($path)
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | ? {{ $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' }})[0]
$task = $asTask.MakeGenericMethod([Windows.Storage.StorageFile]).Invoke($null, @($file))
$storageFile = $task.Result
$ocrEngine = [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]::TryCreateFromUserProfileLanguages()
if (-not $ocrEngine) {{ Write-Output "NO_OCR_ENGINE"; exit 1 }}
$bitmap = ([Windows.Graphics.Imaging.BitmapDecoder,Windows.Foundation,ContentType=WindowsRuntime]::CreateAsync($storageFile))
$asTask2 = ([System.WindowsRuntimeSystemExtensions].GetMethods() | ? {{ $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' }})[0]
$task2 = $asTask2.MakeGenericMethod([Windows.Graphics.Imaging.BitmapDecoder]).Invoke($null, @($bitmap))
$decoder = $task2.Result
$bmp = $decoder.GetSoftwareBitmapAsync()
$task3 = $asTask2.MakeGenericMethod([Windows.Graphics.Imaging.SoftwareBitmap]).Invoke($null, @($bmp))
$softwareBitmap = $task3.Result
$result = $ocrEngine.RecognizeAsync($softwareBitmap)
$task4 = $asTask2.MakeGenericMethod([Windows.Media.Ocr.OcrResult]).Invoke($null, @($result))
$ocr = $task4.Result
Write-Output $ocr.Text
'''
    from backend.app.tools.system_tools import _run

    script_dir = settings.sam_data_dir / "cache" / "scripts"
    script_dir.mkdir(parents=True, exist_ok=True)
    ps1 = script_dir / f"sam_ocr_{int(time.time() * 1000)}.ps1"
    try:
        ps1.write_text(script, encoding="utf-8")
        res = await _run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                          "-File", str(ps1)], timeout=120)
        out = (res.get("stdout") or "").strip()
        if res.get("returncode") == 0 and out and out != "NO_OCR_ENGINE":
            return out, "ok"
        return "", (out or res.get("stderr") or res.get("error") or "no output")[:300]
    except Exception as exc:
        return "", f"windows ocr failed: {exc}"
    finally:
        try:
            ps1.unlink(missing_ok=True)
        except OSError:
            pass


def _materialise(data_uri: Optional[str]) -> Optional[Path]:
    if not data_uri:
        return None
    try:
        header, encoded = data_uri.split(",", 1)
        ext = ".png" if "png" in header else ".jpg"
        cache = settings.sam_data_dir / "cache" / "vision"
        cache.mkdir(parents=True, exist_ok=True)
        p = cache / f"sam_vision_{int(time.time() * 1000)}{ext}"
        p.write_bytes(base64.b64decode(encoded))
        return p
    except Exception as exc:
        log.debug("could not materialise data uri: %s", exc)
        return None


# ===========================================================================
# DOCUMENT / SCREEN UNDERSTANDING
# ===========================================================================
@tool(
    name="vision.document",
    capability="vision.ocr",
    agent="vision",
    device="pc",
    description="Read a scanned document or photo of a page and return structured data",
    risk="LOW",
    timeout=300,
)
async def vision_document(ctx: ToolContext, path: str = "", doc_type: str = "auto",
                          request: str = "") -> Dict[str, Any]:
    source = path or _first_path_in(request or ctx.user_text)
    local, data_uri, error = _resolve_image(source)
    if error:
        return {"ok": False, "error": error, "blocked": "not found" not in error}
    target = local or _materialise(data_uri)
    if target is None:
        return {"ok": False, "error": "could not prepare the image"}

    ocr = await vision_ocr(ctx, path=str(target))
    text = ocr.get("text") or ""
    if not text:
        return {"ok": False, "error": "no text could be read from this document",
                "ocr": ocr.get("attempts"), "path": str(target)}

    detected = doc_type if doc_type != "auto" else _guess_doc_type(text)
    fields = _extract_fields(text, detected)

    from backend.app.models.router import router

    summary = ""
    try:
        status = router.status()
        if any((p or {}).get("available") for p in (status.get("providers") or {}).values()):
            res = await router.ask(
                f"Summarise this {detected} document in 3-5 bullet points and list every "
                f"action the reader must take with its deadline.\n\n{text[:8000]}",
                role="reasoning", temperature=0.2, max_tokens=700,
            )
            if res.ok:
                summary = res.text
    except Exception as exc:
        log.debug("document summary skipped: %s", exc)

    markdown = [f"# Extracted {detected}", "", "## Fields", ""]
    if fields:
        markdown += ["| Field | Value |", "| --- | --- |"]
        markdown += [f"| {k} | {v} |" for k, v in fields.items()]
    else:
        markdown.append("_(no structured fields detected)_")
    markdown += ["", "## Full text", "", "```", text[:6000], "```"]
    if summary:
        markdown += ["", "## Summary", "", summary]

    return {"ok": True, "doc_type": detected, "fields": fields, "text": text,
            "chars": len(text), "summary": summary, "markdown": "\n".join(markdown),
            "path": str(target), "engine": ocr.get("engine"),
            "answer": (summary or f"Extracted {len(text.split())} words from the {detected}."),
            "verified": True}


def _guess_doc_type(text: str) -> str:
    low = text.lower()
    probes = [
        (r"\binvoice\b|\bbill to\b|\bamount due\b", "invoice"),
        (r"\breceipt\b|\bthank you for your purchase\b", "receipt"),
        (r"\bresume\b|\bcurriculum vitae\b|\bexperience\b.*\beducation\b", "resume"),
        (r"\bcontract\b|\bagreement\b|\bterms and conditions\b", "contract"),
        (r"\bpayslip\b|\bsalary\b|\bnet pay\b|\bepf\b|\bpan\b", "payslip"),
        (r"\bpatient\b|\bprescription\b|\bdiagnosis\b", "medical"),
        (r"\bboarded\b|\bflight\b|\bgate\b|\bseat\b|\bpnr\b", "boarding pass"),
        (r"\bmarksheet\b|\bgrade\b|\bsemester\b|\buniversity\b", "academic record"),
        (r"\baadhaar\b|\bpan card\b|\bpassport\b|\blicence\b|\bdriving license\b", "id document"),
        (r"\bmeeting\b|\bagenda\b|\battendees\b|\bminutes\b", "meeting notes"),
    ]
    for pattern, name in probes:
        if re.search(pattern, low, re.S):
            return name
    return "document"


def _extract_fields(text: str, doc_type: str) -> Dict[str, str]:
    fields: Dict[str, str] = {}
    patterns = {
        "invoice_number": r"(?:invoice|bill)\s*(?:no\.?|number|#)?\s*[:\-]?\s*([A-Z0-9\-/]{3,25})",
        "date": r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}\s+\w+\s+\d{4})\b",
        "total": r"(?:total|amount due|grand total|net pay|amount payable)\s*[:\-]?\s*"
                 r"((?:₹|Rs\.?|\$|€|£|INR|USD)?\s?\d[\d,]*(?:\.\d{1,2})?)",
        "currency": r"\b(INR|USD|EUR|GBP|₹|\$|€|£)\b",
        "email": r"([\w.+-]+@[\w-]+\.[\w.-]+)",
        "phone": r"(\+?\d[\d\s\-()]{8,16}\d)",
        "gstin": r"\bGSTIN\s*[:\-]?\s*([0-9A-Z]{15})\b",
        "pan": r"\b([A-Z]{5}\d{4}[A-Z])\b",
        "account": r"(?:a/c|account)\s*(?:no\.?|number)?\s*[:\-]?\s*(\d{6,20})",
        "ifsc": r"\b([A-Z]{4}0[A-Z0-9]{6})\b",
        "due_date": r"(?:due|pay by|payment due)\s*(?:date)?\s*[:\-]?\s*"
                    r"(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}\s+\w+\s+\d{4})",
        "name": r"(?:name|patient|candidate)\s*[:\-]\s*([A-Z][\w'.\- ]{2,40})",
    }
    order = {
        "invoice": ["invoice_number", "date", "due_date", "total", "currency", "gstin"],
        "receipt": ["date", "total", "currency"],
        "payslip": ["date", "total", "pan", "account", "ifsc"],
        "resume": ["name", "email", "phone"],
        "id document": ["name", "pan", "date"],
        "medical": ["name", "date"],
    }.get(doc_type, ["date", "total", "email", "phone", "name"])

    for key in list(order) + [k for k in patterns if k not in order]:
        if key in fields:
            continue
        m = re.search(patterns[key], text, re.I)
        if m:
            fields[key] = m.group(1).strip()
        if len(fields) >= 12:
            break
    return fields


@tool(
    name="vision.camera",
    capability="vision.camera",
    agent="vision",
    device="pc",
    description="Take one photo from the PC webcam and analyse it (privacy-gated, off by default)",
    risk="HIGH",
    confirm=True,
    timeout=120,
)
async def vision_camera(ctx: ToolContext, question: str = "", device_index: int = 0,
                        ocr: bool = False) -> Dict[str, Any]:
    if not settings.pc_screen_capture_enabled:
        return {"ok": False, "error": "camera/screen capture is disabled in SAM settings",
                "blocked": True}
    try:
        import cv2  # type: ignore
    except ImportError:
        return {"ok": False,
                "error": "OpenCV is not installed, so SAM cannot use the camera",
                "install": "pip install opencv-python"}

    out_dir = settings.sam_data_dir / "cache" / "camera"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"sam_cam_{int(time.time() * 1000)}.jpg"

    def _grab() -> Optional[str]:
        cap = cv2.VideoCapture(int(device_index))
        try:
            if not cap.isOpened():
                return None
            # let auto-exposure settle
            for _ in range(6):
                cap.read()
            ok, frame = cap.read()
            if not ok or frame is None:
                return None
            cv2.imwrite(str(out), frame)
            return str(out)
        finally:
            cap.release()

    captured = await _run_in_thread(_grab)
    if not captured:
        return {"ok": False, "error": f"could not capture from camera index {device_index}",
                "hint": "check that no other app is using the camera and that SAM has camera "
                        "permission in Windows Settings → Privacy → Camera"}

    result: Dict[str, Any] = {"ok": True, "path": captured, "captured_at": time.time()}
    if ocr:
        result["ocr"] = await vision_ocr(ctx, path=captured)
    result["analysis"] = await vision_analyse(ctx, path=captured, question=question)
    result["answer"] = result["analysis"].get("answer") or result["analysis"].get("text", "")
    return result


async def _run_in_thread(fn: Any) -> Any:
    import asyncio

    return await asyncio.to_thread(fn)


@tool(
    name="vision.compare",
    capability="vision.image_analysis",
    agent="vision",
    device="pc",
    description="Compare two images and report the differences",
    risk="LOW",
    timeout=240,
)
async def vision_compare(ctx: ToolContext, path_a: str = "", path_b: str = "",
                         question: str = "") -> Dict[str, Any]:
    a, ua, err_a = _resolve_image(path_a)
    b, ub, err_b = _resolve_image(path_b)
    if err_a or err_b:
        return {"ok": False, "error": err_a or err_b}
    uri_a = ua or _to_data_uri(a)
    uri_b = ub or _to_data_uri(b)

    diff: Dict[str, Any] = {}
    if a and b:
        diff = _pixel_diff(Path(a), Path(b))

    result = await _vision(
        "You are given two images, A and B. Report every meaningful difference: "
        "added, removed, moved or changed elements, text changes, colour changes. "
        "If they are the same, say so explicitly. Do not invent differences.",
        [uri_a, uri_b],
    )
    if not result.get("ok"):
        result = {"ok": True, "text": "(no vision model available — only the pixel diff is reported)",
                  "generated_by": "sam-offline-heuristic"}
    result.update({"pixel_diff": diff, "image_a": str(a) if a else "(inline)",
                   "image_b": str(b) if b else "(inline)", "question": question,
                   "answer": result.get("text", "")})
    return result


def _pixel_diff(a: Path, b: Path) -> Dict[str, Any]:
    try:
        from PIL import Image, ImageChops

        with Image.open(a) as ia, Image.open(b) as ib:
            ra, rb = ia.convert("RGB"), ib.convert("RGB")
            if ra.size != rb.size:
                return {"same_size": False, "size_a": ra.size, "size_b": rb.size,
                        "changed_percent": 100.0}
            rb = rb.resize(ra.size)
            diff = ImageChops.difference(ra, rb)
            grey = diff.convert("L")
            pixels = list(grey.getdata())
            changed = sum(1 for p in pixels if p > 12)
            bbox = diff.getbbox()
            return {"same_size": True, "size": list(ra.size),
                    "changed_percent": round(changed / max(len(pixels), 1) * 100, 2),
                    "changed_region": list(bbox) if bbox else None,
                    "identical": changed == 0}
    except Exception as exc:
        return {"error": str(exc)[:200]}


@tool(
    name="vision.describe_screen",
    capability="vision.screen_capture",
    agent="vision",
    device="pc",
    description="Capture the screen and describe what SAM sees, including UI elements",
    risk="HIGH",
    confirm=True,
    timeout=240,
)
async def vision_describe_screen(ctx: ToolContext, question: str = "",
                                 region: str = "full", window: str = "") -> Dict[str, Any]:
    from backend.app.tools.registry import registry

    shot = registry.get("pc.screenshot")
    if shot is None:
        return {"ok": False, "error": "pc.screenshot is not registered"}
    captured = await shot.fn(ctx, region=region, window=window, analyze=False)
    if not captured.get("ok") or not captured.get("path"):
        return captured
    analysis = await vision_analyse(ctx, path=captured["path"], question=question)
    understand = registry.get("pc.screen.understand")
    if understand is not None and question:
        try:
            analysis["ui"] = await understand.fn(ctx, question=question,
                                                 image_path=captured["path"])
        except Exception as exc:
            analysis["ui_error"] = str(exc)[:200]
    analysis["screenshot"] = captured["path"]
    return analysis
