"""
backend.app.tools.browser_tools
===============================

Thin, guarded wrappers around :mod:`backend.app.browser.engine`.

Everything here goes through the tool registry, so the permission + risk +
confirmation + audit pipeline applies to each browser action exactly like any
other SAM operation.

Safety rules baked in
---------------------
* SAM never navigates to a payment/checkout URL without ``browser.credentials``
  and an explicit confirmation (the Risk Engine scores it HIGH).
* Form fills that touch a password field are refused outright.
* Private/local addresses (``localhost``, cloud metadata endpoints) are blocked.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from backend.app.browser.engine import browser_engine, normalize_url
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.browser")

SENSITIVE_URL = re.compile(
    r"(checkout|payment|pay\b|billing|cart|order|bank|netbanking|upi|"
    r"login\.live|accounts\.google\.com/signin|signin|auth|password)",
    re.I,
)
PASSWORD_FIELD = re.compile(r"(password|passwd|pwd|otp|cvv|pin)", re.I)


@tool(
    name="browser.navigate",
    capability="browser.open",
    agent="browser",
    device="browser",
    description="Open a URL, a search query, or an engine:query pair in the browser",
    schema={"url": {"type": "string", "required": True}},
    risk="MEDIUM",
    timeout=90,
)
async def navigate(ctx: ToolContext, url: str = "", request: str = "",
                   wait: str = "domcontentloaded") -> Dict[str, Any]:
    target = url or request
    if not target:
        return {"ok": False, "error": "no URL or search query given"}
    final = normalize_url(target)
    if SENSITIVE_URL.search(final):
        return {"ok": False, "blocked": True,
                "error": ("this looks like a sign-in or payment page. SAM will not drive "
                          "authentication or checkout flows automatically."),
                "url": final,
                "hint": "open it yourself, then ask SAM to read or act on the page you landed on"}
    return await browser_engine.navigate(final, wait=wait)


@tool(
    name="browser.read_page",
    capability="browser.read",
    agent="browser",
    device="browser",
    description="Read the current page: text, headings, links, tables, forms and metadata",
    risk="LOW",
    timeout=90,
)
async def read_page(ctx: ToolContext, screenshot: bool = False, max_text: int = 200_000) -> Dict[str, Any]:
    snap = await browser_engine.snapshot(include_screenshot=screenshot, max_text=int(max_text))
    data = snap.to_dict()
    data["ok"] = not snap.meta.get("error")
    if snap.meta.get("error"):
        data["error"] = snap.meta["error"]
    return data


@tool(
    name="browser.extract",
    capability="browser.read",
    agent="browser",
    device="browser",
    description="Extract structured data from the page (selector, links, table, json-ld, text)",
    risk="LOW",
    timeout=90,
)
async def extract(ctx: ToolContext, selector: str = "", kind: str = "text",
                  limit: int = 200, query: str = "") -> Dict[str, Any]:
    if query and not kind:
        low = query.lower()
        if "table" in low:
            kind = "table"
        elif "link" in low:
            kind = "links"
        elif "price" in low or "product" in low:
            kind = "json_ld"
    return await browser_engine.extract(selector=selector, kind=kind or "text", limit=int(limit))


@tool(
    name="browser.click",
    capability="browser.interact",
    agent="browser",
    device="browser",
    description="Click an element by CSS selector or by its visible text",
    risk="MEDIUM",
    confirm=True,
    timeout=60,
)
async def click(ctx: ToolContext, selector: str = "", text: str = "", index: int = 0) -> Dict[str, Any]:
    if not selector and not text:
        return {"ok": False, "error": "click needs a selector or text"}
    if SENSITIVE_URL.search(browser_engine._page.url if browser_engine._page else ""):
        return {"ok": False, "blocked": True,
                "error": "SAM will not click inside an authentication or payment page"}
    return await browser_engine.click(selector=selector, text=text, index=int(index))


@tool(
    name="browser.form_fill",
    capability="browser.interact",
    agent="browser",
    device="browser",
    description="Fill form fields by selector; password/OTP fields are always refused",
    risk="MEDIUM",
    confirm=True,
    timeout=90,
)
async def form_fill(ctx: ToolContext, fields: Optional[Dict[str, str]] = None,
                    submit: bool = False, submit_selector: str = "") -> Dict[str, Any]:
    fields = fields or {}
    if not fields:
        return {"ok": False, "error": "no fields given"}
    refused = [k for k in fields if PASSWORD_FIELD.search(k)]
    if refused:
        return {"ok": False, "blocked": True,
                "error": f"SAM will not type into credential fields: {refused}",
                "hint": "fill the password yourself, then ask SAM to continue"}
    if submit and SENSITIVE_URL.search(browser_engine._page.url if browser_engine._page else ""):
        return {"ok": False, "blocked": True,
                "error": "SAM will not submit a form on an authentication or payment page"}
    return await browser_engine.fill_form(fields, submit=submit, submit_selector=submit_selector)


@tool(
    name="browser.tabs",
    capability="browser.open",
    agent="browser",
    device="browser",
    description="List, open, switch or close browser tabs",
    risk="LOW",
    timeout=45,
)
async def tabs(ctx: ToolContext, action: str = "list", index: Optional[int] = None,
               url: str = "") -> Dict[str, Any]:
    action = (action or "list").lower()
    if action in ("list", "get"):
        return await browser_engine.tabs()
    if action in ("new", "open", "add"):
        return await browser_engine.new_tab(normalize_url(url) if url else "")
    if action in ("switch", "select", "focus"):
        if index is None:
            return {"ok": False, "error": "switch needs a tab index"}
        return await browser_engine.switch_tab(int(index))
    if action in ("close", "kill"):
        return await browser_engine.close_tab(int(index) if index is not None else None)
    return {"ok": False, "error": f"unknown tab action '{action}'",
            "supported": ["list", "new", "switch", "close"]}


@tool(
    name="browser.screenshot",
    capability="browser.read",
    agent="browser",
    device="browser",
    description="Screenshot the current browser page",
    risk="LOW",
    timeout=60,
)
async def browser_screenshot(ctx: ToolContext, full_page: bool = False) -> Dict[str, Any]:
    return await browser_engine.screenshot(full_page=full_page)


@tool(
    name="browser.download",
    capability="browser.download",
    agent="browser",
    device="browser",
    description="Download a file from the current page",
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def download(ctx: ToolContext, selector: str = "", url: str = "",
                   save_dir: str = "") -> Dict[str, Any]:
    return await browser_engine.download(selector=selector, url=url, save_dir=save_dir or None)


@tool(
    name="browser.bookmarks",
    capability="browser.read",
    agent="browser",
    device="browser",
    description="List, add or remove SAM-managed bookmarks",
    risk="LOW",
    timeout=30,
)
async def bookmarks(ctx: ToolContext, action: str = "list", title: str = "", url: str = "",
                    folder: str = "") -> Dict[str, Any]:
    return await browser_engine.bookmarks(action, title=title, url=url, folder=folder)


@tool(
    name="browser.page_info",
    capability="browser.read",
    agent="browser",
    device="browser",
    description="Inspect the current page: URL, title, meta, word/link/image counts",
    risk="LOW",
    timeout=30,
)
async def page_info(ctx: ToolContext) -> Dict[str, Any]:
    return await browser_engine.page_info()


@tool(
    name="browser.status",
    capability="browser.read",
    agent="browser",
    device="browser",
    description="Report the browser engine state, transport and recent history",
    risk="LOW",
    timeout=30,
)
async def browser_status(ctx: ToolContext) -> Dict[str, Any]:
    return await browser_engine.status()


@tool(
    name="browser.scroll",
    capability="browser.interact",
    agent="browser",
    device="browser",
    description="Scroll the page up or down",
    risk="LOW",
    timeout=30,
)
async def scroll(ctx: ToolContext, direction: str = "down", amount: int = 800) -> Dict[str, Any]:
    return await browser_engine.scroll(direction, int(amount))


@tool(
    name="browser.wait",
    capability="browser.read",
    agent="browser",
    device="browser",
    description="Wait for a selector or text to appear on the page",
    risk="LOW",
    timeout=60,
)
async def wait_for(ctx: ToolContext, selector: str = "", text: str = "",
                   timeout: int = 20_000) -> Dict[str, Any]:
    return await browser_engine.wait_for(selector=selector, text=text, timeout=int(timeout))


@tool(
    name="browser.stop",
    capability="browser.open",
    agent="browser",
    device="browser",
    description="Close the automated browser session",
    risk="LOW",
    timeout=30,
)
async def browser_stop(ctx: ToolContext) -> Dict[str, Any]:
    return await browser_engine.stop()
