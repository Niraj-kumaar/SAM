"""
backend.app.tools.core_tools
============================

The Core Brain's own tools.

``core.answer`` is the tool the Planner picks when the request needs no action
at all — just a thoughtful reply. It is still a tool, so it is planned, audited
and verified like everything else, and it can pull long-term memory into the
answer.

Also here: ``core.capabilities`` (what SAM can do right now, on this machine)
and ``core.help`` — both are what makes SAM self-describing instead of opaque.
"""

from __future__ import annotations

import platform
import time
from typing import Any, Dict, List, Optional

import psutil

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.memory.store import memory_store
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.core")


@tool(
    name="core.answer",
    capability="ai.chat",
    agent="core",
    device="both",
    description="Answer a question or hold a conversation, using memory and live system context",
    schema={"question": {"type": "string", "required": True}},
    risk="LOW",
    timeout=180,
)
async def core_answer(ctx: ToolContext, question: str = "", request: str = "",
                      use_memory: bool = True, language: str = "", style: str = "",
                      max_words: int = 0) -> Dict[str, Any]:
    from backend.app.models.router import router

    text = (question or request or ctx.user_text or "").strip()
    if not text:
        return {"ok": False, "error": "nothing to answer — the message was empty"}

    lang = language or ctx.language or "auto"
    memories: List[Dict[str, Any]] = []
    if use_memory:
        try:
            memories = await memory_store.recall(text, limit=5)
        except Exception as exc:  # pragma: no cover
            log.debug("memory recall failed: %s", exc)

    persona = (
        "You are SAM, a professional AI operating platform running on the user's own computer. "
        "You can control the PC, the browser, files, an Android companion phone, and you can "
        "plan, code, research and create documents. "
        "You are concise, concrete and honest: you say what you did, what failed, and what you "
        "cannot do. You are always transparent that you are an AI. "
        "You never invent facts, file paths, prices, versions, tool output or results. "
        "If you do not know, you say so and offer the exact next step to find out."
    )
    if style:
        persona += f"\nThe user asked for this style: {style}."

    context_lines: List[str] = []
    if memories:
        context_lines.append("WHAT SAM REMEMBERS ABOUT THIS USER (use it only if relevant, "
                             "and never reveal credentials):")
        context_lines += [f"- {m['content'][:200]}" for m in memories]
    try:
        batt = psutil.sensors_battery()
        context_lines.append(
            "CURRENT MACHINE STATE: "
            f"{platform.system()} {platform.release()}, {psutil.cpu_count()} cores, "
            f"CPU {psutil.cpu_percent(interval=0.1):.0f}%, "
            f"RAM {psutil.virtual_memory().percent:.0f}%"
            + (f", battery {batt.percent:.0f}%"
               f"{' (charging)' if batt.power_plugged else ''}" if batt else "")
        )
    except Exception:
        pass
    context_lines.append(f"LOCAL TIME: {time.strftime('%A %d %B %Y, %H:%M')}")
    context_lines.append(f"SAM MODE: {settings.sam_mode} · tools registered: {len(registry.names())}")

    prompt_parts = [persona]
    if context_lines:
        prompt_parts.append("\n".join(context_lines))
    prompt_parts.append(f"USER (language: {lang}):\n{text}")
    if max_words:
        prompt_parts.append(f"Keep the reply under {int(max_words)} words.")
    if lang and lang.lower() not in ("auto", "en", "english", ""):
        prompt_parts.append(f"Reply in this language: {lang}.")
    prompt = "\n\n".join(prompt_parts)

    res = await router.ask(prompt, role=_role_for(text), temperature=0.5,
                           max_tokens=1200, system=persona)
    if not res.ok:
        fallback = _offline_answer(text, memories)
        return {"ok": True, "answer": fallback, "text": fallback, "model": None,
                "provider": "sam-offline-heuristic", "memories_used": len(memories),
                "warning": res.error or "no model responded — SAM answered from local context only"}

    answer = (res.text or "").strip()
    return {
        "ok": True, "answer": answer, "text": answer, "model": res.model,
        "provider": res.provider, "role": _role_for(text), "latency_ms": res.latency_ms,
        "usage": {"prompt_tokens": res.prompt_tokens,
                  "completion_tokens": res.completion_tokens,
                  "total_tokens": res.total_tokens},
        "language": lang, "memories_used": len(memories), "local": res.local,
        "memories": [m["content"][:160] for m in memories],
    }


def _role_for(text: str) -> str:
    low = text.lower()
    if any(k in low for k in ("why", "prove", "compare", "analyse", "analyze", "trade-off",
                              "design", "strategy", "explain the difference", "step by step")):
        return "reasoning"
    if any(k in low for k in ("code", "function", "bug", "error", "api", "sql", "python",
                              "javascript", "regex")):
        return "coding"
    if len(text) < 60 and not any(c in text for c in "?"):
        return "fast"
    return "primary"


def _offline_answer(text: str, memories: List[Dict[str, Any]]) -> str:
    """A useful, honest reply when no model can be reached."""
    lines = [
        "SAM could not reach any AI model right now, so here is what it can tell you locally.",
        "",
        f"Your message: “{text[:200]}”",
        "",
    ]
    if memories:
        lines += ["What SAM remembers that may be relevant:"]
        lines += [f"- {m['content'][:200]}" for m in memories]
        lines.append("")
    lines += [
        "Current status:",
        f"- Mode: {settings.sam_mode}",
        f"- Cloud AI allowed: {'yes' if settings.cloud_enabled else 'no'}",
        f"- Local models (Ollama) enabled: {'yes' if settings.ollama_enabled else 'no'} "
        f"at {settings.ollama_base_url}",
        f"- Tools registered: {len(registry.names())}",
        "",
        "To get a real answer, do one of these:",
        "1. Start Ollama (`ollama serve`) and pull a model (`ollama pull llama3.1:8b`).",
        "2. Put an API key in SAM-AI/.env (OPENAI_API_KEY, ANTHROPIC_API_KEY, GOOGLE_API_KEY, "
        "GROQ_API_KEY or OPENROUTER_API_KEY).",
        "3. Restart SAM and ask again.",
    ]
    return "\n".join(lines)


@tool(
    name="core.capabilities",
    capability="ai.chat",
    agent="core",
    device="pc",
    description="Report what SAM can actually do on this machine right now",
    risk="LOW",
    timeout=60,
)
async def core_capabilities(ctx: ToolContext, category: str = "") -> Dict[str, Any]:
    from backend.app.security.permissions import permission_engine

    tools = registry.all()
    by_agent: Dict[str, List[Dict[str, Any]]] = {}
    for t in tools:
        granted = permission_engine.granted(t.capability)
        entry = {"name": t.name, "capability": t.capability, "description": t.description,
                 "risk": t.risk, "confirm": t.confirm, "platform": t.platform,
                 "available": t.is_available(), "granted": granted,
                 "usable": t.is_available() and granted, "calls": t.calls}
        if category and category.lower() not in t.name.lower() \
                and category.lower() != t.agent:
            continue
        by_agent.setdefault(t.agent, []).append(entry)

    usable = sum(1 for group in by_agent.values() for t in group if t["usable"])
    blocked = [t["name"] for group in by_agent.values() for t in group
               if t["available"] and not t["granted"]]
    unavailable = [t["name"] for group in by_agent.values() for t in group
                   if not t["available"]]

    markdown = ["# What SAM can do right now", "",
                f"**{usable} of {len(tools)} tools are usable** on this machine "
                f"({platform.system()} {platform.release()}, Python {platform.python_version()}).", ""]
    for agent in sorted(by_agent):
        group = by_agent[agent]
        ready = [t["name"] for t in group if t["usable"]]
        markdown.append(f"## {agent.replace('_', ' ').title()} brain — "
                        f"{len(ready)}/{len(group)} ready")
        if ready:
            markdown.append("- " + ", ".join(f"`{n}`" for n in ready))
        blocked_here = [t["name"] for t in group if t["available"] and not t["granted"]]
        if blocked_here:
            markdown.append(f"- _needs permission_: {', '.join(blocked_here)}")
        markdown.append("")
    if blocked:
        markdown += ["## Waiting for your permission", "",
                     f"{len(blocked)} tool(s) are installed but not granted. "
                     "Open SECURITY to review them.", ""]
    if unavailable:
        markdown += ["## Not available on this platform", "",
                     ", ".join(unavailable), ""]
    return {
        "ok": True, "total_tools": len(tools), "usable": usable,
        "by_agent": {k: len(v) for k, v in by_agent.items()},
        "needs_permission": blocked, "unavailable": unavailable,
        "tools": by_agent, "markdown": "\n".join(markdown),
        "platform": platform.system(), "mode": settings.sam_mode,
        "answer": f"{usable} of {len(tools)} tools are ready to use right now.",
    }


@tool(
    name="core.help",
    capability="ai.chat",
    agent="core",
    device="both",
    description="Explain how to use SAM, with real examples that work on this machine",
    risk="LOW",
    timeout=60,
)
async def core_help(ctx: ToolContext, topic: str = "", request: str = "") -> Dict[str, Any]:
    topic = (topic or request or ctx.user_text or "").lower()
    sections: Dict[str, Dict[str, Any]] = {
        "voice": {
            "title": "Talking to SAM",
            "lines": [
                "Say or type what you want done — SAM plans it, picks the right brain and tools, "
                "asks before anything risky, then reports what happened.",
                "Wake word: “hey sam” (enable it in SETTINGS → VOICE).",
                "Voice modes: STANDARD, CONVERSATIONAL, PROFESSIONAL, FAST, QUIET, STUDY, "
                "CODING, COMPANION.",
                "You can interrupt SAM while it speaks; it stops and listens.",
                "Mixed-language speech is detected automatically (English + Hindi + Kannada).",
            ],
        },
        "pc": {
            "title": "Controlling this PC",
            "lines": [
                "“open chrome”, “close notepad”, “minimise this window”, “take a screenshot”",
                "“what's using my CPU”, “set volume to 30”, “lock the PC”, “sleep in 5 minutes”.",
                "Keyboard and mouse automation run through the same permission and risk engine.",
                "Power actions (restart/shutdown/sign out) always need typed confirmation.",
            ],
        },
        "files": {
            "title": "Files",
            "lines": [
                "“find the invoice from Acme last March” — semantic search over indexed content.",
                "“organise my Downloads by type”, “find duplicate photos”, “zip this folder”",
                "“convert report.md to PDF”, “back up Documents”.",
                f"SAM can only touch: {', '.join(str(r) for r in settings.allowed_roots)}.",
                "Deletes go to the recycle bin, never straight to disk.",
            ],
        },
        "coding": {
            "title": "Coding",
            "lines": [
                "“create a python project that ...”, “explain this file”, “run the tests”",
                "“fix the failing test”, “write a README for this repo”.",
                "The pipeline is: analyse → architecture → generate → write → run → diagnose → "
                "repair → retest → document.",
                "Terminal commands are risk-scored; 23 destructive patterns are blocked outright.",
            ],
        },
        "research": {
            "title": "Research",
            "lines": [
                "“research X and cite sources”, “compare these three options”, “summarise this page”.",
                "Facts come back labelled verified / uncertain / conflicting / outdated, "
                "each with a numbered source list.",
                "Works keyless (DuckDuckGo, Wikipedia, arXiv); add BRAVE_API_KEY or "
                "TAVILY_API_KEY for better results.",
            ],
        },
        "phone": {
            "title": "Phone",
            "lines": [
                "Install the SAM Companion app, then “pair my phone” — SAM shows a code and QR.",
                "“phone battery”, “turn on battery saver”, “read my notifications”, "
                "“send a message to ...” (prepare → preview → confirm → send).",
                "Android's permission model is authoritative: if a permission is missing, SAM "
                "tells you exactly which one and never tries to bypass it.",
                "Without the companion, SAM falls back to ADB for read-only status.",
            ],
        },
        "browser": {
            "title": "Browser",
            "lines": [
                "SAM drives your own browser session (Playwright, or attach to Chrome on port 9222).",
                "“open github”, “read this page”, “extract the table”, “fill this form”.",
                "SAM refuses checkout, banking, sign-in and OTP/password fields — always.",
            ],
        },
        "security": {
            "title": "Security & permissions",
            "lines": [
                "Every action is classified LOW / MEDIUM / HIGH / CRITICAL.",
                "LOW runs automatically, MEDIUM asks a simple yes/no, HIGH needs typed "
                "confirmation, CRITICAL needs a passphrase SAM never remembers.",
                "“show the security report”, “revoke terminal access”, “what did SAM do today”.",
                "Nothing is ever hidden: every action is in the audit log.",
            ],
        },
        "automation": {
            "title": "Scheduling & automation",
            "lines": [
                "“every day at 9am summarise my inbox”, “remind me in 20 minutes”, "
                "“when battery is low, turn on battery saver”.",
                "Rules are WHEN → IF → DO → VERIFY, and each run is recorded with its result.",
                "Task Control Center shows status, progress, current action, logs and errors.",
            ],
        },
        "memory": {
            "title": "Memory",
            "lines": [
                "“remember that I prefer dark mode”, “what do you know about me”, "
                "“forget that”, “clear all memory”.",
                "SAM refuses to store passwords, keys and card numbers.",
                "You can view, edit, disable or erase any memory item from the MEMORY page.",
            ],
        },
        "creative": {
            "title": "Creative & documents",
            "lines": [
                "“generate a poster for ...”, “write a LinkedIn post pack”, “make a 60-second script”.",
                "“write a report on X as PDF/PPTX/XLSX/DOCX” — Markdown in, real files out.",
                "Image generation uses OpenAI, Stability or a local Stable Diffusion; with none "
                "configured SAM still returns a real design brief and a placeholder poster.",
            ],
        },
        "models": {
            "title": "Models & modes",
            "lines": [
                "Roles: primary, reasoning, fast, coding, vision, STT, TTS, translation, "
                "embedding, image, local, fallback.",
                "Modes: ONLINE (cloud), LOCAL (Ollama only), HYBRID (default).",
                "Privacy toggles: cloud AI, external web, phone sync, telemetry, local models, "
                "local memory.",
            ],
        },
    }

    matched: List[Dict[str, Any]] = []
    if topic:
        for key, section in sections.items():
            if key in topic or any(word in topic for word in section["title"].lower().split()):
                matched.append({"key": key, **section})
    if not matched:
        matched = [{"key": k, **v} for k, v in sections.items()]

    markdown = ["# How to use SAM", ""]
    for section in matched:
        markdown.append(f"## {section['title']}")
        markdown += [f"- {line.rstrip(',')}" for line in section["lines"]]
        markdown.append("")
    markdown += ["## Quick starts", "",
                 "- `open chrome and go to github`",
                 "- `find all invoices from last month and convert them to pdf`",
                 "- `create a python project that renames my screenshots by date`",
                 "- `research the best noise-cancelling headphones under 20000 inr and compare them`",
                 "- `every weekday at 9am summarise my unread email`",
                 "- `show the security report`", ""]

    return {"ok": True, "topic": topic or "(all)", "sections": matched,
            "markdown": "\n".join(markdown),
            "answer": "\n".join(markdown)[:4000]}
