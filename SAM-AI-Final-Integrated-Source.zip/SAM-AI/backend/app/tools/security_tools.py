"""
backend.app.tools.security_tools
================================

Tools that expose the Security Center to the user and to SAM itself:
permission state, risk explanation, audit history and the security posture
report shown on the dashboard.
"""

from __future__ import annotations

import platform
import time
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.security.audit import audit_trail
from backend.app.security.confirmation_engine import confirmation_engine
from backend.app.security.permissions import BY_NAME, permission_engine
from backend.app.security.risk_engine import risk_engine
from backend.app.tools.registry import ToolContext, tool

log = get_logger("tools.security")


@tool(
    name="security.report",
    capability="ai.chat",
    agent="security",
    device="pc",
    description="Produce the Security Center report: permissions, risk mode, audit stats",
    risk="LOW",
    timeout=60,
)
async def security_report(ctx: ToolContext) -> Dict[str, Any]:
    caps = permission_engine.state()
    granted = [c for c in caps if c["granted"]]
    denied = [c for c in caps if not c["granted"]]
    by_category: Dict[str, Dict[str, int]] = {}
    for c in caps:
        bucket = by_category.setdefault(c["category"], {"granted": 0, "denied": 0})
        bucket["granted" if c["granted"] else "denied"] += 1

    audit = await audit_trail.stats()
    pending = confirmation_engine.pending()

    groups = {
        "Microphone": any(c["granted"] for c in caps if c["capability"] == "voice.microphone"),
        "Camera": any(c["granted"] for c in caps if c["capability"] == "vision.camera"),
        "PC Control": any(c["granted"] for c in caps if c["capability"].startswith("pc.")),
        "Phone Control": any(c["granted"] for c in caps if c["capability"].startswith("phone.")),
        "File Write": any(c["granted"] for c in caps if c["capability"] in ("files.write", "files.move", "files.delete")),
        "Terminal": any(c["granted"] for c in caps if c["capability"] == "pc.terminal.run"),
        "Browser": any(c["granted"] for c in caps if c["capability"].startswith("browser.")),
        "Contacts": any(c["granted"] for c in caps if c["capability"] == "phone.contacts"),
        "Location": any(c["granted"] for c in caps if c["capability"] == "phone.location"),
        "Cloud AI": settings.cloud_enabled,
        "External Web": settings.web_enabled,
        "Phone Sync": settings.privacy_phone_sync,
        "Telemetry": settings.privacy_telemetry,
        "Local Models": settings.privacy_local_models,
        "Local Memory": settings.privacy_local_memory,
    }

    markdown = _render_report(groups, by_category, audit, pending)
    return {
        "ok": True,
        "risk_mode": settings.security_risk_mode,
        "audit_enabled": settings.security_audit_enabled,
        "sam_mode": settings.sam_mode,
        "groups": groups,
        "by_category": by_category,
        "capabilities_total": len(caps),
        "granted": len(granted),
        "denied": len(denied),
        "granted_list": [c["capability"] for c in granted],
        "denied_list": [c["capability"] for c in denied],
        "pending_confirmations": pending,
        "audit": audit,
        "markdown": markdown,
        "platform": platform.system(),
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def _render_report(groups: Dict[str, bool], by_category: Dict[str, Dict[str, int]],
                   audit: Dict[str, Any], pending: List[Dict[str, Any]]) -> str:
    lines = ["# SAM Security Center", ""]
    lines += ["## Capability switches", ""]
    width = max((len(k) for k in groups), default=10)
    for key, value in groups.items():
        lines.append(f"    {key.ljust(width)}   {'ON' if value else 'OFF'}")
    lines += ["", f"Risk mode: **{settings.security_risk_mode}**",
              f"Audit log: **{'enabled' if settings.security_audit_enabled else 'disabled'}**",
              f"Running mode: **{settings.sam_mode}**", "",
              "## Permissions by category", "",
              "| Category | Granted | Not granted |", "| --- | --- | --- |"]
    for cat, counts in sorted(by_category.items()):
        lines.append(f"| {cat} | {counts['granted']} | {counts['denied']} |")
    lines += ["", "## Audit summary", "",
              f"- Total recorded actions: **{audit.get('total', 0):,}**"]
    for result, count in sorted((audit.get("by_result") or {}).items()):
        lines.append(f"- {result}: {count:,}")
    for risk, count in sorted((audit.get("by_risk") or {}).items()):
        lines.append(f"- risk {risk}: {count:,}")
    if pending:
        lines += ["", "## Awaiting your approval", ""]
        for p in pending:
            lines.append(f"- **{p['action']}** ({p['risk']}) — {p['target'] or 'no target'}")
    else:
        lines += ["", "_Nothing is waiting for approval._"]
    return "\n".join(lines)


@tool(
    name="security.permissions",
    capability="ai.chat",
    agent="security",
    device="pc",
    description="List every SAM capability and whether it is currently granted",
    risk="LOW",
    timeout=30,
)
async def security_permissions(ctx: ToolContext, category: str = "", search: str = "") -> Dict[str, Any]:
    caps = permission_engine.state()
    if category:
        caps = [c for c in caps if c["category"].lower() == category.lower()]
    if search:
        s = search.lower()
        caps = [c for c in caps if s in c["capability"].lower() or s in c["description"].lower()]
    return {"ok": True, "count": len(caps), "capabilities": caps,
            "groups": permission_engine.summary()}


@tool(
    name="security.set_permission",
    capability="ai.chat",
    agent="security",
    device="pc",
    description="Grant or revoke a SAM capability (always requires confirmation)",
    risk="HIGH",
    confirm=True,
    timeout=30,
)
async def security_set_permission(ctx: ToolContext, capability: str = "", granted: bool = True,
                                  requires_confirmation: Optional[bool] = None) -> Dict[str, Any]:
    if capability not in BY_NAME:
        near = [c for c in BY_NAME if capability.lower() in c][:8]
        return {"ok": False, "error": f"unknown capability '{capability}'",
                "did_you_mean": near}
    result = await permission_engine.set_grant(
        capability, granted=granted, requires_confirmation=requires_confirmation
    )
    audit_trail.record(action="security.set_permission", target=capability,
                       result="ok", risk="HIGH", confirmation="approved",
                       agent="security", detail=result)
    return {"ok": True, **result,
            "note": ("granted" if granted else "revoked") +
                    f" — {BY_NAME[capability].description}"}


@tool(
    name="security.audit",
    capability="ai.chat",
    agent="security",
    device="pc",
    description="Query the action history / audit log",
    risk="LOW",
    timeout=60,
)
async def security_audit(ctx: ToolContext, limit: int = 50, device: str = "", agent: str = "",
                         result: str = "", risk: str = "", since_hours: Optional[int] = None,
                         search: str = "", clear: bool = False,
                         clear_older_than_days: Optional[int] = None) -> Dict[str, Any]:
    if clear:
        n = await audit_trail.clear(older_than_days=clear_older_than_days)
        return {"ok": True, "cleared": n, "scope": "all" if clear_older_than_days is None
                else f"older than {clear_older_than_days} days"}
    data = await audit_trail.query(
        limit=int(limit), device=device or None, agent=agent or None, result=result or None,
        risk=risk or None, since_hours=since_hours, search=search or None,
    )
    data["ok"] = True
    data["stats"] = await audit_trail.stats()
    return data


@tool(
    name="security.risk_check",
    capability="ai.chat",
    agent="security",
    device="pc",
    description="Explain how SAM would classify a proposed action, without running it",
    risk="LOW",
    timeout=30,
)
async def security_risk_check(ctx: ToolContext, capability: str = "", action: str = "",
                              target: str = "") -> Dict[str, Any]:
    assessment = risk_engine.assess(capability=capability, action=action, target=target)
    perm = permission_engine.check(capability) if capability in BY_NAME else None
    return {
        "ok": True,
        "risk": assessment.to_dict(),
        "explanation": risk_engine.explain(assessment),
        "permission": perm.to_dict() if perm else None,
        "would_be_blocked": risk_engine.is_blocked(assessment.level),
    }


@tool(
    name="security.confirmations",
    capability="ai.chat",
    agent="security",
    device="pc",
    description="List pending and recent confirmation requests",
    risk="LOW",
    timeout=30,
)
async def security_confirmations(ctx: ToolContext, limit: int = 20) -> Dict[str, Any]:
    return {"ok": True, "pending": confirmation_engine.pending(),
            "history": confirmation_engine.history(int(limit)),
            "remembered_rules": len(confirmation_engine._rules)}


@tool(
    name="verification.check",
    capability="ai.chat",
    agent="verification",
    device="pc",
    description="Verify that a claimed action actually took effect",
    risk="LOW",
    timeout=90,
)
async def verification_check(ctx: ToolContext, kind: str = "auto", target: str = "",
                             expected: str = "") -> Dict[str, Any]:
    """
    Observation-based verification.

    ``kind``: file | process | app | url | setting | auto
    """
    kind = (kind or "auto").lower()
    text = target or expected or ctx.user_text

    if kind == "auto":
        low = text.lower()
        if low.endswith((".pdf", ".docx", ".xlsx", ".pptx", ".csv", ".md", ".txt", ".png", ".jpg")) \
                or "/" in low or "\\" in low:
            kind = "file"
        elif low.startswith("http"):
            kind = "url"
        else:
            kind = "process"

    checks: List[Dict[str, Any]] = []

    if kind == "file":
        from pathlib import Path

        p = Path(text).expanduser()
        exists = p.exists()
        checks.append({
            "check": "file exists", "target": str(p), "passed": exists,
            "detail": ({"bytes": p.stat().st_size,
                        "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(p.stat().st_mtime))}
                       if exists else "not found"),
        })
        if exists and p.stat().st_size == 0:
            checks.append({"check": "file is not empty", "passed": False, "detail": "0 bytes"})
        elif exists:
            checks.append({"check": "file is not empty", "passed": True,
                           "detail": f"{p.stat().st_size:,} bytes"})

    elif kind == "url":
        import httpx

        try:
            async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
                r = await client.get(text, headers={"User-Agent": "SAM/1.0"})
            checks.append({"check": "URL reachable", "target": text, "passed": r.status_code < 400,
                           "detail": f"HTTP {r.status_code}, {len(r.content):,} bytes"})
        except Exception as exc:
            checks.append({"check": "URL reachable", "target": text, "passed": False,
                           "detail": str(exc)[:200]})

    else:  # process / app
        import psutil

        needle = text.lower().removesuffix(".exe")
        found = []
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                name = (proc.info.get("name") or "").lower()
                if needle and (needle in name or name.startswith(needle)):
                    found.append({"pid": proc.info["pid"], "name": proc.info["name"]})
            except Exception:
                continue
        checks.append({"check": "process running", "target": needle, "passed": bool(found),
                       "detail": found[:5] if found else "no matching process"})

    passed = all(c["passed"] for c in checks) and bool(checks)
    return {"ok": passed, "verdict": "success" if passed else "failed", "kind": kind,
            "target": text, "checks": checks,
            "summary": ("verified: " if passed else "NOT verified: ") +
                       "; ".join(f"{c['check']}={'pass' if c['passed'] else 'fail'}" for c in checks)}
