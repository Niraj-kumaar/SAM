"""
backend.app.tools.code_exec_tools
=================================

**The developer-utility toolbox** — the "code interpreter" side of SAM that is
*not* arbitrary code execution.

Running a user's script is already handled by ``coding.execute`` (HIGH risk,
always confirmed, subprocess + timeout). These tools cover everything around it
that a ChatGPT-style assistant is asked for constantly: regex testing, JSON/YAML/
CSV surgery, hashing, encoding, JWT decoding, UUIDs, colour and contrast maths,
cron expressions, timestamps, SQLite queries, secret scanning, code metrics and
artifact generation. They are deterministic, offline and safe to leave enabled.

Security notes
--------------
* ``code.sql`` reads a database file only from SAM's own data root (or
  ``:memory:``), defaults to **read-only**, and any statement that can write
  (INSERT/UPDATE/DELETE/DROP/ALTER/PRAGMA journal…) is refused unless the caller
  passes ``allow_write=true``, which is a confirmed, audited action.
* ``code.artifact`` and ``code.qrcode`` only ever write inside the configured
  artifact directory — never to an arbitrary path.
* Nothing here shells out. ``coding.execute`` remains the only way to run code,
  and it stays behind a confirmation.

Tool map
--------
=========================  ===================================================
``code.regex``             test, explain and debug a regular expression
``code.json``              validate, format, minify, query, flatten, diff
``code.format_convert``    JSON ↔ YAML ↔ CSV ↔ TOML ↔ INI ↔ Markdown
``code.hash``              MD5/SHA1/SHA256/SHA512/BLAKE2 + HMAC + file hashes
``code.encode``            base64 / base32 / hex / URL / binary
``code.jwt``               decode and inspect a JWT, verify HS256 with a secret
``code.uuid``              generate and parse UUIDs (v1, v4, v5, nil)
``code.color``             hex ↔ RGB ↔ HSL, WCAG contrast, palettes
``code.cron``              explain a cron expression + the next run times
``code.timestamp``         Unix ↔ ISO ↔ human time, timezone conversion
``code.sql``               run a query against a local SQLite database
``code.number_base``       base conversion, bitwise ops, IEEE-754 float bits
``code.complexity``        lines, functions, nesting, cyclomatic complexity
``code.review``            static review: risky calls, secrets, smells
``code.secret_scan``       find leaked keys and tokens in text or files
``code.snippet``           generate a code snippet for a spec
``code.random_data``       fake datasets for testing (users, orders, events)
``code.artifact``          save generated text/code into the workspace
``code.qrcode``            make a QR code image (share a link with the phone)
=========================  ===================================================
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac as hmac_lib
import json
import math
import os
import random
import re
import struct
import time
import unicodedata
import uuid as uuid_lib
from datetime import datetime, timedelta, timezone as dt_timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, tool

log = get_logger("tools.code")

MAX_TEXT = 400_000          # characters any single tool will process
MAX_ROWS = 5_000            # rows code.sql will return


def _bad(message: str, **extra: Any) -> Dict[str, Any]:
    return {"ok": False, "error": message, **extra}


def _clip(text: str, limit: int = 4000) -> str:
    text = text or ""
    return text if len(text) <= limit else text[:limit] + f"\n… [{len(text) - limit:,} more characters]"


def _artifact_dir(category: str = "code") -> Path:
    """The only directory these tools are allowed to write into."""
    base = Path(settings.sam_data_dir) / "artifacts" / re.sub(r"[^\w.-]", "_", category or "code")
    base.mkdir(parents=True, exist_ok=True)
    return base



def _safe_name(name: str, default: str = "artifact.txt") -> str:
    cleaned = re.sub(r"[^\w.\-]+", "_", (name or "").strip())[:120].strip("._")
    return cleaned or default


# ===========================================================================
# 1. REGEX
# ===========================================================================
_TOKEN_EXPLAIN: List[Tuple[str, str]] = [
    (r"^\^", "match the start of the string"),
    (r"\$$", "match the end of the string"),
    (r"\\b", "a word boundary"),
    (r"\\B", "not a word boundary"),
    (r"\\d", "any digit (0-9)"),
    (r"\\D", "any non-digit"),
    (r"\\w", "any word character (letters, digits, underscore)"),
    (r"\\W", "any non-word character"),
    (r"\\s", "any whitespace"),
    (r"\\S", "any non-whitespace"),
    (r"\.\*", "any characters, zero or more (greedy)"),
    (r"\.\*\?", "any characters, zero or more (lazy — as few as possible)"),
    (r"\.\+", "one or more of any character (greedy)"),
    (r"\.", "any single character except a newline"),
    (r"\(\?=", "positive lookahead: what follows must match, but is not consumed"),
    (r"\(\?!", "negative lookahead: what follows must NOT match"),
    (r"\(\?\<=", "positive lookbehind"),
    (r"\(\?\<!", "negative lookbehind"),
    (r"\(\?P?\<\w+\>", "a named capture group"),
    (r"\(\?:", "a non-capturing group"),
    (r"\{n,m\}", "repeat the previous item between n and m times"),
    (r"\{n,\}", "repeat the previous item n or more times"),
    (r"\*", "repeat the previous item zero or more times"),
    (r"\+", "repeat the previous item one or more times"),
    (r"\?", "make the previous item optional"),
    (r"\|", "OR"),
    (r"\[", "a character class"),
    (r"\(", "start a capture group"),
]


def _explain_regex(pattern: str, flags: int) -> List[str]:
    notes: List[str] = []
    for rx, meaning in _TOKEN_EXPLAIN:
        if re.search(rx, pattern):
            notes.append(meaning)
    if flags & re.IGNORECASE:
        notes.append("case-insensitive matching is on")
    if flags & re.MULTILINE:
        notes.append("^ and $ match at every line, not just the whole string")
    if flags & re.DOTALL:
        notes.append(". also matches newlines (DOTALL)")
    if re.search(r"\\[1-9]", pattern):
        notes.append("uses a backreference to an earlier group")
    if re.search(r"\(\?i\)|\(\?s\)|\(\?m\)", pattern):
        notes.append("flags are set inline in the pattern itself")
    if not notes:
        notes.append("a plain literal pattern — it matches exactly these characters")
    return notes


@tool(
    name="code.regex",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Test a regular expression against sample text: matches, groups, spans, an explanation and common pitfalls",
    schema={"pattern": {"type": "string", "required": True},
            "text": {"type": "string", "required": True, "description": "the sample text to test"},
            "flags": {"type": "string", "default": "",
                      "description": "any of: i (ignorecase), m (multiline), s (dotall), x (verbose)"},
            "replace": {"type": "string", "description": "optional replacement to preview"},
            "limit": {"type": "integer", "default": 25}},
    risk="LOW",
    timeout=60,
)
async def code_regex(ctx: ToolContext, pattern: str = "", text: str = "", flags: str = "",
                     replace: Optional[str] = None, limit: int = 25,
                     request: str = "") -> Dict[str, Any]:
    if not pattern:
        return _bad("give me the regex pattern to test")
    if not text:
        return _bad("give me some sample text to test the pattern against")
    flag_bits = 0
    for ch in (flags or "").lower():
        flag_bits |= {"i": re.I, "m": re.M, "s": re.S, "x": re.X, "u": re.U}.get(ch, 0)
    try:
        rx = re.compile(pattern, flag_bits)
    except re.error as exc:
        return _bad(f"the pattern does not compile: {exc}", pattern=pattern,
                    hint="count your brackets and escape any literal ( ) [ ] { } * + ? . ^ $ | \\")
    if rx.groups > 20:
        return _bad("more than 20 capture groups — simplify the pattern")
    n = max(1, min(int(limit or 25), 200))
    matches: List[Dict[str, Any]] = []
    danger = False
    for m in rx.finditer(text[:MAX_TEXT]):
        if m.start() == m.end():                        # zero-length match: guard against a loop
            danger = True
            if len(matches) >= n:
                break
            matches.append({"index": len(matches), "match": "", "span": [m.start(), m.end()],
                            "groups": list(m.groups()), "named": dict(m.groupdict()),
                            "zero_length": True})
            if m.end() < len(text):
                rx_scan_pos = m.end() + 1
                continue
            break
        matches.append({"index": len(matches), "match": m.group(0)[:300],
                        "span": [m.start(), m.end()], "groups": [g[:100] if g else g
                                                                 for g in m.groups()],
                        "named": {k: (v[:100] if v else v) for k, v in m.groupdict().items()}})
        if len(matches) >= n:
            break
    replaced = None
    if replace is not None:
        try:
            replaced = rx.sub(replace, text[:MAX_TEXT], count=0)
        except (re.error, IndexError) as exc:
            replaced = f"[replacement failed: {exc}]"
    catastrophic = bool(re.search(r"(\+|\*|\{\d+,\})\s*\)?\s*(\+|\*|\{\d+,\})", pattern)) or \
        bool(re.search(r"\((?:[^()]*\|)+[^()]*\)(\+|\*|\{)", pattern))
    out = {
        "ok": True, "pattern": pattern, "flags": flags or None, "match_count": len(matches),
        "matches": matches, "group_count": rx.groups, "group_names": list(rx.groupindex),
        "explanation": _explain_regex(pattern, flag_bits),
        "warnings": ([ "the pattern can match an empty string — most engines will loop or skip "
                       "characters; add a length requirement" ] if danger else [])
        + (["this shape can backtrack exponentially on long input (catastrophic backtracking) — "
             "make the quantifiers possessive or anchor the pattern"] if catastrophic else []),
        "replacement_preview": _clip(replaced, 2000) if replaced is not None else None,
        "python": f"re.compile(r'''{pattern}'''" + (f", {flags.upper()}" if flags else "") + ")",
        "javascript": f"/{pattern}/{'gimsux'.replace('x','')[:0] or ''}"
                      + "".join(sorted(set((flags or "").lower()) & set("gimsuy"))),
    }
    lines = [f"Pattern `{pattern}` — {len(matches)} match(es) in {len(text):,} characters."]
    for m in matches[:8]:
        span = m["span"]
        lines.append(f"- [{span[0]}:{span[1]}] {m['match']!r}"
                     + (f"  groups={m['groups']}" if m["groups"] else "")
                     + (f"  named={m['named']}" if m["named"] else ""))
    if len(matches) > 8:
        lines.append(f"… and {len(matches) - 8} more")
    if not matches:
        lines.append("No match. Check anchors (^ $), escaping, and whether the text really "
                     "contains that shape.")
    lines.append("What it does: " + "; ".join(out["explanation"][:5]))
    for w in out["warnings"]:
        lines.append(f"⚠ {w}")
    out["answer"] = "\n".join(lines)
    return out


# ===========================================================================
# 2. JSON / DATA FORMATS
# ===========================================================================
def _parse_json(text: str) -> Tuple[Any, Optional[str]]:
    """Parse JSON, tolerating the small things humans get wrong."""
    raw = (text or "").strip()
    if not raw:
        return None, "empty input"
    try:
        return json.loads(raw), None
    except json.JSONDecodeError as exc:
        pass
    # strip a UTF-8 BOM, trailing commas and // comments, then retry
    cleaned = raw.lstrip("\ufeff")
    cleaned = re.sub(r"//[^\n]*", "", cleaned)
    cleaned = re.sub(r",(\s*[}\]])", r"\1", cleaned)
    cleaned = re.sub(r"([{,]\s*)(\w+)(\s*:)", r'\1"\2"\3', cleaned)   # unquoted keys
    try:
        return json.loads(cleaned), None
    except json.JSONDecodeError as exc2:
        return None, f"{exc} (after cleanup: {exc2})"


def _json_path(data: Any, path: str) -> Tuple[bool, Any]:
    """A tiny JSONPath-lite: ``store.books[0].title``, ``a.b.*.c``, ``items[*].id``."""
    if not path:
        return True, data
    current = data
    tokens = re.findall(r"\w+|\[\d+\]|\[\*\]|\*", path.replace("$.", "").replace("$", ""))
    for tok in tokens:
        try:
            if tok == "*" or tok == "[*]":
                if isinstance(current, dict):
                    current = list(current.values())
                elif isinstance(current, list):
                    pass
                else:
                    return False, None
            elif tok.startswith("[") and tok.endswith("]"):
                idx = int(tok[1:-1])
                if not isinstance(current, list) or idx >= len(current):
                    return False, None
                current = current[idx]
            else:
                if isinstance(current, list):
                    current = [item.get(tok) if isinstance(item, dict) else None
                               for item in current]
                elif isinstance(current, dict):
                    if tok not in current:
                        return False, None
                    current = current[tok]
                else:
                    return False, None
        except (TypeError, ValueError, AttributeError):
            return False, None
    return True, current


def _flatten(data: Any, prefix: str = "", depth: int = 0, max_depth: int = 6) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if depth > max_depth:
        return {prefix or "$": data}
    if isinstance(data, dict):
        for k, v in data.items():
            out.update(_flatten(v, f"{prefix}.{k}" if prefix else str(k), depth + 1, max_depth))
    elif isinstance(data, list):
        for i, v in enumerate(data[:200]):
            out.update(_flatten(v, f"{prefix}[{i}]", depth + 1, max_depth))
    else:
        out[prefix or "$"] = data
    return out


@tool(
    name="code.json",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Validate, format, minify, query, flatten, sort and diff JSON — repairs trailing commas, comments and unquoted keys",
    schema={"text": {"type": "string", "required": True},
            "operation": {"type": "string", "default": "format",
                          "description": "validate | format | minify | query | flatten | keys | "
                                         "stats | to_yaml | to_csv | sort | repair"},
            "path": {"type": "string", "description": "JSONPath-lite for query, e.g. a.b[0].c"},
            "indent": {"type": "integer", "default": 2},
            "sort_keys": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=90,
)
async def code_json(ctx: ToolContext, text: str = "", operation: str = "format", path: str = "",
                    indent: int = 2, sort_keys: bool = False, request: str = "") -> Dict[str, Any]:
    body = text or request or ""
    if not body.strip():
        return _bad("give me the JSON to work on")
    data, err = _parse_json(body)
    op = (operation or "format").lower()
    if err:
        if op not in ("validate", "repair"):
            return _bad(f"invalid JSON: {err}", operation=op)
        return {"ok": False, "valid": False, "error": err, "operation": op,
                "answer": f"The JSON is **not valid**: {err}"}
    if op == "validate":
        kind = type(data).__name__
        size = len(json.dumps(data))
        return {"ok": True, "valid": True, "type": kind, "size_bytes": size,
                "answer": f"Valid JSON — a {kind} of {size:,} bytes"
                          + (f" with {len(data)} top-level item(s)." if isinstance(data, (list, dict))
                             else ".")}
    if op == "minify":
        out_text = json.dumps(data, separators=(",", ":"), ensure_ascii=False)
        return {"ok": True, "text": out_text, "characters": len(out_text),
                "saved_characters": len(body) - len(out_text),
                "answer": f"Minified: {len(body):,} → {len(out_text):,} characters "
                          f"({len(body) - len(out_text):+,} saved)\n\n{_clip(out_text)}"}
    if op == "query":
        ok, value = _json_path(data, path)
        if not ok:
            return _bad(f"no value at '{path}'", available=list(data)[:20]
                        if isinstance(data, dict) else None)
        rendered = value if isinstance(value, str) else json.dumps(value, indent=2,
                                                                  ensure_ascii=False, default=str)
        return {"ok": True, "path": path, "value": value, "text": rendered,
                "type": type(value).__name__,
                "answer": f"`{path}` → ({type(value).__name__})\n\n{_clip(rendered)}"}
    if op == "flatten":
        flat = _flatten(data)
        return {"ok": True, "flat": flat, "count": len(flat),
                "text": json.dumps(flat, indent=2, ensure_ascii=False, default=str),
                "answer": f"Flattened to {len(flat)} leaf path(s):\n\n"
                          + _clip(json.dumps(flat, indent=2, ensure_ascii=False, default=str))}
    if op == "keys":
        if not isinstance(data, dict):
            return _bad(f"the top level is a {type(data).__name__}, not an object")
        shape = {k: type(v).__name__ for k, v in data.items()}
        return {"ok": True, "keys": list(data), "shape": shape, "count": len(data),
                "answer": f"{len(data)} top-level key(s): "
                          + ", ".join(f"{k} ({t})" for k, t in shape.items())}
    if op == "stats":
        flat = _flatten(data)
        types: Dict[str, int] = {}
        for v in flat.values():
            types[type(v).__name__] = types.get(type(v).__name__, 0) + 1
        deepest = max((k.count(".") + k.count("[") for k in flat), default=0)
        return {"ok": True, "leaves": len(flat), "types": types, "max_depth": deepest,
                "size_bytes": len(json.dumps(data)),
                "top_level_type": type(data).__name__,
                "top_level_count": len(data) if isinstance(data, (list, dict)) else 1,
                "answer": f"JSON stats: a {type(data).__name__} with {len(flat)} leaf values, "
                          f"{deepest} levels deep, {len(json.dumps(data)):,} bytes. "
                          f"Value types: " + ", ".join(f"{k} ×{v}" for k, v in
                                                       sorted(types.items(), key=lambda kv: -kv[1]))}
    if op == "to_yaml":
        try:
            import yaml                                          # type: ignore

            out_text = yaml.safe_dump(data, sort_keys=bool(sort_keys), allow_unicode=True,
                                      default_flow_style=False)
        except Exception:
            out_text = json.dumps(data, indent=2, ensure_ascii=False)
            log.debug("yaml unavailable, returned JSON instead")
        return {"ok": True, "format": "yaml", "text": out_text,
                "answer": f"JSON → YAML ({len(out_text):,} characters):\n\n```yaml\n{_clip(out_text)}\n```"}
    if op == "to_csv":
        rows = data if isinstance(data, list) else [data]
        rows = [r for r in rows if isinstance(r, dict)]
        if not rows:
            return _bad("to_csv needs a list of objects")
        columns: List[str] = []
        for r in rows:
            for k in r:
                if k not in columns:
                    columns.append(k)
        import csv
        import io
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for r in rows:
            writer.writerow({k: (json.dumps(v, ensure_ascii=False)
                                 if isinstance(v, (dict, list)) else v) for k, v in r.items()})
        out_text = buf.getvalue().strip()
        return {"ok": True, "format": "csv", "text": out_text, "rows": len(rows),
                "columns": columns,
                "answer": f"JSON → CSV ({len(rows)} rows, {len(columns)} columns):\n\n"
                          f"```csv\n{_clip(out_text)}\n```"}
    if op == "sort":
        if isinstance(data, list) and data and all(isinstance(x, dict) for x in data):
            key = path or next(iter(data[0]), "")
            try:
                data = sorted(data, key=lambda d: str(d.get(key, "")), reverse=bool(sort_keys))
            except Exception as exc:
                return _bad(f"could not sort by '{key}': {exc}")
        elif isinstance(data, dict):
            data = dict(sorted(data.items(), reverse=bool(sort_keys)))
        out_text = json.dumps(data, indent=int(indent or 2), ensure_ascii=False)
        return {"ok": True, "text": out_text, "sorted_by": path or None,
                "answer": f"Sorted JSON:\n\n```json\n{_clip(out_text)}\n```"}
    # format / repair
    out_text = json.dumps(data, indent=max(0, int(indent or 2)), ensure_ascii=False,
                          sort_keys=bool(sort_keys))
    repaired = out_text != body.strip()
    return {"ok": True, "valid": True, "text": out_text, "repaired": repaired,
            "characters": len(out_text),
            "answer": (f"Formatted JSON ({len(out_text):,} characters"
                       + (", repaired: trailing commas / comments / unquoted keys were fixed)"
                          if repaired else ")")
                       + f"\n\n```json\n{_clip(out_text)}\n```")}


@tool(
    name="code.format_convert",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Convert between JSON, YAML, CSV, TSV, TOML, INI, Markdown table and Python literal",
    schema={"text": {"type": "string", "required": True},
            "to_format": {"type": "string", "required": True,
                          "description": "json | yaml | csv | tsv | toml | ini | markdown | python | xml"},
            "delimiter": {"type": "string", "default": ","},
            "has_header": {"type": "boolean", "default": True},
            "root_name": {"type": "string", "default": "root"}},
    risk="LOW",
    timeout=90,
)
async def code_format_convert(ctx: ToolContext, text: str = "", to_format: str = "json",
                              delimiter: str = ",", has_header: bool = True,
                              root_name: str = "root", request: str = "") -> Dict[str, Any]:
    body = (text or request or "").strip()
    if not body:
        return _bad("give me the text to convert")
    target = (to_format or "json").lower().strip().lstrip(".")

    # ---- detect the source format -----------------------------------------
    src = "unknown"
    if body[0] in "[{":
        src = "json"
    elif re.match(r"^[\w\"\-]+:\s", body) and "\t" not in body and "," not in body.split("\n")[0]:
        src = "yaml"
    elif body.lstrip().startswith("<") and ">" in body:
        src = "xml"
    elif re.match(r"^\[[^\]]+\]\s*$", body.split("\n")[0].strip()):
        src = "ini"
    elif "\t" in body.split("\n")[0]:
        src = "tsv"
    elif "|" in body and re.search(r"\|[\s:-]+\|", body):
        src = "markdown"
    elif delimiter in body.split("\n")[0]:
        src = "csv"

    data: Any = None
    if src == "json":
        data, err = _parse_json(body)
        if err:
            return _bad(f"the input looks like JSON but does not parse: {err}")
    elif src in ("yaml", "ini", "toml"):
        try:
            import yaml                                          # type: ignore

            data = yaml.safe_load(body)
        except Exception as exc:
            return _bad(f"could not parse the YAML/INI input: {exc}")
    elif src in ("csv", "tsv", "markdown"):
        sep = "\t" if src == "tsv" else "|" if src == "markdown" else (delimiter or ",")
        lines = [l for l in body.splitlines() if l.strip() and
                 not (src == "markdown" and re.match(r"^\s*\|?[\s:|-]+\|?\s*$", l))]
        rows = [[c.strip() for c in line.strip().strip("|").split(sep)] for line in lines]
        if not rows:
            return _bad("no rows found to convert")
        if has_header:
            header = rows[0]
            data = [dict(zip(header, r + [""] * (len(header) - len(r)))) for r in rows[1:]]
        else:
            data = [dict(zip([f"col{i + 1}" for i in range(len(r))], r)) for r in rows]
    elif src == "xml":
        try:
            import xml.etree.ElementTree as ET

            root_el = ET.fromstring(body)

            def el_to_dict(el: Any) -> Any:
                kids = list(el)
                if not kids:
                    return (el.text or "").strip()
                out: Dict[str, Any] = {}
                for k in kids:
                    val = el_to_dict(k)
                    if k.tag in out:
                        if not isinstance(out[k.tag], list):
                            out[k.tag] = [out[k.tag]]
                        out[k.tag].append(val)
                    else:
                        out[k.tag] = val
                return out

            data = {root_el.tag: el_to_dict(root_el)}
        except Exception as exc:
            return _bad(f"could not parse the XML: {exc}")
    else:
        # last resort: try JSON, then treat it as key: value lines
        data, err = _parse_json(body)
        if err:
            pairs = dict(re.findall(r"^\s*([\w.\-]+)\s*[:=]\s*(.+?)\s*$", body, flags=re.M))
            if pairs:
                data = pairs
            else:
                return _bad(f"could not work out the source format ({err})")

    # ---- render the target -------------------------------------------------
    try:
        if target == "json":
            out_text = json.dumps(data, indent=2, ensure_ascii=False, default=str)
        elif target == "yaml":
            import yaml                                          # type: ignore

            out_text = yaml.safe_dump(data, sort_keys=False, allow_unicode=True,
                                      default_flow_style=False)
        elif target in ("csv", "tsv"):
            import csv
            import io
            rows = data if isinstance(data, list) else [data]
            rows = [r for r in rows if isinstance(r, dict)] or [{"value": r} for r in rows]
            columns: List[str] = []
            for r in rows:
                for k in r:
                    if k not in columns:
                        columns.append(k)
            buf = io.StringIO()
            writer = csv.DictWriter(buf, fieldnames=columns, extrasaction="ignore",
                                    delimiter="\t" if target == "tsv" else (delimiter or ","))
            writer.writeheader()
            for r in rows:
                writer.writerow({k: (json.dumps(v, ensure_ascii=False, default=str)
                                     if isinstance(v, (dict, list)) else v) for k, v in r.items()})
            out_text = buf.getvalue().strip()
        elif target == "markdown":
            rows = data if isinstance(data, list) else [data]
            if not isinstance(rows, list) or not rows:
                out_text = "```json\n" + json.dumps(data, indent=2, default=str) + "\n```"
            else:
                rows = [r if isinstance(r, dict) else {"value": r} for r in rows]
                columns: List[str] = []
                for r in rows:
                    for k in r:
                        if k not in columns:
                            columns.append(k)
                head = "| " + " | ".join(map(str, columns)) + " |"
                sep = "| " + " | ".join("---" for _ in columns) + " |"
                body_rows = ["| " + " | ".join(str(r.get(c, "")).replace("|", "\\|")
                                               for c in columns) + " |" for r in rows]
                out_text = "\n".join([head, sep] + body_rows)
        elif target == "python":
            import pprint
            out_text = pprint.pformat(data, indent=2, sort_dicts=False, width=100)
        elif target == "toml":
            src_dict = data if isinstance(data, dict) else {root_name: data}
            lines: List[str] = []
            scalars = {k: v for k, v in src_dict.items() if not isinstance(v, dict)}
            for k, v in scalars.items():
                lines.append(f"{k} = {json.dumps(v, ensure_ascii=False, default=str)}")
            for k, v in src_dict.items():
                if isinstance(v, dict):
                    lines.append(f"\n[{k}]")
                    lines += [f"{kk} = {json.dumps(vv, ensure_ascii=False, default=str)}"
                              for kk, vv in v.items() if not isinstance(vv, (dict, list))]
                elif isinstance(v, list):
                    lines.append(f"{k} = {json.dumps(v, ensure_ascii=False, default=str)}")
            out_text = "\n".join(lines)
        elif target == "ini":
            lines = []
            src_dict = data if isinstance(data, dict) else {root_name: data}
            for k, v in src_dict.items():
                if isinstance(v, dict):
                    lines.append(f"[{k}]")
                    lines += [f"{kk} = {vv}" for kk, vv in v.items()
                              if not isinstance(vv, (dict, list))]
                else:
                    lines.append(f"{k} = {v}")
            out_text = "\n".join(lines)
        elif target == "xml":
            import xml.etree.ElementTree as ET

            def build(parent: Any, key: str, value: Any) -> None:
                tag = re.sub(r"[^\w.-]", "_", str(key)) or "item"
                el = ET.SubElement(parent, tag)
                if isinstance(value, dict):
                    for k, v in value.items():
                        build(el, k, v)
                elif isinstance(value, list):
                    for item in value:
                        build(el, "item", item)
                else:
                    el.text = str(value)

            root_el = ET.Element(re.sub(r"[^\w.-]", "_", root_name) or "root")
            if isinstance(data, dict):
                for k, v in data.items():
                    build(root_el, k, v)
            else:
                build(root_el, "value", data)
            out_text = ET.tostring(root_el, encoding="unicode")
        else:
            return _bad(f"unknown target format '{to_format}'. Use json, yaml, csv, tsv, toml, "
                        f"ini, markdown, python or xml")
    except Exception as exc:
        return _bad(f"conversion to {target} failed: {type(exc).__name__}: {exc}",
                    source_format=src)
    return {"ok": True, "from_format": src, "to_format": target, "text": out_text,
            "characters": len(out_text),
            "answer": f"{src.upper()} → {target.upper()} ({len(out_text):,} characters):\n\n"
                      f"```\n{_clip(out_text, 2500)}\n```"}


# ===========================================================================
# 3. CRYPTO UTILITIES (hashing / encoding / tokens) — no key management
# ===========================================================================
@tool(
    name="code.hash",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Hash text or a file: MD5, SHA1, SHA256, SHA512, BLAKE2b, plus HMAC with a key",
    schema={"text": {"type": "string"},
            "path": {"type": "string", "description": "hash a file inside SAM's roots instead"},
            "algorithms": {"type": "string", "default": "sha256",
                           "description": "comma list: md5,sha1,sha224,sha256,sha384,sha512,blake2b,blake2s"},
            "hmac_key": {"type": "string", "description": "if given, also produce HMAC digests"},
            "encoding": {"type": "string", "default": "utf-8"}},
    risk="LOW",
    timeout=120,
)
async def code_hash(ctx: ToolContext, text: str = "", path: str = "", algorithms: str = "sha256",
                    hmac_key: str = "", encoding: str = "utf-8",
                    request: str = "") -> Dict[str, Any]:
    algos = [a.strip().lower() for a in (algorithms or "sha256").split(",") if a.strip()]
    allowed = {"md5", "sha1", "sha224", "sha256", "sha384", "sha512", "blake2b", "blake2s"}
    unknown = [a for a in algos if a not in allowed]
    if unknown:
        return _bad(f"unknown algorithm(s): {', '.join(unknown)}. Available: {', '.join(sorted(allowed))}")
    data: Optional[bytes] = None
    source = "text"
    if path and path.strip():
        try:
            from backend.app.tools.registry import registry
            info = await registry.execute("files.info", ctx, path=path.strip(), include_hash=False)
            if not (isinstance(info, dict) and info.get("ok")):
                return _bad(str((info or {}).get("error") or f"cannot read '{path}'"))
            target = Path(info.get("path") or path.strip())
            if not target.is_file():
                return _bad(f"'{path}' is not a file")
            data = target.read_bytes()
            source = str(target)
        except Exception as exc:
            return _bad(f"could not read '{path}': {type(exc).__name__}: {exc}")
    elif text or request:
        data = (text or request).encode(encoding or "utf-8", errors="replace")
    else:
        return _bad("give me text or a file path to hash")
    digests = {a: hashlib.new(a, data).hexdigest() for a in algos}
    macs: Dict[str, str] = {}
    if hmac_key:
        for a in algos:
            if a in ("blake2b", "blake2s"):
                continue
            macs[a] = hmac_lib.new(hmac_key.encode("utf-8"), data, a).hexdigest()
    out = {"ok": True, "source": source, "bytes": len(data), "algorithms": algos,
           "digests": digests, "hmac": macs or None,
           "base64_sha256": base64.b64encode(hashlib.sha256(data).digest()).decode()
           if "sha256" in algos else None,
           "note": "MD5 and SHA1 are broken for security purposes — fine for checksums and "
                   "cache keys, never for signatures or passwords. Use SHA-256 or better, and "
                   "bcrypt/argon2 for passwords."}
    lines = [f"Hash of {out['bytes']:,} bytes from {source}:"]
    lines += [f"- {a.upper()}: `{d}`" for a, d in digests.items()]
    lines += [f"- HMAC-{a.upper()}: `{d}`" for a, d in macs.items()]
    lines.append(f"_{out['note']}_")
    out["answer"] = "\n".join(lines)
    return out


@tool(
    name="code.encode",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Encode or decode base64, base32, hex, URL-percent and binary",
    schema={"text": {"type": "string", "required": True},
            "operation": {"type": "string", "default": "encode", "description": "encode | decode"},
            "codec": {"type": "string", "default": "base64",
                      "description": "base64 | base64url | base32 | base16 | hex | url | binary | rot13"},
            "encoding": {"type": "string", "default": "utf-8"}},
    risk="LOW",
    timeout=60,
)
async def code_encode(ctx: ToolContext, text: str = "", operation: str = "encode",
                      codec: str = "base64", encoding: str = "utf-8",
                      request: str = "") -> Dict[str, Any]:
    body = text or request or ""
    if not body:
        return _bad("give me the text to encode or decode")
    op = (operation or "encode").lower()
    kind = (codec or "base64").lower().replace("-", "").replace("_", "")
    enc = encoding or "utf-8"
    try:
        if op == "encode":
            raw = body.encode(enc, errors="replace")
            if kind in ("base64", "b64"):
                out_text = base64.b64encode(raw).decode()
            elif kind in ("base64url", "b64url", "jwt"):
                out_text = base64.urlsafe_b64encode(raw).decode().rstrip("=")
            elif kind in ("base32", "b32"):
                out_text = base64.b32encode(raw).decode()
            elif kind in ("base16", "hex"):
                out_text = base64.b16encode(raw).decode().lower()
            elif kind == "url":
                from urllib.parse import quote
                out_text = quote(body, safe="")
            elif kind in ("binary", "bin", "bits"):
                out_text = " ".join(f"{b:08b}" for b in raw)
            elif kind == "rot13":
                import codecs
                out_text = codecs.encode(body, "rot_13")
            else:
                return _bad(f"unknown codec '{codec}'. Use base64, base64url, base32, hex, url, "
                            f"binary or rot13")
        else:
            if kind in ("base64", "b64"):
                padded = body.strip() + "=" * (-len(body.strip()) % 4)
                out_text = base64.b64decode(padded).decode(enc, errors="replace")
            elif kind in ("base64url", "b64url", "jwt"):
                padded = body.strip() + "=" * (-len(body.strip()) % 4)
                out_text = base64.urlsafe_b64decode(padded).decode(enc, errors="replace")
            elif kind in ("base32", "b32"):
                padded = body.strip().upper() + "=" * (-len(body.strip()) % 8)
                out_text = base64.b32decode(padded).decode(enc, errors="replace")
            elif kind in ("base16", "hex"):
                out_text = base64.b16decode(body.strip().replace(" ", "").upper()).decode(
                    enc, errors="replace")
            elif kind == "url":
                from urllib.parse import unquote
                out_text = unquote(body)
            elif kind in ("binary", "bin", "bits"):
                bits = re.sub(r"[^01]", "", body)
                if len(bits) % 8:
                    return _bad("the binary string is not a whole number of bytes")
                out_text = bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)).decode(
                    enc, errors="replace")
            elif kind == "rot13":
                import codecs
                out_text = codecs.decode(body, "rot_13")
            else:
                return _bad(f"unknown codec '{codec}'")
    except (binascii.Error, ValueError, UnicodeDecodeError) as exc:
        return _bad(f"{op} with {kind} failed: {exc}",
                    hint="check the alphabet (base64 vs base64url), padding, and that the input "
                         "is really in that codec")
    printable = all(32 <= ord(c) < 127 or c in "\n\t" for c in out_text[:500])
    out = {"ok": True, "operation": op, "codec": kind, "text": out_text,
           "characters_in": len(body), "characters_out": len(out_text),
           "printable": printable,
           "note": "" if printable else
           "the result contains non-printable bytes — this is probably binary data, not text"}
    out["answer"] = f"{kind} {op}: ({len(body):,} → {len(out_text):,} characters)\n\n{_clip(out_text)}"
    return out


@tool(
    name="code.jwt",
    capability="code.utilities",
    agent="security",
    device="both",
    description="Decode a JWT: header, payload, claims, expiry countdown and HS256 verification when a secret is given",
    schema={"token": {"type": "string", "required": True},
            "secret": {"type": "string", "description": "optional HS256 secret to verify the signature"},
            "leeway_seconds": {"type": "integer", "default": 0}},
    risk="LOW",
    timeout=45,
)
async def code_jwt(ctx: ToolContext, token: str = "", secret: str = "", leeway_seconds: int = 0,
                   request: str = "") -> Dict[str, Any]:
    raw = (token or request or "").strip()
    if raw.lower().startswith("bearer "):
        raw = raw[7:].strip()
    parts = raw.split(".")
    if len(parts) not in (2, 3):
        return _bad("that does not look like a JWT — expected header.payload.signature")

    def b64url(piece: str) -> Dict[str, Any]:
        padded = piece + "=" * (-len(piece) % 4)
        return json.loads(base64.urlsafe_b64decode(padded).decode("utf-8"))

    try:
        header = b64url(parts[0])
        payload = b64url(parts[1])
    except (binascii.Error, ValueError, json.JSONDecodeError) as exc:
        return _bad(f"could not decode the JWT segments: {exc}")
    now = int(time.time())
    leeway = int(leeway_seconds or 0)
    claims: List[Dict[str, Any]] = []

    def when(ts: Any) -> Optional[str]:
        try:
            return datetime.fromtimestamp(int(ts), dt_timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        except (TypeError, ValueError, OSError):
            return None

    for key, meaning in (("iss", "issuer"), ("sub", "subject"), ("aud", "audience"),
                         ("exp", "expires at"), ("nbf", "not valid before"), ("iat", "issued at"),
                         ("jti", "JWT id"), ("scope", "scopes"), ("azp", "authorized party")):
        if key in payload:
            claims.append({"claim": key, "meaning": meaning, "value": payload[key],
                           "when": when(payload[key]) if key in ("exp", "nbf", "iat") else None})
    expired = isinstance(payload.get("exp"), (int, float)) and now > payload["exp"] + leeway
    not_yet = isinstance(payload.get("nbf"), (int, float)) and now < payload["nbf"] - leeway
    alg = str(header.get("alg", "")).upper()
    warnings: List[str] = []
    if alg in ("NONE", ""):
        warnings.append("alg is 'none' — this token is UNSIGNED; never trust it for authorization")
    if alg.startswith("HS") and not secret:
        warnings.append("HS256/HS384/HS512 needs the shared secret to verify — pass 'secret' "
                        "and SAM will check the signature")
    if alg.startswith("RS") or alg.startswith("ES") or alg.startswith("PS"):
        warnings.append(f"{alg} is asymmetric: verification needs the issuer's PUBLIC key, which "
                        f"SAM does not fetch. The signature is NOT verified here.")
    if expired:
        warnings.append(f"the token EXPIRED {now - int(payload['exp'])}s ago")
    if not_yet:
        warnings.append("the token is not valid yet (nbf is in the future)")
    verified: Optional[bool] = None
    if secret and alg.startswith("HS") and len(parts) == 3:
        digest = {"HS256": "sha256", "HS384": "sha384", "HS512": "sha512"}.get(alg, "sha256")
        signing_input = f"{parts[0]}.{parts[1]}".encode()
        expected = base64.urlsafe_b64encode(
            hmac_lib.new(secret.encode(), signing_input, digest).digest()).decode().rstrip("=")
        verified = hmac_lib.compare_digest(expected, parts[2].rstrip("="))
        warnings.append("signature is VALID for the secret you gave" if verified else
                        "signature does NOT match that secret")
    out = {
        "ok": True, "header": header, "payload": payload, "claims": claims,
        "signature_present": len(parts) == 3, "algorithm": alg or "none",
        "typ": header.get("typ"), "kid": header.get("kid"),
        "verified": verified, "expired": bool(expired), "not_yet_valid": bool(not_yet),
        "seconds_to_expiry": int(payload["exp"]) - now if isinstance(payload.get("exp"),
                                                                    (int, float)) else None,
        "expires_at": when(payload.get("exp")), "issued_at": when(payload.get("iat")),
        "warnings": warnings,
        "note": "Decoding a JWT is not verifying it. Only an HS* token checked against the right "
                "secret (or an RS/ES token checked against the issuer's public key) proves "
                "anything. SAM never stores the secret or the token.",
    }
    lines = [f"JWT decoded — alg **{alg or 'none'}**, typ {header.get('typ') or 'JWT'}"
             + (f", kid {header.get('kid')}" if header.get("kid") else "") + "."]
    if out["seconds_to_expiry"] is not None:
        state = "EXPIRED" if expired else "valid"
        lines.append(f"Expiry: {out['expires_at']} — {state} "
                     f"({abs(out['seconds_to_expiry'])}s "
                     f"{'ago' if expired else 'left'}).")
    lines.append("Payload: " + json.dumps(payload, ensure_ascii=False, default=str)[:600])
    if verified is not None:
        lines.append(f"Signature check with your secret: {'VALID' if verified else 'INVALID'}.")
    for w in warnings:
        lines.append(f"⚠ {w}")
    lines.append(f"_{out['note']}_")
    out["answer"] = "\n".join(lines)
    return out


@tool(
    name="code.uuid",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Generate UUIDs (v1, v4, v5, nil) or parse one and explain its version, variant, node and timestamp",
    schema={"operation": {"type": "string", "default": "generate",
                          "description": "generate | parse | batch"},
            "version": {"type": "integer", "default": 4},
            "count": {"type": "integer", "default": 1},
            "hash_name": {"type": "string", "description": "for v3/v5: the name to hash"},
            "namespace": {"type": "string", "default": "dns",
                          "description": "dns | url | oid | x500 | a uuid"},
            "value": {"type": "string", "description": "for parse: the uuid to inspect"},
            "format": {"type": "string", "default": "plain",
                       "description": "plain | hyphenless | urn | braces | upper"}},
    risk="LOW",
    timeout=30,
)
async def code_uuid(ctx: ToolContext, operation: str = "generate", version: int = 4, count: int = 1,
                    hash_name: str = "", namespace: str = "dns", value: str = "",
                    format: str = "plain", request: str = "") -> Dict[str, Any]:
    op = (operation or "generate").lower()

    def render(u: Any) -> str:
        s = str(u)
        kind = (format or "plain").lower()
        if kind == "hyphenless":
            return s.replace("-", "")
        if kind == "urn":
            return f"urn:uuid:{s}"
        if kind == "braces":
            return "{" + s + "}"
        if kind == "upper":
            return s.upper()
        return s

    if op == "parse":
        target = (value or request or "").strip()
        if not target:
            return _bad("give me a uuid to parse")
        try:
            u = uuid_lib.UUID(target)
        except ValueError as exc:
            return _bad(f"that is not a valid UUID: {exc}")
        info = {"ok": True, "uuid": str(u), "hex": u.hex, "urn": u.urn, "int": u.int,
                "version": u.version, "variant": u.variant,
                "version_name": {1: "v1 — time + MAC address (leaks the generating machine and "
                                     "the creation time)",
                                 3: "v3 — MD5 name-based (legacy; prefer v5)",
                                 4: "v4 — random (the usual choice for ids)",
                                 5: "v5 — SHA-1 name-based (stable id for the same name)",
                                 }.get(u.version, f"v{u.version}"),
                "is_nil": u.int == 0, "bytes": base64.b64encode(u.bytes).decode()}
        if u.version == 1:
            try:
                ts = (u.time - 0x01b21dd213814000) / 1e7
                info["timestamp"] = datetime.fromtimestamp(ts, dt_timezone.utc).isoformat()
                info["node_mac"] = ":".join(f"{(u.node >> i) & 0xff:02x}"
                                            for i in range(40, -8, -8))
            except (ValueError, OSError, OverflowError):
                pass
        info["answer"] = (f"{u} — **{info['version_name']}**, variant {u.variant}"
                          + (f", created {info['timestamp']}" if info.get("timestamp") else "")
                          + (f", node {info['node_mac']}" if info.get("node_mac") else "")
                          + (". It is the NIL uuid (all zeros)." if info["is_nil"] else "."))
        return info

    n = max(1, min(int(count or 1), 500))
    ns_map = {"dns": uuid_lib.NAMESPACE_DNS, "url": uuid_lib.NAMESPACE_URL,
              "oid": uuid_lib.NAMESPACE_OID, "x500": uuid_lib.NAMESPACE_X500}
    ns = ns_map.get((namespace or "dns").lower())
    if ns is None:
        try:
            ns = uuid_lib.UUID(namespace)
        except ValueError:
            ns = uuid_lib.NAMESPACE_DNS
    ver = int(version or 4)
    generated: List[str] = []
    for _ in range(n):
        if ver == 1:
            generated.append(render(uuid_lib.uuid1()))
        elif ver == 3:
            if not hash_name:
                return _bad("v3 needs a 'hash_name' to hash")
            generated.append(render(uuid_lib.uuid3(ns, hash_name)))
            break
        elif ver == 5:
            if not hash_name:
                return _bad("v5 needs a 'hash_name' to hash")
            generated.append(render(uuid_lib.uuid5(ns, hash_name)))
            break
        elif ver == 4:
            generated.append(render(uuid_lib.uuid4()))
        else:
            return _bad(f"unsupported uuid version {version} — use 1, 3, 4 or 5")
    out = {"ok": True, "operation": op, "version": ver, "count": len(generated),
           "uuids": generated, "text": "\n".join(generated), "format": format,
           "namespace": str(ns) if ver in (3, 5) else None,
           "note": ("v5 is deterministic: the same namespace + name always gives the same UUID, "
                    "which is what makes it useful for idempotency keys."
                    if ver in (3, 5) else
                    "v4 is random — 122 bits of entropy, so collisions are not a practical worry.")}
    out["answer"] = (f"{len(generated)} UUID v{ver}:" if len(generated) > 1 else
                     f"UUID v{ver}: {generated[0]}")
    if len(generated) > 1:
        out["answer"] += "\n" + "\n".join(generated[:50])
    out["answer"] += f"\n_{out['note']}_"
    return out


# ===========================================================================
# 4. COLOUR + TIME + NUMBERS
# ===========================================================================
_NAMED_COLORS = {
    "black": "#000000", "white": "#ffffff", "red": "#ff0000", "green": "#008000",
    "lime": "#00ff00", "blue": "#0000ff", "yellow": "#ffff00", "cyan": "#00ffff",
    "magenta": "#ff00ff", "silver": "#c0c0c0", "gray": "#808080", "grey": "#808080",
    "maroon": "#800000", "olive": "#808000", "purple": "#800080", "teal": "#008080",
    "navy": "#000080", "orange": "#ffa500", "pink": "#ffc0cb", "brown": "#a52a2a",
    "gold": "#ffd700", "indigo": "#4b0082", "violet": "#ee82ee", "coral": "#ff7f50",
    "salmon": "#fa8072", "tomato": "#ff6347", "khaki": "#f0e68c", "plum": "#dda0dd",
    "orchid": "#da70d6", "turquoise": "#40e0d0", "skyblue": "#87ceeb",
    "slategray": "#708090", "forestgreen": "#228b22", "firebrick": "#b22222",
    "midnightblue": "#191970", "royalblue": "#4169e1", "steelblue": "#4682b4",
    "darkgreen": "#006400", "darkblue": "#00008b", "darkred": "#8b0000",
    "lightgray": "#d3d3d3", "dimgray": "#696969", "beige": "#f5f5dc",
    "ivory": "#fffff0", "lavender": "#e6e6fa", "mintcream": "#f5fffa",
}


def _hex_to_rgb(value: str) -> Tuple[int, int, int]:
    v = (value or "").strip().lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    if len(v) != 6 or not re.fullmatch(r"[0-9a-fA-F]{6}", v):
        raise ValueError(f"'{value}' is not a hex colour (use #rgb or #rrggbb)")
    return int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16)


def _rgb_to_hex(r: int, g: int, b: int) -> str:
    return "#{:02x}{:02x}{:02x}".format(max(0, min(255, int(r))), max(0, min(255, int(g))),
                                        max(0, min(255, int(b))))


def _luminance(rgb: Tuple[int, int, int]) -> float:
    def channel(c: int) -> float:
        s = c / 255
        return s / 12.92 if s <= 0.03928 else ((s + 0.055) / 1.055) ** 2.4
    r, g, b = (channel(x) for x in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _rgb_to_cmyk(rgb: Tuple[int, int, int]) -> List[float]:
    """RGB → CMYK percentages (print workflows ask for this)."""
    r, g, b = (c / 255 for c in rgb)
    k = 1 - max(r, g, b)
    if k >= 1:
        return [0.0, 0.0, 0.0, 100.0]
    return [round((1 - r - k) / (1 - k) * 100, 1), round((1 - g - k) / (1 - k) * 100, 1),
            round((1 - b - k) / (1 - k) * 100, 1), round(k * 100, 1)]


def _contrast(a: Tuple[int, int, int], b: Tuple[int, int, int]) -> float:
    la, lb = _luminance(a), _luminance(b)
    lighter, darker = max(la, lb), min(la, lb)
    return (lighter + 0.05) / (darker + 0.05)


@tool(
    name="code.color",
    capability="code.utilities",
    agent="creative",
    device="both",
    description="Colour tools: hex/RGB/HSL conversion, WCAG contrast ratio and pass/fail, palettes, tints and shades",
    schema={"color": {"type": "string", "required": True,
                      "description": "#rrggbb, #rgb, rgb(r,g,b), hsl(h,s,l) or a CSS name"},
            "other": {"type": "string", "description": "second colour for the contrast ratio"},
            "operation": {"type": "string", "default": "convert",
                          "description": "convert | contrast | palette | tints | shades | invert | "
                                         "nearest | random | grayscale"}},
    risk="LOW",
    timeout=30,
)
async def code_color(ctx: ToolContext, color: str = "", other: str = "", operation: str = "convert",
                     request: str = "") -> Dict[str, Any]:
    def parse(value: str) -> Tuple[int, int, int]:
        v = (value or "").strip().lower()
        if v in _NAMED_COLORS:
            return _hex_to_rgb(_NAMED_COLORS[v])
        m = re.match(r"rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)", v)
        if m:
            return int(m.group(1)), int(m.group(2)), int(m.group(3))
        m = re.match(r"hsla?\(\s*([\d.]+)\s*(?:deg)?[,\s]+([\d.]+)%?[,\s]+([\d.]+)%?", v)
        if m:
            return _hsl_to_rgb(float(m.group(1)), float(m.group(2)) / 100, float(m.group(3)) / 100)
        return _hex_to_rgb(v)

    def _hsl_to_rgb(h: float, s: float, l: float) -> Tuple[int, int, int]:
        h = (h % 360) / 360
        if s == 0:
            v = int(round(l * 255))
            return v, v, v
        q = l * (1 + s) if l < 0.5 else l + s - l * s
        p = 2 * l - q

        def hue(t: float) -> float:
            t %= 1
            if t < 1 / 6:
                return p + (q - p) * 6 * t
            if t < 1 / 2:
                return q
            if t < 2 / 3:
                return p + (q - p) * (2 / 3 - t) * 6
            return p
        return (int(round(hue(h + 1 / 3) * 255)), int(round(hue(h) * 255)),
                int(round(hue(h - 1 / 3) * 255)))

    def rgb_to_hsl(rgb: Tuple[int, int, int]) -> Tuple[float, float, float]:
        r, g, b = (x / 255 for x in rgb)
        mx, mn = max(r, g, b), min(r, g, b)
        l = (mx + mn) / 2
        if mx == mn:
            return 0.0, 0.0, round(l * 100, 1)
        d = mx - mn
        s = d / (2 - mx - mn) if l > 0.5 else d / (mx + mn)
        if mx == r:
            h = (g - b) / d + (6 if g < b else 0)
        elif mx == g:
            h = (b - r) / d + 2
        else:
            h = (r - g) / d + 4
        return round(h * 60, 1), round(s * 100, 1), round(l * 100, 1)

    if not color.strip():
        return _bad("give me a colour (#rrggbb, rgb(), hsl() or a name like 'teal')")
    try:
        rgb = parse(color)
    except ValueError as exc:
        return _bad(str(exc))
    hexv = _rgb_to_hex(*rgb)
    h, s, l = rgb_to_hsl(rgb)
    op = (operation or "convert").lower()

    def describe(ratio: float) -> str:
        return (f"AAA for normal text ({ratio:.2f}:1)" if ratio >= 7 else
                f"AA for normal text, AAA for large text ({ratio:.2f}:1)" if ratio >= 4.5 else
                f"AA for large text only ({ratio:.2f}:1)" if ratio >= 3 else
                f"FAILS WCAG — {ratio:.2f}:1 is below the 3:1 minimum")

    if op == "contrast":
        if not other.strip():
            return _bad("give me a second colour to compare against (the 'other' parameter)")
        try:
            rgb2 = parse(other)
        except ValueError as exc:
            return _bad(str(exc))
        ratio = _contrast(rgb, rgb2)
        hex2 = _rgb_to_hex(*rgb2)
        out = {"ok": True, "operation": op, "color_a": hexv, "color_b": hex2,
               "contrast_ratio": round(ratio, 3), "wcag": describe(ratio),
               "aa_normal": ratio >= 4.5, "aa_large": ratio >= 3, "aaa_normal": ratio >= 7,
               "answer": f"{hexv} on {hex2}: contrast **{ratio:.2f}:1** — {describe(ratio)}.\n"
                         f"WCAG 2.1 needs 4.5:1 for normal text, 3:1 for large text (≥24px or "
                         f"≥18.66px bold), 7:1 for AAA."}
        return out
    if op == "palette":
        steps = []
        for shift in (0, 30, 60, 180, 210, 240):
            rr, gg, bb = _hsl_to_rgb((h + shift) % 360, s / 100, l / 100)
            steps.append({"hue_shift": shift, "hex": _rgb_to_hex(rr, gg, bb),
                          "rgb": [rr, gg, bb]})
        return {"ok": True, "operation": op, "base": hexv, "palette": steps,
                "css": ", ".join(d["hex"] for d in steps),
                "answer": "Palette from " + hexv + " (hue rotations of 0/30/60/180/210/240°): "
                          + ", ".join(d["hex"] for d in steps)}
    if op in ("tints", "shades"):
        steps = []
        for i in range(1, 6):
            factor = i / 5
            if op == "tints":
                mix = tuple(int(c + (255 - c) * factor) for c in rgb)
            else:
                mix = tuple(int(c * (1 - factor)) for c in rgb)
            steps.append({"step": i, "hex": _rgb_to_hex(*mix), "rgb": list(mix),
                          "percent": int(factor * 100)})
        return {"ok": True, "operation": op, "base": hexv, "steps": steps,
                "css": ", ".join(d["hex"] for d in steps),
                "answer": f"{op.title()} of {hexv} (mixed "
                          f"{'toward white' if op == 'tints' else 'toward black'}): "
                          + ", ".join(d["hex"] for d in steps)}
    if op == "invert":
        inv = tuple(255 - c for c in rgb)
        ratio = _contrast(rgb, inv)
        return {"ok": True, "operation": op, "color": hexv, "inverted": _rgb_to_hex(*inv),
                "contrast_ratio": round(ratio, 2),
                "answer": f"Inverse of {hexv} is {_rgb_to_hex(*inv)} "
                          f"(contrast {ratio:.2f}:1 — {describe(ratio)})"}
    if op == "grayscale":
        gray = int(round(0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]))
        luma = int(round(_luminance(rgb) * 255))
        return {"ok": True, "operation": op, "color": hexv,
                "grayscale": _rgb_to_hex(gray, gray, gray), "luminance_hex": _rgb_to_hex(luma, luma, luma),
                "answer": f"{hexv} → greyscale {_rgb_to_hex(gray, gray, gray)} "
                          f"(Rec.601 luma {gray}, WCAG relative luminance {luma})"}
    if op == "nearest":
        best = min(_NAMED_COLORS.items(),
                   key=lambda kv: sum((a - b) ** 2 for a, b in zip(rgb, _hex_to_rgb(kv[1]))))
        dist = math.sqrt(sum((a - b) ** 2 for a, b in zip(rgb, _hex_to_rgb(best[1]))))
        return {"ok": True, "operation": op, "color": hexv, "nearest_name": best[0],
                "nearest_hex": best[1], "distance": round(dist, 2),
                "answer": f"{hexv} is closest to '{best[0]}' ({best[1]}), "
                          f"RGB distance {dist:.1f}"}
    if op == "random":
        picks = [("#%06x" % random.getrandbits(24)) for _ in range(6)]
        return {"ok": True, "operation": op, "colors": picks, "css": ", ".join(picks),
                "answer": "Random colours: " + ", ".join(picks)}
    # convert
    best_text = "white" if _contrast(rgb, (255, 255, 255)) >= _contrast(rgb, (0, 0, 0)) else "black"
    out = {
        "ok": True, "operation": "convert", "input": color.strip(),
        "hex": hexv, "hex_upper": hexv.upper(), "rgb": list(rgb),
        "rgb_css": f"rgb({rgb[0]}, {rgb[1]}, {rgb[2]})",
        "hsl": [h, s, l], "hsl_css": f"hsl({h}, {s}%, {l}%)",
        "cmyk": _rgb_to_cmyk(rgb),
        "luminance": round(_luminance(rgb), 4),
        "int": int(hexv[1:], 16),
        "contrast_on_white": round(_contrast(rgb, (255, 255, 255)), 2),
        "contrast_on_black": round(_contrast(rgb, (0, 0, 0)), 2),
        "best_text_color": best_text,
        "is_light": l > 55, "css_variables": f"--color: {hexv};\n--color-rgb: {rgb[0]}, {rgb[1]}, {rgb[2]};",
    }
    out["answer"] = (f"{hexv} = rgb({rgb[0]}, {rgb[1]}, {rgb[2]}) = hsl({h}, {s}%, {l}%)\n"
                     f"Luminance {out['luminance']} → use **{best_text}** text on it "
                     f"(contrast {out['contrast_on_white'] if best_text == 'white' else out['contrast_on_black']}:1).\n"
                     f"CMYK {out['cmyk']}, int {out['int']}, "
                     f"{'light' if out['is_light'] else 'dark'} colour.")
    return out


@tool(
    name="code.cron",
    capability="code.utilities",
    agent="planning",
    device="both",
    description="Explain a cron expression in plain English and compute the next run times",
    schema={"expression": {"type": "string", "required": True},
            "count": {"type": "integer", "default": 5},
            "timezone": {"type": "string", "default": ""}},
    risk="LOW",
    timeout=45,
)
async def code_cron(ctx: ToolContext, expression: str = "", count: int = 5, timezone: str = "",
                    request: str = "") -> Dict[str, Any]:
    expr = (expression or request or "").strip()
    if not expr:
        return _bad("give me the cron expression, e.g. '0 9 * * 1-5'")
    parts = expr.split()
    if len(parts) not in (5, 6):
        return _bad(f"a cron expression has 5 fields (minute hour day month weekday); "
                    f"'{expr}' has {len(parts)}")
    fields = (parts + ["*"])[:5] if len(parts) == 5 else parts[:5]
    names = ["minute", "hour", "day of month", "month", "day of week"]
    explained = []
    for nm, val in zip(names, fields):
        if val == "*":
            explained.append(f"every {nm}")
        elif val.startswith("*/"):
            explained.append(f"every {val[2:]} {nm}(s)")
        elif "-" in val:
            explained.append(f"{nm} from {val.split('-')[0]} to {val.split('-')[1]}")
        elif "," in val:
            explained.append(f"{nm} at {val.replace(',', ', ')}")
        else:
            explained.append(f"{nm} = {val}")
    plain = "Runs " + ", ".join(explained) + "."
    minute, hour = fields[0], fields[1]
    if minute.isdigit() and hour.isdigit():
        dow = fields[4]
        day_names = {"0": "Sunday", "1": "Monday", "2": "Tuesday", "3": "Wednesday",
                     "4": "Thursday", "5": "Friday", "6": "Saturday", "7": "Sunday"}
        if dow == "*":
            plain = f"Runs every day at {int(hour):02d}:{int(minute):02d}."
        elif dow.replace(",", "").isdigit():
            days = ", ".join(day_names.get(d.strip(), d.strip()) for d in dow.split(","))
            plain = f"Runs on {days} at {int(hour):02d}:{int(minute):02d}."
        elif "-" in dow:
            lo, hi = (x.strip() for x in dow.split("-", 1))
            plain = (f"Runs {day_names.get(lo, lo)}–{day_names.get(hi, hi)} at "
                     f"{int(hour):02d}:{int(minute):02d}.")
    runs: List[str] = []
    engine = "manual"
    try:
        from apscheduler.triggers.cron import CronTrigger    # type: ignore
        import pytz                                           # type: ignore

        tz = None
        if timezone:
            try:
                tz = pytz.timezone(timezone)
            except Exception:
                tz = None
        trigger = CronTrigger.from_crontab(expr, timezone=tz)
        nxt = datetime.now(tz or dt_timezone.utc)
        for _ in range(max(1, min(int(count or 5), 25))):
            fire = trigger.get_next_fire_time(nxt, nxt)
            if fire is None:
                break
            runs.append(fire.strftime("%Y-%m-%d %H:%M:%S %Z"))
            nxt = fire + timedelta(seconds=1)
        engine = "apscheduler"
    except Exception as exc:
        log.debug("cron next-run computation unavailable: %s", exc)
    out = {"ok": True, "expression": expr, "fields": dict(zip(names, fields)),
           "explanation": explained, "plain": plain, "next_runs": runs, "engine": engine,
           "timezone": timezone or "system",
           "note": "Field order is minute hour day-of-month month day-of-week. A day-of-week of "
                   "0 or 7 is Sunday. APScheduler also accepts seconds as a 6th leading field."}
    out["answer"] = (f"`{expr}` — {plain}\n"
                     + (f"Next {len(runs)} run(s): " + "; ".join(runs) + "\n" if runs else
                        "SAM could not compute the next run times here (APScheduler/pytz "
                        "unavailable), but the expression parsed.\n")
                     + f"_{out['note']}_")
    return out


@tool(
    name="code.timestamp",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Convert Unix timestamps, ISO-8601 and human dates; show relative time and timezone offsets",
    schema={"value": {"type": "string", "required": True,
                      "description": "a unix timestamp (s or ms), an ISO date, or 'now'"},
            "to_timezone": {"type": "string", "default": "",
                            "description": "IANA zone (Asia/Kolkata) or an offset like UTC+5:30"},
            "format": {"type": "string", "default": ""}},
    risk="LOW",
    timeout=45,
)
async def code_timestamp(ctx: ToolContext, value: str = "", to_timezone: str = "", format: str = "",
                         request: str = "") -> Dict[str, Any]:
    raw = (value or request or "").strip()
    if not raw:
        return _bad("give me a timestamp, an ISO date, or 'now'")
    now = datetime.now(dt_timezone.utc)
    moment: Optional[datetime] = None
    kind = ""
    if raw.lower() in ("now", "current", "today"):
        moment, kind = now, "now"
    elif re.fullmatch(r"-?\d{9,13}", raw):
        seconds = int(raw)
        if len(raw) >= 12:                              # milliseconds
            seconds = seconds / 1000
            kind = "unix_ms"
        else:
            kind = "unix_s"
        try:
            moment = datetime.fromtimestamp(seconds, dt_timezone.utc)
        except (ValueError, OSError, OverflowError) as exc:
            return _bad(f"that timestamp is out of range: {exc}")
    else:
        cleaned = raw.replace("Z", "+00:00")
        try:
            moment = datetime.fromisoformat(cleaned)
            kind = "iso"
        except ValueError:
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d/%m/%Y",
                        "%m/%d/%Y", "%d-%m-%Y", "%d %b %Y", "%d %B %Y", "%b %d, %Y",
                        "%B %d, %Y", "%Y/%m/%d", "%H:%M:%S"):
                try:
                    parsed = datetime.strptime(raw, fmt)
                    moment = parsed.replace(tzinfo=dt_timezone.utc) if fmt == "%H:%M:%S" else \
                        parsed.astimezone()
                    kind = fmt
                    break
                except ValueError:
                    continue
    if moment is None:
        return _bad(f"could not parse '{raw}' as a timestamp or date")
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=dt_timezone.utc)
    target = moment
    zone_name = "UTC"
    tz_text = (to_timezone or "").strip()
    if tz_text:
        try:
            import zoneinfo
            target = moment.astimezone(zoneinfo.ZoneInfo(tz_text))
            zone_name = tz_text
        except Exception:
            m = re.fullmatch(r"(?:UTC|GMT)?\s*([+-])(\d{1,2})(?::?(\d{2}))?", tz_text, flags=re.I)
            if m:
                sign = 1 if m.group(1) == "+" else -1
                delta = timedelta(hours=int(m.group(2)), minutes=int(m.group(3) or 0)) * sign
                target = moment.astimezone(dt_timezone(delta))
                zone_name = f"UTC{m.group(1)}{m.group(2)}:{m.group(3) or '00'}"
            else:
                try:
                    from datetime import timezone as _tz
                    import pytz                                    # type: ignore
                    target = moment.astimezone(pytz.timezone(tz_text))
                    zone_name = tz_text
                    del _tz
                except Exception:
                    zone_name = "UTC (unknown zone — kept UTC)"
    delta = target - now
    total_seconds = int(delta.total_seconds())
    if abs(total_seconds) < 60:
        relative = "just now" if abs(total_seconds) < 10 else f"{abs(total_seconds)}s " + \
            ("ago" if total_seconds < 0 else "from now")
    elif abs(total_seconds) < 3600:
        relative = f"{abs(total_seconds) // 60}m " + ("ago" if total_seconds < 0 else "from now")
    elif abs(total_seconds) < 86400:
        relative = f"{abs(total_seconds) // 3600}h " + ("ago" if total_seconds < 0 else "from now")
    elif abs(total_seconds) < 86400 * 30:
        relative = f"{abs(total_seconds) // 86400}d " + ("ago" if total_seconds < 0 else "from now")
    else:
        relative = f"{abs(total_seconds) // (86400 * 30)} months " + \
            ("ago" if total_seconds < 0 else "from now")
    fmt = format or "%Y-%m-%d %H:%M:%S %Z"
    out = {
        "ok": True, "input": raw, "input_kind": kind,
        "unix_seconds": int(target.timestamp()), "unix_milliseconds": int(target.timestamp() * 1000),
        "iso_utc": moment.astimezone(dt_timezone.utc).isoformat().replace("+00:00", "Z"),
        "iso_local": target.isoformat(), "utc": moment.astimezone(dt_timezone.utc)
        .strftime("%Y-%m-%d %H:%M:%S"),
        "timezone": zone_name, "formatted": target.strftime(fmt),
        "date": target.strftime("%Y-%m-%d"), "time": target.strftime("%H:%M:%S"),
        "weekday": target.strftime("%A"), "week_number": int(target.strftime("%V")),
        "day_of_year": int(target.strftime("%j")), "is_leap_year": target.year % 4 == 0 and
        (target.year % 100 != 0 or target.year % 400 == 0),
        "relative": relative, "offset_seconds_from_now": total_seconds,
        "utc_offset": target.strftime("%z"),
    }
    out["answer"] = (f"{raw} → **{out['formatted']}** ({zone_name})\n"
                     f"UTC {out['utc']} · ISO {out['iso_utc']}\n"
                     f"Unix {out['unix_seconds']} s ({out['unix_milliseconds']} ms) · "
                     f"{out['weekday']}, week {out['week_number']}, day {out['day_of_year']} "
                     f"of {target.year}\n"
                     f"Relative to now: {relative}")
    return out


@tool(
    name="code.number_base",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Number tools: base conversion (2/8/10/16/36), bitwise operations and IEEE-754 float bit layout",
    schema={"value": {"type": "string", "required": True, "description": "e.g. 255, 0xff, 0b1010, 'a1' base 36"},
            "from_base": {"type": "integer", "default": 10},
            "operation": {"type": "string", "default": "convert",
                          "description": "convert | bitwise | float_bits"},
            "other": {"type": "string", "description": "second operand for bitwise"},
            "op": {"type": "string", "default": "and",
                   "description": "and | or | xor | not | shift_left | shift_right"}},
    risk="LOW",
    timeout=30,
)
async def code_number_base(ctx: ToolContext, value: str = "", from_base: int = 10,
                           operation: str = "convert", other: str = "", op: str = "and",
                           request: str = "") -> Dict[str, Any]:
    raw = (value or request or "").strip()
    if not raw:
        return _bad("give me a number")
    text = raw.lower().replace("_", "").replace(" ", "")
    base = int(from_base or 10)
    try:
        if text.startswith("0x"):
            number, base = int(text, 16), 16
        elif text.startswith("0b"):
            number, base = int(text, 2), 2
        elif text.startswith("0o"):
            number, base = int(text, 8), 8
        else:
            number, base = int(text, base), base
    except ValueError:
        try:
            number = float(text)
        except ValueError:
            return _bad(f"'{raw}' is not a number in base {base}")
    kind = (operation or "convert").lower()

    if kind == "float_bits":
        f = float(number)
        packed = struct.pack(">d", f)
        bits = "".join(f"{b:08b}" for b in packed)
        sign, exponent, mantissa = bits[0], bits[1:12], bits[12:]
        packed32 = struct.pack(">f", f)
        bits32 = "".join(f"{b:08b}" for b in packed32)
        return {"ok": True, "operation": kind, "value": f,
                "double_hex": packed.hex(), "double_bits": bits,
                "float32_hex": packed32.hex(), "float32_bits": bits32,
                "sign": int(sign), "exponent_bits": exponent, "mantissa_bits": mantissa,
                "exponent_unbiased": int(exponent, 2) - 1023,
                "is_integer": f.is_integer(), "is_finite": math.isfinite(f),
                "answer": f"{f} as IEEE-754 double: 0x{packed.hex()}\n"
                          f"bits {sign} {exponent} {mantissa[:26]}… (sign {sign}, unbiased "
                          f"exponent {int(exponent, 2) - 1023})\n"
                          f"as 32-bit float: 0x{packed32.hex()} = {bits32}"}

    if kind == "bitwise":
        if not other.strip():
            if (op or "").lower() == "not":
                result = ~int(number)
                other_value = None
            else:
                return _bad("bitwise needs a second value ('other')")
        else:
            other_text = other.strip().lower()
            other_value = int(other_text, 16 if other_text.startswith("0x") else
                              2 if other_text.startswith("0b") else 10)
            a, b = int(number), other_value
            operation_map = {"and": lambda x, y: x & y, "or": lambda x, y: x | y,
                             "xor": lambda x, y: x ^ y, "&": lambda x, y: x & y,
                             "|": lambda x, y: x | y, "^": lambda x, y: x ^ y,
                             "shift_left": lambda x, y: x << y, "<<": lambda x, y: x << y,
                             "shift_right": lambda x, y: x >> y, ">>": lambda x, y: x >> y}
            fn = operation_map.get((op or "and").lower())
            if fn is None:
                return _bad(f"unknown bitwise op '{op}'. Use and, or, xor, not, shift_left, "
                            f"shift_right")
            try:
                result = fn(a, b)
            except ValueError as exc:
                return _bad(f"bitwise operation failed: {exc}")
        return {"ok": True, "operation": kind, "op": op, "a": int(number), "b": other_value,
                "result": result, "result_hex": hex(result & 0xFFFFFFFFFFFFFFFF),
                "result_binary": bin(result & 0xFF) if 0 <= result <= 255 else bin(result),
                "answer": f"{int(number)} {op} {other_value if other_value is not None else ''} "
                          f"= **{result}** (hex {hex(result & 0xFFFFFFFFFFFFFFFF)}, "
                          f"binary {bin(result)})"}

    n = int(number)
    negative = n < 0
    m = abs(n)
    def base_n(x: int, b: int) -> str:
        if x == 0:
            return "0"
        digits = "0123456789abcdefghijklmnopqrstuvwxyz"
        out = ""
        while x:
            out = digits[x % b] + out
            x //= b
        return out
    out = {
        "ok": True, "operation": "convert", "input": raw, "input_base": base,
        "decimal": n, "binary": bin(m).replace("0b", "") if not negative else "-" + bin(m)[2:],
        "octal": oct(m).replace("0o", ""), "hex": hex(m).replace("0x", "").upper(),
        "base36": base_n(m, 36).upper(), "base16_lower": base_n(m, 16),
        "bytes": (m).to_bytes(max(1, (m.bit_length() + 7) // 8), "big").hex() if m else "00",
        "bit_length": m.bit_length(), "is_negative": negative, "float": float(number),
        "with_underscores": f"{n:,}",
        "ascii": (chr(m) if 32 <= m < 127 else ""),
        "answer": f"{raw} (base {base}) = {n:,} decimal\n"
                  f"- binary {out_binary(n)}\n- octal {oct(m).replace('0o', '')}\n"
                  f"- hex 0x{hex(m).replace('0x', '').upper()}\n"
                  f"- base36 {base_n(m, 36).upper()}\n"
                  f"- {m.bit_length()} bit(s), bytes 0x{(m).to_bytes(max(1, (m.bit_length() + 7) // 8), 'big').hex() if m else '00'}"
                  + (f"\n- ASCII '{chr(m)}'" if 32 <= m < 127 else ""),
    }
    return out


def out_binary(n: int) -> str:
    return ("-" + bin(abs(n))[2:]) if n < 0 else bin(n).replace("0b", "")


# ===========================================================================
# 5. SQL (read-only by default)
# ===========================================================================
_WRITE_SQL = re.compile(r"\b(insert|update|delete|drop|alter|create|replace|truncate|attach|"
                        r"vacuum|reindex|grant|revoke|pragma)\b", re.I)


@tool(
    name="code.sql",
    capability="code.sql",
    agent="data",
    device="pc",
    description="Run SQL against a local SQLite database (or an in-memory one you define). Read-only unless you explicitly allow writes.",
    schema={"query": {"type": "string", "required": True},
            "database": {"type": "string", "default": "",
                         "description": "a .db/.sqlite file inside SAM's data root, or '' for in-memory"},
            "schema": {"type": "string", "description": "CREATE TABLE … statements for the in-memory db"},
            "rows_json": {"type": "string", "description": 'JSON rows to load, e.g. {"users":[{...}]}'},
            "allow_write": {"type": "boolean", "default": False},
            "limit": {"type": "integer", "default": 200}},
    risk="MEDIUM",
    confirm=False,
    timeout=120,
)
async def code_sql(ctx: ToolContext, query: str = "", database: str = "", schema: str = "",
                   rows_json: str = "", allow_write: bool = False, limit: int = 200,
                   request: str = "") -> Dict[str, Any]:
    import sqlite3

    sql = (query or request or "").strip().rstrip(";")
    if not sql:
        return _bad("give me the SQL query to run")
    if re.search(r";\s*\S", sql):
        return _bad("one statement at a time — SAM will not run a stacked query")
    is_write = bool(_WRITE_SQL.search(sql))
    if is_write and not allow_write:
        return _bad("that statement can modify data. Re-run with allow_write=true (a confirmed, "
                    "audited action) or use a SELECT.", statement=sql.split()[0].upper())
    if re.search(r"\b(load_extension|attach\s+database)\b", sql, re.I):
        return _bad("loading extensions or attaching other databases is not allowed")

    db_path = ":memory:"
    if database and database.strip():
        from backend.app.tools.registry import registry
        info = await registry.execute("files.info", ctx, path=database.strip(), include_hash=False)
        if not (isinstance(info, dict) and info.get("ok")):
            return _bad(str((info or {}).get("error") or
                            f"'{database}' is not a readable file inside SAM's roots"))
        candidate = Path(info.get("path") or database.strip())
        if candidate.suffix.lower() not in (".db", ".sqlite", ".sqlite3", ".db3"):
            return _bad(f"'{candidate.name}' does not look like a SQLite database "
                        f"(expected .db/.sqlite)")
        db_path = str(candidate)
    conn = sqlite3.connect(db_path, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        if db_path == ":memory:" and (schema or rows_json):
            if schema:
                conn.executescript(schema)
            if rows_json:
                data, err = _parse_json(rows_json)
                if err:
                    return _bad(f"rows_json is not valid JSON: {err}")
                tables = data if isinstance(data, dict) else {"rows": data}
                for table, rows in tables.items():
                    if not isinstance(rows, list) or not rows:
                        continue
                    if not re.fullmatch(r"\w+", table):
                        continue
                    columns = sorted({k for r in rows if isinstance(r, dict) for k in r})
                    safe_cols = [c for c in columns if re.fullmatch(r"\w+", c)]
                    if not safe_cols:
                        continue
                    existing = {r["name"] for r in conn.execute(
                        f"PRAGMA table_info({table})").fetchall()}
                    if not existing:
                        conn.execute(f"CREATE TABLE {table} "
                                     f"({', '.join(f'{c} TEXT' for c in safe_cols)})")
                    for r in rows[:MAX_ROWS]:
                        if not isinstance(r, dict):
                            continue
                        values = [r.get(c) for c in safe_cols]
                        conn.execute(
                            f"INSERT INTO {table} ({', '.join(safe_cols)}) "
                            f"VALUES ({', '.join('?' * len(safe_cols))})",
                            [json.dumps(v) if isinstance(v, (dict, list)) else v for v in values])
                conn.commit()
        t0 = time.perf_counter()
        cursor = conn.execute(sql)
        if cursor.description:
            columns = [d[0] for d in cursor.description]
            rows = [dict(zip(columns, r)) for r in cursor.fetchmany(max(1, min(int(limit or 200),
                                                                              MAX_ROWS)))]
            total = cursor.rowcount if cursor.rowcount and cursor.rowcount > 0 else len(rows)
            result_kind = "rows"
        else:
            conn.commit()
            columns, rows, total = [], [], cursor.rowcount
            result_kind = "affected"
        took = round((time.perf_counter() - t0) * 1000, 2)
        tables = [r["name"] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' "
            "ORDER BY name").fetchall()]
        out = {"ok": True, "database": db_path, "kind": result_kind, "columns": columns,
               "rows": rows, "row_count": len(rows), "rows_returned": len(rows),
               "affected_rows": total if result_kind == "affected" else None,
               "took_ms": took, "tables": tables, "write": is_write,
               "truncated": len(rows) >= min(int(limit or 200), MAX_ROWS)}
        if result_kind == "rows":
            preview = "\n".join("| " + " | ".join(str(c) for c in columns) + " |", ) if columns else ""
            head = "| " + " | ".join(str(c) for c in columns) + " |"
            sep = "| " + " | ".join("---" for _ in columns) + " |"
            body_rows = ["| " + " | ".join(str(r.get(c, ""))[:40] for c in columns) + " |"
                         for r in rows[:20]]
            out["table_markdown"] = "\n".join([head, sep] + body_rows)
            out["answer"] = (f"Query returned {len(rows)} row(s) in {took} ms"
                             + (f" (truncated at {limit})" if out["truncated"] else "")
                             + f" from {db_path}.\n\n{out['table_markdown']}")
        else:
            out["answer"] = (f"Statement executed in {took} ms: {total} row(s) affected"
                             + (" (write enabled)" if is_write else "") + ".")
        return out
    except sqlite3.Error as exc:
        return _bad(f"SQL error: {exc}", query=sql[:200], database=db_path)
    finally:
        conn.close()


# ===========================================================================
# 6. CODE INSIGHT
# ===========================================================================
_DANGEROUS = [
    (r"\beval\s*\(", "eval() runs arbitrary strings as code"),
    (r"\bexec\s*\(", "exec() runs arbitrary strings as code"),
    (r"\bos\.system\s*\(", "os.system() shells out"),
    (r"\bsubprocess\.(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True", "shell=True passes the string to a shell"),
    (r"\bpickle\.loads?\s*\(", "unpickling untrusted data executes code"),
    (r"\byaml\.load\s*\((?!.*Loader)", "yaml.load without SafeLoader executes arbitrary Python"),
    (r"\b__import__\s*\(", "dynamic import"),
    (r"\bshutil\.rmtree\s*\(", "recursive delete"),
    (r"\bos\.remove\s*\(|\bos\.unlink\s*\(", "file deletion"),
    (r"\brequests\.(?:get|post)\s*\([^)]*verify\s*=\s*False", "TLS verification disabled"),
    (r"\bssl\._create_unverified_context", "TLS verification disabled"),
    (r"\bmd5\s*\(", "MD5 is broken for security use"),
    (r"\bpassword\s*=\s*[\"'][^\"']{3,}[\"']", "a hard-coded password"),
    (r"\bapi[_-]?key\s*=\s*[\"'][A-Za-z0-9_\-]{12,}[\"']", "a hard-coded API key"),
    (r"\bexcept\s*:\s*pass\b", "a bare except that swallows every error"),
    (r"\bSELECT\s+.*\bFROM\b.*[%+].*\bWHERE\b", "SQL built by string concatenation — use parameters"),
    (r"\binnerHTML\s*=", "innerHTML with untrusted data is an XSS vector"),
    (r"\bdangerouslySetInnerHTML", "raw HTML injection in React"),
    (r"\bdocument\.write\s*\(", "document.write is an XSS vector"),
    (r"\bchmod\s+777\b", "world-writable permissions"),
    (r"\bcurl\s+[^\n|]*\|\s*(?:ba)?sh\b", "piping a remote script into a shell"),
]

_SECRET_PATTERNS = [
    ("AWS access key id", r"\b(AKIA|ASIA|ABIA|ACCA)[0-9A-Z]{16}\b"),
    ("AWS secret key", r"(?i)aws(.{0,20})?['\"][0-9a-zA-Z/+]{40}['\"]"),
    ("GitHub token", r"\bgh[pousr]_[A-Za-z0-9]{36,255}\b"),
    ("GitLab token", r"\bglpat-[A-Za-z0-9_\-]{20,}\b"),
    ("Slack token", r"\bxox[baprs]-[A-Za-z0-9\-]{10,}\b"),
    ("Stripe key", r"\b(?:sk|pk|rk)_(?:live|test)_[A-Za-z0-9]{16,}\b"),
    ("OpenAI key", r"\bsk-[A-Za-z0-9_\-]{20,}\b"),
    ("Anthropic key", r"\bsk-ant-[A-Za-z0-9_\-]{20,}\b"),
    ("Google API key", r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    ("Twilio key", r"\bSK[0-9a-fA-F]{32}\b"),
    ("SendGrid key", r"\bSG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}\b"),
    ("Private key block", r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----"),
    ("JWT", r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\b"),
    ("Password in a URL", r"(?i)\b(?:ftp|https?|mysql|postgres(?:ql)?|mongodb|redis)://"
                          r"[^\s/@:]+:[^\s/@]+@"),
    ("Basic auth header", r"(?i)authorization:\s*basic\s+[A-Za-z0-9+/=]{12,}"),
    ("Bearer token", r"(?i)bearer\s+[A-Za-z0-9_\-\.=]{20,}"),
    ("Credit-card-like number", r"\b(?:\d[ \-]?){13,19}\b"),
    ("IPv4 with credentials", r"\b\d{1,3}(?:\.\d{1,3}){3}:[0-9]{2,5}\b"),
    ("Hard-coded secret assignment",
     r"(?i)\b(secret|token|passwd|password|api_key|apikey|access_key|private_key)"
     r"\s*[:=]\s*['\"][^'\"]{6,}['\"]"),
]


def _read_text_file(path: str) -> Tuple[str, Optional[str]]:
    try:
        p = Path(path).expanduser()
        if not p.is_file():
            return "", f"'{path}' is not a file"
        if p.stat().st_size > 8 * 1024 * 1024:
            return "", f"'{path}' is larger than 8 MB"
        return p.read_text(encoding="utf-8", errors="replace"), None
    except Exception as exc:
        return "", f"could not read '{path}': {type(exc).__name__}: {exc}"


@tool(
    name="code.secret_scan",
    capability="code.utilities",
    agent="security",
    device="both",
    description="Scan text or a file for leaked credentials: cloud keys, tokens, private keys, JWTs, passwords in URLs",
    schema={"text": {"type": "string"},
            "path": {"type": "string", "description": "a file inside SAM's roots"},
            "show_values": {"type": "boolean", "default": False,
                            "description": "false = mask the secrets (safer for logs and sharing)"}},
    risk="LOW",
    timeout=120,
)
async def code_secret_scan(ctx: ToolContext, text: str = "", path: str = "",
                           show_values: bool = False, request: str = "") -> Dict[str, Any]:
    body = text or request or ""
    source = "inline text"
    if path and path.strip():
        from backend.app.tools.registry import registry
        info = await registry.execute("files.info", ctx, path=path.strip(), include_hash=False)
        if not (isinstance(info, dict) and info.get("ok")):
            return _bad(str((info or {}).get("error") or f"cannot read '{path}'"))
        body, err = _read_text_file(str(info.get("path") or path))
        if err:
            return _bad(err)
        source = str(info.get("path") or path)
    if not body.strip():
        return _bad("nothing to scan — give me text or a file path")
    body = body[:MAX_TEXT]
    lines = body.splitlines()
    findings: List[Dict[str, Any]] = []
    seen: set = set()
    for label, rx in _SECRET_PATTERNS:
        for m in re.finditer(rx, body):
            value = m.group(0)
            if label == "Credit-card-like number":
                digits = re.sub(r"\D", "", value)
                if len(digits) < 13 or len(digits) > 19:
                    continue
                # a Luhn check keeps false positives down
                total, alt = 0, False
                for ch in reversed(digits):
                    d = int(ch)
                    if alt:
                        d *= 2
                        if d > 9:
                            d -= 9
                    total += d
                    alt = not alt
                if total % 10:
                    continue
            key = (label, value[:40])
            if key in seen:
                continue
            seen.add(key)
            line_no = body[:m.start()].count("\n") + 1
            masked = value if show_values else (value[:4] + "…" + value[-4:]
                                                if len(value) > 12 else "*" * len(value))
            findings.append({"type": label, "masked": masked, "value": value if show_values else None,
                             "line": line_no, "column": m.start() - body.rfind("\n", 0, m.start()),
                             "context": (lines[line_no - 1][:160] if line_no <= len(lines) else "")})
    severity = "critical" if any(f["type"] in ("Private key block", "AWS secret key",
                                               "Stripe key", "Hard-coded secret assignment")
                                 for f in findings) else "high" if findings else "clean"
    out = {"ok": True, "source": source, "characters": len(body), "lines": len(lines),
           "findings": findings, "count": len(findings), "severity": severity,
           "types_found": sorted({f["type"] for f in findings}),
           "values_shown": bool(show_values),
           "advice": ([
               "rotate the credential now — treat it as compromised, do not just delete it",
               "purge it from git history (git filter-repo or BFG), not only from HEAD",
               "move secrets to environment variables or a secret manager",
               "add the pattern to your pre-commit hook / CI secret scanner",
           ] if findings else ["nothing that looks like a credential was found — keep scanning "
                               "in CI, since patterns evolve"])}
    if not findings:
        out["answer"] = f"No secrets found in {source} ({len(lines):,} lines scanned)."
    else:
        out["answer"] = (f"**{len(findings)} possible secret(s)** in {source} — severity "
                         f"{severity}:\n" + "\n".join(
                             f"- line {f['line']} · {f['type']}: `{f['masked']}`"
                             for f in findings[:15])
                         + "\n\nWhat to do:\n" + "\n".join(f"{i + 1}. {a}"
                                                           for i, a in enumerate(out["advice"])))
    return out


@tool(
    name="code.complexity",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Code metrics: line counts, functions, classes, nesting depth, cyclomatic complexity and the longest functions",
    schema={"code": {"type": "string"}, "path": {"type": "string"},
            "language": {"type": "string", "default": "python"}},
    risk="LOW",
    timeout=90,
)
async def code_complexity(ctx: ToolContext, code: str = "", path: str = "", language: str = "python",
                          request: str = "") -> Dict[str, Any]:
    body = code or request or ""
    source = "inline code"
    if path and path.strip():
        from backend.app.tools.registry import registry
        info = await registry.execute("files.info", ctx, path=path.strip(), include_hash=False)
        if not (isinstance(info, dict) and info.get("ok")):
            return _bad(str((info or {}).get("error") or f"cannot read '{path}'"))
        body, err = _read_text_file(str(info.get("path") or path))
        if err:
            return _bad(err)
        source = str(info.get("path") or path)
    if not body.strip():
        return _bad("give me the code to measure (or a path)")
    lang = (language or "python").lower()
    lines = body.splitlines()
    blank = sum(1 for l in lines if not l.strip())
    comment_markers = {"python": "#", "ruby": "#", "bash": "#", "yaml": "#",
                       "javascript": "//", "typescript": "//", "java": "//", "c": "//",
                       "cpp": "//", "go": "//", "rust": "//", "php": "//"}.get(lang, "#")
    comment = sum(1 for l in lines if l.strip().startswith(comment_markers))
    code_lines = len(lines) - blank - comment
    branch_words = ("if", "elif", "else if", "for", "while", "except", "catch", "case",
                    "&&", "||", "and", "or", "?")
    branches = sum(len(re.findall(rf"(?<![\w.]){re.escape(w)}(?![\w])", l))
                   for l in lines for w in branch_words if not l.strip().startswith(comment_markers))
    defs = re.findall(r"^\s*(?:async\s+)?def\s+(\w+)|^\s*function\s+(\w+)|"
                      r"^\s*(?:public|private|protected)?\s*[\w<>\[\]]+\s+(\w+)\s*\(", body,
                      flags=re.M)
    functions = [next((g for g in d if g), "") for d in defs]
    classes = re.findall(r"^\s*class\s+(\w+)", body, flags=re.M)
    imports = re.findall(r"^\s*(?:import|from|require|use|#include)\s+([\w.\-/]+)", body, flags=re.M)
    max_indent = 0
    for l in lines:
        if l.strip():
            indent = len(l) - len(l.lstrip())
            unit = 4 if lang in ("python",) else 2
            max_indent = max(max_indent, indent // unit)
    longest = max((len(l) for l in lines), default=0)
    density = round(branches / max(1, len(functions) or 1), 2)
    verdict = ("small and simple" if code_lines < 100 and density < 6 else
               "reasonable size — watch the functions with the highest complexity"
               if code_lines < 600 else
               "large module: consider splitting it by responsibility")
    out = {
        "ok": True, "source": source, "language": lang, "lines": len(lines), "blank": blank,
        "comment": comment, "code_lines": code_lines,
        "comment_percent": round(comment / max(1, len(lines)) * 100, 1),
        "functions": len(functions), "function_names": functions[:40], "classes": len(classes),
        "class_names": classes[:20], "imports": len(imports),
        "branch_points": branches, "cyclomatic_estimate": branches + 1,
        "complexity_per_function": density, "max_nesting_depth": max_indent,
        "longest_line": longest, "characters": len(body), "verdict": verdict,
        "note": "Cyclomatic complexity here is estimated from branch keywords, not a real AST — "
                "treat it as a smell detector: above ~10 per function and the code needs tests "
                "before it needs changes.",
    }
    out["answer"] = (f"{source}: {code_lines} code lines ({len(lines)} total, {comment} comment, "
                     f"{blank} blank), {len(functions)} function(s), {len(classes)} class(es), "
                     f"{len(imports)} import(s).\n"
                     f"Cyclomatic estimate {branches + 1} ({density} branch points per function), "
                     f"max nesting {max_indent}, longest line {longest} chars.\n"
                     f"Verdict: {verdict}.")
    return out


@tool(
    name="code.review",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Static review of a snippet: dangerous calls, swallowed errors, hard-coded secrets, style smells and a fix list",
    schema={"code": {"type": "string"}, "path": {"type": "string"},
            "language": {"type": "string", "default": "python"},
            "strict": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=120,
)
async def code_review(ctx: ToolContext, code: str = "", path: str = "", language: str = "python",
                      strict: bool = False, request: str = "") -> Dict[str, Any]:
    body = code or request or ""
    source = "inline code"
    if path and path.strip():
        from backend.app.tools.registry import registry
        info = await registry.execute("files.info", ctx, path=path.strip(), include_hash=False)
        if not (isinstance(info, dict) and info.get("ok")):
            return _bad(str((info or {}).get("error") or f"cannot read '{path}'"))
        body, err = _read_text_file(str(info.get("path") or path))
        if err:
            return _bad(err)
        source = str(info.get("path") or path)
    if not body.strip():
        return _bad("give me the code to review (or a path)")
    lines = body.splitlines()
    issues: List[Dict[str, Any]] = []
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        for rx, why in _DANGEROUS:
            if re.search(rx, line):
                issues.append({"line": i, "severity": "high", "rule": "dangerous_call",
                               "problem": why, "code": stripped[:160]})
        for label, rx in _SECRET_PATTERNS[:12]:
            if re.search(rx, line):
                issues.append({"line": i, "severity": "critical", "rule": "secret",
                               "problem": f"possible {label} in the source", "code": "<masked>"})
        if strict:
            if len(line) > 100:
                issues.append({"line": i, "severity": "style", "rule": "long_line",
                               "problem": f"{len(line)} characters — keep lines under 100",
                               "code": stripped[:80] + "…"})
            if re.search(r"#\s*(TODO|FIXME|XXX|HACK)\b", line, re.I):
                issues.append({"line": i, "severity": "info", "rule": "todo",
                               "problem": "unfinished work marker", "code": stripped[:120]})
            if re.search(r"\bprint\s*\(", line) and (language or "python") == "python":
                issues.append({"line": i, "severity": "style", "rule": "print_debug",
                               "problem": "print() in library code — use a logger",
                               "code": stripped[:120]})
    if (language or "python") == "python":
        try:
            import ast
            tree = ast.parse(body)
            for node in ast.walk(tree):
                if isinstance(node, ast.ExceptHandler) and node.type is None:
                    issues.append({"line": node.lineno, "severity": "medium",
                                   "rule": "bare_except", "problem": "bare 'except:' catches "
                                                                    "SystemExit and KeyboardInterrupt too",
                                   "code": lines[node.lineno - 1].strip()[:120]
                                   if node.lineno <= len(lines) else ""})
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    length = (node.end_lineno or node.lineno) - node.lineno
                    if length > 60:
                        issues.append({"line": node.lineno, "severity": "medium",
                                       "rule": "long_function",
                                       "problem": f"{node.name}() is {length} lines — split it",
                                       "code": f"def {node.name}(...)"})
                    args = [a.arg for a in node.args.args if a.arg not in ("self", "cls")]
                    if len(args) > 7:
                        issues.append({"line": node.lineno, "severity": "style",
                                       "rule": "too_many_params",
                                       "problem": f"{node.name}() takes {len(args)} parameters — "
                                                  f"group them into a dataclass",
                                       "code": f"def {node.name}({', '.join(args[:8])}…)"})
        except SyntaxError as exc:
            issues.append({"line": exc.lineno or 0, "severity": "critical", "rule": "syntax_error",
                           "problem": f"the file does not parse: {exc.msg}", "code": ""})
    order = {"critical": 0, "high": 1, "medium": 2, "style": 3, "info": 4}
    issues.sort(key=lambda d: (order.get(d["severity"], 9), d["line"]))
    counts: Dict[str, int] = {}
    for i in issues:
        counts[i["severity"]] = counts.get(i["severity"], 0) + 1
    score = max(0, 100 - sum(w * n for w, n in ((40, counts.get("critical", 0)),
                                                (20, counts.get("high", 0)),
                                                (8, counts.get("medium", 0)),
                                                (2, counts.get("style", 0)),
                                                (1, counts.get("info", 0)))))
    out = {"ok": True, "source": source, "language": language or "python", "issues": issues,
           "issue_count": len(issues), "counts": counts, "score": score, "strict": bool(strict),
           "verdict": ("do not ship this as-is" if score < 40 else
                       "needs work before it is production-ready" if score < 70 else
                       "looks reasonable" if score < 90 else "clean"),
           "note": "Static pattern review, not a full analyser. It finds the shapes that cause "
                   "incidents (secrets, shell-outs, swallowed errors, giant functions); run a "
                   "real linter for style."}
    if not issues:
        out["answer"] = f"No problems found in {source} — score {score}/100."
    else:
        out["answer"] = (f"Review of {source}: **{len(issues)} issue(s)**, score {score}/100 — "
                         f"{out['verdict']}.\n"
                         + "\n".join(f"- L{d['line']} [{d['severity']}] {d['rule']}: {d['problem']}"
                                     + (f"\n    `{d['code']}`" if d.get("code") else "")
                                     for d in issues[:20])
                         + (f"\n… and {len(issues) - 20} more" if len(issues) > 20 else ""))
    return out


# ===========================================================================
# 7. GENERATION
# ===========================================================================
@tool(
    name="code.snippet",
    capability="code.utilities",
    agent="coding",
    device="both",
    description="Produce a ready-to-use code snippet for a task, with the imports and the safety notes spelled out",
    schema={"task": {"type": "string", "required": True,
                     "description": "what the code must do"},
            "language": {"type": "string", "default": "python"},
            "style": {"type": "string", "default": "production",
                      "description": "quick | production | teaching"},
            "save": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=180,
)
async def code_snippet(ctx: ToolContext, task: str = "", language: str = "python",
                       style: str = "production", save: bool = False,
                       request: str = "") -> Dict[str, Any]:
    body = (task or request or "").strip()
    if not body:
        return _bad("tell me what the snippet must do")
    lang = (language or "python").lower()
    style = (style or "production").lower()

    # deterministic offline templates for the things people ask for most
    low = body.lower()
    template = None
    if lang == "python":
        if any(w in low for w in ("http", "request", "api", "fetch", "get json", "post")):
            template = '''import httpx

TIMEOUT = 15.0


async def call(url: str, params: dict | None = None) -> dict:
    """GET a URL and return parsed JSON, with an explicit error shape."""
    async with httpx.AsyncClient(timeout=TIMEOUT,
                                 headers={"User-Agent": "sam/1.0"}) as client:
        resp = await client.get(url, params=params)
        resp.raise_for_status()          # never swallow a 4xx/5xx
        return resp.json()


if __name__ == "__main__":
    import asyncio
    print(asyncio.run(call("https://api.frankfurter.app/latest", {"base": "USD"})))
'''
        elif any(w in low for w in ("csv", "excel", "xlsx", "spreadsheet", "pandas", "dataframe")):
            template = '''from pathlib import Path

import pandas as pd


def load(path: str | Path, sheet: str | int = 0) -> pd.DataFrame:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(p)
    if p.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(p, sheet_name=sheet)
    return pd.read_csv(p)


def summarise(df: pd.DataFrame) -> dict:
    return {
        "rows": int(len(df)),
        "columns": list(df.columns),
        "missing": df.isna().sum().to_dict(),
        "numeric": df.describe().to_dict(),
    }


if __name__ == "__main__":
    frame = load("data.csv")
    print(summarise(frame))
'''
        elif any(w in low for w in ("sqlite", "database", "sql", "insert", "select")):
            template = '''import sqlite3
from contextlib import contextmanager


@contextmanager
def connect(path: str = "app.db"):
    """Always use a context manager: the connection closes even on error."""
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def fetch_all(query: str, params: tuple = ()) -> list[dict]:
    # parameters, never string concatenation — that is what stops SQL injection
    with connect() as conn:
        return [dict(r) for r in conn.execute(query, params).fetchall()]


if __name__ == "__main__":
    with connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, body TEXT)")
        conn.execute("INSERT INTO notes (body) VALUES (?)", ("hello",))
    print(fetch_all("SELECT id, body FROM notes WHERE body LIKE ?", ("%hel%",)))
'''
        elif any(w in low for w in ("file", "read", "write", "json", "config", "save")):
            template = '''import json
from pathlib import Path


def read_json(path: str | Path, default=None):
    p = Path(path)
    if not p.is_file():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"{p} is not valid JSON: {exc}") from exc


def write_json(path: str | Path, data, indent: int = 2) -> Path:
    """Write atomically: build a temp file, then rename. A crash cannot leave
    a half-written config behind."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=indent, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)
    return p


if __name__ == "__main__":
    write_json("config.json", {"theme": "dark", "limit": 50})
    print(read_json("config.json"))
'''
        elif any(w in low for w in ("retry", "backoff", "flaky", "unstable")):
            template = '''import asyncio
import random
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")


async def retry(fn: Callable[..., Awaitable[T]], *args, attempts: int = 4,
                base_delay: float = 0.4, retry_on: tuple = (Exception,), **kwargs) -> T:
    """Exponential backoff with full jitter. Re-raises the last error."""
    last: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return await fn(*args, **kwargs)
        except retry_on as exc:
            last = exc
            if attempt == attempts:
                break
            delay = base_delay * (2 ** (attempt - 1)) * random.uniform(0.5, 1.0)
            await asyncio.sleep(delay)
    raise last  # type: ignore[misc]
'''
    if template is None:
        # no local template: ask the model, and be honest when there is none
        from backend.app.models.router import router
        prompt = (f"Write a {style} {lang} snippet that: {body}\n"
                  "Rules: complete and runnable, no placeholders, include the imports, handle the "
                  "obvious error cases, add a short docstring, and no comments that restate the "
                  "code. Return ONLY the code in one fenced block.")
        try:
            res = await router.ask(prompt, role="coding", max_tokens=1400, temperature=0.2)
            text = (res.text or "").strip()
        except Exception as exc:
            text = ""
            log.debug("snippet model call failed: %s", exc)
        if not text or getattr(res, "provider", "") == "heuristic" or \
                "I parsed that as intent" in text:
            return {"ok": True, "language": lang, "engine": "none", "code": "",
                    "answer": f"SAM has no local template for that and no language model is "
                              f"configured, so it will not invent code. Add a model key to .env "
                              f"(or start Ollama) and ask again — or use coding.generate, which "
                              f"plans the change across your project files first.",
                    "note": "Refusing to guess is deliberate: a plausible-looking snippet that "
                            "was never written is worse than an honest 'no'."}
        m = re.search(r"```[\w+-]*\n(.*?)```", text, re.S)
        code_text = (m.group(1) if m else text).strip()
        engine = "model"
    else:
        code_text, engine = template.strip(), "template"
    saved = None
    if save and code_text:
        ext = {"python": "py", "javascript": "js", "typescript": "ts", "bash": "sh",
               "sql": "sql", "html": "html", "css": "css", "json": "json"}.get(lang, "txt")
        name = _safe_name(re.sub(r"[^a-z0-9]+", "_", body.lower())[:40].strip("_") or "snippet")
        target = _artifact_dir("code") / f"{name}.{ext}"
        target.write_text(code_text + "\n", encoding="utf-8")
        saved = {"path": str(target), "name": target.name, "bytes": target.stat().st_size,
                 "url": f"/api/v1/files/artifact/code/{target.name}"}
    out = {"ok": True, "language": lang, "style": style, "task": body, "engine": engine,
           "code": code_text, "lines": code_text.count("\n") + 1, "saved": saved,
           "answer": f"{lang} snippet ({engine}, {code_text.count(chr(10)) + 1} lines)"
                     + (f", saved to {saved['path']}" if saved else "")
                     + f":\n\n```{lang}\n{_clip(code_text, 3000)}\n```"}
    return out


@tool(
    name="code.random_data",
    capability="code.utilities",
    agent="data",
    device="both",
    description="Generate fake test data (users, orders, events, logs, products) as JSON, CSV or SQL inserts",
    schema={"kind": {"type": "string", "default": "users",
                     "description": "users | orders | events | logs | products | transactions | ips"},
            "count": {"type": "integer", "default": 10},
            "format": {"type": "string", "default": "json", "description": "json | csv | sql | markdown"},
            "table": {"type": "string", "default": "rows"},
            "seed": {"type": "integer", "description": "fix the seed for reproducible data"}},
    risk="LOW",
    timeout=90,
)
async def code_random_data(ctx: ToolContext, kind: str = "users", count: int = 10,
                           format: str = "json", table: str = "rows", seed: Optional[int] = None,
                           request: str = "") -> Dict[str, Any]:
    rng = random.Random(seed)
    n = max(1, min(int(count or 10), 2000))
    kind = (kind or "users").lower().rstrip("s") if (kind or "").lower() not in ("logs",) else "logs"
    first = ["Aarav", "Diya", "Rohan", "Ananya", "Karan", "Meera", "Vihaan", "Isha", "Arjun",
             "Sara", "Liam", "Emma", "Noah", "Olivia", "Rahul", "Priya", "Aditya", "Neha"]
    last = ["Sharma", "Verma", "Iyer", "Nair", "Patel", "Khan", "Singh", "Reddy", "Gupta",
            "Smith", "Johnson", "Brown", "Lee", "Garcia", "Das", "Kulkarni"]
    cities = ["Bengaluru", "Mumbai", "Delhi", "Chennai", "Hyderabad", "Pune", "Kolkata",
              "London", "Berlin", "Singapore", "Dubai", "Tokyo"]
    products = ["Keyboard", "Monitor", "USB-C Hub", "Laptop Stand", "Webcam", "Headset",
                "SSD 1TB", "RAM 16GB", "Mouse", "Docking Station"]
    levels = ["INFO", "WARN", "ERROR", "DEBUG"]
    services = ["api", "auth", "payments", "search", "worker", "gateway", "scheduler"]
    rows: List[Dict[str, Any]] = []
    base = datetime.now(dt_timezone.utc) - timedelta(days=n)
    for i in range(n):
        when = base + timedelta(minutes=rng.randint(0, n * 24 * 60))
        if kind == "user":
            rows.append({"id": i + 1, "name": f"{rng.choice(first)} {rng.choice(last)}",
                         "email": f"user{i + 1}@example.com", "city": rng.choice(cities),
                         "age": rng.randint(18, 70), "signup": when.date().isoformat(),
                         "plan": rng.choice(["free", "pro", "team"]),
                         "active": rng.random() > 0.25})
        elif kind == "order":
            qty = rng.randint(1, 6)
            price = round(rng.uniform(9, 999), 2)
            rows.append({"id": 1000 + i, "user_id": rng.randint(1, max(1, n)),
                         "product": rng.choice(products), "quantity": qty, "unit_price": price,
                         "total": round(qty * price, 2), "currency": "USD",
                         "status": rng.choice(["paid", "pending", "refunded", "shipped"]),
                         "created_at": when.isoformat()})
        elif kind == "event":
            rows.append({"id": i + 1, "type": rng.choice(["click", "view", "purchase", "signup",
                                                          "error", "search"]),
                         "user_id": rng.randint(1, max(1, n)), "session": uuid_lib.uuid4().hex[:12],
                         "page": rng.choice(["/home", "/pricing", "/docs", "/cart", "/checkout"]),
                         "value": round(rng.uniform(0, 500), 2), "at": when.isoformat()})
        elif kind == "logs":
            rows.append({"ts": when.isoformat(), "level": rng.choice(levels),
                         "service": rng.choice(services),
                         "message": rng.choice(["request completed", "cache miss",
                                                "retrying upstream", "timeout after 5s",
                                                "rate limit hit", "connection reset",
                                                "job finished", "invalid token"]),
                         "latency_ms": rng.randint(1, 2500), "status": rng.choice(
                             [200, 201, 400, 401, 404, 429, 500, 503])})
        elif kind == "product":
            cost = round(rng.uniform(2, 400), 2)
            rows.append({"sku": f"SKU-{1000 + i}", "name": rng.choice(products),
                         "category": rng.choice(["hardware", "accessories", "storage"]),
                         "price": round(cost * rng.uniform(1.2, 3.0), 2), "cost": cost,
                         "stock": rng.randint(0, 500), "rating": round(rng.uniform(2.5, 5), 1)})
        elif kind == "transaction":
            amount = round(rng.uniform(1, 5000), 2)
            rows.append({"id": uuid_lib.uuid4().hex[:16], "account": f"ACC-{rng.randint(1, 99):03d}",
                         "amount": amount, "currency": rng.choice(["USD", "INR", "EUR"]),
                         "type": rng.choice(["credit", "debit"]),
                         "merchant": rng.choice(products).lower(), "at": when.isoformat(),
                         "flagged": rng.random() < 0.05})
        elif kind == "ip":
            rows.append({"ip": ".".join(str(rng.randint(1, 254)) for _ in range(4)),
                         "country": rng.choice(["IN", "US", "DE", "GB", "SG", "JP", "BR"]),
                         "city": rng.choice(cities), "requests": rng.randint(1, 9000),
                         "blocked": rng.random() < 0.1})
        else:
            return _bad(f"unknown kind '{kind}'. Use users, orders, events, logs, products, "
                        f"transactions or ips")
    fmt = (format or "json").lower()
    if fmt == "json":
        out_text = json.dumps(rows, indent=2, ensure_ascii=False)
    elif fmt == "csv":
        import csv
        import io
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=list(rows[0]), extrasaction="ignore")
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
        out_text = buf.getvalue().strip()
    elif fmt == "sql":
        columns = list(rows[0])
        tbl = re.sub(r"[^\w_]", "_", table or "rows")
        stmts = [f"CREATE TABLE IF NOT EXISTS {tbl} (" + ", ".join(
            f"{c} TEXT" for c in columns) + ");"]
        for r in rows[:500]:
            vals = ", ".join("'" + str(v).replace("'", "''") + "'" for v in
                             (r.get(c) for c in columns))
            stmts.append(f"INSERT INTO {tbl} ({', '.join(columns)}) VALUES ({vals});")
        out_text = "\n".join(stmts)
    else:
        columns = list(rows[0])
        head = "| " + " | ".join(columns) + " |"
        sep = "| " + " | ".join("---" for _ in columns) + " |"
        body_rows = ["| " + " | ".join(str(r.get(c, "")) for c in columns) + " |" for r in rows]
        out_text = "\n".join([head, sep] + body_rows)
    out = {"ok": True, "kind": kind, "count": len(rows), "format": fmt, "text": out_text,
           "rows": rows[:200], "columns": list(rows[0]), "seed": seed,
           "reproducible": seed is not None,
           "note": "Synthetic data only — no real personal information. Pass a seed to get the "
                   "same dataset again."}
    out["answer"] = (f"{len(rows)} fake {kind} row(s) as {fmt.upper()}"
                     + (f" (seed {seed})" if seed is not None else "")
                     + f", columns: {', '.join(list(rows[0]))}\n\n{_clip(out_text, 2000)}")
    return out


@tool(
    name="code.artifact",
    capability="code.artifact",
    agent="coding",
    device="pc",
    description="Save generated text, code or data as a file in SAM's artifact folder and return a link the UI can open",
    schema={"content": {"type": "string", "required": True},
            "file_name": {"type": "string", "required": True,
                          "description": "file name, e.g. report.md"},
            "category": {"type": "string", "default": "code",
                         "description": "code | documents | data | creative"},
            "append": {"type": "boolean", "default": False}},
    risk="MEDIUM",
    confirm=False,
    timeout=60,
)
async def code_artifact(ctx: ToolContext, content: str = "", file_name: str = "",
                        category: str = "code", append: bool = False,
                        request: str = "") -> Dict[str, Any]:
    body = content or request or ""
    if not body.strip():
        return _bad("there is nothing to save")
    cat = re.sub(r"[^\w.-]", "_", (category or "code").lower())
    if cat not in ("code", "documents", "data", "creative", "reports"):
        cat = "code"
    target = _artifact_dir(cat) / _safe_name(file_name, "artifact.txt")
    try:
        mode = "a" if append else "w"
        with target.open(mode, encoding="utf-8") as fh:
            fh.write(body if body.endswith("\n") else body + "\n")
    except OSError as exc:
        return _bad(f"could not write the artifact: {exc}")
    size = target.stat().st_size
    out = {"ok": True, "path": str(target), "name": target.name, "category": cat, "bytes": size,
           "appended": bool(append), "lines": body.count("\n") + 1,
           "url": artifact_url(cat, target.name),
           "answer": f"Saved `{target.name}` ({size:,} bytes, {body.count(chr(10)) + 1} line(s)) "
                     f"to the **{cat}** artifacts folder at `{target}`.\n"
                     f"The UI can open it at {artifact_url(cat, target.name)}."}
    return out


def artifact_url(category: str, name: str) -> str:
    """Relative URL the dashboard uses to open a saved artifact."""
    return f"/api/v1/files/artifact/{category}/{name}"


@tool(
    name="code.qrcode",
    capability="code.artifact",
    agent="creative",
    device="pc",
    description="Generate a QR code image (share a URL, Wi-Fi details or text with the phone companion)",
    schema={"text": {"type": "string", "required": True, "description": "the payload to encode"},
            "file_name": {"type": "string", "default": "qrcode.png"},
            "size": {"type": "integer", "default": 10, "description": "module size in pixels"},
            "border": {"type": "integer", "default": 4},
            "wifi": {"type": "boolean", "default": False,
                     "description": "true = encode as a Wi-Fi join string (SSID/text = password)"}},
    risk="LOW",
    timeout=60,
)
async def code_qrcode(ctx: ToolContext, text: str = "", file_name: str = "qrcode.png",
                      size: int = 10, border: int = 4, wifi: bool = False,
                      request: str = "") -> Dict[str, Any]:
    payload = (text or request or "").strip()
    if not payload:
        return _bad("give me the text or URL to encode")
    if wifi:
        ssid, _, password = payload.partition("|")
        payload = f"WIFI:T:WPA;S:{ssid};P:{password};;"
    try:
        import qrcode                                            # type: ignore
    except ImportError:
        # no library: fall back to an ASCII rendering so the answer is still useful
        return {"ok": False, "error": "the 'qrcode' package is not installed — run "
                                      "`pip install qrcode[pil]`",
                "payload": payload,
                "answer": "SAM cannot draw the QR image without the `qrcode` package. "
                          "Install it with `pip install qrcode[pil]` and ask again; the payload "
                          f"that would be encoded is:\n\n`{payload}`"}
    target = _artifact_dir("code") / _safe_name(file_name, "qrcode.png")
    if target.suffix.lower() not in (".png", ".jpg", ".jpeg"):
        target = target.with_suffix(".png")
    try:
        qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M,
                           box_size=max(1, int(size or 10)), border=max(0, int(border or 4)))
        qr.add_data(payload)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(str(target))
    except Exception as exc:
        return _bad(f"could not build the QR code: {type(exc).__name__}: {exc}")
    ascii_rows: List[str] = []
    try:
        matrix = qr.get_matrix()
        for row in matrix[:60]:
            ascii_rows.append("".join("##" if cell else "  " for cell in row))
    except Exception:
        pass
    size = target.stat().st_size
    modules = len(qr.get_matrix())
    url = artifact_url("code", target.name)
    out = {"ok": True, "path": str(target), "file_name": target.name, "bytes": size,
           "payload": payload, "version": qr.version, "modules": modules, "url": url,
           "ascii": "\n".join(ascii_rows)[:3000],
           "answer": f"QR code saved to `{target.name}` ({size:,} bytes, version {qr.version}, "
                     f"{modules}×{modules} modules) encoding:\n`{payload}`\n"
                     f"The dashboard can open it at {url}."}
    return out
