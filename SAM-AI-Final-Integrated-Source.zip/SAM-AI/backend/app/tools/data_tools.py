"""
backend.app.tools.data_tools
============================

The Data Brain: CSV/Excel loading, cleaning, statistics, transformation,
charting and reporting.

Charts are rendered with Pillow (always available) or Matplotlib when installed,
so SAM can produce a PNG/PDF chart without a heavy dependency. Reports come out
as Markdown that the Document System renders into DOCX/PDF/XLSX.
"""

from __future__ import annotations

import asyncio
import csv
import io
import json
import math
import re
import statistics
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.data")

MAX_ROWS = 100_000


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def _load_csv(path: Path, delimiter: str = "") -> Tuple[List[str], List[List[Any]]]:
    sample = path.read_text(encoding="utf-8", errors="replace")[:8192]
    if not delimiter:
        try:
            delimiter = csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
        except Exception:
            delimiter = "," if sample.count(",") >= sample.count(";") else ";"
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        reader = csv.reader(fh, delimiter=delimiter)
        rows = list(reader)
    if not rows:
        return [], []
    header = [h.strip() or f"column_{i + 1}" for i, h in enumerate(rows[0])]
    return header, rows[1:]


def _load_xlsx(path: Path, sheet: str = "") -> Tuple[List[str], List[List[Any]], List[str]]:
    import openpyxl

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    names = wb.sheetnames
    ws = wb[sheet] if sheet and sheet in names else wb[names[0]]
    rows = []
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        rows.append(list(row))
        if i >= MAX_ROWS:
            break
    wb.close()
    if not rows:
        return [], [], names
    header = [str(c).strip() if c is not None else f"column_{i + 1}" for i, c in enumerate(rows[0])]
    return header, rows[1:], names


def _coerce(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (int, float, bool)):
        return value
    s = str(value).strip()
    if not s:
        return None
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    if re.fullmatch(r"-?\d*\.\d+", s):
        return float(s)
    if re.fullmatch(r"-?\d{1,3}(,\d{3})+(\.\d+)?", s):
        return float(s.replace(",", ""))
    if s.endswith("%") and re.fullmatch(r"-?\d+(\.\d+)?%", s):
        return float(s[:-1])
    low = s.lower()
    if low in ("true", "yes", "y"):
        return True
    if low in ("false", "no", "n"):
        return False
    return s


def load_table(path: str | Path, sheet: str = "") -> Dict[str, Any]:
    p = Path(path).expanduser()
    if not p.exists():
        return {"ok": False, "error": f"file does not exist: {p}"}
    ext = p.suffix.lower()
    sheets: List[str] = []
    try:
        if ext in (".xlsx", ".xlsm"):
            header, rows, sheets = _load_xlsx(p, sheet)
        elif ext in (".csv", ".tsv", ".txt"):
            header, rows = _load_csv(p, "\t" if ext == ".tsv" else "")
        elif ext == ".json":
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data = data.get("data") or data.get("rows") or list(data.values())[0]
            if not isinstance(data, list) or not data:
                return {"ok": False, "error": "JSON file does not contain a list of records"}
            header = list(data[0].keys()) if isinstance(data[0], dict) else [f"column_{i + 1}" for i in range(len(data[0]))]
            rows = [[r.get(h) for h in header] if isinstance(r, dict) else list(r) for r in data]
        else:
            return {"ok": False, "error": f"unsupported data format '{ext}'",
                    "supported": [".csv", ".tsv", ".xlsx", ".json"]}
    except Exception as exc:
        return {"ok": False, "error": f"could not load {p.name}: {exc}"}

    typed = [[_coerce(c) for c in row] for row in rows[:MAX_ROWS]]
    types = _infer_types(header, typed)
    return {"ok": True, "path": str(p), "name": p.name, "sheets": sheets,
            "columns": header, "types": types, "rows": typed, "row_count": len(typed),
            "column_count": len(header)}


def _infer_types(header: List[str], rows: List[List[Any]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for i, name in enumerate(header):
        values = [r[i] for r in rows[:500] if i < len(r) and r[i] is not None]
        if not values:
            out[name] = "empty"
        elif all(isinstance(v, bool) for v in values):
            out[name] = "boolean"
        elif all(isinstance(v, (int, float)) for v in values):
            out[name] = "integer" if all(isinstance(v, int) for v in values) else "number"
        else:
            strs = [str(v) for v in values]
            if all(re.match(r"\d{4}-\d{2}-\d{2}", s) for s in strs):
                out[name] = "date"
            elif len(set(strs)) <= max(12, len(strs) // 20):
                out[name] = "category"
            else:
                out[name] = "text"
    return out


def _column(table: Dict[str, Any], name: str) -> Tuple[int, List[Any]]:
    cols = table["columns"]
    if name in cols:
        idx = cols.index(name)
    else:
        match = [c for c in cols if c.lower() == name.lower()]
        if not match:
            match = [c for c in cols if name.lower() in c.lower()]
        if not match:
            return -1, []
        idx = cols.index(match[0])
        name = match[0]
    values = [r[idx] for r in table["rows"] if idx < len(r)]
    return idx, values


def _numeric(values: List[Any]) -> List[float]:
    out = []
    for v in values:
        if isinstance(v, bool):
            continue
        if isinstance(v, (int, float)):
            out.append(float(v))
        elif isinstance(v, str):
            n = _coerce(v)
            if isinstance(n, (int, float)) and not isinstance(n, bool):
                out.append(float(n))
    return out


# ===========================================================================
# TOOLS
# ===========================================================================
@tool(
    name="data.load",
    capability="files.read",
    agent="data",
    device="pc",
    description="Load a CSV/Excel/JSON dataset and profile its columns",
    risk="LOW",
    timeout=180,
)
async def data_load(ctx: ToolContext, path: str = "", sheet: str = "",
                    query: str = "") -> Dict[str, Any]:
    from backend.app.files.file_ops import FileSecurityError, assert_allowed

    target = path or _path_from_text(query or ctx.user_text)
    if not target:
        # fall back to the newest recent data file in an allowed root
        target = _guess_data_file()
    if not target:
        return {"ok": False, "error": "no dataset path given"}
    try:
        assert_allowed(target)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}

    loop = asyncio.get_running_loop()
    table = await loop.run_in_executor(None, load_table, target, sheet)
    if not table.get("ok"):
        return table

    profile = _profile(table)
    return {
        "ok": True, "path": table["path"], "name": table["name"], "sheets": table.get("sheets", []),
        "row_count": table["row_count"], "column_count": table["column_count"],
        "columns": table["columns"], "types": table["types"], "profile": profile,
        "head": [dict(zip(table["columns"], r)) for r in table["rows"][:10]],
        "_table_ref": _stash(table),
    }


_STASH: Dict[str, Dict[str, Any]] = {}


def _stash(table: Dict[str, Any]) -> str:
    key = f"tbl_{int(time.time() * 1000)}_{len(_STASH)}"
    if len(_STASH) > 20:
        _STASH.pop(next(iter(_STASH)))
    _STASH[key] = table
    return key


def _get_stashed(ctx: ToolContext) -> Optional[Dict[str, Any]]:
    for value in list(ctx.outputs.values())[::-1]:
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict) and inner.get("_table_ref") in _STASH:
                return _STASH[inner["_table_ref"]]
    ref = ctx.params.get("_table_ref")
    return _STASH.get(ref) if ref else None


def _path_from_text(text: str) -> str:
    m = re.search(r"([A-Za-z]:[\\/][^\s'\"]+\.(?:csv|xlsx|json|tsv)|~/[^\s'\"]+\.(?:csv|xlsx|json|tsv)|"
                  r"/[^\s'\"]+\.(?:csv|xlsx|json|tsv))", text or "")
    return m.group(1) if m else ""


def _guess_data_file() -> str:
    from backend.app.files.file_ops import walk

    best: Tuple[float, str] = (0.0, "")
    for root in settings.allowed_roots:
        if not root.exists():
            continue
        for p in walk(root, max_files=5000):
            if p.suffix.lower() in (".csv", ".xlsx", ".json") and p.stat().st_mtime > best[0]:
                best = (p.stat().st_mtime, str(p))
    return best[1]


def _profile(table: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for col in table["columns"]:
        idx, values = _column(table, col)
        if idx < 0:
            continue
        non_null = [v for v in values if v is not None]
        entry: Dict[str, Any] = {
            "type": table["types"].get(col, "text"),
            "count": len(values),
            "non_null": len(non_null),
            "missing": len(values) - len(non_null),
            "missing_percent": round((len(values) - len(non_null)) / max(1, len(values)) * 100, 2),
            "unique": len(set(str(v) for v in non_null)),
        }
        nums = _numeric(non_null)
        if nums:
            entry.update({
                "min": round(min(nums), 4), "max": round(max(nums), 4),
                "mean": round(statistics.fmean(nums), 4),
                "median": round(statistics.median(nums), 4),
                "stdev": round(statistics.pstdev(nums), 4) if len(nums) > 1 else 0.0,
                "sum": round(sum(nums), 4),
            })
            qs = statistics.quantiles(nums, n=4) if len(nums) >= 4 else None
            if qs:
                entry.update({"q1": round(qs[0], 4), "q3": round(qs[2], 4)})
        else:
            counter = Counter(str(v) for v in non_null)
            entry["top_values"] = [{"value": k, "count": v} for k, v in counter.most_common(8)]
        out[col] = entry
    return out


@tool(
    name="data.clean",
    capability="files.write",
    agent="data",
    device="pc",
    description="Clean a dataset: trim, fix types, dedupe, fill or drop missing values",
    risk="MEDIUM",
    confirm=True,
    timeout=300,
)
async def data_clean(ctx: ToolContext, path: str = "", drop_missing: bool = False,
                     fill_missing: str = "", dedupe: bool = True, trim: bool = True,
                     output: str = "", query: str = "") -> Dict[str, Any]:
    from backend.app.files.file_ops import FileSecurityError, assert_allowed

    table = _get_stashed(ctx)
    if table is None:
        loaded = await data_load(ctx, path=path or _path_from_text(query or ctx.user_text))
        if not loaded.get("ok"):
            return loaded
        table = _STASH.get(loaded["_table_ref"])
    if table is None:
        return {"ok": False, "error": "no dataset loaded"}

    header: List[str] = list(table["columns"])
    rows: List[List[Any]] = [list(r) for r in table["rows"]]
    changes: List[str] = []
    before = len(rows)

    if trim:
        trimmed = 0
        for r in rows:
            for i, v in enumerate(r):
                if isinstance(v, str) and v != v.strip():
                    r[i] = v.strip()
                    trimmed += 1
        if trimmed:
            changes.append(f"trimmed whitespace in {trimmed} cells")

    # type coercion
    coerced = 0
    for r in rows:
        for i, v in enumerate(r):
            new = _coerce(v)
            if new != v:
                coerced += 1
                r[i] = new
    if coerced:
        changes.append(f"normalised {coerced} values to their proper type")

    if dedupe:
        seen = set()
        unique: List[List[Any]] = []
        for r in rows:
            key = json.dumps(r, default=str, sort_keys=True)
            if key in seen:
                continue
            seen.add(key)
            unique.append(r)
        if len(unique) != len(rows):
            changes.append(f"removed {len(rows) - len(unique)} duplicate rows")
            rows = unique

    if drop_missing:
        kept = [r for r in rows if all(v is not None and v != "" for v in r)]
        if len(kept) != len(rows):
            changes.append(f"dropped {len(rows) - len(kept)} rows with missing values")
            rows = kept
    elif fill_missing:
        strategy = fill_missing.lower()
        filled = 0
        for i, col in enumerate(header):
            values = [r[i] for r in rows if i < len(r) and r[i] is not None]
            nums = _numeric(values)
            if strategy in ("mean", "average") and nums:
                fill_value: Any = round(statistics.fmean(nums), 4)
            elif strategy == "median" and nums:
                fill_value = round(statistics.median(nums), 4)
            elif strategy in ("zero", "0"):
                fill_value = 0
            elif strategy == "mode" and values:
                fill_value = Counter(str(v) for v in values).most_common(1)[0][0]
            else:
                fill_value = fill_missing
            for r in rows:
                while len(r) <= i:
                    r.append(None)
                if r[i] is None or r[i] == "":
                    r[i] = fill_value
                    filled += 1
        if filled:
            changes.append(f"filled {filled} missing values with strategy '{strategy}'")

    result = {"ok": True, "rows_before": before, "rows_after": len(rows),
              "columns": header, "changes": changes, "cleaned_rows": rows[:50]}

    if output:
        try:
            out_path = assert_allowed(output, for_write=True)
        except FileSecurityError as exc:
            result["save_error"] = str(exc)
            return result
        loop = asyncio.get_running_loop()
        result.update(await loop.run_in_executor(None, _save_table, header, rows, out_path))
    else:
        result["note"] = "no output path given — pass `output` to save the cleaned dataset"

    result["_table_ref"] = _stash({"ok": True, "columns": header, "rows": rows,
                                   "types": table["types"], "row_count": len(rows),
                                   "column_count": len(header), "path": table.get("path", ""),
                                   "name": "cleaned"})
    return result


def _save_table(header: List[str], rows: List[List[Any]], path: Path) -> Dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    ext = path.suffix.lower()
    try:
        if ext == ".csv":
            with open(path, "w", newline="", encoding="utf-8") as fh:
                writer = csv.writer(fh)
                writer.writerow(header)
                writer.writerows(rows)
        elif ext == ".json":
            path.write_text(json.dumps([dict(zip(header, r)) for r in rows], indent=2, default=str),
                            encoding="utf-8")
        else:
            import openpyxl
            from openpyxl.styles import Font, PatternFill

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Cleaned"
            ws.append(header)
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1F2937")
            for r in rows[:MAX_ROWS]:
                ws.append([v if isinstance(v, (int, float, bool)) or v is None else str(v) for v in r])
            ws.freeze_panes = "A2"
            wb.save(str(path))
        return {"saved": str(path), "bytes": path.stat().st_size}
    except Exception as exc:
        return {"save_error": str(exc)}


@tool(
    name="data.analyse",
    capability="files.read",
    agent="data",
    device="pc",
    description="Compute statistics, group-bys, correlations and top/bottom N for a dataset",
    risk="LOW",
    timeout=180,
)
async def data_analyse(ctx: ToolContext, group_by: str = "", metric: str = "",
                       agg: str = "mean", top: int = 10, path: str = "",
                       query: str = "") -> Dict[str, Any]:
    table = _get_stashed(ctx)
    if table is None:
        loaded = await data_load(ctx, path=path or _path_from_text(query or ctx.user_text))
        if not loaded.get("ok"):
            return loaded
        table = _STASH.get(loaded["_table_ref"])
    if table is None:
        return {"ok": False, "error": "no dataset loaded"}

    header: List[str] = table["columns"]
    rows: List[List[Any]] = table["rows"]
    out: Dict[str, Any] = {"ok": True, "row_count": len(rows), "columns": header,
                           "types": table["types"], "summary": {}}

    numeric_cols = [c for c, t in table["types"].items() if t in ("number", "integer")]
    for col in numeric_cols[:20]:
        _, values = _column(table, col)
        nums = _numeric(values)
        if not nums:
            continue
        out["summary"][col] = {
            "count": len(nums), "sum": round(sum(nums), 4),
            "mean": round(statistics.fmean(nums), 4), "median": round(statistics.median(nums), 4),
            "min": round(min(nums), 4), "max": round(max(nums), 4),
            "stdev": round(statistics.pstdev(nums), 4) if len(nums) > 1 else 0.0,
        }
        if len(nums) >= 4:
            qs = statistics.quantiles(nums, n=4)
            out["summary"][col].update({"q1": round(qs[0], 4), "q3": round(qs[2], 4)})

    # correlations between numeric columns
    if len(numeric_cols) >= 2:
        corr: Dict[str, Dict[str, float]] = {}
        for a in numeric_cols[:10]:
            _, av = _column(table, a)
            an = _numeric(av)
            for b in numeric_cols[:10]:
                if a == b:
                    continue
                _, bv = _column(table, b)
                bn = _numeric(bv)
                n = min(len(an), len(bn))
                if n < 3:
                    continue
                r = _pearson(an[:n], bn[:n])
                if r is not None and abs(r) > 0.3:
                    corr.setdefault(a, {})[b] = round(r, 3)
        if corr:
            out["correlations"] = corr

    # group by
    if group_by:
        gidx, gvalues = _column(table, group_by)
        if gidx < 0:
            out["group_by_error"] = f"column '{group_by}' not found"
        else:
            target = metric or (numeric_cols[0] if numeric_cols else None)
            buckets: Dict[str, List[float]] = defaultdict(list)
            counts: Counter = Counter()
            for r in rows:
                key = str(r[gidx]) if gidx < len(r) and r[gidx] is not None else "(blank)"
                counts[key] += 1
                if target:
                    tidx, _ = _column(table, target)
                    if 0 <= tidx < len(r):
                        n = _coerce(r[tidx])
                        if isinstance(n, (int, float)) and not isinstance(n, bool):
                            buckets[key].append(float(n))
            groups = []
            for key, count in counts.most_common(500):
                values = buckets.get(key, [])
                entry: Dict[str, Any] = {"group": key, "count": count}
                if values:
                    entry.update({
                        agg: round(_aggregate(values, agg), 4),
                        "mean": round(statistics.fmean(values), 4),
                        "sum": round(sum(values), 4),
                        "min": round(min(values), 4), "max": round(max(values), 4),
                    })
                groups.append(entry)
            if target and values:
                groups.sort(key=lambda d: d.get(agg, d.get("count", 0)), reverse=True)
            out["group_by"] = {"column": group_by, "metric": target, "agg": agg,
                               "groups": groups[: max(1, int(top))], "total_groups": len(groups)}

    # top / bottom N on the metric
    if metric or numeric_cols:
        col = metric or numeric_cols[0]
        midx, values = _column(table, col)
        if midx >= 0:
            indexed = [(i, _coerce(v)) for i, v in enumerate(values)]
            indexed = [(i, v) for i, v in indexed if isinstance(v, (int, float)) and not isinstance(v, bool)]
            indexed.sort(key=lambda t: t[1], reverse=True)
            out["top"] = [{"row": i + 2, col: v,
                           **{c: rows[i][j] for j, c in enumerate(header) if j < len(rows[i])
                              and c != col}}
                          for i, v in indexed[: max(1, int(top))]]
            out["bottom"] = [{"row": i + 2, col: v} for i, v in indexed[-max(1, int(top)):]]

    out["insights"] = _insights(out, table)
    return out


def _aggregate(values: List[float], agg: str) -> float:
    agg = (agg or "mean").lower()
    if agg in ("sum", "total"):
        return sum(values)
    if agg in ("mean", "average", "avg"):
        return statistics.fmean(values)
    if agg == "median":
        return statistics.median(values)
    if agg in ("min", "minimum"):
        return min(values)
    if agg in ("max", "maximum"):
        return max(values)
    if agg in ("count", "n"):
        return float(len(values))
    if agg in ("stdev", "std"):
        return statistics.pstdev(values) if len(values) > 1 else 0.0
    return statistics.fmean(values)


def _pearson(a: List[float], b: List[float]) -> Optional[float]:
    if len(a) != len(b) or len(a) < 3:
        return None
    ma, mb = statistics.fmean(a), statistics.fmean(b)
    num = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    da = math.sqrt(sum((x - ma) ** 2 for x in a))
    db = math.sqrt(sum((y - mb) ** 2 for y in b))
    if da == 0 or db == 0:
        return None
    return num / (da * db)


def _insights(analysis: Dict[str, Any], table: Dict[str, Any]) -> List[str]:
    notes: List[str] = []
    summary = analysis.get("summary", {})
    for col, s in list(summary.items())[:6]:
        if s.get("stdev") and s.get("mean"):
            cv = s["stdev"] / abs(s["mean"]) if s["mean"] else 0
            if cv > 1:
                notes.append(f"{col} is highly dispersed (coefficient of variation {cv:.2f}) — "
                             f"expect outliers.")
        if s.get("max") and s.get("median") and s["median"]:
            if s["max"] > 5 * abs(s["median"]):
                notes.append(f"{col} has extreme values (max {s['max']} vs median {s['median']}).")
    corr = analysis.get("correlations", {})
    for a, partners in list(corr.items())[:3]:
        for b, r in list(partners.items())[:2]:
            direction = "positively" if r > 0 else "negatively"
            notes.append(f"{a} and {b} are {direction} correlated (r = {r}).")
    gb = analysis.get("group_by")
    if gb and gb.get("groups"):
        top = gb["groups"][0]
        notes.append(f"Largest {gb['column']} group is “{top['group']}” with {top['count']} rows.")
    profile_missing = [
        c for c in table["columns"]
        if any(r[i] in (None, "") for r in table["rows"][:200] for i in [table["columns"].index(c)]
               if i < len(r))
    ]
    if profile_missing:
        notes.append(f"Columns with missing values: {', '.join(profile_missing[:6])}.")
    if not notes:
        notes.append("No strong anomalies detected in the first pass.")
    return notes[:8]


@tool(
    name="data.chart",
    capability="creative.document.generate",
    agent="data",
    device="pc",
    description="Render a bar, line, pie or scatter chart to PNG from a dataset",
    risk="LOW",
    timeout=180,
)
async def data_chart(ctx: ToolContext, chart: str = "bar", x: str = "", y: str = "",
                     title: str = "", output: str = "", path: str = "",
                     group_by: str = "", agg: str = "mean", limit: int = 12) -> Dict[str, Any]:
    table = _get_stashed(ctx)
    if table is None:
        loaded = await data_load(ctx, path=path)
        if not loaded.get("ok"):
            return loaded
        table = _STASH.get(loaded["_table_ref"])
    if table is None:
        return {"ok": False, "error": "no dataset loaded"}

    # build the series
    labels: List[str] = []
    values: List[float] = []
    if group_by or (x and not y):
        gcol = group_by or x
        gidx, _ = _column(table, gcol)
        numeric_cols = [c for c, t in table["types"].items() if t in ("number", "integer") and c != gcol]
        vcol = y or (numeric_cols[0] if numeric_cols else None)
        if gidx < 0:
            return {"ok": False, "error": f"column '{gcol}' not found",
                    "columns": table["columns"]}
        buckets: Dict[str, List[float]] = defaultdict(list)
        vidx = -1
        if vcol:
            vidx, _ = _column(table, vcol)
        for r in table["rows"]:
            if gidx >= len(r):
                continue
            key = str(r[gidx]) if r[gidx] is not None else "(blank)"
            if vidx >= 0 and vidx < len(r):
                n = _coerce(r[vidx])
                if isinstance(n, (int, float)) and not isinstance(n, bool):
                    buckets[key].append(float(n))
            else:
                buckets[key].append(1.0)
        items = sorted(buckets.items(), key=lambda kv: _aggregate(kv[1], agg), reverse=True)[: int(limit)]
        labels = [k for k, _ in items]
        values = [round(_aggregate(v, agg), 4) for _, v in items]
        title = title or f"{agg.title()} of {vcol or 'count'} by {gcol}"
    elif x and y:
        xidx, xvals = _column(table, x)
        yidx, yvals = _column(table, y)
        if xidx < 0 or yidx < 0:
            return {"ok": False, "error": f"column not found ({x} / {y})", "columns": table["columns"]}
        pairs = [(a, _coerce(b)) for a, b in zip(xvals, yvals)
                 if isinstance(_coerce(b), (int, float)) and not isinstance(_coerce(b), bool)]
        pairs = pairs[: int(limit) * 10]
        labels = [str(a) for a, _ in pairs]
        values = [float(b) for _, b in pairs]
        title = title or f"{y} vs {x}"
    else:
        numeric_cols = [c for c, t in table["types"].items() if t in ("number", "integer")]
        if not numeric_cols:
            return {"ok": False, "error": "no numeric column found to chart",
                    "columns": table["columns"]}
        col = numeric_cols[0]
        _, vals = _column(table, col)
        nums = _numeric(vals)[: int(limit) * 10]
        labels = [str(i + 1) for i in range(len(nums))]
        values = nums
        title = title or col

    if not values:
        return {"ok": False, "error": "no numeric data to chart"}

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _render_chart, chart, labels, values, title, output)


def _render_chart(chart: str, labels: List[str], values: List[float], title: str,
                  output: str = "") -> Dict[str, Any]:
    chart = (chart or "bar").lower()
    out_dir = settings.sam_data_dir / "creative" / "charts"
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = int(time.time() * 1000)

    # --- matplotlib when available --------------------------------------
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(11, 6), dpi=130)
        fig.patch.set_facecolor("#0B1220")
        ax.set_facecolor("#0B1220")
        for spine in ax.spines.values():
            spine.set_color("#334155")
        ax.tick_params(colors="#CBD5E1")
        ax.xaxis.label.set_color("#CBD5E1")
        ax.yaxis.label.set_color("#CBD5E1")
        ax.title.set_color("#F8FAFC")
        ax.grid(True, color="#1E293B", linewidth=0.6, alpha=0.8)

        if chart in ("bar", "column", "histogram"):
            ax.bar(range(len(values)), values, color="#38BDF8", edgecolor="#0EA5E9")
            ax.set_xticks(range(len(values)))
            ax.set_xticklabels([l[:18] for l in labels], rotation=35, ha="right", fontsize=8)
        elif chart in ("line", "area", "trend"):
            ax.plot(range(len(values)), values, color="#38BDF8", linewidth=2.2, marker="o",
                    markersize=3.5)
            if chart == "area":
                ax.fill_between(range(len(values)), values, color="#38BDF8", alpha=0.22)
            step = max(1, len(labels) // 14)
            ax.set_xticks(range(0, len(labels), step))
            ax.set_xticklabels([labels[i][:18] for i in range(0, len(labels), step)],
                               rotation=35, ha="right", fontsize=8)
        elif chart in ("pie", "donut"):
            top = sorted(zip(labels, values), key=lambda t: t[1], reverse=True)[:8]
            other = sum(v for _, v in sorted(zip(labels, values), key=lambda t: t[1], reverse=True)[8:])
            plabels = [l for l, _ in top] + (["Other"] if other > 0 else [])
            pvalues = [v for _, v in top] + ([other] if other > 0 else [])
            colours = ["#38BDF8", "#F59E0B", "#22C55E", "#EF4444", "#A78BFA",
                       "#EC4899", "#14B8A6", "#F97316", "#64748B"]
            wedges, _ = ax.pie(pvalues, labels=None, autopct="%1.1f%%", startangle=110,
                               colors=colours[: len(pvalues)],
                               wedgeprops={"width": 0.42} if chart == "donut" else None,
                               textprops={"color": "#0B1220", "fontsize": 8, "weight": "bold"})
            ax.legend(wedges, plabels, loc="center left", bbox_to_anchor=(1.0, 0.5),
                      facecolor="#0B1220", edgecolor="#334155", labelcolor="#CBD5E1", fontsize=8)
        elif chart in ("scatter", "xy"):
            ax.scatter(range(len(values)), values, s=22, color="#22C55E", alpha=0.8)
        else:
            ax.bar(range(len(values)), values, color="#38BDF8")

        ax.set_title(title or "SAM chart", fontsize=13, weight="bold", pad=12)
        fig.tight_layout()
        path = Path(output) if output else out_dir / f"sam_chart_{stamp}.png"
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(str(path), facecolor=fig.get_facecolor(), bbox_inches="tight")
        plt.close(fig)
        return {"ok": True, "engine": "matplotlib", "chart": chart, "path": str(path),
                "bytes": path.stat().st_size, "title": title, "points": len(values),
                "labels": labels[:30], "values": values[:30]}
    except ImportError:
        pass
    except Exception as exc:
        log.debug("matplotlib chart failed: %s", exc)

    # --- Pillow fallback --------------------------------------------------
    try:
        from PIL import Image, ImageDraw, ImageFont

        W, H = 1200, 680
        pad_l, pad_r, pad_t, pad_b = 90, 40, 70, 130
        img = Image.new("RGB", (W, H), "#0B1220")
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("DejaVuSans-Bold.ttf", 24)
            small = ImageFont.truetype("DejaVuSans.ttf", 15)
            tiny = ImageFont.truetype("DejaVuSans.ttf", 12)
        except Exception:
            font = small = tiny = ImageFont.load_default()

        draw.text((pad_l, 24), (title or "SAM chart")[:80], fill="#F8FAFC", font=font)
        vmax = max(values) if values else 1
        vmin = min(0, min(values))
        span = (vmax - vmin) or 1
        plot_w, plot_h = W - pad_l - pad_r, H - pad_t - pad_b

        # grid
        for i in range(6):
            y = pad_t + int(plot_h * i / 5)
            draw.line([(pad_l, y), (W - pad_r, y)], fill="#1E293B", width=1)
            label = f"{vmax - span * i / 5:,.0f}"
            draw.text((pad_l - 12, y - 8), label, fill="#94A3B8", font=tiny, anchor="rm")

        n = len(values)
        if chart in ("line", "area", "trend"):
            pts = [(pad_l + int(plot_w * i / max(1, n - 1)),
                    pad_t + int(plot_h * (1 - (v - vmin) / span))) for i, v in enumerate(values)]
            if chart == "area":
                draw.polygon(pts + [(pts[-1][0], pad_t + plot_h), (pts[0][0], pad_t + plot_h)],
                             fill="#0E3A52")
            draw.line(pts, fill="#38BDF8", width=3)
            for p in pts[:400]:
                draw.ellipse([p[0] - 3, p[1] - 3, p[0] + 3, p[1] + 3], fill="#7DD3FC")
        elif chart in ("pie", "donut"):
            total = sum(values) or 1
            colours = ["#38BDF8", "#F59E0B", "#22C55E", "#EF4444", "#A78BFA",
                       "#EC4899", "#14B8A6", "#F97316"]
            r = min(plot_w, plot_h) // 2
            cx, cy = pad_l + plot_w // 3, pad_t + plot_h // 2
            start = -90
            for i, v in enumerate(values[:8]):
                extent = v / total * 360
                draw.pieslice([cx - r, cy - r, cx + r, cy + r], start, start + extent,
                              fill=colours[i % len(colours)], outline="#0B1220", width=2)
                draw.text((cx + r + 30, pad_t + 20 + i * 26),
                          f"{labels[i][:26]}  ({v / total * 100:.1f}%)",
                          fill="#CBD5E1", font=small)
                start += extent
            if chart == "donut":
                draw.ellipse([cx - r // 2, cy - r // 2, cx + r // 2, cy + r // 2], fill="#0B1220")
        else:
            bar_w = max(4, int(plot_w / max(1, n) * 0.68))
            gap = plot_w / max(1, n)
            for i, v in enumerate(values[:60]):
                x0 = pad_l + int(gap * i + (gap - bar_w) / 2)
                h = int(plot_h * (v - vmin) / span)
                y0 = pad_t + plot_h - h
                draw.rounded_rectangle([x0, y0, x0 + bar_w, pad_t + plot_h],
                                       radius=min(6, bar_w // 2), fill="#38BDF8")
                if n <= 20:
                    draw.text((x0 + bar_w // 2, pad_t + plot_h + 10), labels[i][:14],
                              fill="#94A3B8", font=tiny, anchor="mt")
                    draw.text((x0 + bar_w // 2, y0 - 8), f"{v:,.0f}", fill="#E2E8F0",
                              font=tiny, anchor="mb")
        draw.line([(pad_l, pad_t + plot_h), (W - pad_r, pad_t + plot_h)], fill="#334155", width=2)
        draw.text((W - pad_r, H - 26), "SAM · data brain", fill="#475569", font=tiny, anchor="rm")

        path = Path(output) if output else out_dir / f"sam_chart_{stamp}.png"
        path.parent.mkdir(parents=True, exist_ok=True)
        img.save(str(path), "PNG")
        return {"ok": True, "engine": "pillow", "chart": chart, "path": str(path),
                "bytes": path.stat().st_size, "title": title, "points": len(values),
                "labels": labels[:30], "values": values[:30],
                "note": "install matplotlib for higher-quality charts"}
    except Exception as exc:
        return {"ok": False, "error": f"chart rendering failed: {exc}"}


@tool(
    name="data.report",
    capability="creative.document.generate",
    agent="data",
    device="pc",
    description="Build a Markdown analysis report (optionally rendered to DOCX/PDF/XLSX)",
    risk="MEDIUM",
    confirm=True,
    timeout=300,
)
async def data_report(ctx: ToolContext, format: str = "md", output: str = "",
                      title: str = "", path: str = "") -> Dict[str, Any]:
    from backend.app.coding.documents import render

    table = _get_stashed(ctx)
    analysis: Optional[Dict[str, Any]] = None
    for value in (ctx.outputs or {}).values():
        if isinstance(value, dict):
            inner = value.get("value") if isinstance(value.get("value"), dict) else value
            if isinstance(inner, dict) and inner.get("summary"):
                analysis = inner
    if analysis is None:
        analysis = await data_analyse(ctx, path=path)
    if not analysis.get("ok"):
        return analysis
    if table is None and path:
        loaded = await data_load(ctx, path=path)
        table = _STASH.get(loaded.get("_table_ref", "")) if loaded.get("ok") else None

    name = title or (table or {}).get("name") or "Data analysis report"
    md = _report_markdown(name, analysis, table)

    if format in ("md", "markdown"):
        out_dir = settings.sam_data_dir / "documents"
        out_dir.mkdir(parents=True, exist_ok=True)
        p = Path(output) if output else out_dir / f"{re.sub(r'[^\\w]+', '_', name)[:60]}_{int(time.time())}.md"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(md, encoding="utf-8")
        return {"ok": True, "format": "md", "path": str(p), "bytes": p.stat().st_size,
                "markdown": md, "word_count": len(md.split())}

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, render, format, md, name, output or None)


def _report_markdown(title: str, analysis: Dict[str, Any],
                     table: Optional[Dict[str, Any]]) -> str:
    lines = [f"# {title}", "", f"_Generated by SAM · {time.strftime('%d %B %Y %H:%M')}_", ""]
    lines += ["## Dataset overview", ""]
    if table:
        lines += [f"- Source: `{table.get('path', '')}`",
                  f"- Rows: **{analysis.get('row_count', 0):,}**",
                  f"- Columns: **{analysis.get('column_count', len(analysis.get('columns', [])))}**",
                  "", "| Column | Type |", "| --- | --- |"]
        for col in analysis.get("columns", []):
            lines.append(f"| {col} | {analysis.get('types', {}).get(col, '?')} |")
        lines.append("")

    summary = analysis.get("summary", {})
    if summary:
        lines += ["## Numeric summary", "",
                  "| Column | Count | Mean | Median | Min | Max | Std dev | Sum |",
                  "| --- | --- | --- | --- | --- | --- | --- | --- |"]
        for col, s in summary.items():
            lines.append(
                f"| {col} | {s.get('count', 0):,} | {s.get('mean', 0):,.2f} | {s.get('median', 0):,.2f} "
                f"| {s.get('min', 0):,.2f} | {s.get('max', 0):,.2f} | {s.get('stdev', 0):,.2f} "
                f"| {s.get('sum', 0):,.2f} |"
            )
        lines.append("")

    gb = analysis.get("group_by")
    if gb and gb.get("groups"):
        lines += [f"## Breakdown by {gb['column']} ({gb['agg']} of {gb['metric'] or 'count'})", "",
                  f"| {gb['column']} | Count | {gb['agg']} | Sum | Min | Max |",
                  "| --- | --- | --- | --- | --- | --- |"]
        for g in gb["groups"][:20]:
            lines.append(f"| {g['group']} | {g.get('count', 0):,} | {g.get(gb['agg'], ''):,} "
                         f"| {g.get('sum', 0):,.2f} | {g.get('min', '')} | {g.get('max', '')} |")
        lines.append("")

    corr = analysis.get("correlations", {})
    if corr:
        lines += ["## Notable correlations", ""]
        for a, partners in list(corr.items())[:6]:
            for b, r in list(partners.items())[:3]:
                strength = "strong" if abs(r) > 0.7 else "moderate"
                direction = "positive" if r > 0 else "negative"
                lines.append(f"- **{a}** ↔ **{b}**: {strength} {direction} (r = {r})")
        lines.append("")

    insights = analysis.get("insights", [])
    if insights:
        lines += ["## Insights", ""] + [f"- {i}" for i in insights] + [""]

    top = analysis.get("top")
    if top:
        lines += ["## Top records", "", "| # | " + " | ".join(str(k) for k in top[0].keys()) + " |",
                  "| " + " | ".join("---" for _ in top[0]) + " |"]
        for row in top[:10]:
            lines.append("| " + " | ".join(str(v)[:40] for v in row.values()) + " |")
        lines.append("")

    lines += ["---", "",
              "*Every number above was computed locally from the source file. "
              "No data left this machine.*"]
    return "\n".join(lines)
