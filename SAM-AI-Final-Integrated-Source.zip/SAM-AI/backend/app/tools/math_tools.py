"""
backend.app.tools.math_tools
============================

**SAM's calculator, statistician and finance desk.**

ChatGPT answers "what is 15% of 2400" with a language model and can be wrong.
SAM answers it with a *math engine*: every tool here computes deterministically
with Python's ``decimal``/``fractions``/``numpy`` and, when available,
``sympy`` for symbolic algebra (solve, differentiate, integrate, simplify).

Safety
------
No tool ever calls ``eval()`` on user text. Expressions are parsed with
``sympy.parsing`` into an AST against a **whitelisted namespace** with
``__builtins__`` removed, and a pre-filter rejects anything that looks like
code (``import``, ``open(``, ``__``, ``os.``, ``subprocess``…). If sympy is not
installed, SAM falls back to a restricted AST evaluator that supports the same
arithmetic and a fixed set of math functions — so the tools still work offline.

Tool map
--------
=========================  =====================================================
``math.evaluate``          arithmetic + functions, exact and decimal answer
``math.solve``             equations, systems, inequalities
``math.simplify``          simplify / expand / factor / cancel
``math.calculus``          derivative, integral, limit, series expansion
``math.statistics``        descriptive stats over a list of numbers
``math.regression``        linear fit, correlation, forecast
``math.matrix``            multiply, inverse, determinant, eigen, solve
``math.unit_convert``      length, mass, temperature, data, speed, area, …
``math.date_calc``         date arithmetic, differences, next weekday, age
``math.finance``           EMI, SIP, compound interest, CAGR, GST, amortisation
``math.base_convert``      binary/octal/hex, bit operations, bytes
``math.prime_factor``      primes, factors, GCD/LCM, modular arithmetic
``math.geometry``          area, perimeter, volume, distance
``math.percent``           percentage, change %, discount, tip, margin
``math.fraction``          fraction ⇄ decimal, ratio simplification
``math.random``            numbers, dice, picks, shuffle, passwords, UUIDs
``math.round``             rounding, significant figures, human-readable sizes
``math.series``            AP/GP sums, closed forms, sequences
=========================  =====================================================
"""

from __future__ import annotations

import math as pymath
import random as pyrandom
import re
import secrets
import string
import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction
from typing import Any, Dict, List, Optional, Tuple

from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, tool

log = get_logger("tools.math")

try:  # optional but recommended
    import sympy as sp
    from sympy.parsing.sympy_parser import (convert_equals_signs, implicit_multiplication_application,
                                            parse_expr, standard_transformations)

    SYMPY = True
    # parse_expr needs a namespace that contains Symbol/Eq/Integer/... but must
    # NOT contain Python builtins — that combination is what keeps user input
    # from ever executing code.
    SYMPY_GLOBALS: Dict[str, Any] = {k: v for k, v in sp.__dict__.items()
                                     if not k.startswith("_")}
    SYMPY_GLOBALS["__builtins__"] = {}
    SYMPY_TRANSFORMS = standard_transformations + (implicit_multiplication_application,
                                                   convert_equals_signs)
except Exception:  # pragma: no cover
    sp = None
    SYMPY = False
    SYMPY_GLOBALS = {}
    SYMPY_TRANSFORMS = ()

try:
    import numpy as np

    NUMPY = True
except Exception:  # pragma: no cover
    np = None
    NUMPY = False


# ---------------------------------------------------------------------------
# safe expression parsing
# ---------------------------------------------------------------------------
_DANGER = re.compile(
    r"(__|import|open\s*\(|eval\s*\(|exec\s*\(|compile\s*\(|os\.|sys\.|subprocess|socket|"
    r"lambda|getattr|setattr|globals|locals|vars|input\s*\(|file|pathlib|shutil|pickle|"
    r"marshal|ctypes|__builtins__)", re.I)

_ALLOWED_FUNCS = {
    "sqrt": pymath.sqrt, "abs": abs, "sin": pymath.sin, "cos": pymath.cos, "tan": pymath.tan,
    "asin": pymath.asin, "acos": pymath.acos, "atan": pymath.atan, "atan2": pymath.atan2,
    "log": pymath.log, "log2": pymath.log2, "log10": pymath.log10, "exp": pymath.exp,
    "floor": pymath.floor, "ceil": pymath.ceil, "round": round, "pow": pow, "min": min,
    "max": max, "sum": sum, "factorial": pymath.factorial, "gcd": pymath.gcd,
    "degrees": pymath.degrees, "radians": pymath.radians, "sinh": pymath.sinh,
    "cosh": pymath.cosh, "tanh": pymath.tanh, "hypot": pymath.hypot,
    "pi": pymath.pi, "e": pymath.e, "tau": pymath.tau, "inf": pymath.inf,
}

_AST_ALLOWED = {"Expression", "BinOp", "UnaryOp", "Constant", "Name", "Load", "Call",
                "Add", "Sub", "Mult", "Div", "FloorDiv", "Mod", "Pow", "USub", "UAdd",
                "Tuple", "List", "Compare", "Lt", "LtE", "Gt", "GtE", "Eq", "NotEq"}


def _precheck(expr: str) -> Optional[str]:
    if not expr or not expr.strip():
        return "empty expression"
    if _DANGER.search(expr):
        return ("that looks like code, not a mathematical expression — SAM only evaluates "
                "arithmetic and math functions")
    if len(expr) > 2000:
        return "expression too long (2000 char limit)"
    return None


def clean_expression(text: str) -> str:
    """Normalise human maths: × ÷ ^ , 'of', words, percentages."""
    s = (text or "").strip()
    s = s.replace("×", "*").replace("÷", "/").replace("−", "-").replace("–", "-")
    s = s.replace("^", "**").replace("，", ",").replace("，", ",")
    s = re.sub(r"(\d)[,](?=\d{3}\b)", r"\1", s)          # 1,00,000 -> 100000
    s = re.sub(r"\bplus\b", "+", s, flags=re.I)
    s = re.sub(r"\bminus\b", "-", s, flags=re.I)
    s = re.sub(r"\b(?:times|multiplied\s+by)\b", "*", s, flags=re.I)
    s = re.sub(r"\b(?:divided\s+by|over)\b", "/", s, flags=re.I)
    s = re.sub(r"\bsquared\b", "**2", s, flags=re.I)
    s = re.sub(r"\bcubed\b", "**3", s, flags=re.I)
    s = re.sub(r"\bto\s+the\s+power\s+of\s+(\d+)\b", r"**\1", s, flags=re.I)
    s = re.sub(r"\bsquare\s+root\s+(?:of\s+)?", "sqrt(", s, flags=re.I)
    if s.count("(") < s.count(")") or ("sqrt(" in s and s.count("(") > s.count(")")):
        s = s + ")" * max(0, s.count("(") - s.count(")"))
    s = re.sub(r"(?<![\w)])\bpi\b(?![\w(])", str(pymath.pi), s)
    s = s.rstrip("=? \t")
    return s.strip()


def _ast_eval(expr: str) -> Any:
    """Restricted evaluator used when sympy is unavailable."""
    import ast

    tree = ast.parse(expr, mode="eval")
    for node in ast.walk(tree):
        if type(node).__name__ not in _AST_ALLOWED:
            raise ValueError(f"'{type(node).__name__}' is not allowed in a SAM expression")
        if isinstance(node, ast.Call):
            fn = node.func
            if not isinstance(fn, ast.Name) or fn.id not in _ALLOWED_FUNCS:
                raise ValueError(f"function '{getattr(fn, 'id', '?')}' is not allowed")
        if isinstance(node, ast.Name) and node.id not in _ALLOWED_FUNCS:
            raise ValueError(f"unknown name '{node.id}'")
        if isinstance(node, ast.Pow if hasattr(ast, "Pow") else ast.BinOp):
            pass
    return eval(compile(tree, "<math>", "eval"), {"__builtins__": {}}, dict(_ALLOWED_FUNCS))  # noqa: S307


def _num(value: Any) -> Optional[float]:
    try:
        if isinstance(value, str):
            value = value.replace(",", "")
        f = float(value)
        return f if pymath.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def _numbers(values: Any) -> List[float]:
    """Accept a list, a comma string, or a string with numbers in it."""
    if values is None:
        return []
    if isinstance(values, (int, float)):
        return [float(values)]
    if isinstance(values, str):
        found = re.findall(r"-?\d+(?:\.\d+)?", values)
        return [float(f) for f in found]
    out: List[float] = []
    for v in values:
        n = _num(v)
        if n is not None:
            out.append(n)
    return out


def _round(value: Any, places: int = 6) -> Any:
    n = _num(value)
    if n is None:
        return value
    if float(n).is_integer() and abs(n) < 1e15:
        return int(n)
    return round(n, places)


def _fmt(value: Any) -> str:
    n = _num(value)
    if n is None:
        return str(value)
    if float(n).is_integer():
        return f"{int(n):,}"
    return f"{n:,.6f}".rstrip("0").rstrip(".")


# ===========================================================================
# 1. EVALUATE
# ===========================================================================
@tool(
    name="math.evaluate",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Evaluate a mathematical expression exactly (arithmetic, powers, roots, trig, logs, percentages)",
    schema={"expression": {"type": "string", "required": True,
                           "description": "e.g. '15% of 2400', 'sqrt(2)*3', '2**10', '(5+3)/2'"},
            "precision": {"type": "integer", "default": 10}},
    risk="LOW",
    timeout=30,
)
async def math_evaluate(ctx: ToolContext, expression: str = "", precision: int = 10,
                        request: str = "") -> Dict[str, Any]:
    raw = (expression or request or ctx.user_text or "").strip()
    raw = re.sub(r"^(what\s+is|calculate|compute|evaluate|solve)\s+", "", raw, flags=re.I).strip(" ?=")
    # "15% of 2400" -> "(15/100)*2400"
    raw = re.sub(r"(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)", r"(\1/100)*\2", raw, flags=re.I)
    raw = re.sub(r"(\d+(?:\.\d+)?)\s*%", r"(\1/100)", raw) if " of " not in raw.lower() else raw
    expr = clean_expression(raw)

    problem = _precheck(expr)
    if problem:
        return {"ok": False, "expression": raw, "error": problem}

    exact: Optional[str] = None
    approx: Optional[float] = None
    engine = "python-ast"
    steps: List[str] = []

    if SYMPY:
        try:
            parsed = sp.parse_expr(expr, transformations=SYMPY_TRANSFORMS,
                                   global_dict=SYMPY_GLOBALS, evaluate=True)
            engine = "sympy"
            exact = str(sp.nsimplify(parsed) if parsed.free_symbols else sp.simplify(parsed))
            approx = float(parsed.evalf(int(precision) + 4))
            steps.append(f"parsed: {expr}")
            steps.append(f"exact: {exact}")
            steps.append(f"decimal: {approx}")
        except Exception as exc:
            log.debug("sympy eval failed for %r: %s", expr, exc)
            engine = "python-ast"

    if approx is None:
        try:
            value = _ast_eval(expr)
            if isinstance(value, (tuple, list)):
                return {"ok": True, "expression": expr, "results": [_round(v) for v in value],
                        "engine": engine}
            exact = str(Fraction(value).limit_denominator(10 ** 9)) if isinstance(value, float) \
                and float(value).is_integer() is False else str(value)
            approx = _num(value)
            steps.append(f"evaluated: {expr} = {approx}")
        except ZeroDivisionError:
            return {"ok": False, "expression": expr, "error": "division by zero"}
        except Exception as exc:
            return {"ok": False, "expression": expr,
                    "error": f"could not evaluate that: {type(exc).__name__}: {exc}"}

    if approx is None:
        return {"ok": False, "expression": expr, "error": "the expression produced no numeric result"}

    out = {"ok": True, "expression": expr, "input": raw, "engine": engine,
           "result": _round(approx, int(precision)), "formatted": _fmt(approx),
           "exact": exact, "steps": steps}
    if abs(approx - round(approx)) < 1e-12:
        out["integer"] = int(round(approx))
    out["answer"] = f"{raw or expr} = **{_fmt(approx)}**" + (f" (exactly {exact})"
                                                            if exact and exact != str(_round(approx))
                                                            and not re.fullmatch(r"-?\d+", str(exact)) else "")
    return out


# ===========================================================================
# 2. SOLVE / SIMPLIFY / CALCULUS
# ===========================================================================
@tool(
    name="math.solve",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Solve an equation, a system of equations, or an inequality for the given variable(s)",
    schema={"equation": {"type": "string", "required": True, "description": "e.g. '2x + 3 = 11' or 'x**2 - 5x + 6 = 0'"},
            "variables": {"type": "array", "description": "variables to solve for; auto-detected when omitted"}},
    risk="LOW",
    timeout=60,
)
async def math_solve(ctx: ToolContext, equation: str = "", variables: Optional[List[str]] = None,
                     request: str = "") -> Dict[str, Any]:
    raw = (equation or request or ctx.user_text or "").strip()
    raw = re.sub(r"^(solve|find|what\s+is)\s+(for\s+)?", "", raw, flags=re.I).strip(" ?")
    if not raw:
        return {"ok": False, "error": "which equation should I solve?"}
    if not SYMPY:
        return {"ok": False, "equation": raw,
                "error": "symbolic solving needs sympy — install it with `pip install sympy`"}
    # a system may be given as "x + y = 10, x - y = 4" (or with 'and' / ';')
    parts = [p.strip() for p in re.split(r"\s*(?:,|;|\band\b)\s*", raw) if p.strip()]
    parts = [p for p in parts if re.search(r"[=\d]", p)]
    if not parts:
        parts = [raw]
    expr = clean_expression(parts[0])
    problem = _precheck(expr)
    if problem:
        return {"ok": False, "equation": raw, "error": problem}
    try:
        equations = []
        for part in parts:
            piece = clean_expression(part)
            problem = _precheck(piece)
            if problem:
                return {"ok": False, "equation": raw, "error": problem}
            parsed_one = sp.parse_expr(piece, transformations=SYMPY_TRANSFORMS,
                                       global_dict=SYMPY_GLOBALS)
            if "=" in part and not getattr(parsed_one, "is_Relational", False):
                lhs, rhs = [clean_expression(p) for p in part.split("=", 1)]
                parsed_one = (sp.parse_expr(lhs, transformations=SYMPY_TRANSFORMS,
                                            global_dict=SYMPY_GLOBALS)
                              - sp.parse_expr(rhs, transformations=SYMPY_TRANSFORMS,
                                              global_dict=SYMPY_GLOBALS))
            equations.append(parsed_one)
        parsed = equations[0]
        syms: List[str] = []
        for eq in equations:
            for s in eq.free_symbols:
                if str(s) not in syms:
                    syms.append(str(s))
        syms = sorted(syms)
        want = [sp.Symbol(v) for v in (variables or []) if re.fullmatch(r"[A-Za-z]\w*", str(v))]
        targets = want or [sp.Symbol(s) for s in syms] or [sp.Symbol("x")]
        sols = sp.solve(equations if len(equations) > 1 else equations[0],
                        targets, dict=True) if len(targets) > 1 else \
            sp.solve(equations if len(equations) > 1 else equations[0], targets[0])
        if sols == []:
            return {"ok": False, "equation": raw, "variables": syms,
                    "error": "no solution found (the equation may be inconsistent or need constraints)"}
        pretty: List[Dict[str, Any]] = []
        if isinstance(sols, list) and sols and isinstance(sols[0], dict):
            for s in sols[:10]:
                pretty.append({str(k): str(v) for k, v in s.items()})
        else:
            pretty = [{str(targets[0]): str(s)} for s in list(sols)[:10]]
        answer = ", ".join(
            "; ".join(f"{k} = {v}" for k, v in row.items()) for row in pretty
        )
        return {"ok": True, "equation": raw, "variables": syms or [str(t) for t in targets],
                "solutions": pretty, "answer": f"{raw}  ⇒  {answer}",
                "check": [{"substituted": [str(sp.simplify(eq.subs(
                    {sp.Symbol(k): sp.sympify(v) for k, v in row.items()}))) for eq in equations]}
                    for row in pretty[:3]]}
    except Exception as exc:
        return {"ok": False, "equation": raw, "error": f"could not solve that: {type(exc).__name__}: {exc}"}


@tool(
    name="math.simplify",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Simplify, expand, factor or cancel a symbolic expression",
    schema={"expression": {"type": "string", "required": True},
            "mode": {"type": "string", "description": "simplify|expand|factor|cancel|trigsimp|radsimp"}},
    risk="LOW",
    timeout=60,
)
async def math_simplify(ctx: ToolContext, expression: str = "", mode: str = "simplify",
                        request: str = "") -> Dict[str, Any]:
    raw = (expression or request or ctx.user_text or "").strip()
    if not SYMPY:
        return {"ok": False, "error": "symbolic maths needs sympy (`pip install sympy`)"}
    expr = clean_expression(re.sub(r"^(simplify|expand|factor)\s+", "", raw, flags=re.I))
    problem = _precheck(expr)
    if problem:
        return {"ok": False, "expression": raw, "error": problem}
    if mode not in ("simplify", "expand", "factor", "cancel", "trigsimp", "radsimp"):
        for m in ("expand", "factor", "cancel", "trigsimp"):
            if m in raw.lower():
                mode = m
                break
    try:
        parsed = sp.parse_expr(expr, transformations=SYMPY_TRANSFORMS,
                               global_dict=SYMPY_GLOBALS)
        result = getattr(sp, mode)(parsed)
        return {"ok": True, "expression": raw, "mode": mode, "result": str(result),
                "latex": sp.latex(result),
                "answer": f"{mode}({raw}) = **{result}**"}
    except Exception as exc:
        return {"ok": False, "expression": raw, "mode": mode,
                "error": f"{mode} failed: {type(exc).__name__}: {exc}"}


@tool(
    name="math.calculus",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Differentiate, integrate, take a limit or expand a series symbolically",
    schema={"expression": {"type": "string", "required": True},
            "operation": {"type": "string", "description": "diff|integrate|limit|series"},
            "variable": {"type": "string", "default": "x"},
            "order": {"type": "integer", "default": 1},
            "lower": {"type": "string", "description": "lower bound for a definite integral"},
            "upper": {"type": "string", "description": "upper bound for a definite integral"},
            "point": {"type": "string", "description": "point for limit/series"}},
    risk="LOW",
    timeout=90,
)
async def math_calculus(ctx: ToolContext, expression: str = "", operation: str = "",
                        variable: str = "x", order: int = 1, lower: str = "", upper: str = "",
                        point: str = "", request: str = "") -> Dict[str, Any]:
    raw = (expression or request or ctx.user_text or "").strip()
    if not SYMPY:
        return {"ok": False, "error": "calculus needs sympy (`pip install sympy`)"}
    text = raw.lower()
    if not operation:
        operation = ("diff" if any(k in text for k in ("derivative", "differentiate", "diff"))
                     else "integrate" if any(k in text for k in ("integrate", "integral", "antiderivative"))
                     else "limit" if "limit" in text
                     else "series" if "series" in text else "diff")
    expr = clean_expression(re.sub(r"^(the\s+)?(derivative|integral|limit|series)\s+(of\s+)?",
                                   "", raw, flags=re.I))
    m = re.search(r"\bint(?:egrate)?\s*(?:of\s+)?(.+?)\s*(?:from|between)\s*(-?[\w.]+)\s*(?:to|and)\s*(-?[\w.]+)",
                  raw, re.I)
    if m and not (lower and upper):
        expr, lower, upper = clean_expression(m.group(1)), m.group(2), m.group(3)
        operation = "integrate"
    problem = _precheck(expr)
    if problem:
        return {"ok": False, "expression": raw, "error": problem}
    try:
        parsed = sp.parse_expr(expr, transformations=SYMPY_TRANSFORMS,
                               global_dict=SYMPY_GLOBALS)
        sym = sp.Symbol(variable or "x")
        if operation == "diff":
            result = sp.diff(parsed, sym, int(order))
            answer = f"d{'^' + str(order) if int(order) > 1 else ''}/d{variable}" \
                     f"[{raw}] = {result}"
        elif operation == "integrate":
            if lower and upper:
                result = sp.integrate(parsed, (sym, sp.sympify(lower), sp.sympify(upper)))
                answer = f"∫ from {lower} to {upper} of {raw} d{variable} = {result}"
            else:
                result = sp.integrate(parsed, sym)
                answer = f"∫ {raw} d{variable} = {result} + C"
        elif operation == "limit":
            pt = sp.sympify(point or "0")
            direction = "-" if "from the left" in text or "0-" in text else "+"
            result = sp.limit(parsed, sym, pt, direction)
            answer = f"limit of {raw} as {variable}→{point or '0'} = {result}"
        else:  # series
            result = sp.series(parsed, sym, sp.sympify(point or "0"), int(order) + 3)
            answer = f"series of {raw} about {variable}={point or '0'}: {result}"
        return {"ok": True, "expression": raw, "operation": operation, "variable": variable,
                "result": str(result), "latex": sp.latex(result), "answer": answer}
    except Exception as exc:
        return {"ok": False, "expression": raw, "operation": operation,
                "error": f"{operation} failed: {type(exc).__name__}: {exc}"}


# ===========================================================================
# 3. STATISTICS
# ===========================================================================
def _stats(values: List[float]) -> Dict[str, Any]:
    import statistics as st

    n = len(values)
    srt = sorted(values)
    q1, q2, q3 = st.quantiles(values, n=4, method="inclusive") if n >= 2 else (None, None, None)
    out: Dict[str, Any] = {
        "count": n, "sum": _round(sum(values)), "mean": _round(st.fmean(values)),
        "median": _round(st.median(values)),
        "mode": _round(st.multimode(values)[0]) if n else None,
        "min": _round(srt[0]), "max": _round(srt[-1]), "range": _round(srt[-1] - srt[0]),
        "q1": _round(q1), "q3": _round(q3),
        "iqr": _round((q3 or 0) - (q1 or 0)) if n >= 2 else None,
    }
    if n >= 2:
        variance = st.pvariance(values)
        out["variance"] = _round(variance)
        out["std_dev"] = _round(pymath.sqrt(variance))
        out["sample_std_dev"] = _round(st.stdev(values))
        out["cv_percent"] = _round((out["std_dev"] / out["mean"]) * 100, 4) if out["mean"] else None
    else:
        out.update({"variance": 0, "std_dev": 0, "sample_std_dev": None, "cv_percent": None})
    # outliers by 1.5*IQR
    if n >= 4 and q1 is not None and q3 is not None:
        lo, hi = q1 - 1.5 * (q3 - q1), q3 + 1.5 * (q3 - q1)
        out["outliers"] = [_round(v) for v in srt if v < lo or v > hi]
    else:
        out["outliers"] = []
    return out


@tool(
    name="math.statistics",
    capability="ai.reasoning",
    agent="data",
    device="both",
    description="Compute descriptive statistics (mean, median, mode, std dev, quartiles, outliers) for a list of numbers",
    schema={"values": {"type": "array", "required": True,
                       "description": "numbers, or a string containing numbers"},
            "group_by": {"type": "string", "description": "optional label to describe the dataset"}},
    risk="LOW",
    timeout=30,
)
async def math_statistics(ctx: ToolContext, values: Any = None, group_by: str = "",
                          request: str = "") -> Dict[str, Any]:
    nums = _numbers(values if values is not None else (request or ctx.user_text))
    if len(nums) < 1:
        return {"ok": False, "error": "give me at least one number, e.g. values=[12, 15, 9, 22]"}
    stats = _stats(nums)
    stats.update({"ok": True, "dataset": group_by, "sorted": [_round(v) for v in sorted(nums)],
                  "engine": "python-statistics"})
    stats["answer"] = (
        f"{group_by or 'Dataset'} (n={stats['count']}): mean {stats['mean']}, median {stats['median']}, "
        f"min {stats['min']}, max {stats['max']}, range {stats['range']}, "
        f"std dev {stats['std_dev']}"
        + (f", Q1 {stats['q1']} / Q3 {stats['q3']}" if stats['q1'] is not None else "")
        + (f", outliers {stats['outliers']}" if stats['outliers'] else "")
    )
    return stats


@tool(
    name="math.regression",
    capability="ai.reasoning",
    agent="data",
    device="both",
    description="Fit a straight line to paired data, report correlation and forecast a value",
    schema={"x": {"type": "array", "required": True}, "y": {"type": "array", "required": True},
            "forecast_x": {"type": "number", "description": "x value to predict y for"}},
    risk="LOW",
    timeout=30,
)
async def math_regression(ctx: ToolContext, x: Any = None, y: Any = None,
                          forecast_x: Optional[float] = None, request: str = "") -> Dict[str, Any]:
    xs, ys = _numbers(x), _numbers(y)
    if len(xs) != len(ys) or len(xs) < 2:
        return {"ok": False, "error": f"need equal-length x and y lists with ≥2 points "
                                      f"(got {len(xs)} x, {len(ys)} y)"}
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    sxx = sum((a - mx) ** 2 for a in xs)
    syy = sum((b - my) ** 2 for b in ys)
    if sxx == 0:
        return {"ok": False, "error": "all x values are identical — a line cannot be fitted"}
    slope = sxy / sxx
    intercept = my - slope * mx
    r = (sxy / pymath.sqrt(sxx * syy)) if syy else 0.0
    r2 = r ** 2
    resid = [round(b - (slope * a + intercept), 6) for a, b in zip(xs, ys)]
    rmse = pymath.sqrt(sum(v * v for v in resid) / n)
    out: Dict[str, Any] = {
        "ok": True, "n": n, "slope": _round(slope), "intercept": _round(intercept),
        "equation": f"y = {round(slope, 6)}x {'+' if intercept >= 0 else '-'} {abs(round(intercept, 6))}",
        "pearson_r": _round(r), "r_squared": _round(r2), "rmse": _round(rmse),
        "strength": ("very strong" if abs(r) >= 0.9 else "strong" if abs(r) >= 0.7 else
                     "moderate" if abs(r) >= 0.5 else "weak" if abs(r) >= 0.3 else "very weak"),
        "direction": "positive" if r > 0 else "negative", "residuals": resid,
    }
    if forecast_x is not None:
        fx = _num(forecast_x)
        out["forecast"] = {"x": fx, "y": _round(slope * fx + intercept)}
        out["answer"] = (f"{out['equation']} (r={round(r, 3)}, R²={round(r2, 3)}, {out['strength']} "
                         f"{out['direction']} relationship). At x={fx}, predicted y ≈ "
                         f"{out['forecast']['y']}.")
    else:
        out["answer"] = (f"{out['equation']} — {out['strength']} {out['direction']} relationship "
                         f"(r={round(r, 3)}, R²={round(r2, 3)} explains "
                         f"{round(r2 * 100, 1)}% of the variation).")
    return out


@tool(
    name="math.matrix",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Matrix operations: multiply, add, transpose, inverse, determinant, rank, eigenvalues, solve Ax=b",
    schema={"operation": {"type": "string", "required": True,
                          "description": "multiply|add|transpose|inverse|determinant|rank|eigen|solve|identity"},
            "a": {"type": "array", "description": "matrix as nested lists"},
            "b": {"type": "array", "description": "second matrix or vector"},
            "size": {"type": "integer", "description": "for identity(n)"}},
    risk="LOW",
    timeout=60,
)
async def math_matrix(ctx: ToolContext, operation: str = "", a: Any = None, b: Any = None,
                      size: int = 3, request: str = "") -> Dict[str, Any]:
    op = (operation or "").strip().lower()
    text = (request or ctx.user_text or "").lower()
    if not op:
        for k in ("multiply", "inverse", "determinant", "transpose", "eigen", "rank", "solve", "add"):
            if k in text:
                op = k
                break
    if not SYMPY:
        return {"ok": False, "error": "matrix maths needs sympy (`pip install sympy`)"}
    try:
        if op == "identity":
            M = sp.eye(int(size))
            return {"ok": True, "operation": op, "size": int(size), "result": str(M.tolist()),
                    "answer": f"I({size}) = {M.tolist()}"}
        if not a:
            return {"ok": False, "error": "provide matrix a as nested lists, e.g. [[1,2],[3,4]]"}
        M = sp.Matrix(a)
        if op in ("transpose",):
            R = M.T
        elif op in ("determinant", "det"):
            R = M.det()
        elif op in ("rank",):
            R = M.rank()
        elif op in ("inverse", "inv"):
            if M.det() == 0:
                return {"ok": False, "operation": op, "error": "matrix is singular — it has no inverse"}
            R = M.inv()
        elif op in ("eigen", "eigenvalues"):
            vals = M.eigenvals()
            vecs = M.eigenvects()
            return {"ok": True, "operation": "eigen",
                    "eigenvalues": {str(k): v for k, v in vals.items()},
                    "eigenvectors": [{"value": str(v[0]), "multiplicity": v[1],
                                      "vectors": [str(x.tolist()) for x in v[2]]} for v in vecs],
                    "answer": "eigenvalues: " + ", ".join(str(k) for k in vals)}
        elif op in ("multiply", "mul", "add", "sub", "subtract"):
            if not b:
                return {"ok": False, "operation": op, "error": f"{op} needs a second matrix b"}
            N = sp.Matrix(b)
            R = {"multiply": lambda: M * N, "mul": lambda: M * N, "add": lambda: M + N,
                 "sub": lambda: M - N, "subtract": lambda: M - N}[op]()
        elif op == "solve":
            if not b:
                return {"ok": False, "operation": "solve", "error": "solve needs vector b (Ax = b)"}
            sol = M.solve(sp.Matrix(b))
            R = sol
        elif op == "rref":
            R, pivots = M.rref()
            return {"ok": True, "operation": "rref", "result": str(R.tolist()),
                    "pivot_columns": list(pivots), "answer": f"RREF = {R.tolist()}"}
        else:
            return {"ok": False, "operation": op,
                    "error": "unknown operation — use multiply, add, transpose, inverse, "
                             "determinant, rank, eigen, solve, rref or identity"}
        result = R.tolist() if hasattr(R, "tolist") else str(R)
        return {"ok": True, "operation": op, "shape": list(M.shape), "result": result,
                "answer": f"{op}: {result}"}
    except Exception as exc:
        return {"ok": False, "operation": op, "error": f"{op} failed: {type(exc).__name__}: {exc}"}


# ===========================================================================
# 4. UNITS / DATES
# ===========================================================================
UNITS: Dict[str, Dict[str, float]] = {
    "length": {"m": 1.0, "meter": 1.0, "metre": 1.0, "km": 1000.0, "kilometer": 1000.0,
               "cm": 0.01, "mm": 0.001, "um": 1e-6, "nm": 1e-9, "in": 0.0254, "inch": 0.0254,
               "ft": 0.3048, "feet": 0.3048, "foot": 0.3048, "yd": 0.9144, "yard": 0.9144,
               "mi": 1609.344, "mile": 1609.344, "nmi": 1852.0, "lightyear": 9.4607304725808e15},
    "mass": {"kg": 1.0, "kilogram": 1.0, "g": 0.001, "gram": 0.001, "mg": 1e-6, "t": 1000.0,
             "tonne": 1000.0, "lb": 0.45359237, "pound": 0.45359237, "oz": 0.028349523125,
             "ounce": 0.028349523125, "st": 6.35029318, "stone": 6.35029318,
             "quintal": 100.0, "carat": 0.0002},
    "area": {"m2": 1.0, "km2": 1e6, "cm2": 1e-4, "ha": 10000.0, "hectare": 10000.0,
             "acre": 4046.8564224, "ft2": 0.09290304, "sqft": 0.09290304, "in2": 0.00064516,
             "mi2": 2589988.110336, "yard2": 0.83612736, "ground": 222.9674, "cent": 40.4685642},
    "volume": {"l": 1.0, "liter": 1.0, "litre": 1.0, "ml": 0.001, "m3": 1000.0,
               "gal": 3.785411784, "gallon": 3.785411784, "qt": 0.946352946, "pt": 0.473176473,
               "cup": 0.2365882365, "floz": 0.0295735295625, "tbsp": 0.0147867647813,
               "tsp": 0.00492892159375, "in3": 0.016387064, "ft3": 28.316846592},
    "speed": {"mps": 1.0, "kmph": 0.2777777778, "kmh": 0.2777777778, "mph": 0.44704,
              "knot": 0.5144444444, "fps": 0.3048, "mach": 340.29},
    "data": {"b": 1.0, "byte": 1.0, "kb": 1000.0, "mb": 1e6, "gb": 1e9, "tb": 1e12, "pb": 1e15,
             "kib": 1024.0, "mib": 1048576.0, "gib": 1073741824.0, "tib": 1099511627776.0,
             "bit": 0.125, "kbit": 125.0, "mbit": 125000.0, "gbit": 125000000.0},
    "time": {"s": 1.0, "sec": 1.0, "second": 1.0, "ms": 0.001, "us": 1e-6, "ns": 1e-9,
             "min": 60.0, "minute": 60.0, "h": 3600.0, "hr": 3600.0, "hour": 3600.0,
             "day": 86400.0, "week": 604800.0, "fortnight": 1209600.0, "month": 2629800.0,
             "year": 31557600.0, "decade": 315576000.0, "century": 3155760000.0},
    "pressure": {"pa": 1.0, "kpa": 1000.0, "mpa": 1e6, "bar": 1e5, "mbar": 100.0,
                 "atm": 101325.0, "psi": 6894.757293168, "mmhg": 133.322387415, "torr": 133.322368},
    "energy": {"j": 1.0, "kj": 1000.0, "mj": 1e6, "cal": 4.184, "kcal": 4184.0,
               "wh": 3600.0, "kwh": 3.6e6, "mwh": 3.6e9, "ev": 1.602176634e-19, "btu": 1055.06},
    "power": {"w": 1.0, "kw": 1000.0, "mw": 1e6, "hp": 745.699872, "btuh": 0.29307107},
    "angle": {"deg": 1.0, "rad": 57.29577951308232, "grad": 0.9, "turn": 360.0,
              "arcmin": 1 / 60, "arcsec": 1 / 3600},
}

_UNIT_INDEX: Dict[str, Tuple[str, float]] = {}
for _family, _table in UNITS.items():
    for _u, _f in _table.items():
        _UNIT_INDEX[_u] = (_family, _f)

_TEMP_UNITS = {"c", "celsius", "f", "fahrenheit", "k", "kelvin", "r", "rankine"}


def _convert_temp(value: float, src: str, dst: str) -> float:
    s, d = src[0].lower(), dst[0].lower()
    celsius = {"c": value, "f": (value - 32) * 5 / 9, "k": value - 273.15,
               "r": (value - 491.67) * 5 / 9}[s]
    return {"c": celsius, "f": celsius * 9 / 5 + 32, "k": celsius + 273.15,
            "r": (celsius + 273.15) * 9 / 5}[d]


@tool(
    name="math.unit_convert",
    capability="ai.reasoning",
    agent="data",
    device="both",
    description="Convert between units: length, mass, temperature, area, volume, speed, data, time, pressure, energy, power, angle",
    schema={"value": {"type": "number", "required": True},
            "from": {"type": "string", "required": True, "description": "source unit, e.g. km, kg, celsius, gb"},
            "to": {"type": "string", "required": True, "description": "target unit"}},
    risk="LOW",
    timeout=30,
)
async def math_unit_convert(ctx: ToolContext, value: float = 0.0, **kw: Any) -> Dict[str, Any]:
    src = str(kw.get("from") or kw.get("source") or kw.get("from_unit") or "").strip().lower()
    dst = str(kw.get("to") or kw.get("target") or kw.get("to_unit") or "").strip().lower()
    request = kw.get("request") or ctx.user_text or ""
    amount = _num(value) or 0.0
    if not src or not dst or amount in (0.0, None) and value in (0, 0.0):
        m = re.match(r"\s*(-?\d+(?:\.\d+)?)\s*([a-zA-Z°/²³]+)\s*(?:to|in|into|as)\s*([a-zA-Z°/²³]+)",
                     request)
        if m:
            amount, src, dst = float(m.group(1)), m.group(2).lower(), m.group(3).lower()
    src = src.replace("°", "").replace("degrees", "").strip()
    dst = dst.replace("°", "").replace("degrees", "").strip()
    aliases = {"meter": "m", "metres": "m", "meters": "m", "kilometers": "km", "kms": "km",
               "centimeters": "cm", "inches": "in", "feet": "ft", "miles": "mi",
               "kilograms": "kg", "grams": "g", "pounds": "lb", "lbs": "lb", "ounces": "oz",
               "liters": "l", "litres": "l", "gallons": "gal", "celsius": "c", "centigrade": "c",
               "fahrenheit": "f", "kelvin": "k", "hours": "h", "minutes": "min", "seconds": "s",
               "days": "day", "weeks": "week", "months": "month", "years": "year",
               "megabytes": "mb", "gigabytes": "gb", "terabytes": "tb", "kilobytes": "kb",
               "sqft": "ft2", "square feet": "ft2", "square meters": "m2", "acres": "acre",
               "hectares": "ha", "km/h": "kmph", "km/hr": "kmph", "mph": "mph", "m/s": "mps"}
    src = aliases.get(src, src)
    dst = aliases.get(dst, dst)

    if src in _TEMP_UNITS or dst in _TEMP_UNITS or src in ("c", "f", "k") or dst in ("c", "f", "k"):
        if src not in ("c", "f", "k", "r") or dst not in ("c", "f", "k", "r"):
            return {"ok": False, "error": f"unknown temperature unit '{src}' or '{dst}' (use c, f, k)"}
        result = _convert_temp(amount, src, dst)
        names = {"c": "°C", "f": "°F", "k": "K", "r": "°R"}
        return {"ok": True, "value": amount, "from": src, "to": dst, "result": _round(result),
                "answer": f"{_fmt(amount)} {names[src]} = **{_fmt(result)} {names[dst]}**",
                "family": "temperature"}

    if src not in _UNIT_INDEX:
        return {"ok": False, "error": f"unknown unit '{src}'",
                "supported": sorted({fam for fam, _ in _UNIT_INDEX.values()})}
    if dst not in _UNIT_INDEX:
        return {"ok": False, "error": f"unknown unit '{dst}'",
                "supported_units": sorted(_UNIT_INDEX)[:80]}
    fam_s, factor_s = _UNIT_INDEX[src]
    fam_d, factor_d = _UNIT_INDEX[dst]
    if fam_s != fam_d:
        return {"ok": False, "error": f"cannot convert {src} ({fam_s}) to {dst} ({fam_d})",
                f"{fam_d}_units": sorted(u for u, (f, _) in _UNIT_INDEX.items() if f == fam_d)}
    result = amount * factor_s / factor_d
    return {"ok": True, "value": amount, "from": src, "to": dst, "family": fam_s,
            "result": _round(result), "formatted": _fmt(result),
            "answer": f"{_fmt(amount)} {src} = **{_fmt(result)} {dst}**"}


@tool(
    name="math.date_calc",
    capability="ai.reasoning",
    agent="planning",
    device="both",
    description="Date arithmetic: difference between dates, add/subtract days, next weekday, age, ISO week, business days",
    schema={"operation": {"type": "string", "description": "diff|add|age|next|week|business_days|today"},
            "date": {"type": "string", "description": "YYYY-MM-DD or 'today'/'tomorrow'"},
            "other_date": {"type": "string"}, "days": {"type": "integer"},
            "weekday": {"type": "string", "description": "monday..sunday for 'next'"}},
    risk="LOW",
    timeout=30,
)
async def math_date_calc(ctx: ToolContext, operation: str = "", date: str = "",
                         other_date: str = "", days: Optional[int] = None, weekday: str = "",
                         request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()

    def parse(d: str) -> Optional[date]:
        d = (d or "").strip().lower()
        if not d or d in ("today", "now"):
            return datetime.now().date()
        if d == "tomorrow":
            return datetime.now().date() + timedelta(days=1)
        if d == "yesterday":
            return datetime.now().date() - timedelta(days=1)
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d", "%d %b %Y",
                    "%d %B %Y", "%b %d %Y", "%B %d, %Y", "%d-%b-%Y", "%d.%m.%Y"):
            try:
                return datetime.strptime(d, fmt).date()
            except ValueError:
                continue
        m = re.search(r"(\d{1,2})\s*(?:st|nd|rd|th)?\s+([a-z]+)\s+(\d{4})", d)
        if m:
            try:
                return datetime.strptime(f"{m.group(1)} {m.group(2)[:3]} {m.group(3)}",
                                         "%d %b %Y").date()
            except ValueError:
                return None
        return None

    op = operation.strip().lower()
    if not op:
        op = ("diff" if (other_date or "between" in text or "how many days" in text)
              else "age" if "age" in text or "how old" in text
              else "next" if weekday or "next" in text
              else "add" if days is not None or "after" in text or "from now" in text
              else "today")
    d1 = parse(date)
    if d1 is None and op not in ("today", "next"):
        return {"ok": False, "error": f"could not understand the date '{date}' — use YYYY-MM-DD"}
    today = datetime.now().date()

    if op == "today":
        now = datetime.now()
        return {"ok": True, "operation": "today", "date": today.isoformat(),
                "datetime": now.isoformat(timespec="seconds"),
                "weekday": today.strftime("%A"), "iso_week": today.isocalendar()[1],
                "day_of_year": today.timetuple().tm_yday, "leap_year": today.year % 4 == 0
                and (today.year % 100 != 0 or today.year % 400 == 0),
                "answer": f"Today is {today.strftime('%A, %d %B %Y')} (week {today.isocalendar()[1]}, "
                          f"day {today.timetuple().tm_yday} of the year)."}

    if op == "diff":
        d2 = parse(other_date) or today
        delta = d2 - (d1 or today)
        total = abs(delta.days)
        years, rem = divmod(total, 365)
        months, rem_days = divmod(rem, 30)
        weeks = total // 7
        return {"ok": True, "operation": "diff", "start": (d1 or today).isoformat(),
                "end": d2.isoformat(), "days": delta.days, "abs_days": total,
                "weeks": weeks, "weekdays_between": _business_days((d1 or today), d2),
                "approx": f"{years}y {months}m {rem_days}d",
                "answer": f"There are {total:,} days ({weeks:,} weeks ≈ {years}y {months}m {rem_days}d) "
                          f"between {(d1 or today).strftime('%d %b %Y')} and {d2.strftime('%d %b %Y')}."}

    if op == "age":
        if not d1:
            return {"ok": False, "error": "give a birth date, e.g. date='1998-04-12'"}
        years = today.year - d1.year - ((today.month, today.day) < (d1.month, d1.day))
        days_lived = (today - d1).days
        next_bday = d1.replace(year=today.year)
        if next_bday < today:
            next_bday = d1.replace(year=today.year + 1)
        return {"ok": True, "operation": "age", "birth_date": d1.isoformat(), "age_years": years,
                "days_lived": days_lived, "months_lived": round(days_lived / 30.44),
                "hours_lived": days_lived * 24,
                "next_birthday": next_bday.isoformat(), "days_to_next_birthday": (next_bday - today).days,
                "answer": f"{d1.isoformat()} ⇒ {years} years old ({days_lived:,} days). "
                          f"Next birthday in {(next_bday - today).days} days."}

    if op == "add":
        n = int(days or 0)
        if not n:
            m = re.search(r"(\d+)\s*(day|week|month|year)s?", text)
            if m:
                n = int(m.group(1)) * {"day": 1, "week": 7, "month": 30, "year": 365}[m.group(2)]
        base = d1 or today
        if re.search(r"\b(business|working)\s+days?\b", text):
            result, added = base, 0
            while added < abs(n):
                result += timedelta(days=1 if n > 0 else -1)
                if result.weekday() < 5:
                    added += 1
        else:
            result = base + timedelta(days=n)
        return {"ok": True, "operation": "add", "base": base.isoformat(), "days": n,
                "result": result.isoformat(), "weekday": result.strftime("%A"),
                "answer": f"{base.strftime('%d %b %Y')} {'+' if n >= 0 else '-'} {abs(n)} days = "
                          f"**{result.strftime('%A, %d %B %Y')}**"}

    if op == "next":
        names = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
        target = (weekday or "").strip().lower()
        if not target:
            m = re.search(r"next\s+(" + "|".join(names) + r")", text)
            target = m.group(1) if m else ""
        if target[:3] not in [n[:3] for n in names]:
            return {"ok": False, "error": "which weekday? monday..sunday"}
        idx = next(i for i, n in enumerate(names) if n.startswith(target[:3]))
        base = d1 or today
        delta = (idx - base.weekday()) % 7 or 7
        result = base + timedelta(days=delta)
        return {"ok": True, "operation": "next", "weekday": names[idx], "base": base.isoformat(),
                "result": result.isoformat(), "days_ahead": delta,
                "answer": f"The next {names[idx].title()} is {result.strftime('%d %B %Y')} "
                          f"(in {delta} day{'s' if delta != 1 else ''})."}

    if op in ("business_days", "week"):
        if op == "week":
            start = today - timedelta(days=today.weekday())
            return {"ok": True, "operation": "week", "iso_week": today.isocalendar()[1],
                    "monday": start.isoformat(), "sunday": (start + timedelta(days=6)).isoformat(),
                    "answer": f"This week (ISO week {today.isocalendar()[1]}) runs "
                              f"{start.strftime('%d %b')} – {(start + timedelta(days=6)).strftime('%d %b %Y')}."}
        d2 = parse(other_date) or today
        bd = _business_days(d1 or today, d2)
        return {"ok": True, "operation": "business_days", "start": (d1 or today).isoformat(),
                "end": d2.isoformat(), "business_days": bd, "calendar_days": abs((d2 - (d1 or today)).days),
                "answer": f"{bd} business days between {(d1 or today).isoformat()} and {d2.isoformat()}."}

    return {"ok": False, "operation": op,
            "error": "unknown operation — use diff, add, age, next, week, business_days or today"}


def _business_days(start: date, end: date) -> int:
    if start > end:
        start, end = end, start
    days = 0
    cur = start
    while cur < end:
        cur += timedelta(days=1)
        if cur.weekday() < 5:
            days += 1
    return days


# ===========================================================================
# 5. FINANCE
# ===========================================================================
@tool(
    name="math.finance",
    capability="ai.reasoning",
    agent="data",
    device="both",
    description="Financial maths: EMI, SIP, compound/simple interest, CAGR, loan amortisation, GST, inflation, break-even, ROI",
    schema={"operation": {"type": "string", "required": True,
                          "description": "emi|sip|compound|simple|cagr|amortisation|gst|inflation|break_even|roi|discount|salary"},
            "principal": {"type": "number"}, "rate": {"type": "number", "description": "annual percent"},
            "years": {"type": "number"}, "months": {"type": "number"},
            "monthly_investment": {"type": "number"}, "future_value": {"type": "number"},
            "extra": {"type": "number"}},
    risk="LOW",
    timeout=30,
)
async def math_finance(ctx: ToolContext, operation: str = "", principal: float = 0.0,
                       rate: float = 0.0, years: float = 0.0, months: float = 0.0,
                       monthly_investment: float = 0.0, future_value: float = 0.0,
                       extra: float = 0.0, request: str = "") -> Dict[str, Any]:
    op = (operation or "").strip().lower()
    text = (request or ctx.user_text or "").lower()
    if not op:
        for k in ("emi", "sip", "compound", "cagr", "amortisation", "gst", "inflation",
                  "break_even", "roi", "discount", "salary", "simple"):
            if k in text:
                op = k
                break
    P = float(principal or 0)
    r = float(rate or 0)
    n_years = float(years or 0)
    n_months = float(months or (n_years * 12))
    out: Dict[str, Any] = {"ok": True, "operation": op, "inputs": {
        "principal": P, "rate_percent": r, "years": n_years, "months": n_months,
        "monthly_investment": float(monthly_investment or 0), "future_value": float(future_value or 0),
        "extra": float(extra or 0)}}

    if op == "emi":
        if not P or not r or not n_months:
            return {"ok": False, "operation": op,
                    "error": "EMI needs principal, annual rate (percent) and tenure in months/years"}
        i = r / 12 / 100
        emi = P * i * (1 + i) ** n_months / ((1 + i) ** n_months - 1) if i else P / n_months
        total = emi * n_months
        schedule = _amortisation(P, r, int(n_months), emi)[:12]
        out.update({"emi": round(emi, 2), "total_payment": round(total, 2),
                    "total_interest": round(total - P, 2), "interest_percent":
                        round((total - P) / P * 100, 2), "first_year_schedule": schedule,
                    "answer": f"EMI = **₹{emi:,.2f}**/month for {int(n_months)} months at {r}% p.a. "
                              f"on ₹{P:,.0f}. Total paid ₹{total:,.2f}, of which "
                              f"₹{total - P:,.2f} is interest ({round((total - P) / P * 100, 1)}%)."})
        return out

    if op == "sip":
        m = float(monthly_investment or 0)
        if not m or not r or not n_months:
            return {"ok": False, "operation": op,
                    "error": "SIP needs monthly_investment, expected annual return percent and tenure"}
        i = r / 12 / 100
        fv = m * (((1 + i) ** n_months - 1) / i) * (1 + i) if i else m * n_months
        invested = m * n_months
        out.update({"invested": round(invested, 2), "future_value": round(fv, 2),
                    "gains": round(fv - invested, 2), "gain_percent": round((fv - invested) / invested * 100, 2),
                    "answer": f"₹{m:,.0f}/month for {int(n_months)} months at {r}% ⇒ invested "
                              f"₹{invested:,.0f}, worth **₹{fv:,.0f}** (gains ₹{fv - invested:,.0f}, "
                              f"{round((fv - invested) / invested * 100, 1)}%)."})
        return out

    if op == "compound":
        if not P or not r or not n_years:
            return {"ok": False, "operation": op, "error": "compound interest needs principal, rate and years"}
        freq = int(extra or 1)
        fv = P * (1 + r / 100 / freq) ** (freq * n_years)
        out.update({"future_value": round(fv, 2), "interest_earned": round(fv - P, 2),
                    "compounding_per_year": freq, "effective_annual_rate_percent":
                        round(((1 + r / 100 / freq) ** freq - 1) * 100, 4),
                    "answer": f"₹{P:,.0f} at {r}% for {n_years:g} years (compounded {freq}×/year) grows to "
                              f"**₹{fv:,.2f}** — interest earned ₹{fv - P:,.2f}."})
        return out

    if op == "simple":
        if not P or not r or not n_years:
            return {"ok": False, "operation": op, "error": "simple interest needs principal, rate and years"}
        si = P * r * n_years / 100
        out.update({"simple_interest": round(si, 2), "total": round(P + si, 2),
                    "answer": f"Simple interest on ₹{P:,.0f} at {r}% for {n_years:g}y = "
                              f"₹{si:,.2f}; total ₹{P + si:,.2f}."})
        return out

    if op == "cagr":
        begin, end = float(principal or 0), float(future_value or extra or 0)
        if not begin or not end or not n_years:
            return {"ok": False, "operation": op,
                    "error": "CAGR needs principal (beginning value), future_value (ending value) and years"}
        cagr = (end / begin) ** (1 / n_years) - 1
        out.update({"cagr_percent": round(cagr * 100, 3), "multiple": round(end / begin, 4),
                    "answer": f"{begin:,.0f} → {end:,.0f} over {n_years:g} years = "
                              f"**{round(cagr * 100, 2)}% CAGR** ({round(end / begin, 2)}×)."})
        return out

    if op == "amortisation":
        if not P or not r or not n_months:
            return {"ok": False, "operation": op, "error": "amortisation needs principal, rate and months"}
        i = r / 12 / 100
        emi = P * i * (1 + i) ** n_months / ((1 + i) ** n_months - 1) if i else P / n_months
        table = _amortisation(P, r, int(n_months), emi)
        yearly = {}
        for row in table:
            y = (row["month"] - 1) // 12 + 1
            agg = yearly.setdefault(y, {"year": y, "principal": 0.0, "interest": 0.0, "paid": 0.0})
            agg["principal"] += row["principal"]
            agg["interest"] += row["interest"]
            agg["paid"] += row["payment"]
        for agg in yearly.values():
            for k in ("principal", "interest", "paid"):
                agg[k] = round(agg[k], 2)
        out.update({"emi": round(emi, 2), "yearly": sorted(yearly.values(), key=lambda d: d["year"]),
                    "first_rows": table[:6], "last_balance": table[-1]["balance"] if table else 0,
                    "answer": f"Loan of ₹{P:,.0f} at {r}% over {int(n_months)} months: EMI ₹{emi:,.2f}. "
                              f"Year 1 pays ₹{yearly[1]['interest']:,.0f} interest and "
                              f"₹{yearly[1]['principal']:,.0f} principal."})
        return out

    if op == "gst":
        if not P:
            return {"ok": False, "operation": op, "error": "GST needs an amount (principal)"}
        pct = r or 18
        if extra:  # extra=1 means the amount already includes GST
            base = P / (1 + pct / 100)
            out.update({"inclusive_amount": round(P, 2), "base": round(base, 2),
                        "gst": round(P - base, 2), "rate_percent": pct,
                        "answer": f"₹{P:,.2f} includes ₹{P - base:,.2f} GST at {pct}% "
                                  f"(base ₹{base:,.2f})."})
        else:
            gst = P * pct / 100
            out.update({"base": round(P, 2), "gst": round(gst, 2), "total": round(P + gst, 2),
                        "rate_percent": pct,
                        "answer": f"₹{P:,.2f} + {pct}% GST = ₹{gst:,.2f} tax, total **₹{P + gst:,.2f}**."})
        return out

    if op == "inflation":
        if not P or not r or not n_years:
            return {"ok": False, "operation": op,
                    "error": "inflation needs an amount (principal), annual inflation percent and years"}
        future_cost = P * (1 + r / 100) ** n_years
        today_value = P / (1 + r / 100) ** n_years
        out.update({"future_cost": round(future_cost, 2), "purchasing_power_today": round(today_value, 2),
                    "loss_percent": round((1 - today_value / P) * 100, 2),
                    "answer": f"At {r}% inflation, something costing ₹{P:,.0f} today costs "
                              f"**₹{future_cost:,.0f}** in {n_years:g} years; ₹{P:,.0f} then is worth "
                              f"₹{today_value:,.0f} in today's money."})
        return out

    if op == "break_even":
        fixed = float(principal or 0)
        price = float(extra or 0)
        variable = float(future_value or 0)
        if not price or price <= variable:
            return {"ok": False, "operation": op,
                    "error": "break-even needs principal=fixed costs, extra=unit price, "
                             "future_value=unit variable cost (price must exceed cost)"}
        units = fixed / (price - variable)
        out.update({"units": round(units, 2), "revenue_at_break_even": round(units * price, 2),
                    "contribution_margin": round(price - variable, 2),
                    "contribution_margin_percent": round((price - variable) / price * 100, 2),
                    "answer": f"Break-even at **{units:,.0f} units** (contribution ₹{price - variable:,.2f}/unit, "
                              f"revenue ₹{units * price:,.0f})."})
        return out

    if op == "roi":
        cost, gain = float(principal or 0), float(future_value or 0)
        if not cost:
            return {"ok": False, "operation": op, "error": "ROI needs principal=investment and future_value=return"}
        roi = (gain - cost) / cost * 100
        out.update({"roi_percent": round(roi, 3), "profit": round(gain - cost, 2),
                    "multiple": round(gain / cost, 4),
                    "answer": f"Invested ₹{cost:,.0f}, got back ₹{gain:,.0f} ⇒ **ROI {roi:,.2f}%** "
                              f"(profit ₹{gain - cost:,.0f})."})
        return out

    if op == "discount":
        price, pct = float(principal or 0), float(rate or 0)
        if not price:
            return {"ok": False, "operation": op, "error": "discount needs principal=price and rate=percent"}
        final = price * (1 - pct / 100)
        out.update({"original": round(price, 2), "discount_percent": pct,
                    "discount_amount": round(price - final, 2), "final_price": round(final, 2),
                    "answer": f"₹{price:,.2f} at {pct:g}% off = **₹{final:,.2f}** "
                              f"(you save ₹{price - final:,.2f})."})
        return out

    if op == "salary":
        annual = float(principal or 0)
        if not annual:
            return {"ok": False, "operation": op, "error": "salary breakdown needs principal=annual CTC"}
        monthly = annual / 12
        out.update({"annual": round(annual, 2), "monthly": round(monthly, 2),
                    "biweekly": round(annual / 26, 2), "weekly": round(annual / 52, 2),
                    "daily_working": round(annual / 261, 2), "hourly": round(annual / 2080, 2),
                    "answer": f"₹{annual:,.0f}/year = ₹{monthly:,.0f}/month = ₹{annual / 52:,.0f}/week "
                              f"= ₹{annual / 2080:,.0f}/hour (2080 h basis)."})
        return out

    return {"ok": False, "operation": op,
            "error": "unknown operation — use emi, sip, compound, simple, cagr, amortisation, gst, "
                     "inflation, break_even, roi, discount or salary"}


def _amortisation(principal: float, annual_rate: float, months: int,
                  emi: float) -> List[Dict[str, Any]]:
    balance = principal
    i = annual_rate / 12 / 100
    rows: List[Dict[str, Any]] = []
    for m in range(1, months + 1):
        interest = balance * i
        principal_part = emi - interest
        balance -= principal_part
        if balance < 0:
            principal_part += balance
            balance = 0.0
        rows.append({"month": m, "payment": round(emi, 2), "interest": round(interest, 2),
                     "principal": round(principal_part, 2), "balance": round(balance, 2)})
        if balance <= 0:
            break
    return rows


# ===========================================================================
# 6. NUMBER THEORY / BASES / RANDOM / PERCENT / FRACTIONS / GEOMETRY
# ===========================================================================
@tool(
    name="math.base_convert",
    capability="ai.reasoning",
    agent="coding",
    device="both",
    description="Convert numbers between bases (decimal, binary, octal, hex) and do bitwise operations",
    schema={"value": {"type": "string", "required": True, "description": "number, optionally prefixed 0x/0b/0o"},
            "from_base": {"type": "integer", "description": "2, 8, 10 or 16 (auto-detected when omitted)"},
            "operation": {"type": "string", "description": "convert|and|or|xor|not|shift_left|shift_right"},
            "other": {"type": "string", "description": "second operand for bitwise ops"}},
    risk="LOW",
    timeout=30,
)
async def math_base_convert(ctx: ToolContext, value: str = "", from_base: int = 0,
                            operation: str = "convert", other: str = "",
                            request: str = "") -> Dict[str, Any]:
    raw = (value or request or ctx.user_text or "").strip().replace(" ", "")
    raw = re.sub(r"^(convert|what\s+is)\s+", "", raw, flags=re.I)
    if not raw:
        return {"ok": False, "error": "which number?"}
    try:
        if from_base:
            n = int(raw.lower().replace("0x", "").replace("0b", "").replace("0o", ""), int(from_base))
        elif raw.lower().startswith("0x"):
            n = int(raw, 16)
        elif raw.lower().startswith("0b"):
            n = int(raw, 2)
        elif raw.lower().startswith("0o"):
            n = int(raw, 8)
        elif re.fullmatch(r"[01]{2,}", raw):
            n = int(raw, 2)
        elif re.fullmatch(r"[0-9a-fA-F]+", raw) and re.search(r"[a-fA-F]", raw):
            n = int(raw, 16)
        else:
            n = int(raw, 10)
    except ValueError:
        return {"ok": False, "value": value, "error": f"'{value}' is not a valid integer"}

    base = {"decimal": n, "binary": bin(n), "octal": oct(n), "hex": hex(n).upper().replace("0X", "0x"),
            "hex_plain": format(n, "x"), "bytes": _human_bytes(abs(n)) if abs(n) >= 1024 else f"{n} B",
            "bit_length": n.bit_length(), "signed_8bit": n if -128 <= n < 128 else None,
            "twos_complement_8bit": format(n & 0xFF, "08b"),
            "twos_complement_16bit": format(n & 0xFFFF, "016b"),
            "grouped_binary": _group(bin(n)[2:] if n >= 0 else "-" + bin(-n)[2:])}
    out: Dict[str, Any] = {"ok": True, "input": raw, "operation": operation, **base}

    if operation != "convert" and other:
        try:
            m = int(str(other).replace(" ", ""), 0) if str(other).startswith("0") else int(other, 0)
        except ValueError:
            return {"ok": False, "error": f"second operand '{other}' is not a valid integer"}
        ops = {"and": lambda: n & m, "or": lambda: n | m, "xor": lambda: n ^ m,
               "not": lambda: ~n, "shift_left": lambda: n << m, "shift_right": lambda: n >> m}
        if operation not in ops:
            return {"ok": False, "operation": operation, "error": "bitwise op must be and|or|xor|not|shift_left|shift_right"}
        res = ops[operation]()
        out["bitwise"] = {"operation": operation, "other": m, "result_decimal": res,
                          "result_binary": bin(res), "result_hex": hex(res)}
        out["answer"] = f"{n} {operation} {m} = {res} ({bin(res)})"
    else:
        out["answer"] = (f"{raw} ⇒ decimal {n}, binary {base['binary']}, octal {base['octal']}, "
                         f"hex {base['hex']}")
    return out


def _group(bits: str) -> str:
    neg = bits.startswith("-")
    bits = bits.lstrip("-")
    padded = bits.zfill((len(bits) + 3) // 4 * 4)
    grouped = " ".join(padded[i:i + 4] for i in range(0, len(padded), 4))
    return ("-" if neg else "") + grouped


def _human_bytes(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if abs(n) < 1024 or unit == "PB":
            return f"{n:,.2f} {unit}".replace(".00", "")
        n /= 1024
    return f"{n} PB"


@tool(
    name="math.prime_factor",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Prime test, prime factorisation, GCD/LCM, next/previous prime, modular arithmetic, divisors",
    schema={"operation": {"type": "string", "description": "factor|is_prime|gcd|lcm|next_prime|divisors|mod|fibonacci"},
            "value": {"type": "integer", "required": True}, "other": {"type": "integer"}},
    risk="LOW",
    timeout=30,
)
async def math_prime_factor(ctx: ToolContext, operation: str = "factor", value: int = 0,
                            other: Optional[int] = None, request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    op = operation.strip().lower()
    if not op or op == "factor":
        for k in ("is_prime", "prime", "gcd", "lcm", "next_prime", "divisors", "mod", "fibonacci", "factor"):
            if k in text:
                op = "is_prime" if k == "prime" else k
                break
    nums = [int(v) for v in re.findall(r"\d+", text)] if not value else [int(value)]
    n = int(value) if value else (nums[0] if nums else 0)
    if not n:
        return {"ok": False, "error": "give me a positive integer to work with"}

    def is_prime(k: int) -> bool:
        if k < 2:
            return False
        if k % 2 == 0:
            return k == 2
        d = 3
        while d * d <= k:
            if k % d == 0:
                return False
            d += 2
        return True

    if op == "is_prime":
        return {"ok": True, "operation": op, "value": n, "is_prime": is_prime(n),
                "answer": f"{n} is {'a prime number' if is_prime(n) else 'NOT prime'}."}
    if op == "factor":
        remaining, factors = abs(n), []
        d = 2
        while d * d <= remaining:
            while remaining % d == 0:
                factors.append(d)
                remaining //= d
            d += 1 if d == 2 else 2
        if remaining > 1:
            factors.append(remaining)
        grouped: Dict[int, int] = {}
        for f in factors:
            grouped[f] = grouped.get(f, 0) + 1
        expr = " × ".join(f"{k}^{v}" if v > 1 else str(k) for k, v in sorted(grouped.items()))
        return {"ok": True, "operation": op, "value": n, "factors": factors,
                "unique_factors": sorted(grouped), "factorisation": expr,
                "number_of_divisors": _divisor_count(grouped),
                "answer": f"{n} = {expr or str(n)}"}
    if op in ("gcd", "lcm"):
        m = int(other or (nums[1] if len(nums) > 1 else 0))
        if not m:
            return {"ok": False, "operation": op, "error": f"{op} needs two numbers (value and other)"}
        g = pymath.gcd(n, m)
        if op == "gcd":
            return {"ok": True, "operation": op, "a": n, "b": m, "gcd": g,
                    "coprime": g == 1, "answer": f"gcd({n}, {m}) = {g}"
                                                  + (" — they are coprime" if g == 1 else "")}
        lcm = abs(n * m) // g
        return {"ok": True, "operation": op, "a": n, "b": m, "lcm": lcm,
                "answer": f"lcm({n}, {m}) = {lcm}"}
    if op == "next_prime":
        k = n + 1
        while not is_prime(k):
            k += 1
        prev = n - 1
        while prev > 1 and not is_prime(prev):
            prev -= 1
        return {"ok": True, "operation": op, "value": n, "next_prime": k,
                "previous_prime": prev if prev > 1 else None,
                "answer": f"next prime after {n} is {k}"
                          + (f"; previous prime is {prev}" if prev > 1 else "")}
    if op == "divisors":
        divs = [i for i in range(1, int(pymath.isqrt(n)) + 1) if n % i == 0]
        full = sorted(set(divs + [n // d for d in divs]))
        proper = [d for d in full if d != n]
        return {"ok": True, "operation": op, "value": n, "divisors": full[:200], "count": len(full),
                "proper_divisors": proper[:200], "sum_of_proper_divisors": sum(proper),
                "classification": ("perfect" if sum(proper) == n else
                                   "abundant" if sum(proper) > n else "deficient"),
                "answer": f"{n} has {len(full)} divisors; sum of proper divisors is {sum(proper)} "
                          f"⇒ {('perfect' if sum(proper) == n else 'abundant' if sum(proper) > n else 'deficient')}."}
    if op == "mod":
        m = int(other or (nums[1] if len(nums) > 1 else 0))
        if not m:
            return {"ok": False, "operation": op, "error": "mod needs value and other (the modulus)"}
        return {"ok": True, "operation": op, "a": n, "modulus": m, "remainder": n % m,
                "quotient": n // m, "modular_inverse": pow(n, -1, m) if pymath.gcd(n, m) == 1 else None,
                "answer": f"{n} mod {m} = {n % m} (quotient {n // m})"}
    if op == "fibonacci":
        seq = [0, 1]
        for _ in range(max(0, min(n, 200)) - 1):
            seq.append(seq[-1] + seq[-2])
        seq = seq[: max(1, min(n, 200))]
        golden = seq[-1] / seq[-2] if len(seq) > 1 and seq[-2] else None
        return {"ok": True, "operation": op, "n": n, "sequence": seq, "value_at_n": seq[-1] if seq else 0,
                "ratio_towards_golden": _round(golden, 8) if golden else None,
                "answer": f"Fibonacci({n}) = {seq[-1] if seq else 0}; first {len(seq)} terms: "
                          f"{', '.join(map(str, seq[:15]))}{'…' if len(seq) > 15 else ''}"}
    return {"ok": False, "operation": op,
            "error": "use factor, is_prime, gcd, lcm, next_prime, divisors, mod or fibonacci"}


def _divisor_count(grouped: Dict[int, int]) -> int:
    total = 1
    for v in grouped.values():
        total *= (v + 1)
    return total


@tool(
    name="math.geometry",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Area, perimeter, volume and surface area for common shapes, plus distance between points",
    schema={"shape": {"type": "string", "required": True,
                      "description": "circle|rectangle|square|triangle|trapezoid|sphere|cylinder|cone|cube|cuboid|pyramid|distance|polygon"},
            "dimensions": {"type": "object", "description": "named measurements, e.g. {'radius': 5}"}},
    risk="LOW",
    timeout=30,
)
async def math_geometry(ctx: ToolContext, shape: str = "", dimensions: Optional[Dict[str, float]] = None,
                        request: str = "") -> Dict[str, Any]:
    s = (shape or request or ctx.user_text or "").strip().lower()
    s = re.sub(r"^(area|perimeter|volume|surface\s+area)\s+(of\s+(a|an|the)\s+)?", "", s)
    d = {k.lower(): _num(v) for k, v in (dimensions or {}).items()}
    text = (request or ctx.user_text or "").lower()
    if not d:
        for pair in re.findall(r"(\w+)\s*(?:=|of|:)\s*(\d+(?:\.\d+)?)", text):
            d[pair[0].lower()] = float(pair[1])
        nums = re.findall(r"\b(\d+(?:\.\d+)?)\b", text)
        if nums and not d:
            keys = {"circle": ["radius"], "sphere": ["radius"], "square": ["side"],
                    "rectangle": ["length", "width"], "cube": ["side"],
                    "cuboid": ["length", "width", "height"], "triangle": ["base", "height"],
                    "cylinder": ["radius", "height"], "cone": ["radius", "height"]}
            for i, k in enumerate(keys.get(s.split()[0] if s else "", [])[:len(nums)]):
                d[k] = float(nums[i])

    def get(*names: str) -> Optional[float]:
        for n in names:
            if n in d and d[n] is not None:
                return d[n]
        return None

    try:
        if s.startswith("circle"):
            r = get("radius", "r") or ((get("diameter", "d") or 0) / 2)
            if not r:
                return {"ok": False, "shape": s, "error": "a circle needs radius (or diameter)"}
            return _geo(s, {"radius": r}, {
                "area": pymath.pi * r * r, "circumference": 2 * pymath.pi * r,
                "diameter": 2 * r, "sector_area_90deg": pymath.pi * r * r / 4})
        if s.startswith("sphere"):
            r = get("radius", "r")
            if not r:
                return {"ok": False, "shape": s, "error": "a sphere needs a radius"}
            return _geo(s, {"radius": r}, {
                "volume": 4 / 3 * pymath.pi * r ** 3, "surface_area": 4 * pymath.pi * r * r})
        if s.startswith("square"):
            a = get("side", "a", "length")
            if not a:
                return {"ok": False, "shape": s, "error": "a square needs a side length"}
            return _geo(s, {"side": a}, {"area": a * a, "perimeter": 4 * a,
                                         "diagonal": a * pymath.sqrt(2)})
        if s.startswith("rectangle") or s.startswith("cuboid") or s.startswith("box"):
            l, w, h = get("length", "l"), get("width", "w", "breadth", "b"), get("height", "h", "depth")
            if not l or not w:
                return {"ok": False, "shape": s, "error": "needs length and width (and height for a cuboid)"}
            if h:
                return _geo(s, {"length": l, "width": w, "height": h}, {
                    "volume": l * w * h, "surface_area": 2 * (l * w + w * h + l * h),
                    "space_diagonal": pymath.sqrt(l * l + w * w + h * h)})
            return _geo(s, {"length": l, "width": w}, {
                "area": l * w, "perimeter": 2 * (l + w), "diagonal": pymath.sqrt(l * l + w * w)})
        if s.startswith("cube"):
            a = get("side", "a", "edge")
            if not a:
                return {"ok": False, "shape": s, "error": "a cube needs a side length"}
            return _geo(s, {"side": a}, {"volume": a ** 3, "surface_area": 6 * a * a,
                                         "space_diagonal": a * pymath.sqrt(3)})
        if s.startswith("triangle"):
            b, h = get("base", "b"), get("height", "h")
            sides = [get("side_a", "a"), get("side_b", "b2"), get("side_c", "c")]
            if b and h:
                out = {"area": 0.5 * b * h}
                if all(sides):
                    a_, b_, c_ = sides
                    peri = a_ + b_ + c_
                    sr = peri / 2
                    out["perimeter"] = peri
                    out["area_heron"] = pymath.sqrt(max(0.0, sr * (sr - a_) * (sr - b_) * (sr - c_)))
                    out["type"] = ("equilateral" if a_ == b_ == c_ else
                                   "isosceles" if a_ == b_ or b_ == c_ or a_ == c_ else "scalene")
                    out["right_angled"] = abs(max(a_, b_, c_) ** 2 -
                                              sum(x ** 2 for x in (a_, b_, c_) if x != max(a_, b_, c_))) < 1e-9
                return _geo(s, {"base": b, "height": h, **(dimensions or {})}, out)
            if all(sides):
                a_, b_, c_ = sides
                peri = a_ + b_ + c_
                sr = peri / 2
                return _geo(s, {"sides": [a_, b_, c_]}, {
                    "perimeter": peri,
                    "area": pymath.sqrt(max(0.0, sr * (sr - a_) * (sr - b_) * (sr - c_)))})
            return {"ok": False, "shape": s,
                    "error": "a triangle needs base+height, or all three sides (side_a, side_b, side_c)"}
        if s.startswith("trapez"):
            a, b, h = get("a", "base1"), get("b", "base2"), get("height", "h")
            if not all((a, b, h)):
                return {"ok": False, "shape": s, "error": "needs a, b (parallel sides) and height"}
            return _geo(s, {"a": a, "b": b, "height": h}, {"area": 0.5 * (a + b) * h,
                                                           "midsegment": (a + b) / 2})
        if s.startswith("cylinder"):
            r, h = get("radius", "r"), get("height", "h")
            if not r or not h:
                return {"ok": False, "shape": s, "error": "a cylinder needs radius and height"}
            return _geo(s, {"radius": r, "height": h}, {
                "volume": pymath.pi * r * r * h,
                "surface_area": 2 * pymath.pi * r * h + 2 * pymath.pi * r * r,
                "lateral_area": 2 * pymath.pi * r * h})
        if s.startswith("cone"):
            r, h = get("radius", "r"), get("height", "h")
            if not r or not h:
                return {"ok": False, "shape": s, "error": "a cone needs radius and height"}
            slant = pymath.sqrt(r * r + h * h)
            return _geo(s, {"radius": r, "height": h}, {
                "volume": pymath.pi * r * r * h / 3, "slant_height": slant,
                "lateral_area": pymath.pi * r * slant,
                "surface_area": pymath.pi * r * slant + pymath.pi * r * r})
        if s.startswith("pyramid"):
            b, h = get("base_area"), get("height", "h")
            side = get("side", "base_side")
            if not b and side:
                b = side * side
            if not b or not h:
                return {"ok": False, "shape": s, "error": "needs base_area (or side) and height"}
            return _geo(s, {"base_area": b, "height": h}, {"volume": b * h / 3})
        if s.startswith("distance"):
            pts = dimensions or {}
            x1, y1 = _num(pts.get("x1")), _num(pts.get("y1"))
            x2, y2 = _num(pts.get("x2")), _num(pts.get("y2"))
            if None in (x1, y1, x2, y2):
                lat1, lon1 = _num(pts.get("lat1")), _num(pts.get("lon1"))
                lat2, lon2 = _num(pts.get("lat2")), _num(pts.get("lon2"))
                if None in (lat1, lon1, lat2, lon2):
                    return {"ok": False, "shape": "distance",
                            "error": "need (x1,y1,x2,y2) or (lat1,lon1,lat2,lon2)"}
                return _geo("great_circle", {"lat1": lat1, "lon1": lon1, "lat2": lat2, "lon2": lon2},
                            {"distance_km": _haversine(lat1, lon1, lat2, lon2),
                             "distance_miles": _haversine(lat1, lon1, lat2, lon2) * 0.621371})
            return _geo("distance_2d", {"x1": x1, "y1": y1, "x2": x2, "y2": y2}, {
                "distance": pymath.hypot(x2 - x1, y2 - y1),
                "midpoint": [(x1 + x2) / 2, (y1 + y2) / 2],
                "slope": (y2 - y1) / (x2 - x1) if x2 != x1 else None})
        if s.startswith("polygon"):
            n, side = get("n", "sides"), get("side", "a")
            if not n or n < 3:
                return {"ok": False, "shape": s, "error": "a regular polygon needs n ≥ 3 sides"}
            interior = (n - 2) * 180
            out = {"interior_angle_sum": interior, "each_interior_angle": interior / n,
                   "each_exterior_angle": 360 / n, "diagonals": n * (n - 3) / 2}
            if side:
                out["perimeter"] = n * side
                out["area"] = 0.25 * n * side * side / pymath.tan(pymath.pi / n)
            return _geo(s, {"n": n, "side": side}, out)
        return {"ok": False, "shape": s,
                "error": "supported shapes: circle, sphere, square, rectangle, cuboid, cube, "
                         "triangle, trapezoid, cylinder, cone, pyramid, polygon, distance"}
    except Exception as exc:
        return {"ok": False, "shape": s, "error": f"geometry failed: {type(exc).__name__}: {exc}"}


def _geo(shape: str, dims: Dict[str, Any], results: Dict[str, Any]) -> Dict[str, Any]:
    clean = {k: _round(v) for k, v in results.items() if v is not None}
    parts = ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in list(clean.items())[:4])
    return {"ok": True, "shape": shape, "dimensions": dims, **clean,
            "answer": f"{shape.title()}: {parts}"}


def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0088
    p1, p2 = pymath.radians(lat1), pymath.radians(lat2)
    dp, dl = pymath.radians(lat2 - lat1), pymath.radians(lon2 - lon1)
    a = pymath.sin(dp / 2) ** 2 + pymath.cos(p1) * pymath.cos(p2) * pymath.sin(dl / 2) ** 2
    return round(2 * r * pymath.asin(pymath.sqrt(a)), 3)


@tool(
    name="math.percent",
    capability="ai.reasoning",
    agent="data",
    device="both",
    description="Percentage maths: X% of Y, what percent is X of Y, percentage change, increase/decrease, tip, margin, markup",
    schema={"operation": {"type": "string", "description": "of|is_what_percent|change|increase|decrease|tip|margin|markup|reverse"},
            "a": {"type": "number", "required": True}, "b": {"type": "number"}},
    risk="LOW",
    timeout=30,
)
async def math_percent(ctx: ToolContext, operation: str = "", a: float = 0.0, b: float = 0.0,
                       request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    op = operation.strip().lower()
    x, y = _num(a) or 0.0, _num(b) or 0.0
    if not op:
        m = re.search(r"(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)", text)
        if m:
            op, x, y = "of", float(m.group(1)), float(m.group(2))
        elif "percentage change" in text or "change" in text or "increase" in text or "decrease" in text:
            nums = re.findall(r"(\d+(?:\.\d+)?)", text)
            op = "change"
            if len(nums) >= 2:
                x, y = float(nums[0]), float(nums[1])
        elif "what percent" in text or "percent of" in text:
            nums = re.findall(r"(\d+(?:\.\d+)?)", text)
            op = "is_what_percent"
            if len(nums) >= 2:
                x, y = float(nums[0]), float(nums[1])
        else:
            op = "of"
    out: Dict[str, Any] = {"ok": True, "operation": op, "a": x, "b": y}

    if op == "of":
        if not y:
            return {"ok": False, "operation": op, "error": "percent-of needs a=percent and b=amount"}
        result = x / 100 * y
        out.update({"result": _round(result),
                    "answer": f"{x:g}% of {y:g} = **{_fmt(result)}**"})
    elif op == "is_what_percent":
        if not y:
            return {"ok": False, "operation": op, "error": "needs a=part and b=whole"}
        pct = x / y * 100
        out.update({"percent": _round(pct, 4),
                    "answer": f"{x:g} is **{pct:,.2f}%** of {y:g}"})
    elif op in ("change", "increase", "decrease"):
        if not x:
            return {"ok": False, "operation": op, "error": "percentage change needs a=old and b=new"}
        delta = y - x
        pct = delta / abs(x) * 100
        out.update({"delta": _round(delta), "percent_change": _round(pct, 4),
                    "direction": "increase" if pct >= 0 else "decrease",
                    "answer": f"{x:g} → {y:g} is a {'+' if pct >= 0 else ''}{pct:,.2f}% "
                              f"{'increase' if pct >= 0 else 'decrease'} ({'+' if delta >= 0 else ''}{_fmt(delta)})"})
    elif op == "tip":
        bill, pct = y or x, (x if y else 10)
        tip = bill * pct / 100
        out.update({"bill": _round(bill), "tip_percent": pct, "tip": _round(tip),
                    "total": _round(bill + tip), "per_person_2": _round((bill + tip) / 2),
                    "answer": f"{pct:g}% tip on {_fmt(bill)} = {_fmt(tip)}; total **{_fmt(bill + tip)}**"})
    elif op in ("margin", "markup"):
        cost, price = x, y
        if not cost or not price:
            return {"ok": False, "operation": op, "error": "margin needs a=cost and b=selling price"}
        profit = price - cost
        margin = profit / price * 100 if op == "margin" else profit / cost * 100
        out.update({"cost": cost, "price": price, "profit": _round(profit),
                    f"{op}_percent": _round(margin, 4),
                    "answer": f"cost {cost:g}, price {price:g} ⇒ profit {profit:g}, "
                              f"**{op} {margin:,.2f}%**"})
    elif op == "reverse":
        final, pct = x, y
        if not final or not pct:
            return {"ok": False, "operation": op,
                    "error": "reverse needs a=final value and b=percent change"}
        original = final / (1 + pct / 100)
        out.update({"original": _round(original), "percent": pct, "final": final,
                    "answer": f"If the final value is {final:g} after {pct:+g}%, the original was "
                              f"**{_fmt(original)}**"})
    else:
        return {"ok": False, "operation": op,
                "error": "use of, is_what_percent, change, increase, decrease, tip, margin, markup, reverse"}
    return out


@tool(
    name="math.fraction",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Convert between fractions and decimals, simplify ratios, add/subtract/multiply/divide fractions",
    schema={"operation": {"type": "string", "description": "simplify|to_decimal|to_fraction|add|subtract|multiply|divide|ratio"},
            "value": {"type": "string", "required": True, "description": "e.g. '3/4', '0.75', '12:18'"},
            "other": {"type": "string"}},
    risk="LOW",
    timeout=30,
)
async def math_fraction(ctx: ToolContext, operation: str = "simplify", value: str = "",
                        other: str = "", request: str = "") -> Dict[str, Any]:
    raw = (value or request or ctx.user_text or "").strip()
    if not raw:
        return {"ok": False, "error": "which fraction or decimal?"}
    op = operation.strip().lower()

    def to_frac(s: str) -> Fraction:
        s = s.strip().replace(" ", "")
        m = re.fullmatch(r"(-?\d+):(-?\d+)", s)
        if m:
            return Fraction(int(m.group(1)), int(m.group(2)))
        m = re.fullmatch(r"(-?\d+)\s+(\d+)/(\d+)", s)  # mixed number "1 1/2"
        if m:
            whole = Fraction(int(m.group(1)))
            return whole + Fraction(int(m.group(2)), int(m.group(3)))
        return Fraction(s)

    try:
        f = to_frac(raw)
    except (ValueError, ZeroDivisionError):
        return {"ok": False, "value": raw, "error": f"'{raw}' is not a fraction, decimal or ratio"}

    if op in ("simplify", "ratio"):
        g = pymath.gcd(f.numerator, f.denominator)
        return {"ok": True, "operation": op, "input": raw, "fraction": f"{f.numerator}/{f.denominator}",
                "decimal": _round(float(f), 8), "percent": _round(float(f) * 100, 4),
                "answer": f"{raw} simplifies to **{f.numerator}/{f.denominator}** "
                          f"= {float(f):.6g} = {float(f) * 100:.4g}%"}
    if op == "to_decimal":
        return {"ok": True, "operation": op, "input": raw, "decimal": _round(float(f), 10),
                "repeating": _detect_repeating(f),
                "answer": f"{raw} = {float(f):.10g}" + (_detect_repeating(f) or "")}
    if op == "to_fraction":
        approx = Fraction(float(raw)).limit_denominator(10000)
        return {"ok": True, "operation": op, "input": raw, "exact": f"{f.numerator}/{f.denominator}",
                "approximate": f"{approx.numerator}/{approx.denominator}",
                "answer": f"{raw} as a fraction = {f.numerator}/{f.denominator}"
                          + (f" (≈ {approx.numerator}/{approx.denominator})"
                             if str(approx) != str(f) else "")}
    if op in ("add", "subtract", "multiply", "divide"):
        if not other:
            return {"ok": False, "operation": op, "error": f"{op} needs a second value"}
        try:
            g = to_frac(other)
        except (ValueError, ZeroDivisionError):
            return {"ok": False, "operation": op, "error": f"'{other}' is not a valid fraction"}
        result = {"add": lambda: f + g, "subtract": lambda: f - g,
                  "multiply": lambda: f * g, "divide": lambda: f / g}[op]()
        return {"ok": True, "operation": op, "a": f"{f.numerator}/{f.denominator}",
                "b": f"{g.numerator}/{g.denominator}",
                "result": f"{result.numerator}/{result.denominator}",
                "decimal": _round(float(result), 10),
                "answer": f"{f.numerator}/{f.denominator} {op} {g.numerator}/{g.denominator} = "
                          f"**{result.numerator}/{result.denominator}** ({float(result):.6g})"}
    return {"ok": False, "operation": op,
            "error": "use simplify, to_decimal, to_fraction, add, subtract, multiply, divide or ratio"}


def _detect_repeating(f: Fraction) -> str:
    d = f.denominator
    while d % 2 == 0:
        d //= 2
    while d % 5 == 0:
        d //= 5
    return "" if d == 1 else " (repeating decimal)"


@tool(
    name="math.random",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Generate random numbers, dice rolls, coin flips, picks from a list, shuffles, passwords, UUIDs and OTPs",
    schema={"operation": {"type": "string", "description": "number|dice|coin|pick|shuffle|password|uuid|otp|sample"},
            "count": {"type": "integer", "default": 1}, "minimum": {"type": "integer", "default": 1},
            "maximum": {"type": "integer", "default": 100},
            "options": {"type": "array", "description": "list to pick/shuffle/sample from"},
            "sides": {"type": "integer", "default": 6}, "length": {"type": "integer", "default": 16},
            "cryptographic": {"type": "boolean", "default": False}},
    risk="LOW",
    timeout=30,
)
async def math_random(ctx: ToolContext, operation: str = "number", count: int = 1,
                      minimum: int = 1, maximum: int = 100, options: Optional[List[Any]] = None,
                      sides: int = 6, length: int = 16, cryptographic: bool = False,
                      request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    op = operation.strip().lower()
    if not op or op == "number":
        for k in ("dice", "roll", "coin", "flip", "pick", "choose", "shuffle", "password",
                  "uuid", "otp", "sample"):
            if k in text:
                op = {"roll": "dice", "flip": "coin", "choose": "pick"}.get(k, k)
                break
    n = max(1, min(int(count), 500))
    rng_int = secrets.randbelow if cryptographic else None
    out: Dict[str, Any] = {"ok": True, "operation": op, "cryptographic": bool(cryptographic)}

    if op == "number":
        lo, hi = min(minimum, maximum), max(minimum, maximum)
        if rng_int:
            vals = [lo + secrets.randbelow(hi - lo + 1) for _ in range(n)]
        else:
            vals = [pyrandom.randint(lo, hi) for _ in range(n)]
        out.update({"min": lo, "max": hi, "count": n, "values": vals,
                    "answer": ", ".join(str(v) for v in vals[:20])
                              + (f" … ({n} values between {lo} and {hi})" if n > 20 else "")})
    elif op == "dice":
        s = max(2, int(sides))
        rolls = max(1, min(int(count), 10))
        flat = [(secrets.randbelow(s) + 1) if rng_int else pyrandom.randint(1, s)
                for _ in range(rolls)]
        out.update({"dice": f"{len(flat)}d{s}", "rolls": flat, "total": sum(flat),
                    "answer": f"{len(flat)}d{s} → {flat} = **{sum(flat)}**"})
    elif op == "coin":
        flips = [("HEADS" if ((secrets.randbelow(2) if rng_int else pyrandom.randint(0, 1))) else "TAILS")
                 for _ in range(n)]
        out.update({"flips": flips, "heads": flips.count("HEADS"), "tails": flips.count("TAILS"),
                    "answer": f"{n} flip{'s' if n != 1 else ''}: "
                              f"{flips.count('HEADS')} heads, {flips.count('TAILS')} tails"})
    elif op in ("pick", "choose", "sample"):
        pool = options or []
        if not pool:
            return {"ok": False, "operation": op, "error": "give me a list of options to pick from"}
        k = max(1, min(n, len(pool)))
        if rng_int:
            picked = [pool[secrets.randbelow(len(pool))] for _ in range(k)]
        else:
            picked = pyrandom.sample(list(pool), k) if op == "sample" else pyrandom.choices(list(pool), k=k)
        out.update({"pool_size": len(pool), "picked": picked,
                    "answer": "Picked: " + ", ".join(str(p) for p in picked)})
    elif op == "shuffle":
        pool = list(options or [])
        if not pool:
            return {"ok": False, "operation": op, "error": "give me a list to shuffle"}
        if rng_int:
            for i in range(len(pool) - 1, 0, -1):
                j = secrets.randbelow(i + 1)
                pool[i], pool[j] = pool[j], pool[i]
        else:
            pyrandom.shuffle(pool)
        out.update({"shuffled": pool, "count": len(pool),
                    "answer": "Shuffled: " + ", ".join(str(p) for p in pool[:30])})
    elif op == "password":
        ln = max(6, min(int(length), 256))
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*-_=+?/.,;:"
        pw = "".join(secrets.choice(alphabet) for _ in range(ln))
        out.update({"password": pw, "length": ln, "entropy_bits": round(pymath.log2(len(alphabet)) * ln, 1),
                    "strength": "strong" if ln >= 16 else "medium" if ln >= 12 else "weak",
                    "answer": f"Generated password ({ln} chars, "
                              f"~{round(pymath.log2(len(alphabet)) * ln)} bits of entropy): `{pw}`"})
    elif op == "uuid":
        ids = [str(uuid.uuid4()) for _ in range(min(n, 100))]
        out.update({"uuids": ids, "version": 4,
                    "answer": "\n".join(ids[:20])})
    elif op == "otp":
        ln = max(4, min(int(length), 10))
        codes = ["".join(secrets.choice(string.digits) for _ in range(ln)) for _ in range(min(n, 20))]
        out.update({"otps": codes, "digits": ln, "answer": ", ".join(codes)})
    else:
        return {"ok": False, "operation": op,
                "error": "use number, dice, coin, pick, shuffle, password, uuid, otp or sample"}
    return out


@tool(
    name="math.round",
    capability="ai.reasoning",
    agent="data",
    device="both",
    description="Round and format numbers: decimals, significant figures, thousands/crore/lakh words, human-readable bytes and durations",
    schema={"value": {"type": "number", "required": True},
            "mode": {"type": "string", "description": "decimals|sigfigs|nearest|bytes|duration|words|scientific"},
            "places": {"type": "integer", "default": 2}},
    risk="LOW",
    timeout=30,
)
async def math_round(ctx: ToolContext, value: float = 0.0, mode: str = "decimals",
                     places: int = 2, request: str = "") -> Dict[str, Any]:
    n = _num(value)
    if n is None:
        m = re.search(r"-?\d+(?:\.\d+)?", request or ctx.user_text or "")
        n = float(m.group(0)) if m else None
    if n is None:
        return {"ok": False, "error": "which number should I format?"}
    p = max(0, min(int(places), 15))
    mode = (mode or "decimals").strip().lower()
    out: Dict[str, Any] = {"ok": True, "value": n, "mode": mode}

    if mode == "decimals":
        q = Decimal(1).scaleb(-p)
        out["result"] = float(Decimal(str(n)).quantize(q, rounding=ROUND_HALF_UP))
        out["answer"] = f"{n} rounded to {p} decimals = **{out['result']}**"
    elif mode == "sigfigs":
        if n == 0:
            out["result"] = 0.0
        else:
            from decimal import Context

            ctxd = Context(prec=max(1, p))
            out["result"] = float(ctxd.create_decimal_from_float(n))
        out["answer"] = f"{n} to {p} significant figures = **{out['result']}**"
    elif mode == "nearest":
        step = p or 1
        out["result"] = round(n / step) * step
        out["answer"] = f"{n} rounded to the nearest {step} = **{out['result']}**"
    elif mode == "bytes":
        binary = n
        units = ["B", "KiB", "MiB", "GiB", "TiB", "PiB"]
        i = 0
        while abs(binary) >= 1024 and i < len(units) - 1:
            binary /= 1024
            i += 1
        dec, j = n, 0
        dec_units = ["B", "KB", "MB", "GB", "TB", "PB"]
        while abs(dec) >= 1000 and j < len(dec_units) - 1:
            dec /= 1000
            j += 1
        out.update({"binary": f"{binary:,.2f} {units[i]}", "decimal": f"{dec:,.2f} {dec_units[j]}",
                    "answer": f"{int(n):,} bytes = **{binary:,.2f} {units[i]}** "
                              f"(= {dec:,.2f} {dec_units[j]} in decimal units)"})
    elif mode == "duration":
        secs = int(abs(n))
        days, rem = divmod(secs, 86400)
        hours, rem = divmod(rem, 3600)
        mins, sec = divmod(rem, 60)
        parts = [f"{days}d" if days else "", f"{hours}h" if hours or days else "",
                 f"{mins}m" if mins or hours or days else "", f"{sec}s"]
        out.update({"seconds": secs, "iso": f"P{days}DT{hours}H{mins}M{sec}S",
                    "human": " ".join(p for p in parts if p),
                    "minutes": round(secs / 60, 3), "hours": round(secs / 3600, 4),
                    "answer": f"{int(n):,} seconds = **{' '.join(p for p in parts if p)}**"})
    elif mode == "words":
        out.update({"indian": _indian_words(int(n)), "international": _intl_words(int(n)),
                    "answer": f"{int(n):,} = {_indian_words(int(n))} (Indian system) / "
                              f"{_intl_words(int(n))} (international)"})
    elif mode == "scientific":
        out.update({"scientific": f"{n:.{max(p, 3)}e}", "mantissa": float(f"{n:.{max(p, 6)}e}".split("e")[0]),
                    "exponent": int(f"{n:.6e}".split("e")[1]),
                    "answer": f"{n} in scientific notation = **{n:.{max(p, 3)}e}**"})
    else:
        return {"ok": False, "mode": mode,
                "error": "use decimals, sigfigs, nearest, bytes, duration, words or scientific"}
    return out


_ONES = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
         "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
         "eighteen", "nineteen"]
_TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]


def _under_1000(n: int) -> str:
    parts = []
    if n >= 100:
        parts.append(_ONES[n // 100] + " hundred")
        n %= 100
    if n >= 20:
        parts.append(_TENS[n // 10] + ("-" + _ONES[n % 10] if n % 10 else ""))
    elif n:
        parts.append(_ONES[n])
    return " ".join(parts)


def _intl_words(n: int) -> str:
    if n == 0:
        return "zero"
    sign = "negative " if n < 0 else ""
    n = abs(n)
    scales = [(10 ** 12, "trillion"), (10 ** 9, "billion"), (10 ** 6, "million"), (10 ** 3, "thousand")]
    words = []
    for value, name in scales:
        if n >= value:
            words.append(_under_1000(n // value) + " " + name)
            n %= value
    if n:
        words.append(_under_1000(n))
    return sign + " ".join(words)


def _indian_words(n: int) -> str:
    if n == 0:
        return "zero"
    sign = "negative " if n < 0 else ""
    n = abs(n)
    scales = [(10 ** 7, "crore"), (10 ** 5, "lakh"), (10 ** 3, "thousand")]
    words = []
    for value, name in scales:
        if n >= value:
            words.append(_under_1000(n // value) + " " + name)
            n %= value
    if n:
        words.append(_under_1000(n))
    return sign + " ".join(words)


@tool(
    name="math.series",
    capability="ai.reasoning",
    agent="reasoning",
    device="both",
    description="Arithmetic and geometric progressions: nth term, sum, mean, and next terms of a sequence",
    schema={"operation": {"type": "string", "description": "ap|gp|sum|nth|next|sequence"},
            "first": {"type": "number"}, "common": {"type": "number", "description": "difference (AP) or ratio (GP)"},
            "terms": {"type": "integer", "default": 10}, "values": {"type": "array"}},
    risk="LOW",
    timeout=30,
)
async def math_series(ctx: ToolContext, operation: str = "", first: float = 0.0,
                      common: float = 0.0, terms: int = 10, values: Any = None,
                      request: str = "") -> Dict[str, Any]:
    text = (request or ctx.user_text or "").lower()
    op = operation.strip().lower()
    if not op:
        op = "gp" if any(k in text for k in ("geometric", "gp", "ratio")) else \
             "ap" if any(k in text for k in ("arithmetic", "ap", "difference")) else \
             "next" if values is not None or "next" in text else "ap"
    n = max(1, min(int(terms), 500))
    out: Dict[str, Any] = {"ok": True, "operation": op, "terms": n}

    if op in ("next", "sequence") and values is not None:
        seq = _numbers(values)
        if len(seq) < 3:
            return {"ok": False, "operation": op, "error": "give at least three numbers to find a pattern"}
        diffs = [round(b - a, 6) for a, b in zip(seq, seq[1:])]
        ratios = [round(b / a, 6) if a else None for a, b in zip(seq, seq[1:])]
        constant_diff = len(set(diffs)) == 1
        constant_ratio = all(r is not None for r in ratios) and len(set(ratios)) == 1
        if constant_diff:
            d = diffs[0]
            nxt = [seq[-1] + d * (i + 1) for i in range(min(n, 10))]
            out.update({"pattern": "arithmetic", "common_difference": d, "next": [_round(v) for v in nxt],
                        "general_term": f"aₙ = {seq[0]:g} + (n-1)·{d:g}",
                        "answer": f"Arithmetic sequence with d={d:g}. Next: {', '.join(_fmt(v) for v in nxt[:6])}"})
        elif constant_ratio:
            r = ratios[0]
            nxt = [seq[-1] * r ** (i + 1) for i in range(min(n, 10))]
            out.update({"pattern": "geometric", "common_ratio": r, "next": [_round(v) for v in nxt],
                        "general_term": f"aₙ = {seq[0]:g} · {r:g}^(n-1)",
                        "answer": f"Geometric sequence with r={r:g}. Next: {', '.join(_fmt(v) for v in nxt[:6])}"})
        elif _is_fibonacci_like(seq):
            nxt = list(seq)
            for _ in range(min(n, 10)):
                nxt.append(nxt[-1] + nxt[-2])
            out.update({"pattern": "fibonacci-like (each term = sum of the two before)",
                        "next": [_round(v) for v in nxt[len(seq):]],
                        "answer": f"Each term is the sum of the two before. Next: "
                                  f"{', '.join(_fmt(v) for v in nxt[len(seq):len(seq) + 6])}"})
        else:
            second = [round(b - a, 6) for a, b in zip(diffs, diffs[1:])]
            out.update({"pattern": "no simple AP/GP pattern", "differences": diffs,
                        "second_differences": second,
                        "answer": f"No constant difference or ratio. First differences {diffs}; "
                                  f"second differences {second}."})
        return out

    if op == "ap":
        a, d = float(first), float(common)
        seq = [a + d * i for i in range(n)]
        total = n / 2 * (2 * a + (n - 1) * d)
        out.update({"first_term": a, "common_difference": d, "sequence": [_round(v) for v in seq[:30]],
                    "nth_term": _round(seq[-1]), "sum": _round(total), "mean": _round(total / n),
                    "formula": f"Sₙ = n/2 · (2a + (n-1)d)",
                    "answer": f"AP a={a:g}, d={d:g}: term {n} = {_fmt(seq[-1])}, "
                              f"sum of {n} terms = **{_fmt(total)}**"})
        return out

    if op == "gp":
        a, r = float(first), float(common)
        if r == 0:
            return {"ok": False, "operation": op, "error": "a geometric ratio of 0 is degenerate"}
        seq = [a * r ** i for i in range(n)]
        total = a * (1 - r ** n) / (1 - r) if r != 1 else a * n
        out.update({"first_term": a, "common_ratio": r, "sequence": [_round(v) for v in seq[:30]],
                    "nth_term": _round(seq[-1]), "sum": _round(total),
                    "infinite_sum": _round(a / (1 - r)) if abs(r) < 1 else None,
                    "answer": f"GP a={a:g}, r={r:g}: term {n} = {_fmt(seq[-1])}, sum = {_fmt(total)}"
                              + (f", converges to {_fmt(a / (1 - r))} infinitely" if abs(r) < 1 else "")})
        return out

    if op in ("sum", "nth"):
        vals = _numbers(values)
        if not vals:
            return {"ok": False, "operation": op, "error": "sum/nth needs a list of values"}
        total = sum(vals)
        out.update({"count": len(vals), "sum": _round(total),
                    "sum_of_squares": _round(sum(v * v for v in vals)),
                    "product": _round(_product(vals)),
                    "answer": f"Sum of {len(vals)} values = **{_fmt(total)}**"})
        return out

    return {"ok": False, "operation": op, "error": "use ap, gp, sum, nth, next or sequence"}


def _is_fibonacci_like(seq: List[float]) -> bool:
    return len(seq) >= 3 and all(abs(seq[i + 2] - (seq[i + 1] + seq[i])) < 1e-6
                                 for i in range(len(seq) - 2))


def _product(values: List[float]) -> float:
    result = 1.0
    for v in values:
        result *= v
    return result
