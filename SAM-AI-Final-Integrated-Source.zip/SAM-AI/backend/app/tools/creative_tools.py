"""
backend.app.tools.creative_tools
================================

The Creative Brain: image generation, image editing, design briefs, social
media content and document rendering.

Image generation is provider-agnostic — it uses whichever image backend is
configured (OpenAI images, Stability, Replicate, ComfyUI, or a local
Stable Diffusion WebUI). With nothing configured, SAM still produces useful
output: a full production-ready **prompt pack**, an SVG/PNG placeholder poster,
and a design brief, so the Creative workspace is never a dead end.

Document rendering is delegated to :mod:`backend.app.coding.documents`.
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, registry, tool

log = get_logger("tools.creative")

OUT_DIR = settings.sam_data_dir / "creative"
ASPECTS = {"square": (1024, 1024), "portrait": (832, 1216), "landscape": (1216, 832),
           "wide": (1344, 768), "story": (1080, 1920), "thumbnail": (1280, 720)}


def _ensure_out() -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUT_DIR


# ===========================================================================
# PROMPT ENGINEERING
# ===========================================================================
@tool(
    name="creative.prompt",
    capability="creative.image.generate",
    agent="creative",
    device="cloud",
    description="Turn a rough idea into a production-grade image prompt pack",
    risk="LOW",
    timeout=90,
)
async def creative_prompt(ctx: ToolContext, request: str = "", style: str = "",
                          aspect: str = "square", count: int = 3) -> Dict[str, Any]:
    idea = request or ctx.user_text or ""
    if not idea:
        return {"ok": False, "error": "no creative brief given"}

    from backend.app.models.router import router

    prompt = f"""You are SAM's Creative Brain — a professional art director and prompt engineer.

CLIENT BRIEF:
{idea}

STYLE PREFERENCE: {style or 'not specified — choose what fits the brief'}
ASPECT RATIO: {aspect}

Produce ONLY valid JSON:
{{
  "title": "short project name",
  "concept": "2-3 sentence art direction explaining the visual idea",
  "palette": ["#hex", "#hex", "#hex", "#hex"],
  "typography": "font pairing suggestion",
  "prompts": [
    {{"prompt": "full positive prompt, 40-80 words, no filler",
      "negative": "what to avoid", "style": "photorealistic|illustration|3d|flat|...",
      "aspect": "{aspect}", "seed_hint": "lighting + composition notes"}}
  ],
  "variations": ["3 alternative directions in one line each"],
  "usage": ["where this asset fits: thumbnail, poster, social, logo, hero image"]
}}
Generate exactly {max(1, min(5, int(count)))} prompts."""

    data = await router.ask_json(prompt, role="primary", temperature=0.75, default=None)
    if not isinstance(data, dict):
        # offline fallback: build a usable prompt pack without a model
        data = _fallback_prompt_pack(idea, style, aspect, count)
        data["generated_by"] = "sam-offline-heuristic"
    else:
        data["generated_by"] = "model"
    data["ok"] = True
    data["brief"] = idea
    return data


def _fallback_prompt_pack(idea: str, style: str, aspect: str, count: int) -> Dict[str, Any]:
    styles = [style or "clean modern illustration", "photorealistic studio shot",
              "flat vector design", "cinematic 3d render", "minimal line art"]
    prompts = []
    for i in range(max(1, min(5, count))):
        s = styles[i % len(styles)]
        prompts.append({
            "prompt": (f"{idea}, {s}, professional composition, balanced lighting, "
                       f"high detail, sharp focus, {ASPECTS.get(aspect, (1024, 1024))[0]}x"
                       f"{ASPECTS.get(aspect, (1024, 1024))[1]}"),
            "negative": "blurry, low quality, distorted, watermark, text artifacts, extra limbs",
            "style": s, "aspect": aspect,
            "seed_hint": "rule of thirds, soft key light from the left, shallow depth of field",
        })
    return {
        "title": idea[:48].title(),
        "concept": (f"A {styles[0]} treatment of “{idea}”. Composition follows the rule of thirds "
                    f"with a single clear focal point and a restrained palette."),
        "palette": ["#0F172A", "#38BDF8", "#F8FAFC", "#F59E0B"],
        "typography": "Inter Tight (headings) + Inter (body)",
        "prompts": prompts,
        "variations": ["swap to a dark moody palette", "try an isometric 3D scene",
                       "reduce to a two-colour flat poster"],
        "usage": ["social post", "thumbnail", "poster"],
    }


# ===========================================================================
# IMAGE GENERATION
# ===========================================================================
async def _generate_openai(prompt: str, size: str, n: int) -> Optional[Dict[str, Any]]:
    if not settings.openai_api_key:
        return None
    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            r = await client.post(
                f"{settings.openai_base_url.rstrip('/')}/images/generations",
                headers={"Authorization": f"Bearer {settings.openai_api_key}"},
                json={"model": "gpt-image-1", "prompt": prompt, "size": size, "n": n},
            )
            if r.status_code >= 400:
                log.debug("openai image error %s: %s", r.status_code, r.text[:200])
                return None
            data = r.json()
            items = data.get("data") or []
            out = []
            for item in items:
                if item.get("b64_json"):
                    out.append({"b64": item["b64_json"]})
                elif item.get("url"):
                    out.append({"url": item["url"]})
            return {"provider": "openai", "images": out} if out else None
    except Exception as exc:
        log.debug("openai image generation failed: %s", exc)
        return None


async def _generate_stability(prompt: str, width: int, height: int) -> Optional[Dict[str, Any]]:
    key = getattr(settings, "stability_api_key", "") or getattr(settings, "openai_api_key", "")
    if not getattr(settings, "stability_api_key", ""):
        return None
    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            r = await client.post(
                "https://api.stability.ai/v2beta/stable-image/generate/core",
                headers={"Authorization": f"Bearer {key}", "Accept": "image/*"},
                files={"none": ""},
                data={"prompt": prompt, "output_format": "png",
                      "aspect_ratio": _aspect_ratio(width, height)},
            )
            if r.status_code >= 400:
                return None
            return {"provider": "stability",
                    "images": [{"b64": base64.b64encode(r.content).decode()}]}
    except Exception as exc:
        log.debug("stability failed: %s", exc)
        return None


async def _generate_local_sd(prompt: str, width: int, height: int,
                             negative: str = "") -> Optional[Dict[str, Any]]:
    """Talk to a local Stable Diffusion WebUI / ComfyUI / Fooocus API."""
    for base in ("http://127.0.0.1:7860", "http://127.0.0.1:8188"):
        try:
            async with httpx.AsyncClient(timeout=240.0) as client:
                r = await client.post(
                    f"{base}/sdapi/v1/txt2img",
                    json={"prompt": prompt, "negative_prompt": negative, "width": width,
                          "height": height, "steps": 25, "cfg_scale": 7, "batch_size": 1},
                    timeout=10.0,
                )
                if r.status_code == 200:
                    data = r.json()
                    images = data.get("images") or []
                    if images:
                        return {"provider": f"local-sd ({base})",
                                "images": [{"b64": images[0]}]}
        except Exception:
            continue
    return None


def _aspect_ratio(w: int, h: int) -> str:
    from math import gcd

    g = gcd(w, h) or 1
    return f"{w // g}:{h // g}"


@tool(
    name="creative.image_generate",
    capability="creative.image.generate",
    agent="creative",
    device="cloud",
    description="Generate an image from a prompt using the configured image model",
    risk="LOW",
    timeout=300,
)
async def image_generate(ctx: ToolContext, prompt: str = "", request: str = "",
                         negative: str = "", aspect: str = "square", style: str = "",
                         count: int = 1, pack: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    idea = prompt or request or ctx.user_text or ""
    if not idea and not pack:
        return {"ok": False, "error": "no image prompt given"}

    # use a prompt pack produced by an earlier step when available
    prior_pack = pack
    if prior_pack is None:
        for value in (ctx.outputs or {}).values():
            if isinstance(value, dict):
                inner = value.get("value") if isinstance(value.get("value"), dict) else value
                if isinstance(inner, dict) and inner.get("prompts"):
                    prior_pack = inner
                    break

    if prior_pack and not prompt:
        first = (prior_pack.get("prompts") or [{}])[0]
        idea = first.get("prompt") or idea
        negative = negative or first.get("negative") or ""
        style = style or first.get("style") or ""
        aspect = first.get("aspect") or aspect

    width, height = ASPECTS.get(aspect, (1024, 1024))
    full_prompt = f"{idea}{', ' + style if style else ''}"

    t0 = time.time()
    result: Optional[Dict[str, Any]] = None
    for generator in (
        _generate_openai(full_prompt, f"{width}x{height}", max(1, min(4, int(count)))),
        _generate_stability(full_prompt, width, height),
        _generate_local_sd(full_prompt, width, height, negative),
    ):
        result = await generator
        if result:
            break

    out_dir = _ensure_out() / "images"
    out_dir.mkdir(parents=True, exist_ok=True)
    saved: List[Dict[str, Any]] = []

    if result and result.get("images"):
        for i, item in enumerate(result["images"][:4]):
            stamp = int(time.time() * 1000)
            path = out_dir / f"sam_{stamp}_{i}.png"
            try:
                if item.get("b64"):
                    path.write_bytes(base64.b64decode(item["b64"]))
                    saved.append({"path": str(path), "bytes": path.stat().st_size})
                elif item.get("url"):
                    async with httpx.AsyncClient(timeout=120.0) as client:
                        r = await client.get(item["url"])
                        if r.status_code == 200:
                            path.write_bytes(r.content)
                            saved.append({"path": str(path), "bytes": path.stat().st_size,
                                          "source_url": item["url"]})
            except Exception as exc:
                log.debug("image save failed: %s", exc)

    if saved:
        return {
            "ok": True, "provider": result.get("provider"), "prompt": full_prompt,
            "negative_prompt": negative, "aspect": aspect, "width": width, "height": height,
            "images": saved, "count": len(saved),
            "duration_ms": int((time.time() - t0) * 1000),
        }

    # ---- no image backend: deliver a placeholder poster + the prompt pack --
    poster = _render_placeholder_poster(idea, style, aspect, prior_pack or {})
    return {
        "ok": True, "provider": "none", "prompt": full_prompt, "aspect": aspect,
        "images": [poster] if poster.get("ok") else [],
        "prompt_pack": prior_pack or _fallback_prompt_pack(idea, style, aspect, 3),
        "note": ("No image model is configured, so SAM generated a vector placeholder plus a "
                 "ready-to-use prompt pack. Set OPENAI_API_KEY or STABILITY_API_KEY in .env, "
                 "or run a local Stable Diffusion WebUI on port 7860, to get real renders."),
        "duration_ms": int((time.time() - t0) * 1000),
    }


def _render_placeholder_poster(idea: str, style: str, aspect: str,
                               pack: Dict[str, Any]) -> Dict[str, Any]:
    """Produce a real, usable SVG (and PNG when Pillow is present)."""
    w, h = ASPECTS.get(aspect, (1024, 1024))
    palette = pack.get("palette") or ["#0F172A", "#38BDF8", "#F8FAFC", "#F59E0B"]
    title = (pack.get("title") or idea)[:60]
    wrapped = _wrap(title, 26)
    out_dir = _ensure_out() / "images"
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = int(time.time() * 1000)

    lines_svg = "".join(
        f'<tspan x="{w // 2}" dy="{58 if i else 0}">{_esc(line)}</tspan>'
        for i, line in enumerate(wrapped)
    )
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="{palette[0]}"/>
      <stop offset="100%" stop-color="{palette[1]}"/>
    </linearGradient>
    <filter id="soft"><feGaussianBlur stdDeviation="60"/></filter>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#bg)"/>
  <circle cx="{int(w * 0.78)}" cy="{int(h * 0.22)}" r="{int(min(w, h) * 0.30)}"
          fill="{palette[3]}" opacity="0.35" filter="url(#soft)"/>
  <circle cx="{int(w * 0.18)}" cy="{int(h * 0.82)}" r="{int(min(w, h) * 0.26)}"
          fill="{palette[2]}" opacity="0.18" filter="url(#soft)"/>
  <text x="{w // 2}" y="{int(h * 0.44)}" text-anchor="middle" font-family="Segoe UI, Helvetica, Arial, sans-serif"
        font-size="{max(34, min(w, h) // 14)}" font-weight="700" fill="{palette[2]}">{lines_svg}</text>
  <text x="{w // 2}" y="{int(h * 0.72)}" text-anchor="middle" font-family="Segoe UI, Helvetica, Arial, sans-serif"
        font-size="{max(16, min(w, h) // 42)}" fill="{palette[2]}" opacity="0.8">{_esc(style or 'SAM Creative placeholder')}</text>
  <text x="{w // 2}" y="{int(h * 0.93)}" text-anchor="middle" font-family="Segoe UI, Helvetica, Arial, sans-serif"
        font-size="{max(12, min(w, h) // 60)}" fill="{palette[2]}" opacity="0.55">SAM · concept preview · not the final render</text>
</svg>"""
    svg_path = out_dir / f"sam_concept_{stamp}.svg"
    svg_path.write_text(svg, encoding="utf-8")
    entry: Dict[str, Any] = {"ok": True, "path": str(svg_path), "bytes": svg_path.stat().st_size,
                             "format": "svg", "kind": "concept-placeholder",
                             "width": w, "height": h}

    try:
        from PIL import Image, ImageDraw

        img = Image.new("RGB", (w, h), palette[0])
        draw = ImageDraw.Draw(img, "RGBA")
        # soft diagonal gradient
        for i in range(h):
            t = i / max(1, h)
            r = _mix(palette[0], palette[1], t)
            draw.line([(0, i), (w, i)], fill=r)
        draw.ellipse([int(w * 0.55), int(h * -0.05), int(w * 1.25), int(h * 0.65)],
                     fill=_hex_rgba(palette[3], 90))
        try:
            from PIL import ImageFont

            font_big = ImageFont.truetype("DejaVuSans-Bold.ttf", max(36, min(w, h) // 12))
            font_small = ImageFont.truetype("DejaVuSans.ttf", max(16, min(w, h) // 42))
        except Exception:
            font_big = font_small = None
        y = int(h * 0.40)
        for line in wrapped:
            draw.text((w // 2, y), line, fill=palette[2], font=font_big, anchor="mm")
            y += int(min(w, h) * 0.08)
        draw.text((w // 2, int(h * 0.75)), style or "SAM Creative placeholder",
                  fill=palette[2], font=font_small, anchor="mm")
        png_path = out_dir / f"sam_concept_{stamp}.png"
        img.save(png_path, "PNG")
        entry["png_path"] = str(png_path)
        entry["png_bytes"] = png_path.stat().st_size
    except Exception as exc:
        log.debug("placeholder PNG render failed: %s", exc)
    return entry


def _hex_rgba(hexcolor: str, alpha: int) -> tuple:
    hexcolor = hexcolor.lstrip("#")
    try:
        r, g, b = (int(hexcolor[i : i + 2], 16) for i in (0, 2, 4))
    except Exception:
        r = g = b = 128
    return (r, g, b, alpha)


def _mix(a: str, b: str, t: float) -> tuple:
    ra, ga, ba = _hex_rgba(a, 255)[:3]
    rb, gb, bb = _hex_rgba(b, 255)[:3]
    return (int(ra + (rb - ra) * t), int(ga + (gb - ga) * t), int(ba + (bb - ba) * t))


def _wrap(text: str, width: int) -> List[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 <= width:
            cur = (cur + " " + w).strip()
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [text[:width]]


def _esc(text: str) -> str:
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


# ===========================================================================
# IMAGE EDITING
# ===========================================================================
@tool(
    name="creative.image_edit",
    capability="creative.image.edit",
    agent="creative",
    device="pc",
    description="Edit an image: resize, crop, rotate, convert, watermark, thumbnail, compress",
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def image_edit(ctx: ToolContext, path: str = "", action: str = "resize",
                     width: Optional[int] = None, height: Optional[int] = None,
                     degrees: int = 0, quality: int = 88, text: str = "",
                     output: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.files.file_ops import assert_allowed, FileSecurityError

    src = path or _first_path(request or ctx.user_text)
    if not src:
        return {"ok": False, "error": "no image path given"}
    try:
        p = assert_allowed(src)
        if output:
            assert_allowed(output, for_write=True)
    except FileSecurityError as exc:
        return {"ok": False, "error": str(exc), "blocked": True}
    if not p.exists():
        return {"ok": False, "error": f"image does not exist: {p}"}

    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return {"ok": False, "error": "Pillow is not installed (pip install Pillow)"}

    if not request:
        pass
    action = (action or "resize").lower()
    if action == "auto":
        action = _edit_action_from_text(request or ctx.user_text)

    loop = asyncio.get_running_loop()

    def work() -> Dict[str, Any]:
        with Image.open(p) as im:
            im.load()
            original = {"width": im.width, "height": im.height, "mode": im.mode,
                        "format": im.format}
            out = im
            applied: List[str] = []

            if action == "resize" and (width or height):
                w = width or int(im.width * (height or im.height) / im.height)
                h = height or int(im.height * (width or im.width) / im.width)
                out = im.resize((max(1, w), max(1, h)), Image.LANCZOS)
                applied.append(f"resized to {w}x{h}")
            elif action == "thumbnail":
                out = im.copy()
                out.thumbnail((width or 512, height or 512), Image.LANCZOS)
                applied.append(f"thumbnail {out.width}x{out.height}")
            elif action == "crop":
                box = (0, 0, width or im.width, height or im.height)
                out = im.crop(box)
                applied.append(f"cropped to {box}")
            elif action in ("rotate", "flip"):
                if action == "rotate":
                    out = im.rotate(degrees or 90, expand=True)
                    applied.append(f"rotated {degrees or 90}°")
                else:
                    from PIL import ImageOps

                    out = ImageOps.mirror(im)
                    applied.append("flipped horizontally")
            elif action == "convert":
                applied.append("format converted")
            elif action == "grayscale":
                out = im.convert("L").convert("RGB")
                applied.append("converted to grayscale")
            elif action == "compress":
                applied.append(f"recompressed at quality {quality}")
            elif action == "watermark":
                out = im.convert("RGBA")
                layer = Image.new("RGBA", out.size, (0, 0, 0, 0))
                draw = ImageDraw.Draw(layer)
                try:
                    font = ImageFont.truetype("DejaVuSans-Bold.ttf", max(18, out.width // 28))
                except Exception:
                    font = ImageFont.load_default()
                label = text or "SAM"
                draw.text((out.width - 24, out.height - 24), label, fill=(255, 255, 255, 170),
                          font=font, anchor="rb")
                out = Image.alpha_composite(out, layer).convert("RGB")
                applied.append(f"watermarked '{label}'")
            else:
                applied.append("no change (unknown action)")

            target = Path(output) if output else p.with_name(f"{p.stem}_sam{p.suffix}")
            fmt = (target.suffix.lstrip(".").upper() or "PNG")
            fmt = {"JPG": "JPEG", "JPEG": "JPEG", "PNG": "PNG", "WEBP": "WEBP"}.get(fmt, "PNG")
            if fmt in ("JPEG", "WEBP") and out.mode in ("RGBA", "P", "LA"):
                out = out.convert("RGB")
            save_kwargs: Dict[str, Any] = {}
            if fmt in ("JPEG", "WEBP"):
                save_kwargs["quality"] = max(10, min(100, int(quality)))
            if fmt == "PNG":
                save_kwargs["optimize"] = True
            target.parent.mkdir(parents=True, exist_ok=True)
            out.save(str(target), fmt, **save_kwargs)
            return {"ok": True, "input": str(p), "output": str(target), "format": fmt,
                    "original": original, "result": {"width": out.width, "height": out.height},
                    "bytes": target.stat().st_size, "applied": applied, "action": action}

    try:
        return await loop.run_in_executor(None, work)
    except Exception as exc:
        return {"ok": False, "error": f"image edit failed: {exc}"}


def _edit_action_from_text(text: str) -> str:
    low = (text or "").lower()
    for key, action in (("thumbnail", "thumbnail"), ("resize", "resize"), ("crop", "crop"),
                        ("rotate", "rotate"), ("flip", "flip"), ("grey", "grayscale"),
                        ("gray", "grayscale"), ("watermark", "watermark"),
                        ("compress", "compress"), ("convert", "convert")):
        if key in low:
            return action
    return "resize"


def _first_path(text: str) -> str:
    m = re.search(r"([A-Za-z]:[\\/][^\s'\"]+|~/[^\s'\"]+|/[^\s'\"]+|\./[^\s'\"]+)", text or "")
    return m.group(1) if m else ""


# ===========================================================================
# SOCIAL MEDIA WORKSPACE
# ===========================================================================
@tool(
    name="creative.social_pack",
    capability="creative.document.generate",
    agent="creative",
    device="cloud",
    description="Generate a social media content pack: caption, hashtags, alt text, schedule",
    risk="LOW",
    timeout=120,
)
async def social_pack(ctx: ToolContext, topic: str = "", platform: str = "instagram",
                      tone: str = "professional", request: str = "") -> Dict[str, Any]:
    idea = topic or request or ctx.user_text
    if not idea:
        return {"ok": False, "error": "no topic given"}
    from backend.app.models.router import router

    limits = {"instagram": 2200, "twitter": 280, "x": 280, "linkedin": 3000,
              "facebook": 5000, "youtube": 5000, "threads": 500}
    limit = limits.get(platform.lower(), 2200)

    prompt = f"""You are SAM's Creative Brain writing social content.

TOPIC / BRIEF: {idea}
PLATFORM: {platform} (max {limit} characters)
TONE: {tone}

Return ONLY valid JSON:
{{
  "hook": "first line that stops the scroll (<=120 chars)",
  "caption": "the full caption, within the platform limit, with line breaks as \\n",
  "hashtags": ["15-25 relevant hashtags without the # symbol"],
  "alt_text": "accessibility description of the intended image",
  "cta": "one call to action",
  "variants": ["2 alternative hooks"],
  "best_times": ["3 suggested posting times in IST with a one-line reason each"],
  "visual_brief": "what the accompanying image or reel should show",
  "thread": ["if the platform supports threads, 3-6 posts; otherwise an empty list"]
}}"""
    data = await router.ask_json(prompt, role="primary", temperature=0.8, default=None)
    if not isinstance(data, dict):
        data = {
            "hook": idea[:110],
            "caption": (f"{idea}\n\nHere's what changed, why it matters, and what to do next. "
                        f"Save this for later."),
            "hashtags": [w for w in re.findall(r"[A-Za-z]{4,}", idea)[:12]],
            "alt_text": idea[:200], "cta": "Follow for more.", "variants": [idea[:100]],
            "best_times": ["09:30 IST — commute scroll", "13:00 IST — lunch break",
                           "20:30 IST — evening unwind"],
            "visual_brief": f"A clean single-subject visual illustrating {idea[:80]}",
            "thread": [],
            "generated_by": "sam-offline-heuristic",
        }
    data.update({"ok": True, "platform": platform, "tone": tone, "topic": idea,
                 "char_count": len(data.get("caption", "")), "platform_limit": limit,
                 "note": ("Nothing was posted. Publishing needs the platform's own API and an "
                          "explicit confirmation (social.post is not granted by default).")})
    return data


@tool(
    name="creative.script",
    capability="creative.document.generate",
    agent="creative",
    device="cloud",
    description="Write a video/reel/presentation script with shot list and timings",
    risk="LOW",
    timeout=150,
)
async def video_script(ctx: ToolContext, topic: str = "", duration_seconds: int = 60,
                       style: str = "", request: str = "") -> Dict[str, Any]:
    idea = topic or request or ctx.user_text
    if not idea:
        return {"ok": False, "error": "no topic given"}
    from backend.app.models.router import router

    prompt = f"""Write a {duration_seconds}-second video script.

TOPIC: {idea}
STYLE: {style or 'clear, energetic, informative'}

Return ONLY valid JSON:
{{
  "title": "...",
  "logline": "one sentence",
  "shots": [
    {{"n": 1, "time": "0:00-0:04", "visual": "what is on screen",
      "voiceover": "exact words", "on_screen_text": "...", "b_roll": "..."}}
  ],
  "music": "tempo and mood suggestion",
  "captions": ["3 caption options for social posting"],
  "thumbnail": "thumbnail concept"
}}"""
    data = await router.ask_json(prompt, role="primary", temperature=0.7, default=None)
    if not isinstance(data, dict):
        shots = []
        step = max(4, duration_seconds // 8)
        beats = [f"Hook: {idea[:60]}", "The problem", "Why it matters", "The solution",
                 "How to do it", "Proof / example", "Recap", "Call to action"]
        for i, beat in enumerate(beats):
            shots.append({"n": i + 1, "time": f"0:{i * step:02d}-0:{(i + 1) * step:02d}",
                          "visual": beat, "voiceover": beat, "on_screen_text": beat[:40],
                          "b_roll": ""})
        data = {"title": idea[:60].title(), "logline": idea[:140], "shots": shots,
                "music": "upbeat 100 BPM", "captions": [idea[:100]],
                "thumbnail": f"Bold text overlay: {idea[:40]}",
                "generated_by": "sam-offline-heuristic"}
    data.update({"ok": True, "topic": idea, "duration_seconds": int(duration_seconds),
                 "word_count": sum(len(str(s.get("voiceover", "")).split())
                                   for s in data.get("shots", []))})
    return data


# ===========================================================================
# DOCUMENTS
# ===========================================================================
@tool(
    name="documents.outline",
    capability="creative.document.generate",
    agent="writing",
    device="cloud",
    description="Create a structured outline for a document, report or deck",
    risk="LOW",
    timeout=120,
)
async def documents_outline(ctx: ToolContext, request: str = "", format: str = "docx",
                            sections: int = 6) -> Dict[str, Any]:
    brief = request or ctx.user_text
    if not brief:
        return {"ok": False, "error": "no document brief given"}
    from backend.app.models.router import router

    prompt = f"""You are SAM's Writing Brain. Create an outline.

BRIEF: {brief}
OUTPUT FORMAT: {format}
TARGET SECTIONS: {sections}

Return ONLY valid JSON:
{{"title": "...", "audience": "...", "tone": "...", "word_target": 1200,
  "sections": [{{"heading": "...", "purpose": "...", "bullets": ["...", "..."]}}]}}"""
    data = await router.ask_json(prompt, role="primary", temperature=0.5, default=None)
    if not isinstance(data, dict) or not data.get("sections"):
        data = {
            "title": brief[:70].title(), "audience": "general", "tone": "professional",
            "word_target": 300 * max(1, int(sections)),
            "sections": [
                {"heading": heading, "purpose": purpose, "bullets": [brief[:80]]}
                for heading, purpose in (
                    [
                        ("Executive summary", "state the outcome in 3 sentences"),
                        ("Background", "why this matters now"),
                        ("Analysis", "the evidence and the reasoning"),
                        ("Options", "what could be done, with trade-offs"),
                        ("Recommendation", "the single best next step"),
                        ("Next steps", "owner, date, measure of done"),
                    ][: max(1, int(sections))]
                )
            ],
            "generated_by": "sam-offline-heuristic",
        }
    data.update({"ok": True, "format": format, "brief": brief})
    return data


@tool(
    name="documents.write",
    capability="creative.document.generate",
    agent="writing",
    device="cloud",
    description="Write the full Markdown content for a document from an outline or brief",
    risk="LOW",
    timeout=300,
)
async def documents_write(ctx: ToolContext, request: str = "", outline: Optional[Dict[str, Any]] = None,
                          word_target: int = 900, tone: str = "professional") -> Dict[str, Any]:
    from backend.app.models.router import router

    brief = request or ctx.user_text
    prior = outline
    if prior is None:
        for value in (ctx.outputs or {}).values():
            if isinstance(value, dict):
                inner = value.get("value") if isinstance(value.get("value"), dict) else value
                if isinstance(inner, dict) and inner.get("sections"):
                    prior = inner
                    break

    outline_json = json.dumps(prior, indent=2)[:6000] if prior else "(no outline — create one)"
    prompt = f"""You are SAM's Writing Brain. Write the complete document.

BRIEF: {brief or (prior or {}).get('title', '')}
OUTLINE:
{outline_json}

REQUIREMENTS:
- Approximately {int(word_target)} words.
- Tone: {tone}.
- Output clean Markdown: one H1 title, H2 sections, short paragraphs, bullets where useful,
  a table if the content benefits from one.
- No preamble, no "as an AI", no meta commentary. Just the document.
"""
    res = await router.ask(prompt, role="primary", temperature=0.5, max_tokens=3000)
    content = res.text.strip()
    if not content:
        content = _fallback_document(brief, prior)
    return {"ok": True, "markdown": content, "word_count": len(content.split()),
            "model": res.model, "provider": res.provider,
            "title": (prior or {}).get("title") or content.splitlines()[0].lstrip("# ").strip()[:80]}


def _fallback_document(brief: str, outline: Optional[Dict[str, Any]]) -> str:
    title = (outline or {}).get("title") or (brief[:60].title() or "Untitled document")
    parts = [f"# {title}", "",
             f"_Prepared by SAM · {time.strftime('%d %B %Y')}_", "",
             "## Executive summary", "",
             f"This document addresses: {brief or title}.", "",
             "## Background", "", "Context and why this matters.", ""]
    for section in (outline or {}).get("sections", []):
        heading = section.get("heading") or "Section"
        parts += [f"## {heading}", "", section.get("purpose", ""), ""]
        for b in section.get("bullets", []) or []:
            parts.append(f"- {b}")
        parts.append("")
    parts += ["## Next steps", "", "- Owner and due date for each action",
              "- Measure of done", "", "---", "",
              "*Generated offline: add a model key to .env for fully written prose.*"]
    return "\n".join(parts)


@tool(
    name="documents.render",
    capability="creative.document.generate",
    agent="files",
    device="pc",
    description="Render Markdown into DOCX, PDF, PPTX, XLSX, HTML, CSV or TXT",
    schema={"format": {"type": "string", "required": True}, "markdown": {"type": "string"}},
    risk="MEDIUM",
    confirm=True,
    timeout=180,
)
async def documents_render(ctx: ToolContext, format: str = "docx", markdown: str = "",
                           title: str = "", output: str = "") -> Dict[str, Any]:
    from backend.app.coding.documents import render
    from backend.app.files.file_ops import FileSecurityError, assert_allowed

    content = markdown
    if not content:
        for value in (ctx.outputs or {}).values():
            if isinstance(value, dict):
                inner = value.get("value") if isinstance(value.get("value"), dict) else value
                if isinstance(inner, dict) and inner.get("markdown"):
                    content = inner["markdown"]
                    title = title or inner.get("title", "")
                    break
    if not content:
        return {"ok": False, "error": "no content to render"}

    if output:
        try:
            assert_allowed(output, for_write=True)
        except FileSecurityError as exc:
            return {"ok": False, "error": str(exc), "blocked": True}

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, render, format, content, title or None, output or None)


@tool(
    name="documents.verify",
    capability="files.read",
    agent="verification",
    device="pc",
    description="Verify a generated document opens correctly and report its structure",
    risk="LOW",
    timeout=90,
)
async def documents_verify(ctx: ToolContext, path: str = "") -> Dict[str, Any]:
    from backend.app.files.file_ops import FileSecurityError, assert_allowed

    target = path
    if not target:
        for value in (ctx.outputs or {}).values():
            if isinstance(value, dict):
                inner = value.get("value") if isinstance(value.get("value"), dict) else value
                if isinstance(inner, dict) and inner.get("path"):
                    target = inner["path"]
                    break
    if not target:
        return {"ok": False, "verdict": "failed", "error": "no document path to verify"}
    try:
        p = assert_allowed(target)
    except FileSecurityError as exc:
        return {"ok": False, "verdict": "failed", "error": str(exc)}
    if not p.exists():
        return {"ok": False, "verdict": "failed", "error": f"file does not exist: {p}"}
    if p.stat().st_size == 0:
        return {"ok": False, "verdict": "failed", "error": "file is empty"}

    ext = p.suffix.lower()
    checks: List[str] = []
    problems: List[str] = []
    try:
        if ext == ".docx":
            import docx

            d = docx.Document(str(p))
            checks.append(f"{len(d.paragraphs)} paragraphs, {len(d.tables)} tables")
            if not any(par.text.strip() for par in d.paragraphs):
                problems.append("document has no text")
        elif ext == ".pptx":
            from pptx import Presentation

            prs = Presentation(str(p))
            n = len(prs.slides._sldIdLst)
            checks.append(f"{n} slides")
            if n == 0:
                problems.append("presentation has no slides")
        elif ext == ".xlsx":
            import openpyxl

            wb = openpyxl.load_workbook(str(p), read_only=True)
            checks.append(f"{len(wb.sheetnames)} sheets: {', '.join(wb.sheetnames[:5])}")
            wb.close()
        elif ext == ".pdf":
            from pypdf import PdfReader

            reader = PdfReader(str(p))
            checks.append(f"{len(reader.pages)} pages")
            if not reader.pages:
                problems.append("PDF has no pages")
        elif ext == ".csv":
            import csv

            with open(p, newline="", encoding="utf-8") as fh:
                rows = list(csv.reader(fh))
            checks.append(f"{len(rows)} rows, {len(rows[0]) if rows else 0} columns")
        else:
            text = p.read_text(encoding="utf-8", errors="replace")
            checks.append(f"{len(text)} characters, {len(text.splitlines())} lines")
            if not text.strip():
                problems.append("file is blank")
    except Exception as exc:
        problems.append(f"could not parse the file: {exc}")

    verdict = "success" if not problems else "failed"
    return {"ok": not problems, "verdict": verdict, "path": str(p), "format": ext.lstrip("."),
            "bytes": p.stat().st_size, "checks": checks, "problems": problems}


# ===========================================================================
# CREATIVE WORKSPACE — save, list, open
# ===========================================================================
def _stringify(value: Any, depth: int = 0) -> str:
    """Turn any tool result into readable Markdown without losing structure."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (int, float)):
        return str(value)
    if depth > 4:
        return str(value)[:200]
    if isinstance(value, list):
        parts: List[str] = []
        for item in value:
            if isinstance(item, dict):
                parts.append(_stringify(item, depth + 1))
            else:
                parts.append(f"- {_stringify(item, depth + 1)}")
        return "\n".join(parts)
    if isinstance(value, dict):
        lines: List[str] = []
        for key, item in value.items():
            if key in ("raw", "attempts", "embedding", "base64", "b64_json", "data"):
                continue
            rendered = _stringify(item, depth + 1)
            if not rendered:
                continue
            if isinstance(item, (dict, list)):
                lines.append(f"## {str(key).replace('_', ' ').title()}\n\n{rendered}")
            else:
                lines.append(f"**{str(key).replace('_', ' ').title()}:** {rendered}")
        return "\n\n".join(lines)
    return str(value)


@tool(
    name="creative.save",
    capability="creative.document.generate",
    agent="creative",
    device="pc",
    description="Save creative work (brief, script, social pack, prompt pack) into the Creative workspace",
    risk="LOW",
    timeout=120,
)
async def creative_save(ctx: ToolContext, content: str = "", title: str = "",
                        kind: str = "brief", format: str = "md", folder: str = "",
                        from_step: str = "", request: str = "") -> Dict[str, Any]:
    from backend.app.coding.documents import render

    text = content
    if not text and from_step:
        prior = ctx.prior(from_step)
        if prior is not None:
            inner = prior.get("value") if isinstance(prior, dict) and "value" in prior else prior
            text = _stringify(inner)
    if not text:
        # fall back to the most recent creative-looking output in this task
        for value in (ctx.outputs or {}).values():
            inner = value.get("value") if isinstance(value, dict) and "value" in value else value
            if isinstance(inner, dict) and any(
                k in inner for k in ("prompts", "posts", "caption", "script", "markdown", "brief")
            ):
                text = _stringify(inner)
                break
    if not text:
        text = request or ctx.user_text
    if not text.strip():
        return {"ok": False, "error": "nothing to save — give content, or from_step"}

    if kind not in ("brief", "script", "social", "prompt", "storyboard", "copy", "notes"):
        kind = "notes"
    if format not in ("md", "txt", "docx", "pdf", "pptx", "html"):
        format = "md"

    slug = re.sub(r"[^\w]+", "-", (title or text.strip().splitlines()[0])[:48]).strip("-").lower() \
        or f"{kind}-{int(time.time())}"
    subdir = OUT_DIR / (folder or kind)
    subdir.mkdir(parents=True, exist_ok=True)
    output = subdir / f"{slug}_{int(time.time())}.{format}"

    if format in ("md", "txt"):
        body = text if format == "txt" else _markdown_wrap(title or slug, kind, text)
        try:
            output.write_text(body, encoding="utf-8")
        except OSError as exc:
            return {"ok": False, "error": f"could not write {output}: {exc}"}
        result: Dict[str, Any] = {"path": str(output), "bytes": output.stat().st_size}
    else:
        body = _markdown_wrap(title or slug, kind, text)
        result = await render(format, body, title=title or slug, output=str(output))
        if not result.get("ok"):
            return {"ok": False, "error": result.get("error", "rendering failed"),
                    "hint": "docx/pdf/pptx/html need python-docx, reportlab, python-pptx"}

    path = Path(result.get("path") or output)
    verified = path.exists() and path.stat().st_size > 0
    return {
        "ok": verified, "path": str(path), "name": path.name, "kind": kind, "format": format,
        "bytes": path.stat().st_size if path.exists() else 0, "words": len(text.split()),
        "workspace": str(OUT_DIR), "verified": verified,
        "answer": f"Saved to the Creative workspace: {path.name}",
    }


def _markdown_wrap(title: str, kind: str, text: str) -> str:
    header = f"# {title}\n\n_Creative workspace · {kind} · {time.strftime('%Y-%m-%d %H:%M')}_\n\n"
    if text.lstrip().startswith("#"):
        return text
    return header + text.strip() + "\n"


@tool(
    name="creative.list",
    capability="files.read",
    agent="creative",
    device="pc",
    description="List everything in the Creative workspace (images, charts, documents, briefs)",
    risk="LOW",
    timeout=60,
)
async def creative_list(ctx: ToolContext, kind: str = "", limit: int = 60,
                        search: str = "") -> Dict[str, Any]:
    if not OUT_DIR.exists():
        return {"ok": True, "count": 0, "items": [], "workspace": str(OUT_DIR),
                "answer": "The Creative workspace is empty — nothing has been generated yet."}

    items: List[Dict[str, Any]] = []
    for p in sorted(OUT_DIR.rglob("*"), key=lambda x: x.stat().st_mtime if x.exists() else 0,
                    reverse=True):
        if not p.is_file():
            continue
        rel = p.relative_to(OUT_DIR).as_posix()
        category = rel.split("/")[0] if "/" in rel else "root"
        if kind and kind.lower() not in (category.lower(), p.suffix.lower().lstrip(".")):
            continue
        if search and search.lower() not in p.name.lower():
            continue
        stat = p.stat()
        items.append({
            "name": p.name, "path": str(p), "relative": rel, "category": category,
            "ext": p.suffix.lower().lstrip("."), "bytes": stat.st_size,
            "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(stat.st_mtime)),
            "is_image": p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".svg", ".gif"),
        })
        if len(items) >= int(limit):
            break

    by_category: Dict[str, int] = {}
    for it in items:
        by_category[it["category"]] = by_category.get(it["category"], 0) + 1
    total_bytes = sum(i["bytes"] for i in items)
    return {
        "ok": True, "count": len(items), "items": items, "workspace": str(OUT_DIR),
        "by_category": by_category, "total_bytes": total_bytes,
        "answer": (f"{len(items)} item(s) in the Creative workspace "
                   f"({', '.join(f'{k}: {v}' for k, v in sorted(by_category.items()))})."
                   if items else "The Creative workspace is empty."),
    }
