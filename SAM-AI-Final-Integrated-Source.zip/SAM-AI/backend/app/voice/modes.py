"""
backend.app.voice.modes
=======================

Voice modes, personality and multilingual handling.

A **voice mode** is a saved bundle of TTS/STT/personality/proactivity settings,
so "switch to CODING mode" changes how SAM talks *and* how chatty it is, in one
step. The eight modes come straight from the specification.

Personality sliders are applied as system-prompt modifiers — they change tone
and length, never facts.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import PersonalityConfig, ProactiveLevel, VoiceMode

log = get_logger("voice.modes")


@dataclass
class ModeProfile:
    key: VoiceMode
    title: str
    description: str
    gender: str = "female"
    voice_id: str = ""
    speed: float = 1.0
    verbosity: float = 0.4
    friendliness: float = 0.6
    professionalism: float = 0.7
    humor: float = 0.2
    proactivity: float = 0.5
    interruptions: bool = True
    speak_results: bool = True
    response_style: str = "adaptive"
    system_modifier: str = ""
    proactive_level: str = "normal"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key.value, "title": self.title, "description": self.description,
            "voice": {"gender": self.gender, "voice_id": self.voice_id, "speed": self.speed},
            "personality": {"verbosity": self.verbosity, "friendliness": self.friendliness,
                            "professionalism": self.professionalism, "humor": self.humor,
                            "proactivity": self.proactivity,
                            "response_style": self.response_style},
            "interruptions": self.interruptions, "speak_results": self.speak_results,
            "proactive_level": self.proactive_level,
            "system_modifier": self.system_modifier,
        }


MODES: Dict[str, ModeProfile] = {
    VoiceMode.STANDARD.value: ModeProfile(
        VoiceMode.STANDARD, "Standard", "Balanced default: clear, friendly, reasonably brief.",
        gender="female", voice_id="en-US-AriaNeural", speed=1.0, verbosity=0.4,
        friendliness=0.6, professionalism=0.7, humor=0.25,
        system_modifier="Be clear and balanced. Two to five sentences unless detail is asked for.",
    ),
    VoiceMode.CONVERSATIONAL.value: ModeProfile(
        VoiceMode.CONVERSATIONAL, "Conversational", "Chatty companion voice, warm and relaxed.",
        gender="female", voice_id="en-IN-NeerjaNeural", speed=1.02, verbosity=0.55,
        friendliness=0.9, professionalism=0.4, humor=0.6, proactivity=0.8,
        response_style="friendly", proactive_level="proactive",
        system_modifier="Talk like a friendly companion. Short warm sentences, natural pauses, "
                        "one light follow-up question when it helps. Never fake emotion you do not have.",
    ),
    VoiceMode.PROFESSIONAL.value: ModeProfile(
        VoiceMode.PROFESSIONAL, "Professional", "Precise, formal, business-ready.",
        gender="male", voice_id="en-GB-RyanNeural", speed=0.98, verbosity=0.35,
        friendliness=0.35, professionalism=0.95, humor=0.05,
        response_style="concise",
        system_modifier="Use precise, formal business language. No slang, no filler, no jokes. "
                        "State the result first, then the detail.",
    ),
    VoiceMode.FAST.value: ModeProfile(
        VoiceMode.FAST, "Fast", "Maximum speed: short answers, quick voice.",
        gender="female", voice_id="en-US-JennyNeural", speed=1.25, verbosity=0.15,
        friendliness=0.4, professionalism=0.7, humor=0.0,
        response_style="concise",
        system_modifier="Answer in as few words as possible. One short sentence per point. "
                        "Skip preamble and pleasantries.",
    ),
    VoiceMode.QUIET.value: ModeProfile(
        VoiceMode.QUIET, "Quiet", "Minimal speech — mostly silent, text-first.",
        gender="female", voice_id="en-GB-SoniaNeural", speed=0.95, verbosity=0.2,
        friendliness=0.5, professionalism=0.8, humor=0.0, speak_results=False,
        response_style="concise", proactive_level="important_only",
        system_modifier="Be extremely brief. The user is reading, not listening.",
    ),
    VoiceMode.STUDY.value: ModeProfile(
        VoiceMode.STUDY, "Study", "Patient teacher: explains step by step, checks understanding.",
        gender="female", voice_id="en-US-AriaNeural", speed=0.92, verbosity=0.7,
        friendliness=0.75, professionalism=0.8, humor=0.15, proactivity=0.7,
        response_style="detailed",
        system_modifier="Teach. Break the topic into numbered steps, define every new term, give "
                        "one concrete example, then end with a short check question. Be patient "
                        "and never condescending.",
    ),
    VoiceMode.CODING.value: ModeProfile(
        VoiceMode.CODING, "Coding", "Terse technical partner: code first, talk second.",
        gender="male", voice_id="en-US-GuyNeural", speed=1.08, verbosity=0.25,
        friendliness=0.3, professionalism=0.9, humor=0.1, interruptions=True,
        response_style="technical", proactive_level="important_only",
        system_modifier="Lead with the code or the exact command, then at most two lines of "
                        "explanation. Name files, flags and versions precisely. Do not narrate "
                        "what you are about to do — just report what you did and the result.",
    ),
    VoiceMode.COMPANION.value: ModeProfile(
        VoiceMode.COMPANION, "Companion", "Long-running, proactive, remembers context.",
        gender="female", voice_id="en-IN-NeerjaNeural", speed=1.0, verbosity=0.6,
        friendliness=0.95, professionalism=0.5, humor=0.5, proactivity=0.9,
        response_style="friendly", proactive_level="proactive",
        system_modifier="Behave like a companion who has been with the user all day: reference "
                        "earlier context naturally, offer the next useful step, keep it warm and "
                        "human. Stay transparent that you are an AI and never claim feelings.",
    ),
}

DEFAULT_MODE = VoiceMode.STANDARD.value


class VoiceModeManager:
    """Holds the active mode + personality and renders the system-prompt modifier."""

    def __init__(self) -> None:
        self.mode: str = DEFAULT_MODE
        self.personality = PersonalityConfig()
        self.interruptions: bool = True
        self.speak_results: bool = True
        self.custom: Dict[str, ModeProfile] = {}

    # ------------------------------------------------------------------ modes
    def list_modes(self) -> List[Dict[str, Any]]:
        out = [p.to_dict() for p in MODES.values()]
        out += [p.to_dict() for p in self.custom.values()]
        for item in out:
            item["active"] = item["key"] == self.mode
        return out

    def get(self, key: str = "") -> ModeProfile:
        key = (key or self.mode).lower().replace(" ", "_").replace("-", "_")
        return self.custom.get(key) or MODES.get(key) or MODES[DEFAULT_MODE]

    def set_mode(self, key: str) -> Dict[str, Any]:
        profile = self.get(key)
        self.mode = profile.key.value
        self.interruptions = profile.interruptions
        self.speak_results = profile.speak_results
        self.personality = PersonalityConfig(
            friendliness=profile.friendliness, professionalism=profile.professionalism,
            humor=profile.humor, verbosity=profile.verbosity,
            proactivity=profile.proactivity, response_style=profile.response_style,
        )
        # push the voice settings into the TTS engine
        try:
            from backend.app.voice.tts import tts_engine

            tts_engine.configure(voice_id=profile.voice_id or None, gender=profile.gender,
                                 speed=profile.speed)
        except Exception as exc:  # pragma: no cover
            log.debug("could not apply voice settings: %s", exc)
        log.info("voice mode -> %s", self.mode)
        return self.state()

    def save_custom(self, key: str, profile: Dict[str, Any]) -> Dict[str, Any]:
        slug = re.sub(r"[^a-z0-9]+", "_", key.lower()).strip("_")[:32] or "custom"
        base = MODES[DEFAULT_MODE]
        merged = ModeProfile(
            key=VoiceMode(base.key.value) if base.key.value in VoiceMode._value2member_map_
            else base.key,
            title=str(profile.get("title") or slug.title()),
            description=str(profile.get("description") or "Custom voice mode"),
            gender=str(profile.get("gender") or base.gender),
            voice_id=str(profile.get("voice_id") or base.voice_id),
            speed=float(profile.get("speed") or base.speed),
            verbosity=float(profile.get("verbosity", base.verbosity)),
            friendliness=float(profile.get("friendliness", base.friendliness)),
            professionalism=float(profile.get("professionalism", base.professionalism)),
            humor=float(profile.get("humor", base.humor)),
            proactivity=float(profile.get("proactivity", base.proactivity)),
            interruptions=bool(profile.get("interruptions", True)),
            speak_results=bool(profile.get("speak_results", True)),
            response_style=str(profile.get("response_style") or base.response_style),
            system_modifier=str(profile.get("system_modifier") or ""),
            proactive_level=str(profile.get("proactive_level") or base.proactive_level),
        )
        self.custom[slug] = merged
        return self.state()

    # ----------------------------------------------------------- personality
    def set_personality(self, **values: Any) -> Dict[str, Any]:
        data = self.personality.model_dump()
        for key, value in values.items():
            if value is None or key not in data:
                continue
            if key == "response_style":
                data[key] = value
            else:
                data[key] = max(0.0, min(1.0, float(value)))
        self.personality = PersonalityConfig(**data)
        return self.state()

    def system_modifier(self) -> str:
        """The tone instruction appended to every SAM prompt."""
        profile = self.get()
        p = self.personality
        parts = [profile.system_modifier]
        parts.append(
            f"Tone targets: friendliness {p.friendliness:.1f}, professionalism "
            f"{p.professionalism:.1f}, humour {p.humor:.1f}."
        )
        if p.verbosity <= 0.25:
            parts.append("Keep it very short — one or two sentences.")
        elif p.verbosity >= 0.7:
            parts.append("Be thorough: explain the reasoning, not just the result.")
        style = {
            "concise": "Prefer the shortest accurate answer.",
            "detailed": "Include the reasoning and the trade-offs.",
            "technical": "Use exact technical terms, file paths, flags and versions.",
            "friendly": "Sound warm and human, but stay precise.",
        }.get(p.response_style, "")
        if style:
            parts.append(style)
        return " ".join(x for x in parts if x).strip()

    def proactive_level(self) -> str:
        profile = self.get()
        configured = settings.proactive_level
        order = ["off", "important_only", "normal", "proactive"]
        # the stricter of the global setting and the mode wins
        try:
            return order[min(order.index(configured), order.index(profile.proactive_level))]
        except ValueError:
            return configured

    def speak(self, text: str) -> bool:
        """Should this reply be spoken aloud in the current mode?"""
        if not settings.voice_enabled:
            return False
        return self.speak_results and bool(text and text.strip())

    def state(self) -> Dict[str, Any]:
        profile = self.get()
        return {
            "mode": self.mode, "profile": profile.to_dict(),
            "personality": self.personality.model_dump(),
            "interruptions": self.interruptions, "speak_results": self.speak_results,
            "proactive_level": self.proactive_level(),
            "system_modifier": self.system_modifier(),
            "modes": self.list_modes(),
        }


voice_modes = VoiceModeManager()


# ---------------------------------------------------------------------------
# Language handling (multilingual + code-mixed speech)
# ---------------------------------------------------------------------------
SCRIPTS = [
    ("kn", re.compile(r"[\u0C80-\u0CFF]")),
    ("hi", re.compile(r"[\u0900-\u097F]")),
    ("ta", re.compile(r"[\u0B80-\u0BFF]")),
    ("te", re.compile(r"[\u0C00-\u0C7F]")),
    ("ml", re.compile(r"[\u0D00-\u0D7F]")),
    ("bn", re.compile(r"[\u0980-\u09FF]")),
    ("gu", re.compile(r"[\u0A80-\u0AFF]")),
    ("mr", re.compile(r"[\u0900-\u097F]")),
    ("pa", re.compile(r"[\u0A00-\u0A7F]")),
    ("ur", re.compile(r"[\u0600-\u06FF]")),
    ("ar", re.compile(r"[\u0600-\u06FF]")),
    ("zh", re.compile(r"[\u4E00-\u9FFF]")),
    ("ja", re.compile(r"[\u3040-\u30FF]")),
    ("ko", re.compile(r"[\uAC00-\uD7AF]")),
    ("ru", re.compile(r"[\u0400-\u04FF]")),
    ("th", re.compile(r"[\u0E00-\u0E7F]")),
]

ROMAN_HINTS = {
    "hi": r"\b(kya|kaise|hai|hain|karo|batao|chahiye|nahi|nahin|haan|acha|accha|theek|"
          r"abhi|kal|aaj|yaar|bhai|please kar|kholo|band karo|shuru|dheere|jaldi|madat)\b",
    "kn": r"\b(madu|maadu|beku|illa|hege|hage|yaake|gottu|chennagide|nanna|nimma|ivattu|"
           r"nanage|helu|kelsa|sari|beda)\b",
    "ta": r"\b(enna|seyya|venum|illa|epdi|nan|ungal|inniku|nalaiku|sonna|pannu|sollu)\b",
    "te": r"\b(emi|cheyali|kavali|ledu|ela|naku|mee|nedu| repu|chepu|pani)\b",
}

LATIN_STOPWORDS = {
    "en": {"the", "and", "for", "with", "what", "when", "please", "could", "would", "this"},
    "es": {"que", "para", "con", "como", "cuando", "por", "una", "los", "las"},
    "fr": {"que", "pour", "avec", "comment", "quand", "les", "une", "est"},
    "de": {"und", "für", "mit", "wie", "wann", "die", "der", "ist"},
    "pt": {"que", "para", "com", "como", "quando", "uma", "os", "as"},
}


def detect_language(text: str) -> str:
    """Script-first, then romanised-Indic hints, then Latin stopwords."""
    if not text or not text.strip():
        return "en"
    sample = text[:600]
    for lang, pattern in SCRIPTS:
        if pattern.search(sample):
            # Devanagari is shared by Hindi and Marathi — disambiguate with words
            if lang in ("hi", "mr"):
                if re.search(r"\b(aahe|nahi|kay|tumhi|mhana|kela|karan)\b", sample, re.I):
                    return "mr"
                return "hi"
            return lang
    for lang, pattern in ROMAN_HINTS.items():
        if re.search(pattern, sample, re.I):
            return lang
    words = set(re.findall(r"[a-zA-Z']+", sample.lower()))
    if not words:
        return "en"
    best, best_hits = "en", 0
    for lang, stops in LATIN_STOPWORDS.items():
        hits = len(words & stops)
        if hits > best_hits:
            best, best_hits = lang, hits
    return best if best_hits >= 2 else "en"


def language_mix(text: str) -> Dict[str, Any]:
    """Report every language present, for the mixed-language indicator in the UI."""
    if not text:
        return {"primary": "en", "scripts": [], "mixed": False, "confidence": 0.0}
    primary = detect_language(text)
    found: Dict[str, int] = {}
    for lang, pattern in SCRIPTS:
        hits = len(pattern.findall(text))
        if hits:
            found[lang] = hits
    latin = len(re.findall(r"[A-Za-z]+", text))
    if latin:
        found["latin"] = latin
    hinglish = bool(re.search(ROMAN_HINTS["hi"], text, re.I)) and latin > 0
    mixed = len([k for k in found if k != "latin"]) > 0 and latin > 2
    return {
        "primary": primary,
        "detected": sorted(found, key=lambda k: -found[k]),
        "counts": found,
        "mixed": mixed or hinglish,
        "code_mixed": hinglish,
        "confidence": 0.9 if found else 0.4,
        "reply_language": primary,
    }


async def translate(text: str, target: str) -> str:
    from backend.app.models.router import router

    return await router.translate(text, target)


def speakable(text: str, max_chars: int = 900) -> str:
    """Trim a long answer down to something sane to read aloud."""
    clean = re.sub(r"```.*?```", " Code block in the panel. ", text or "", flags=re.S)
    clean = re.sub(r"\|.*\|", " table in the panel ", clean)
    clean = re.sub(r"[#*_>`\[\]()]|https?://\S+", " ", clean)
    clean = re.sub(r"\s+", " ", clean).strip()
    if len(clean) <= max_chars:
        return clean
    cut = clean[:max_chars]
    stop = max(cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
    return (cut[:stop + 1] if stop > max_chars * 0.5 else cut) + " The full details are in the panel."
