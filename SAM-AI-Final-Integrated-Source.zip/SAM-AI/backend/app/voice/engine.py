"""
backend.app.voice.engine
========================

The Voice pipeline facade — the thing the REST/WS API actually calls.

Full duplex flow::

    LISTEN  (client mic -> POST /voice/transcribe, or server mic)
      -> TRANSCRIBE   (stt_engine, provider chain)
      -> WAKE FILTER  (if wake word mode is on and the phrase is absent, ignore)
      -> UNDERSTAND   (orchestrator.handle_text)
      -> SPEAK        (tts_engine.speak -> /voice/audio/<file>)
      -> BARGE-IN     (client POST /voice/stop cancels mid-utterance)

Everything degrades honestly: if no STT engine exists, SAM says so; if no TTS
engine exists, the reply is returned as text with ``spoken=false`` and an
install hint.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.voice.modes import (detect_language, language_mix, speakable, voice_modes)
from backend.app.voice.stt import stt_engine
from backend.app.voice.tts import tts_engine, VOICES
from backend.app.voice.wake import contains_wake, strip_wake, wake_listener

log = get_logger("voice.engine")


class VoiceEngine:
    """Glue between the API, the voice providers and the orchestrator."""

    def __init__(self) -> None:
        self.session: Dict[str, Any] = {
            "conversation_id": None,
            "last_transcript": "",
            "last_reply": "",
            "last_audio": None,
            "turns": 0,
            "started_at": None,
        }
        self.push_to_talk = False
        self.auto_speak = True
        self.stats = {"turns": 0, "stt_ms": 0, "tts_ms": 0, "pipeline_ms": 0}

    # ------------------------------------------------------------------ state
    def state(self) -> Dict[str, Any]:
        return {
            "enabled": settings.voice_enabled,
            "mode": voice_modes.state(),
            "tts": tts_engine.state(),
            "stt": stt_engine.state(),
            "wake": wake_listener.state(),
            "session": self.session,
            "stats": self.stats,
            "push_to_talk": self.push_to_talk,
            "auto_speak": self.auto_speak,
            "voices_available": len(VOICES),
            "languages": sorted({v.language for v in VOICES}),
        }

    def configure(self, **values: Any) -> Dict[str, Any]:
        mode = values.pop("mode", None)
        if mode:
            voice_modes.set_mode(str(mode))
        if "personality" in values and isinstance(values["personality"], dict):
            voice_modes.set_personality(**values.pop("personality"))
        if "wake_word_enabled" in values:
            wake_listener.configure(enabled=bool(values.pop("wake_word_enabled")))
        if "wake_word" in values and values["wake_word"]:
            wake_listener.configure(phrase=str(values.pop("wake_word")))
        if "sensitivity" in values:
            wake_listener.configure(sensitivity=values.pop("sensitivity"))
        if "push_to_talk" in values:
            self.push_to_talk = bool(values.pop("push_to_talk"))
        if "auto_speak" in values:
            self.auto_speak = bool(values.pop("auto_speak"))
        tts_engine.configure(**{k: v for k, v in values.items() if k in
                                ("voice_id", "voice", "gender", "language", "speed",
                                 "pitch", "volume", "enabled")})
        stt_engine.configure(**{k: v for k, v in values.items() if k == "language"})
        emit(Topics.SYSTEM_STATUS, component="voice", **{"mode": voice_modes.mode})
        return self.state()

    # ----------------------------------------------------------------- listen
    async def listen(self, seconds: float = 5.0, device: str = "",
                     transcribe: bool = True) -> Dict[str, Any]:
        """Server-side record (and optionally transcribe)."""
        if not settings.voice_enabled:
            return {"ok": False, "error": "voice is disabled (VOICE_ENABLED=false)"}
        rec = await stt_engine.record(seconds=seconds, device=device)
        if not rec.get("ok") or not transcribe:
            return rec
        tr = await stt_engine.transcribe_file(rec["path"])
        return {"ok": tr.ok, "recording": rec, "transcript": tr.to_dict(),
                "text": tr.text, "language": tr.language, "error": tr.error}

    async def transcribe(self, *, path: str = "", audio: bytes = b"", b64: str = "",
                         filename: str = "audio.wav", language: str = "",
                         wake_filter: bool = False) -> Dict[str, Any]:
        t0 = time.perf_counter()
        if path:
            tr = await stt_engine.transcribe_file(path, language=language)
        elif audio:
            tr = await stt_engine.transcribe_bytes(audio, filename, language=language)
        elif b64:
            tr = await stt_engine.transcribe_b64(b64, language=language)
        else:
            return {"ok": False, "error": "no audio supplied — send a file, raw bytes or base64"}

        payload = tr.to_dict()
        payload["latency_ms"] = int((time.perf_counter() - t0) * 1000)
        self.stats["stt_ms"] += payload["latency_ms"]
        if wake_filter and payload["ok"]:
            payload["wake"] = contains_wake(payload["text"])
            payload["command"] = strip_wake(payload["text"]) if payload["wake"] else payload["text"]
        self.session["last_transcript"] = payload.get("text", "")
        return payload

    # ------------------------------------------------------------------ speak
    async def speak(self, text: str, *, voice_id: str = "", language: str = "",
                    speed: Optional[float] = None, style: str = "") -> Dict[str, Any]:
        if not text or not text.strip():
            return {"ok": False, "error": "nothing to speak"}
        t0 = time.perf_counter()
        profile = voice_modes.get()
        result = await tts_engine.speak(
            speakable(text) if len(text) > 900 else text,
            voice_id=voice_id or profile.voice_id,
            language=language or tts_engine.language,
            speed=speed if speed is not None else profile.speed,
            style=style,
        )
        result["took_ms"] = int((time.perf_counter() - t0) * 1000)
        self.stats["tts_ms"] += result["took_ms"]
        if result.get("ok"):
            self.session["last_audio"] = result.get("path")
        return result

    def stop_speaking(self) -> Dict[str, Any]:
        return tts_engine.stop()

    async def preview_voice(self, voice_id: str = "", text: str = "") -> Dict[str, Any]:
        sample = text or {
            "en": "Hi, I'm SAM. I can control your PC, phone and browser, and I'll always ask "
                  "before doing anything risky.",
            "hi": "नमस्ते, मैं सैम हूँ। मैं आपका काम आसान बना सकता हूँ।",
            "kn": "ನಮಸ್ಕಾರ, ನಾನು ಸ್ಯಾಮ್. ನಿಮ್ಮ ಕೆಲಸ ಸುಲಭ ಮಾಡುತ್ತೇನೆ.",
        }.get(detect_language(text) if text else "en",
              "Hi, I'm SAM. How can I help you today?")
        return await self.speak(sample, voice_id=voice_id)

    # ------------------------------------------------------------- full turn
    async def voice_turn(self, *, text: str = "", path: str = "", audio: bytes = b"",
                         b64: str = "", filename: str = "audio.wav", language: str = "",
                         conversation_id: Optional[str] = None,
                         speak_reply: Optional[bool] = None,
                         wake_filter: bool = False) -> Dict[str, Any]:
        """One complete voice turn: audio in -> action -> audio out."""
        from backend.app.core.orchestrator import orchestrator

        t0 = time.perf_counter()
        transcript_text = text.strip()
        stt: Dict[str, Any] = {}

        if not transcript_text and (path or audio or b64):
            stt = await self.transcribe(path=path, audio=audio, b64=b64, filename=filename,
                                        language=language, wake_filter=wake_filter)
            if not stt.get("ok"):
                return {"ok": False, "stage": "stt", "error": stt.get("error"),
                        "hint": stt.get("hint", ""), "stt": stt}
            transcript_text = (stt.get("command") if wake_filter and stt.get("wake")
                               else stt.get("text")) or ""

        if wake_filter and stt and stt.get("wake") is False:
            return {"ok": True, "stage": "wake", "wake": False,
                    "text": stt.get("text", ""), "reply": "",
                    "note": "the wake phrase was not detected, so SAM stayed quiet"}

        if not transcript_text:
            return {"ok": False, "stage": "input", "error": "no speech was understood",
                    "stt": stt}

        detected = language_mix(transcript_text)
        conv = conversation_id or self.session.get("conversation_id")

        result = await orchestrator.handle_text(
            transcript_text, conversation_id=conv, language=language or detected["primary"],
            channel="voice", speak=False,
        )
        self.session["conversation_id"] = result.conversation_id
        self.session["turns"] += 1
        self.stats["turns"] += 1
        self.session["last_reply"] = result.reply

        should_speak = self.auto_speak and voice_modes.speak(result.reply) \
            if speak_reply is None else bool(speak_reply)
        audio_out: Dict[str, Any] = {"ok": False, "skipped": True}
        if should_speak and result.reply:
            audio_out = await self.speak(result.reply, language=result.language or detected["primary"])

        pipeline_ms = int((time.perf_counter() - t0) * 1000)
        self.stats["pipeline_ms"] += pipeline_ms
        payload = {
            "ok": result.ok,
            "conversation_id": result.conversation_id,
            "message_id": result.message_id,
            "heard": transcript_text,
            "language": {"detected": detected["primary"], "mix": detected,
                         "reply": result.language},
            "reply": result.reply,
            "spoken_text": speakable(result.reply) if should_speak else "",
            "intent": result.intent,
            "agent": result.agent,
            "model": result.model,
            "task_id": result.task.id if result.task else None,
            "task": result.task.model_dump(mode="json") if result.task else None,
            "actions": result.actions,
            "sources": result.sources,
            "confirmations": result.confirmations,
            "stt": stt,
            "audio": audio_out,
            "audio_url": (f"/api/v1/voice/audio/{audio_out['file']}"
                          if audio_out.get("ok") and audio_out.get("file") else None),
            "timings": {"pipeline_ms": pipeline_ms, "took_ms": result.took_ms,
                        "tts_ms": audio_out.get("took_ms", 0),
                        "stt_ms": stt.get("latency_ms", 0)},
        }
        emit(Topics.CHAT_DONE, channel="voice", conversation_id=result.conversation_id,
             ok=result.ok, spoken=bool(audio_out.get("ok")))
        return payload

    # -------------------------------------------------------------- proactive
    async def announce(self, title: str, body: str = "", *, level: str = "info",
                       speak: bool = True) -> Dict[str, Any]:
        """Proactive speech — respects the mode's proactive level."""
        allowed = {"off": 0, "important_only": 1, "normal": 2, "proactive": 3}
        rank = allowed.get(voice_modes.proactive_level(), 2)
        importance = {"info": 2, "success": 2, "warning": 1, "critical": 0}.get(level, 2)
        emit(Topics.NOTIFICATION, title=title, body=body, level=level, source="voice")
        if not speak or importance < rank or not settings.voice_enabled:
            return {"ok": True, "spoken": False, "reason": "below the proactive threshold",
                    "proactive_level": voice_modes.proactive_level()}
        text = f"{title}. {body}".strip()
        out = await self.speak(text)
        return {"ok": out.get("ok", False), "spoken": out.get("ok", False), "tts": out}

    def devices(self) -> Dict[str, Any]:
        """Microphone and speaker lists for the VOICE dashboard."""
        inputs = stt_engine.input_devices()
        outputs = _output_devices()
        return {"ok": True, "inputs": inputs, "outputs": outputs,
                "server_recording_available": bool(inputs),
                "note": "The desktop app records in the browser/Electron and sends audio to SAM; "
                        "server-side recording needs sounddevice on the backend machine."}


def _output_devices() -> List[Dict[str, Any]]:
    if not _have("sounddevice"):
        return []
    try:
        import sounddevice as sd  # type: ignore

        out: List[Dict[str, Any]] = []
        for index, info in enumerate(sd.query_devices()):
            if info.get("max_output_channels", 0) > 0:
                out.append({"index": index, "name": info["name"],
                            "channels": info["max_output_channels"],
                            "default": index == sd.default.device[1]})
        return out
    except Exception as exc:
        log.debug("could not list output devices: %s", exc)
        return []


def _have(module: str) -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec(module) is not None
    except (ImportError, ValueError):
        return False


voice_engine = VoiceEngine()


def wire_wake_to_orchestrator() -> None:
    """When the wake word fires on the server, start listening for the command."""

    async def handler(payload: Dict[str, Any]) -> None:
        command = (payload or {}).get("command") or ""
        if not command:
            await voice_engine.announce("Yes?", "", speak=True)
            return
        result = await voice_engine.voice_turn(text=command, speak_reply=True)
        if not result.get("ok"):
            await voice_engine.announce("I could not do that", str(result.get("error") or ""),
                                        level="warning")

    wake_listener.on_wake(handler)
