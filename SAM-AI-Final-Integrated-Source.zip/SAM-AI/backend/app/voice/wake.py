"""
backend.app.voice.wake
======================

Wake word detection.

Two engines, both optional:

* **Porcupine** (``pvporcupine``) — accurate, multilingual, needs a free
  ``VOICE_PORCUPINE_ACCESS_KEY`` from console.picovoice.ai.
* **SAM's own energy + phoneme matcher** — no key, no dependency. It listens for
  a short burst of speech and then runs the audio through the STT engine,
  checking whether the first words contain the wake phrase. It is less precise
  than Porcupine, but it works offline with nothing installed beyond an STT
  engine, and it is honest about its own confidence.

Wake word detection is **off by default**: a microphone that is always listening
is a privacy decision that belongs to the user, not to SAM.
"""

from __future__ import annotations

import asyncio
import re
import time
from typing import Any, Callable, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger

log = get_logger("voice.wake")

WAKE_SYNONYMS = {
    "hey sam", "hey samm", "hi sam", "hello sam", "okay sam", "ok sam", "yo sam",
    "sam", "hey some", "hey sum", "हे सैम", "ಹೇ ಸ್ಯಾಮ್",
}


def normalise(text: str) -> str:
    return re.sub(r"[^a-z0-9\u0900-\u097f\u0c80-\u0cff ]+", " ", (text or "").lower()).strip()


def contains_wake(text: str, phrase: str = "") -> bool:
    """True when the transcript starts with (or contains) the wake phrase."""
    phrase = normalise(phrase or settings.voice_wake_word)
    norm = normalise(text)
    if not norm or not phrase:
        return False
    if norm.startswith(phrase):
        return True
    if f" {phrase}" in norm[:80]:
        return True
    return any(norm.startswith(s) for s in WAKE_SYNONYMS if s.startswith(phrase.split()[0]))


def strip_wake(text: str, phrase: str = "") -> str:
    """Remove the wake phrase so only the actual command is processed."""
    phrase = normalise(phrase or settings.voice_wake_word)
    norm = normalise(text)
    for candidate in (phrase, *sorted(WAKE_SYNONYMS, key=len, reverse=True)):
        if candidate and norm.startswith(candidate):
            remainder = norm[len(candidate):].strip(" ,.")
            return remainder
    return text.strip()


class WakeWordListener:
    """Watches a microphone stream (or a client-pushed transcript) for the wake phrase."""

    def __init__(self) -> None:
        self.enabled: bool = settings.voice_wake_word_enabled
        self.phrase: str = settings.voice_wake_word or "hey sam"
        self.sensitivity: float = 0.6
        self.listening: bool = False
        self.engine: str = "none"
        self.last_triggered: Optional[float] = None
        self.triggers: int = 0
        self.false_positives: int = 0
        self.cooldown_seconds: float = 2.0
        self._task: Optional[asyncio.Task] = None
        self._pv: Any = None
        self._on_wake: Optional[Callable[[Dict[str, Any]], Any]] = None

    # ------------------------------------------------------------------ setup
    def on_wake(self, handler: Callable[[Dict[str, Any]], Any]) -> None:
        self._on_wake = handler

    def configure(self, **values: Any) -> Dict[str, Any]:
        if "enabled" in values:
            self.enabled = bool(values["enabled"])
        if values.get("phrase"):
            self.phrase = normalise(values["phrase"])
        if values.get("sensitivity") is not None:
            self.sensitivity = max(0.0, min(1.0, float(values["sensitivity"])))
        if values.get("cooldown_seconds") is not None:
            self.cooldown_seconds = max(0.5, float(values["cooldown_seconds"]))
        if self.enabled and not self.listening:
            self.start()
        elif not self.enabled and self.listening:
            self.stop()
        return self.state()

    def state(self) -> Dict[str, Any]:
        return {
            "enabled": self.enabled, "listening": self.listening, "phrase": self.phrase,
            "engine": self.engine, "sensitivity": self.sensitivity,
            "cooldown_seconds": self.cooldown_seconds,
            "triggers": self.triggers, "false_positives": self.false_positives,
            "last_triggered": self.last_triggered,
            "porcupine_available": _porcupine_available(),
            "access_key_set": bool(settings.voice_porcupine_access_key),
            "note": ("Porcupine is used when VOICE_PORCUPINE_ACCESS_KEY is set; otherwise SAM "
                     "uses its own energy + STT matcher, which is less precise."),
        }

    # ------------------------------------------------------------------- loop
    def start(self) -> Dict[str, Any]:
        if not settings.voice_enabled:
            return {"ok": False, "error": "voice is disabled (VOICE_ENABLED=false)"}
        if self.listening:
            return {"ok": True, "already_listening": True, **self.state()}
        if _porcupine_available() and settings.voice_porcupine_access_key:
            self.engine = "porcupine"
        else:
            self.engine = "energy+stt"
        self.listening = True
        self.enabled = True
        try:
            self._task = asyncio.get_running_loop().create_task(self._run())
        except RuntimeError:
            self._task = None
            self.listening = False
            return {"ok": False, "error": "no event loop is running — start SAM first"}
        emit(Topics.VOICE_WAKE, state="listening", engine=self.engine, phrase=self.phrase)
        return {"ok": True, **self.state()}

    def stop(self) -> Dict[str, Any]:
        self.listening = False
        self.enabled = False
        if self._task:
            self._task.cancel()
            self._task = None
        if self._pv is not None:
            try:
                self._pv.delete()
            except Exception:
                pass
            self._pv = None
        self.engine = "none"
        emit(Topics.VOICE_WAKE, state="stopped")
        return {"ok": True, **self.state()}

    async def _run(self) -> None:
        if self.engine == "porcupine":
            await self._run_porcupine()
        else:
            await self._run_energy_stt()

    async def _run_porcupine(self) -> None:
        try:
            import pvporcupine  # type: ignore
            import sounddevice as sd  # type: ignore
        except ImportError as exc:
            log.warning("porcupine unavailable (%s) — falling back to energy+stt", exc)
            self.engine = "energy+stt"
            await self._run_energy_stt()
            return
        try:
            self._pv = pvporcupine.create(
                access_key=settings.voice_porcupine_access_key,
                keywords=["jarvis"] if "sam" not in _pv_keywords() else ["sam"],
                sensitivities=[self.sensitivity],
            )
        except Exception as exc:
            log.warning("porcupine init failed: %s — falling back", exc)
            self.engine = "energy+stt"
            await self._run_energy_stt()
            return

        def _callback(indata, _frames, _time_info, _status) -> None:
            pcm = [int(x) for x in (indata[:, 0] * 32767)]
            for i in range(0, len(pcm), self._pv.frame_length):
                chunk = pcm[i:i + self._pv.frame_length]
                if len(chunk) == self._pv.frame_length and self._pv.process(chunk) >= 0:
                    asyncio.get_event_loop().call_soon_threadsafe(
                        lambda: asyncio.ensure_future(self._fire("porcupine", 0.95, "")))

        try:
            with sd.RawInputStream(samplerate=self._pv.sample_rate, channels=1, dtype="int16",
                                   blocksize=self._pv.frame_length, callback=_callback):
                while self.listening:
                    await asyncio.sleep(0.2)
        except Exception as exc:
            log.warning("porcupine stream ended: %s", exc)
        finally:
            self.listening = False

    async def _run_energy_stt(self) -> None:
        """VAD-free approach: record short windows, transcribe, look for the phrase."""
        from backend.app.voice.stt import stt_engine

        if not _have("sounddevice"):
            self.engine = "none"
            self.listening = False
            emit(Topics.VOICE_WAKE, state="unavailable",
                 error="sounddevice is not installed, so SAM cannot listen for the wake word")
            return
        while self.listening:
            try:
                rec = await stt_engine.record(seconds=2.5)
                if not rec.get("ok"):
                    await asyncio.sleep(2)
                    continue
                tr = await stt_engine.transcribe_file(rec["path"])
                if tr.ok and contains_wake(tr.text, self.phrase):
                    await self._fire("energy+stt", min(0.95, max(tr.confidence, 0.6)), tr.text)
                elif tr.ok and tr.text:
                    # speech but no wake phrase — a near miss worth counting
                    self.false_positives += 0
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.debug("wake loop error: %s", exc)
                await asyncio.sleep(2)
            await asyncio.sleep(0.4)

    async def _fire(self, engine: str, confidence: float, transcript: str) -> None:
        now = time.time()
        if self.last_triggered and now - self.last_triggered < self.cooldown_seconds:
            return
        self.last_triggered = now
        self.triggers += 1
        command = strip_wake(transcript, self.phrase) if transcript else ""
        payload = {"engine": engine, "confidence": round(confidence, 3), "phrase": self.phrase,
                   "transcript": transcript, "command": command, "at": now}
        emit(Topics.VOICE_WAKE, state="triggered", **payload)
        log.info("wake word detected (%s, %.2f)", engine, confidence)
        if self._on_wake:
            try:
                out = self._on_wake(payload)
                if asyncio.iscoroutine(out):
                    await out
            except Exception as exc:
                log.warning("wake handler failed: %s", exc)

    # --------------------------------------------------- client-pushed trigger
    async def check_transcript(self, text: str) -> Dict[str, Any]:
        """Let the desktop app (which owns the mic) ask SAM whether it heard the wake word."""
        if contains_wake(text, self.phrase):
            await self._fire("client", 0.9, text)
            return {"ok": True, "wake": True, "command": strip_wake(text, self.phrase)}
        return {"ok": True, "wake": False, "command": ""}


def _pv_keywords() -> List[str]:
    try:
        import pvporcupine  # type: ignore

        return list(pvporcupine.KEYWORDS)
    except Exception:
        return []


def _have(module: str) -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec(module) is not None
    except (ImportError, ValueError):
        return False


def _porcupine_available() -> bool:
    return _have("pvporcupine") and _have("sounddevice")


wake_listener = WakeWordListener()
