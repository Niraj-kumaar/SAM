"""
backend.app.voice.stt
=====================

Speech to text.

Two input paths, both real:

1. **Browser/desktop capture** — the UI records audio (WebAudio / Electron) and
   POSTs it here. SAM transcribes it with the configured provider.
2. **Server-side mic** — when SAM runs on the same machine as the microphone and
   ``sounddevice``/``pyaudio`` is available, it can record directly.

Provider chain::

    OpenAI Whisper API  ->  Groq Whisper  ->  local faster-whisper / whisper.cpp
      ->  Vosk (offline, small)  ->  honest failure with an install hint

Nothing is uploaded when Privacy Mode or LOCAL mode is on: in that case only the
local engines are tried, and if none are installed SAM says so instead of
quietly sending audio to the cloud.
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import os
import re
import shutil
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger

log = get_logger("voice.stt")

CACHE_DIR = settings.sam_data_dir / "cache" / "audio"
SUPPORTED_EXT = (".wav", ".mp3", ".m4a", ".ogg", ".opus", ".webm", ".flac", ".aac", ".raw")
MAX_AUDIO_BYTES = 25 * 1024 * 1024

LANGUAGE_NAMES = {
    "en": "English", "hi": "Hindi", "kn": "Kannada", "ta": "Tamil", "te": "Telugu",
    "ml": "Malayalam", "mr": "Marathi", "bn": "Bengali", "gu": "Gujarati",
    "ur": "Urdu", "pa": "Punjabi", "es": "Spanish", "fr": "French", "de": "German",
    "ja": "Japanese", "zh": "Chinese", "ar": "Arabic", "pt": "Portuguese",
    "ru": "Russian", "it": "Italian", "ko": "Korean",
}


@dataclass
class Transcript:
    text: str = ""
    language: str = "en"
    confidence: float = 0.0
    provider: str = ""
    model: str = ""
    duration_ms: int = 0
    latency_ms: int = 0
    segments: List[Dict[str, Any]] = field(default_factory=list)
    mixed_language: bool = False
    ok: bool = True
    error: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok, "text": self.text, "language": self.language,
            "language_name": LANGUAGE_NAMES.get(self.language.split("-")[0], self.language),
            "confidence": self.confidence, "provider": self.provider, "model": self.model,
            "duration_ms": self.duration_ms, "latency_ms": self.latency_ms,
            "segments": self.segments[:40], "mixed_language": self.mixed_language,
            "error": self.error, "words": len(self.text.split()),
        }


class STTEngine:
    def __init__(self) -> None:
        self.language = settings.voice_language
        self.listening = False
        self.stats = {"calls": 0, "seconds": 0.0, "failures": 0, "by_provider": {}}
        self.last: Dict[str, Any] = {}
        CACHE_DIR.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ state
    def state(self) -> Dict[str, Any]:
        return {
            "listening": self.listening,
            "language": self.language,
            "providers": self.provider_status(),
            "stats": self.stats,
            "last": self.last,
            "wake_word": settings.voice_wake_word,
            "wake_word_enabled": settings.voice_wake_word_enabled,
            "cache_dir": str(CACHE_DIR),
            "supported_formats": list(SUPPORTED_EXT),
        }

    def provider_status(self) -> Dict[str, Any]:
        return {
            "openai": {"available": bool(settings.openai_api_key) and settings.cloud_enabled,
                       "model": "whisper-1 / gpt-4o-mini-transcribe", "local": False},
            "groq": {"available": bool(settings.groq_api_key) and settings.cloud_enabled,
                     "model": "whisper-large-v3-turbo", "local": False},
            "faster_whisper": {"available": _have("faster_whisper"),
                               "model": settings.model_voice_stt or "base", "local": True},
            "whisper_cpp": {"available": shutil.which("whisper-cli") is not None
                            or shutil.which("main") is not None,
                            "model": "ggml model", "local": True},
            "vosk": {"available": _have("vosk") and bool(_vosk_model()),
                     "model": "vosk-small", "local": True},
        }

    def configure(self, **values: Any) -> Dict[str, Any]:
        if "language" in values and values["language"]:
            self.language = values["language"]
        return self.state()

    # ------------------------------------------------------------- transcribe
    async def transcribe_file(self, path: str | Path, *, language: str = "",
                              prompt: str = "") -> Transcript:
        p = Path(path).expanduser()
        if not p.exists():
            return Transcript(ok=False, error=f"audio file not found: {p}")
        if p.stat().st_size > MAX_AUDIO_BYTES:
            return Transcript(ok=False, error=f"audio is too large ({p.stat().st_size // (1024 * 1024)} MB, max 25 MB)")
        if p.suffix.lower() not in SUPPORTED_EXT:
            log.warning("transcribing an unusual format: %s", p.suffix)
        return await self._transcribe_bytes(p.read_bytes(), p.name, language=language,
                                            prompt=prompt)

    async def transcribe_bytes(self, audio: bytes, filename: str = "audio.wav", *,
                               language: str = "", prompt: str = "") -> Transcript:
        if not audio:
            return Transcript(ok=False, error="no audio data received")
        if len(audio) > MAX_AUDIO_BYTES:
            return Transcript(ok=False, error="audio payload is too large (max 25 MB)")
        # keep a copy so the user can replay what SAM heard
        try:
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            kept = CACHE_DIR / f"sam_stt_{int(time.time() * 1000)}_{Path(filename).name}"
            kept.write_bytes(audio)
            _prune_cache()
        except OSError:
            kept = None
        result = await self._transcribe_bytes(audio, filename, language=language, prompt=prompt)
        if kept:
            result.segments = result.segments or []
            self.last["audio_file"] = str(kept)
        return result

    async def transcribe_b64(self, data_uri_or_b64: str, *, language: str = "") -> Transcript:
        raw = data_uri_or_b64
        if "," in raw and raw.strip().startswith("data:"):
            raw = raw.split(",", 1)[1]
        try:
            audio = base64.b64decode(raw)
        except Exception as exc:
            return Transcript(ok=False, error=f"could not decode base64 audio: {exc}")
        return await self.transcribe_bytes(audio, "audio.wav", language=language)

    async def _transcribe_bytes(self, audio: bytes, filename: str, *, language: str = "",
                                prompt: str = "") -> Transcript:
        t0 = time.perf_counter()
        lang = language or (self.language if self.language not in ("", "auto") else "")
        emit(Topics.VOICE_LISTENING, state="transcribing", bytes=len(audio))

        chain = self._chain()
        attempts: List[Dict[str, Any]] = []
        result = Transcript(ok=False, error="no STT provider succeeded")
        for provider in chain:
            try:
                result = await provider(audio, filename, lang, prompt)
            except Exception as exc:
                result = Transcript(ok=False, provider=provider.__name__.strip("_"),
                                    error=f"{type(exc).__name__}: {exc}"[:250])
            attempts.append({"provider": result.provider or provider.__name__.strip("_"),
                             "ok": result.ok, "error": result.error})
            if result.ok and result.text.strip():
                break

        result.latency_ms = int((time.perf_counter() - t0) * 1000)
        if result.ok:
            result.text = _postprocess(result.text)
            result.mixed_language = _looks_code_mixed(result.text)
            if not lang:
                lang = _guess_language(result.text)
                result.language = lang
            self.stats["calls"] += 1
            self.stats["seconds"] += result.duration_ms / 1000
            self.stats["by_provider"][result.provider] = \
                self.stats["by_provider"].get(result.provider, 0) + 1
            self.last = result.to_dict()
            emit(Topics.VOICE_TRANSCRIPT, text=result.text, language=result.language,
                 provider=result.provider, confidence=result.confidence)
        else:
            self.stats["failures"] += 1
            result.error = result.error or "could not transcribe the audio"
            result.hint = _install_hint()          # type: ignore[attr-defined]
            emit(Topics.VOICE_TRANSCRIPT, text="", ok=False, error=result.error)
        result.segments = (result.segments or []) + [{"attempts": attempts}]
        return result

    def _chain(self) -> List[Any]:
        local_only = (settings.sam_mode == "local") or settings.privacy_cloud_ai
        cloud: List[Any] = [] if local_only else [_openai_stt, _groq_stt]
        local: List[Any] = [_faster_whisper, _whisper_cpp, _vosk]
        return cloud + local if not local_only else local

    # ---------------------------------------------------------- server-side mic
    async def record(self, seconds: float = 5.0, device: str = "") -> Dict[str, Any]:
        """Record from the server machine's microphone (needs sounddevice)."""
        if not _have("sounddevice"):
            return {"ok": False, "error": "sounddevice is not installed, so SAM cannot record "
                                          "from this machine's microphone",
                    "install": "pip install sounddevice",
                    "alternative": "record in the desktop app and send the audio to SAM"}
        seconds = max(0.5, min(60.0, float(seconds)))
        self.listening = True
        emit(Topics.VOICE_LISTENING, state="recording", seconds=seconds, device=device)
        try:
            audio = await asyncio.to_thread(_record_sync, seconds, device)
        except Exception as exc:
            self.listening = False
            return {"ok": False, "error": f"recording failed: {exc}"}
        finally:
            self.listening = False
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        path = CACHE_DIR / f"sam_mic_{int(time.time() * 1000)}.wav"
        try:
            with wave.open(str(path), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(int(settings.voice_sample_rate))
                wf.writeframes(audio)
        except Exception as exc:
            return {"ok": False, "error": f"could not save the recording: {exc}"}
        emit(Topics.VOICE_LISTENING, state="done", path=str(path), seconds=seconds)
        return {"ok": True, "path": str(path), "seconds": seconds,
                "bytes": path.stat().st_size, "sample_rate": settings.voice_sample_rate}

    def input_devices(self) -> List[Dict[str, Any]]:
        if not _have("sounddevice"):
            return []
        try:
            import sounddevice as sd  # type: ignore

            out = []
            for index, info in enumerate(sd.query_devices()):
                if info.get("max_input_channels", 0) > 0:
                    out.append({"index": index, "name": info["name"],
                                "channels": info["max_input_channels"],
                                "default_samplerate": info.get("default_samplerate"),
                                "default": index == sd.default.device[0]})
            return out
        except Exception as exc:
            log.debug("could not list input devices: %s", exc)
            return []


def _record_sync(seconds: float, device: str) -> bytes:
    import numpy as np  # type: ignore
    import sounddevice as sd  # type: ignore

    rate = int(settings.voice_sample_rate)
    kwargs: Dict[str, Any] = {"samplerate": rate, "channels": 1, "dtype": "int16"}
    if device:
        kwargs["device"] = int(device) if str(device).isdigit() else device
    audio = sd.rec(int(seconds * rate), **kwargs)
    sd.wait()
    return audio.tobytes() if hasattr(audio, "tobytes") else np.asarray(audio).tobytes()


# ---------------------------------------------------------------------------
# providers
# ---------------------------------------------------------------------------
def _have(module: str) -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec(module) is not None
    except (ImportError, ValueError):
        return False


def _vosk_model() -> Optional[Path]:
    base = settings.sam_data_dir / "models" / "vosk"
    if base.exists():
        for child in sorted(base.iterdir()):
            if child.is_dir() and (child / "am").exists():
                return child
    return None


async def _openai_stt(audio: bytes, filename: str, lang: str, prompt: str) -> Transcript:
    if not settings.openai_api_key:
        return Transcript(ok=False, provider="openai", error="OPENAI_API_KEY is not set")
    try:
        from openai import AsyncOpenAI  # type: ignore
    except ImportError:
        return Transcript(ok=False, provider="openai", error="the openai package is not installed")

    client = AsyncOpenAI(api_key=settings.openai_api_key, base_url=settings.openai_base_url)
    buf = io.BytesIO(audio)
    buf.name = filename or "audio.wav"
    kwargs: Dict[str, Any] = {"model": "whisper-1", "file": buf, "response_format": "verbose_json"}
    if lang and lang != "auto":
        kwargs["language"] = lang.split("-")[0]
    if prompt:
        kwargs["prompt"] = prompt[:240]
    try:
        res = await client.audio.transcriptions.create(**kwargs)
    except Exception as exc:
        return Transcript(ok=False, provider="openai", error=str(exc)[:250])
    data = getattr(res, "model_extra", None) or {}
    text = getattr(res, "text", "") or (data.get("text") if isinstance(data, dict) else "") or ""
    segments = [dict(s) for s in (data.get("segments") or [])] if isinstance(data, dict) else []
    detected = (data.get("language") if isinstance(data, dict) else "") or lang or "en"
    duration = float((data.get("duration") if isinstance(data, dict) else 0) or 0)
    return Transcript(ok=bool(text.strip()), text=text, language=detected, provider="openai",
                      model="whisper-1", confidence=0.9 if text else 0.0,
                      duration_ms=int(duration * 1000), segments=segments,
                      error="" if text else "OpenAI returned no text")


async def _groq_stt(audio: bytes, filename: str, lang: str, prompt: str) -> Transcript:
    if not settings.groq_api_key:
        return Transcript(ok=False, provider="groq", error="GROQ_API_KEY is not set")
    import httpx

    model = settings.model_voice_stt
    model = model if model and model != "auto" else "whisper-large-v3-turbo"
    files = {"file": (filename or "audio.wav", audio)}
    data: Dict[str, Any] = {"model": model, "response_format": "verbose_json"}
    if lang and lang != "auto":
        data["language"] = lang.split("-")[0]
    if prompt:
        data["prompt"] = prompt[:240]
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post("https://api.groq.com/openai/v1/audio/transcriptions",
                                  files=files, data=data,
                                  headers={"Authorization": f"Bearer {settings.groq_api_key}"})
        if r.status_code != 200:
            return Transcript(ok=False, provider="groq",
                              error=f"HTTP {r.status_code}: {r.text[:200]}")
        payload = r.json()
    except Exception as exc:
        return Transcript(ok=False, provider="groq", error=str(exc)[:250])
    text = payload.get("text", "")
    return Transcript(ok=bool(text.strip()), text=text,
                      language=payload.get("language") or lang or "en", provider="groq",
                      model=model, confidence=0.9 if text else 0.0,
                      duration_ms=int(float(payload.get("duration") or 0) * 1000),
                      segments=[dict(s) for s in (payload.get("segments") or [])],
                      error="" if text else "Groq returned no text")


async def _faster_whisper(audio: bytes, filename: str, lang: str, prompt: str) -> Transcript:
    if not _have("faster_whisper"):
        return Transcript(ok=False, provider="faster_whisper",
                          error="faster-whisper is not installed")
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = CACHE_DIR / f"fw_{int(time.time() * 1000)}{Path(filename).suffix or '.wav'}"
    tmp.write_bytes(audio)

    def _run() -> Dict[str, Any]:
        from faster_whisper import WhisperModel  # type: ignore

        size = os.environ.get("SAM_WHISPER_SIZE", "base")
        model = WhisperModel(size, device="cpu", compute_type="int8")
        segments, info = model.transcribe(str(tmp), language=lang.split("-")[0] or None,
                                          vad_filter=True, beam_size=1)
        chunks: List[Dict[str, Any]] = []
        texts: List[str] = []
        for seg in segments:
            texts.append(seg.text)
            chunks.append({"start": round(seg.start, 2), "end": round(seg.end, 2),
                           "text": seg.text.strip()})
        return {"text": " ".join(texts).strip(), "language": info.language,
                "probability": float(info.language_probability or 0),
                "duration": float(info.duration or 0), "segments": chunks}

    try:
        data = await asyncio.to_thread(_run)
    except Exception as exc:
        return Transcript(ok=False, provider="faster_whisper", error=str(exc)[:250])
    finally:
        tmp.unlink(missing_ok=True)
    text = data["text"]
    return Transcript(ok=bool(text), text=text, language=data.get("language") or "en",
                      provider="faster_whisper", model="faster-whisper",
                      confidence=round(data.get("probability", 0.0), 3),
                      duration_ms=int(data.get("duration", 0) * 1000),
                      segments=data.get("segments") or [],
                      error="" if text else "whisper produced no text")


async def _whisper_cpp(audio: bytes, filename: str, lang: str, prompt: str) -> Transcript:
    exe = shutil.which("whisper-cli") or shutil.which("whisper-cpp")
    if not exe:
        return Transcript(ok=False, provider="whisper_cpp",
                          error="whisper.cpp CLI (whisper-cli) is not on PATH")
    model_path = os.environ.get("SAM_WHISPER_CPP_MODEL", "")
    if not model_path or not Path(model_path).exists():
        return Transcript(ok=False, provider="whisper_cpp",
                          error="set SAM_WHISPER_CPP_MODEL to a ggml model file")
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    wav = CACHE_DIR / f"wcpp_{int(time.time() * 1000)}.wav"
    try:
        wav.write_bytes(_to_wav(audio))
        proc = await asyncio.create_subprocess_exec(
            exe, "-m", model_path, "-f", str(wav), "-oj",
            *(["-l", lang.split("-")[0]] if lang and lang != "auto" else []),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        out, err = await proc.communicate()
    except Exception as exc:
        return Transcript(ok=False, provider="whisper_cpp", error=str(exc)[:250])
    finally:
        wav.unlink(missing_ok=True)
    text = ""
    try:
        payload = json.loads(out.decode(errors="replace") or "{}")
        text = " ".join(t.get("text", "") for t in payload.get("transcription", [])).strip()
    except ValueError:
        text = out.decode(errors="replace").strip()
    return Transcript(ok=bool(text), text=text, language=lang or "en", provider="whisper_cpp",
                      model=Path(model_path).name, error="" if text else
                      (err.decode(errors="replace")[:200] or "no transcription returned"))


def _to_wav(audio: bytes) -> bytes:
    """Best-effort conversion to 16 kHz mono WAV using ffmpeg when available."""
    if audio[:4] == b"RIFF":
        return audio
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return audio
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    src = CACHE_DIR / f"src_{int(time.time() * 1000)}.bin"
    dst = CACHE_DIR / f"dst_{int(time.time() * 1000)}.wav"
    try:
        src.write_bytes(audio)
        import subprocess

        subprocess.run([ffmpeg, "-y", "-i", str(src), "-ar", "16000", "-ac", "1",
                        str(dst)], capture_output=True, timeout=60, check=False)
        return dst.read_bytes() if dst.exists() else audio
    except Exception:
        return audio
    finally:
        src.unlink(missing_ok=True)
        dst.unlink(missing_ok=True)


async def _vosk(audio: bytes, filename: str, lang: str, prompt: str) -> Transcript:
    model_dir = _vosk_model()
    if not _have("vosk") or model_dir is None:
        return Transcript(ok=False, provider="vosk",
                          error="Vosk is not installed or no model is present in "
                                f"{settings.sam_data_dir / 'models' / 'vosk'}")

    def _run() -> Dict[str, Any]:
        import json as _json

        from vosk import KaldiRecognizer, Model  # type: ignore

        wav = _to_wav(audio)
        with wave.open(io.BytesIO(wav), "rb") as wf:
            if wf.getnchannels() != 1 or wf.getsampwidth() != 2:
                raise ValueError("Vosk needs 16-bit mono WAV")
            rate = wf.getframerate()
            rec = KaldiRecognizer(Model(str(model_dir)), rate)
            rec.SetWords(True)
            chunks: List[Dict[str, Any]] = []
            while True:
                data = wf.readframes(4000)
                if not data:
                    break
                if rec.AcceptWaveform(data):
                    part = _json.loads(rec.Result() or "{}")
                    if part.get("text"):
                        chunks.append(part)
            final = _json.loads(rec.FinalResult() or "{}")
            if final.get("text"):
                chunks.append(final)
            return {"chunks": chunks, "rate": rate}

    try:
        data = await asyncio.to_thread(_run)
    except Exception as exc:
        return Transcript(ok=False, provider="vosk", error=str(exc)[:250])
    text = " ".join(c.get("text", "") for c in data["chunks"]).strip()
    return Transcript(ok=bool(text), text=text, language=lang or "en", provider="vosk",
                      model=model_dir.name, confidence=0.6 if text else 0.0,
                      segments=[{"text": c.get("text", "")} for c in data["chunks"]],
                      error="" if text else "vosk produced no text")


# ---------------------------------------------------------------------------
# post-processing / language detection
# ---------------------------------------------------------------------------
def _postprocess(text: str) -> str:
    t = (text or "").strip()
    t = " ".join(t.split())
    # whisper's famous hallucinations on silence
    for junk in ("Thank you.", "Thanks for watching!", "Subtitles by", "字幕", "you",
                 "MBC 뉴스", "AMARA.ORG"):
        if t.strip().lower().rstrip(".") == junk.lower().rstrip("."):
            return ""
    return t


_INDIC = re.compile(r"[\u0900-\u097F\u0C80-\u0CFF\u0B80-\u0BFF\u0D00-\u0D7F\u0980-\u09FF]")
_LATIN = re.compile(r"[A-Za-z]")
_HINGLISH = re.compile(
    r"\b(kya|kaise|hai|hain|karo|kar do|batao|bata|chahiye|mera|meri|tum|tumhara|aap|"
    r"acha|accha|theek|thik|nahi|nahin|haan|abhi|kal|aaj|please|yaar|bhai|dheere|jaldi|"
    r"madat|madaat|kholo|band karo|chalu|shuru)\b", re.I)


def _looks_code_mixed(text: str) -> bool:
    """True when one sentence mixes scripts or transliterated words."""
    if not text:
        return False
    for sentence in re.split(r"[.!?।\n]", text):
        if _INDIC.search(sentence) and _LATIN.search(sentence):
            words = sentence.split()
            if len(words) >= 3:
                return True
    return bool(_HINGLISH.search(text)) and bool(_INDIC.search(text) is None) is False


def _guess_language(text: str) -> str:
    if not text:
        return "en"
    if _INDIC.search(text):
        sample = text[:400]
        if re.search(r"[\u0C80-\u0CFF]", sample):
            return "kn"
        if re.search(r"[\u0B80-\u0BFF]", sample):
            return "ta"
        if re.search(r"[\u0D00-\u0D7F]", sample):
            return "ml"
        if re.search(r"[\u0980-\u09FF]", sample):
            return "bn"
        return "hi"
    if _HINGLISH.search(text):
        return "hi"
    return "en"


def _install_hint() -> str:
    if settings.sam_mode == "local" or settings.privacy_cloud_ai:
        return ("Local mode is on, so cloud STT is disabled. Install an offline engine: "
                "`pip install faster-whisper` (downloads a model on first use) or "
                "`pip install vosk` plus a model in data/models/vosk.")
    if not settings.any_cloud_key:
        return ("No provider key is set. Add OPENAI_API_KEY or GROQ_API_KEY to .env, or install "
                "an offline engine with `pip install faster-whisper`.")
    return "Check the provider key and the audio format (16 kHz mono WAV works best)."


def _prune_cache() -> None:
    try:
        files = sorted(CACHE_DIR.glob("sam_stt_*"), key=lambda p: p.stat().st_mtime)
        for old in files[:-100]:
            old.unlink(missing_ok=True)
    except OSError:
        pass


stt_engine = STTEngine()
