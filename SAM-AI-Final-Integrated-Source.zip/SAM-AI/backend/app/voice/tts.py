"""
backend.app.voice.tts
=====================

Text to speech with a provider chain that always lands somewhere useful::

    edge-tts (free, many languages/voices, needs internet)
      -> OpenAI TTS          (needs OPENAI_API_KEY)
      -> ElevenLabs          (needs ELEVENLABS_API_KEY)
      -> Piper               (fully offline, local .onnx voices)
      -> OS voice            (Windows SAPI / macOS `say` / espeak-ng)

Every call returns ``{"ok", "path", "provider", "voice", "bytes", "duration_ms"}``
so the UI can play ``/api/v1/voice/audio/<file>`` immediately.

SAM writes the audio into ``data/voices/out`` and prunes it, so the voice
pipeline never fills the disk.
"""

from __future__ import annotations

import asyncio
import os
import platform
import re
import shutil
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger

log = get_logger("voice.tts")

OUT_DIR = settings.sam_data_dir / "voices" / "out"
MAX_FILES = 200

# ---------------------------------------------------------------------------
# Voice catalogue — real provider voice ids, grouped for the Voice Dashboard
# ---------------------------------------------------------------------------
@dataclass
class Voice:
    id: str
    name: str
    provider: str
    gender: str            # male | female | neutral
    language: str          # BCP-47
    style: str = "general"
    local: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "name": self.name, "provider": self.provider,
                "gender": self.gender, "language": self.language, "style": self.style,
                "local": self.local}


VOICES: List[Voice] = [
    # edge-tts: free, neural, multilingual
    Voice("en-US-AriaNeural", "Aria (US)", "edge", "female", "en-US", "warm"),
    Voice("en-US-JennyNeural", "Jenny (US)", "edge", "female", "en-US", "friendly"),
    Voice("en-US-GuyNeural", "Guy (US)", "edge", "male", "en-US", "clear"),
    Voice("en-US-ChristopherNeural", "Christopher (US)", "edge", "male", "en-US", "deep"),
    Voice("en-GB-SoniaNeural", "Sonia (UK)", "edge", "female", "en-GB", "professional"),
    Voice("en-GB-RyanNeural", "Ryan (UK)", "edge", "male", "en-GB", "professional"),
    Voice("en-IN-NeerjaNeural", "Neerja (IN)", "edge", "female", "en-IN", "indian english"),
    Voice("en-IN-PrabhatNeural", "Prabhat (IN)", "edge", "male", "en-IN", "indian english"),
    Voice("hi-IN-SwaraNeural", "Swara (हिन्दी)", "edge", "female", "hi-IN", "hindi"),
    Voice("hi-IN-MadhurNeural", "Madhur (हिन्दी)", "edge", "male", "hi-IN", "hindi"),
    Voice("kn-IN-SapnaNeural", "Sapna (ಕನ್ನಡ)", "edge", "female", "kn-IN", "kannada"),
    Voice("kn-IN-GaganNeural", "Gagan (ಕನ್ನಡ)", "edge", "male", "kn-IN", "kannada"),
    Voice("ta-IN-PallaviNeural", "Pallavi (தமிழ்)", "edge", "female", "ta-IN", "tamil"),
    Voice("ta-IN-ValluvarNeural", "Valluvar (தமிழ்)", "edge", "male", "ta-IN", "tamil"),
    Voice("te-IN-ShrutiNeural", "Shruti (తెలుగు)", "edge", "female", "te-IN", "telugu"),
    Voice("te-IN-MohanNeural", "Mohan (తెలుగు)", "edge", "male", "te-IN", "telugu"),
    Voice("ml-IN-SobhanaNeural", "Sobhana (മലയാളം)", "edge", "female", "ml-IN", "malayalam"),
    Voice("mr-IN-AarohiNeural", "Aarohi (मराठी)", "edge", "female", "mr-IN", "marathi"),
    Voice("bn-IN-TanishaaNeural", "Tanishaa (বাংলা)", "edge", "female", "bn-IN", "bengali"),
    Voice("gu-IN-DhwaniNeural", "Dhwani (ગુજરાતી)", "edge", "female", "gu-IN", "gujarati"),
    Voice("ur-PK-UzmaNeural", "Uzma (اردو)", "edge", "female", "ur-PK", "urdu"),
    Voice("es-ES-ElviraNeural", "Elvira (ES)", "edge", "female", "es-ES", "spanish"),
    Voice("fr-FR-DeniseNeural", "Denise (FR)", "edge", "female", "fr-FR", "french"),
    Voice("de-DE-KatjaNeural", "Katja (DE)", "edge", "female", "de-DE", "german"),
    Voice("ja-JP-NanamiNeural", "Nanami (JP)", "edge", "female", "ja-JP", "japanese"),
    Voice("zh-CN-XiaoxiaoNeural", "Xiaoxiao (CN)", "edge", "female", "zh-CN", "chinese"),
    Voice("ar-SA-ZariyahNeural", "Zariyah (AR)", "edge", "female", "ar-SA", "arabic"),
    Voice("pt-BR-FranciscaNeural", "Francisca (BR)", "edge", "female", "pt-BR", "portuguese"),
    Voice("ru-RU-SvetlanaNeural", "Svetlana (RU)", "edge", "female", "ru-RU", "russian"),
    # OpenAI
    Voice("alloy", "Alloy", "openai", "neutral", "multi", "balanced"),
    Voice("nova", "Nova", "openai", "female", "multi", "bright"),
    Voice("shimmer", "Shimmer", "openai", "female", "multi", "warm"),
    Voice("onyx", "Onyx", "openai", "male", "multi", "deep"),
    Voice("echo", "Echo", "openai", "male", "multi", "clear"),
    Voice("fable", "Fable", "openai", "neutral", "multi", "expressive"),
    # ElevenLabs
    Voice("21m00Tcm4TlvDq8ikWAM", "Rachel", "elevenlabs", "female", "multi", "calm"),
    Voice("9BWtsMINqrJLrRacOk9x", "Aria", "elevenlabs", "female", "multi", "expressive"),
    Voice("EXAVITQu4vr4xnSDxMaL", "Bella", "elevenlabs", "female", "multi", "soft"),
    Voice("IKne3meq5aSn9XLyUdCD", "Charlie", "elevenlabs", "male", "multi", "natural"),
    Voice("JBFqnCBsd6RMkjVDRZzb", "George", "elevenlabs", "male", "multi", "british"),
    # local
    Voice("piper:en_US-lessac-medium", "Lessac (Piper, offline)", "piper", "female", "en-US", "offline", True),
    Voice("piper:en_GB-alba-medium", "Alba (Piper, offline)", "piper", "female", "en-GB", "offline", True),
    Voice("os-default", "Operating system voice", "system", "neutral", "auto", "offline", True),
]

VOICE_BY_ID: Dict[str, Voice] = {v.id: v for v in VOICES}

LANG_DEFAULTS = {
    "en": "en-US-AriaNeural", "en-US": "en-US-AriaNeural", "en-GB": "en-GB-SoniaNeural",
    "en-IN": "en-IN-NeerjaNeural", "hi": "hi-IN-SwaraNeural", "kn": "kn-IN-SapnaNeural",
    "ta": "ta-IN-PallaviNeural", "te": "te-IN-ShrutiNeural", "ml": "ml-IN-SobhanaNeural",
    "mr": "mr-IN-AarohiNeural", "bn": "bn-IN-TanishaaNeural", "gu": "gu-IN-DhwaniNeural",
    "ur": "ur-PK-UzmaNeural", "es": "es-ES-ElviraNeural", "fr": "fr-FR-DeniseNeural",
    "de": "de-DE-KatjaNeural", "ja": "ja-JP-NanamiNeural", "zh": "zh-CN-XiaoxiaoNeural",
    "ar": "ar-SA-ZariyahNeural", "pt": "pt-BR-FranciscaNeural", "ru": "ru-RU-SvetlanaNeural",
}


def pick_voice(language: str = "auto", gender: str = "", voice_id: str = "",
               style: str = "", prefer_local: bool = False) -> Voice:
    """Choose the best available voice for a language/gender/style request."""
    if voice_id and voice_id in VOICE_BY_ID:
        return VOICE_BY_ID[voice_id]
    lang = (language or "auto").strip()
    if lang in ("", "auto"):
        lang = settings.voice_language if settings.voice_language not in ("", "auto") else "en"
    base = LANG_DEFAULTS.get(lang) or LANG_DEFAULTS.get(lang.split("-")[0]) or "en-US-AriaNeural"
    candidates = [VOICE_BY_ID[base]]
    candidates += [v for v in VOICES if v.language.startswith(lang.split("-")[0])
                   and v.id != base]
    if prefer_local or not settings.cloud_enabled:
        local = [v for v in candidates if v.local]
        if local:
            candidates = local + candidates
    if gender in ("male", "female"):
        matched = [v for v in candidates if v.gender == gender]
        if matched:
            candidates = matched
    if style:
        matched = [v for v in candidates if style.lower() in v.style.lower()]
        if matched:
            candidates = matched
    return candidates[0]


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------
class TTSEngine:
    """Provider chain + voice settings + interruption control."""

    def __init__(self) -> None:
        self.voice_id: str = settings.voice_tts_voice
        self.gender: str = "female"
        self.language: str = settings.voice_language
        self.speed: float = float(settings.voice_tts_speed)
        self.pitch: str = "+0Hz"
        self.volume: str = "+0%"
        self.enabled: bool = settings.voice_enabled
        self.speaking: bool = False
        self.cancel_event = asyncio.Event()
        self.cancel_event.set()          # set == not cancelled
        self.last: Dict[str, Any] = {}
        self.history: List[Dict[str, Any]] = []
        self.stats = {"calls": 0, "chars": 0, "failures": 0, "by_provider": {}}
        OUT_DIR.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------------- config
    def configure(self, **values: Any) -> Dict[str, Any]:
        for key, value in values.items():
            if value is None:
                continue
            if key == "voice_id" and value in VOICE_BY_ID:
                self.voice_id = value
                self.gender = VOICE_BY_ID[value].gender
            elif key == "voice" and value in VOICE_BY_ID:
                self.voice_id = value
                self.gender = VOICE_BY_ID[value].gender
            elif key == "gender" and value in ("male", "female", "neutral"):
                self.gender = value
                self.voice_id = pick_voice(self.language, gender=value).id
            elif key == "language":
                self.language = value
                self.voice_id = pick_voice(value, gender=self.gender).id
            elif key == "speed":
                self.speed = max(0.5, min(2.0, float(value)))
            elif key == "pitch":
                self.pitch = value if str(value).startswith(("+", "-")) else f"+{value}"
            elif key == "volume":
                self.volume = value if str(value).startswith(("+", "-")) else f"+{value}"
            elif key == "enabled":
                self.enabled = bool(value)
        return self.state()

    def state(self) -> Dict[str, Any]:
        voice = VOICE_BY_ID.get(self.voice_id)
        return {
            "enabled": self.enabled, "speaking": self.speaking,
            "voice": voice.to_dict() if voice else {"id": self.voice_id},
            "voice_id": self.voice_id, "gender": self.gender, "language": self.language,
            "speed": self.speed, "pitch": self.pitch, "volume": self.volume,
            "providers": self.provider_status(), "stats": self.stats,
            "output_dir": str(OUT_DIR), "last": self.last,
        }

    def provider_status(self) -> Dict[str, Any]:
        has_edge = _module_available("edge_tts")
        return {
            "edge": {"available": has_edge and settings.cloud_enabled,
                     "note": "free Microsoft neural voices" if has_edge else "pip install edge-tts"},
            "openai": {"available": bool(settings.openai_api_key),
                       "note": "OPENAI_API_KEY"},
            "elevenlabs": {"available": bool(settings.elevenlabs_api_key),
                           "note": "ELEVENLABS_API_KEY"},
            "piper": {"available": _module_available("piper") and bool(_piper_voices()),
                      "note": "offline .onnx voices in data/voices/piper"},
            "system": {"available": _system_voice_command() is not None,
                       "note": _system_voice_command()[0] if _system_voice_command() else "none found"},
        }

    def voices(self, language: str = "", gender: str = "", provider: str = "") -> List[Dict[str, Any]]:
        out = []
        for v in VOICES:
            if language and not v.language.lower().startswith(language.lower().split("-")[0]):
                continue
            if gender and v.gender != gender:
                continue
            if provider and v.provider != provider:
                continue
            item = v.to_dict()
            item["active"] = v.id == self.voice_id
            out.append(item)
        return out

    # ----------------------------------------------------------------- speak
    async def speak(self, text: str, *, voice_id: str = "", language: str = "",
                    speed: Optional[float] = None, wait: bool = False,
                    style: str = "") -> Dict[str, Any]:
        text = _clean_for_speech(text)
        if not text:
            return {"ok": False, "error": "nothing to say"}
        if not self.enabled:
            return {"ok": False, "error": "voice output is disabled (VOICE_ENABLED=false)"}

        lang = language or self.language
        voice = pick_voice(lang, gender=self.gender, voice_id=voice_id or self.voice_id,
                           style=style, prefer_local=not settings.cloud_enabled)
        rate = float(speed if speed is not None else self.speed)
        self.cancel_event.clear()
        self.speaking = True
        emit(Topics.VOICE_SPEAKING, voice=voice.id, provider=voice.provider, chars=len(text),
             preview=text[:120])

        attempts: List[Dict[str, Any]] = []
        chain = _provider_chain(voice, prefer_local=not settings.cloud_enabled)
        result: Dict[str, Any] = {"ok": False, "error": "every TTS provider failed"}
        try:
            for provider in chain:
                if self.cancel_event.is_set():
                    result = {"ok": False, "error": "cancelled by the user (barge-in)",
                              "cancelled": True}
                    break
                try:
                    result = await provider(text, voice, rate, lang)
                except Exception as exc:
                    result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"[:300]}
                attempts.append({"provider": result.get("provider", provider.__name__),
                                 "ok": result.get("ok", False),
                                 "error": result.get("error")})
                if result.get("ok"):
                    break
        finally:
            self.speaking = False
            self.cancel_event.set()

        if result.get("ok"):
            result.update({"text": text, "chars": len(text), "voice": voice.id,
                           "voice_name": voice.name, "gender": voice.gender,
                           "language": lang, "speed": rate, "attempts": attempts})
            self.stats["calls"] += 1
            self.stats["chars"] += len(text)
            key = result.get("provider", "unknown")
            self.stats["by_provider"][key] = self.stats["by_provider"].get(key, 0) + 1
            self.last = {k: result.get(k) for k in ("path", "provider", "voice", "bytes",
                                                    "duration_ms", "chars")}
            self.history.append(self.last)
            self.history = self.history[-20:]
            _prune()
            emit(Topics.VOICE_STOPPED, ok=True, provider=key, path=result.get("path"))
        else:
            self.stats["failures"] += 1
            result["attempts"] = attempts
            result["hint"] = _install_hint()
            emit(Topics.VOICE_STOPPED, ok=False, error=result.get("error"))
        return result

    def stop(self) -> Dict[str, Any]:
        """Barge-in: stop the current utterance."""
        self.cancel_event.set()
        self.speaking = False
        emit(Topics.VOICE_STOPPED, ok=True, reason="user interruption")
        return {"ok": True, "stopped": True}

    async def preview(self, text: str = "Hi, I'm SAM. How can I help?",
                      voice_id: str = "") -> Dict[str, Any]:
        return await self.speak(text, voice_id=voice_id)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _module_available(name: str) -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def _piper_voices() -> List[Path]:
    d = Path(settings.piper_voice_dir)
    return sorted(d.glob("*.onnx")) if d.exists() else []


def _system_voice_command() -> Optional[Tuple[str, ...]]:
    system = platform.system()
    if system == "Darwin" and shutil.which("say"):
        return ("say",)
    if system == "Windows":
        return ("powershell",)
    for exe in ("espeak-ng", "espeak", "spd-say", "festival"):
        if shutil.which(exe):
            return (exe,)
    return None


def _provider_chain(voice: Voice, prefer_local: bool = False) -> List[Any]:
    """Order the providers to try, honouring the requested voice."""
    order: List[Any] = []
    if voice.provider == "edge":
        order += [_edge_tts]
    elif voice.provider == "openai":
        order += [_openai_tts]
    elif voice.provider == "elevenlabs":
        order += [_elevenlabs_tts]
    elif voice.provider == "piper":
        order += [_piper_tts]
    elif voice.provider == "system":
        order += [_system_tts]

    if settings.voice_tts_provider not in ("auto", voice.provider):
        explicit = {"edge": _edge_tts, "openai": _openai_tts, "elevenlabs": _elevenlabs_tts,
                    "piper": _piper_tts, "system": _system_tts}.get(settings.voice_tts_provider)
        if explicit:
            order.insert(0, explicit)

    if prefer_local:
        order += [_piper_tts, _system_tts, _edge_tts, _openai_tts]
    else:
        order += [_edge_tts, _openai_tts, _elevenlabs_tts, _piper_tts, _system_tts]

    seen: set = set()
    unique: List[Any] = []
    for fn in order:
        if fn not in seen:
            seen.add(fn)
            unique.append(fn)
    return unique


def _clean_for_speech(text: str) -> str:
    """Strip Markdown, code blocks, URLs and emoji — they read terribly aloud."""
    t = text or ""
    t = re.sub(r"```.*?```", " Code block omitted. ", t, flags=re.S)
    t = re.sub(r"`([^`]+)`", r"\1", t)
    t = re.sub(r"!?\[([^\]]*)\]\([^)]+\)", r"\1", t)
    t = re.sub(r"https?://\S+", " link ", t)
    t = re.sub(r"<[^>]+>", " ", t)
    t = re.sub(r"[#*_>|~\-]{2,}", " ", t)
    t = re.sub(r"^\s*[-*]\s+", "", t, flags=re.M)
    t = re.sub(r"[^\w\s.,;:!?%°+/'()\u0900-\u097F\u0C80-\u0CFF\u0B80-\u0BFF-]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t[:4000]


def _install_hint() -> str:
    if not _module_available("edge_tts"):
        return ("Install a TTS provider: `pip install edge-tts` (free neural voices, needs "
                "internet), or download a Piper voice into data/voices/piper for offline use, "
                "or set OPENAI_API_KEY / ELEVENLABS_API_KEY in .env")
    if not settings.cloud_enabled:
        return "Cloud providers are disabled by Privacy Mode — add a Piper voice to data/voices/piper"
    return "Check the network connection and the provider keys in .env"


def _out_path(ext: str = ".mp3") -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUT_DIR / f"sam_tts_{int(time.time() * 1000)}{ext}"


def _prune() -> None:
    try:
        files = sorted(OUT_DIR.glob("sam_tts_*"), key=lambda p: p.stat().st_mtime)
        for old in files[:-MAX_FILES]:
            old.unlink(missing_ok=True)
    except OSError:
        pass


def _duration_ms(path: Path) -> int:
    try:
        if path.suffix.lower() == ".wav":
            with wave.open(str(path), "rb") as wf:
                return int(wf.getnframes() / max(wf.getframerate(), 1) * 1000)
        from PIL import Image  # noqa: F401  (only to keep the import surface small)
    except Exception:
        pass
    try:
        import mutagen  # type: ignore

        audio = mutagen.File(str(path))
        if audio and audio.info and getattr(audio.info, "length", None):
            return int(audio.info.length * 1000)
    except Exception:
        pass
    return 0


def _ok(path: Path, provider: str, voice: str, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    result = {"ok": True, "path": str(path), "file": path.name, "provider": provider,
              "voice": voice, "bytes": path.stat().st_size, "format": path.suffix.lstrip("."),
              "duration_ms": _duration_ms(path), "created_at": time.time()}
    if extra:
        result.update(extra)
    return result


# ---------------------------------------------------------------------------
# providers
# ---------------------------------------------------------------------------
async def _edge_tts(text: str, voice: Voice, rate: float, lang: str) -> Dict[str, Any]:
    if not _module_available("edge_tts"):
        return {"ok": False, "provider": "edge", "error": "edge-tts is not installed"}
    if not settings.cloud_enabled and settings.privacy_cloud_ai:
        return {"ok": False, "provider": "edge", "error": "blocked by Privacy Mode"}
    import edge_tts  # type: ignore

    target = voice.id if voice.provider == "edge" else \
        pick_voice(lang, gender=voice.gender).id
    percent = int(round((rate - 1.0) * 100))
    communicate = edge_tts.Communicate(text, target,
                                       rate=f"{percent:+d}%", pitch=voice_pitch(),
                                       volume="+0%")
    path = _out_path(".mp3")
    await communicate.save(str(path))
    if not path.exists() or path.stat().st_size < 512:
        return {"ok": False, "provider": "edge", "error": "edge-tts produced no audio"}
    return _ok(path, "edge", target)


def voice_pitch() -> str:
    return "+0Hz"


async def _openai_tts(text: str, voice: Voice, rate: float, lang: str) -> Dict[str, Any]:
    if not settings.openai_api_key:
        return {"ok": False, "provider": "openai", "error": "OPENAI_API_KEY is not set"}
    try:
        from openai import AsyncOpenAI  # type: ignore
    except ImportError:
        return {"ok": False, "provider": "openai", "error": "the openai package is not installed"}
    client = AsyncOpenAI(api_key=settings.openai_api_key, base_url=settings.openai_base_url)
    name = voice.id if voice.provider == "openai" else \
        ("nova" if voice.gender == "female" else "onyx")
    try:
        speech = await client.audio.speech.with_raw_response.create(
            model="gpt-4o-mini-tts", voice=name, input=text[:4000], speed=max(0.5, min(2.0, rate)),
        )
        path = _out_path(".mp3")
        path.write_bytes(await speech.read())
    except Exception as exc:
        # older API shape
        try:
            speech = await client.audio.speech.create(model="tts-1", voice=name,
                                                      input=text[:4000],
                                                      speed=max(0.5, min(2.0, rate)))
            path = _out_path(".mp3")
            path.write_bytes(speech.content)
        except Exception as exc2:
            return {"ok": False, "provider": "openai", "error": f"{exc}"[:200] or f"{exc2}"[:200]}
    if path.stat().st_size < 512:
        return {"ok": False, "provider": "openai", "error": "OpenAI returned empty audio"}
    return _ok(path, "openai", name)


async def _elevenlabs_tts(text: str, voice: Voice, rate: float, lang: str) -> Dict[str, Any]:
    if not settings.elevenlabs_api_key:
        return {"ok": False, "provider": "elevenlabs", "error": "ELEVENLABS_API_KEY is not set"}
    import httpx

    vid = voice.id if voice.provider == "elevenlabs" else "21m00Tcm4TlvDq8ikWAM"
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{vid}"
    payload = {"text": text[:4000], "model_id": "eleven_multilingual_v2",
               "voice_settings": {"stability": 0.45, "similarity_boost": 0.75,
                                  "speed": max(0.7, min(1.2, rate))}}
    try:
        async with httpx.AsyncClient(timeout=90.0) as client:
            r = await client.post(url, json=payload,
                                  headers={"xi-api-key": settings.elevenlabs_api_key,
                                           "Accept": "audio/mpeg"})
        if r.status_code != 200:
            return {"ok": False, "provider": "elevenlabs",
                    "error": f"HTTP {r.status_code}: {r.text[:180]}"}
        path = _out_path(".mp3")
        path.write_bytes(r.content)
    except Exception as exc:
        return {"ok": False, "provider": "elevenlabs", "error": str(exc)[:200]}
    return _ok(path, "elevenlabs", vid)


async def _piper_tts(text: str, voice: Voice, rate: float, lang: str) -> Dict[str, Any]:
    voices = _piper_voices()
    if not voices:
        return {"ok": False, "provider": "piper",
                "error": f"no Piper voices in {settings.piper_voice_dir}"}
    exe = shutil.which("piper")
    model = voices[0]
    path = _out_path(".wav")
    try:
        if exe:
            proc = await asyncio.create_subprocess_exec(
                exe, "--model", str(model), "--output_file", str(path),
                "--length_scale", str(round(1.0 / max(0.5, rate), 3)),
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            _, err = await proc.communicate(text.encode("utf-8"))
            if proc.returncode != 0:
                return {"ok": False, "provider": "piper",
                        "error": (err or b"").decode(errors="replace")[:200]}
        else:
            from piper import PiperVoice  # type: ignore

            piper_voice = PiperVoice.load(str(model))
            with wave.open(str(path), "wb") as wf:
                piper_voice.synthesize_wav(text, wf)
    except Exception as exc:
        return {"ok": False, "provider": "piper", "error": str(exc)[:200]}
    if not path.exists() or path.stat().st_size < 1024:
        return {"ok": False, "provider": "piper", "error": "Piper produced no audio"}
    return _ok(path, "piper", model.name)


async def _system_tts(text: str, voice: Voice, rate: float, lang: str) -> Dict[str, Any]:
    cmd = _system_voice_command()
    if cmd is None:
        return {"ok": False, "provider": "system", "error": "no system voice engine found"}
    from backend.app.tools.system_tools import _run

    system = platform.system()
    safe = text.replace('"', "'").replace("\n", " ")[:1500]
    if system == "Darwin":
        out = _out_path(".aiff")
        args = ["say", "-o", str(out)]
        if rate != 1.0:
            args += ["-r", str(int(175 * rate))]
        args += [safe]
    elif system == "Windows":
        out = _out_path(".wav")
        ps = (
            "Add-Type -AssemblyName System.Speech;"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            f"$s.Rate = {int(round((rate - 1.0) * 5))};"
            f"$s.SetOutputToWaveFile('{out.as_posix()}');"
            f"$s.Speak('{safe.replace(chr(39), chr(39) * 2)}');"
            "$s.Dispose()"
        )
        args = ["powershell", "-NoProfile", "-Command", ps]
    else:
        out = _out_path(".wav")
        exe = cmd[0]
        if exe == "espeak-ng" or exe == "espeak":
            args = [exe, "-w", str(out), "-s", str(int(165 * rate)), safe]
        elif exe == "spd-say":
            args = [exe, "-w", safe]
        else:
            args = [exe, safe]
            out = _out_path(".txt")

    try:
        res = await _run(args, timeout=120)
    except Exception as exc:
        return {"ok": False, "provider": "system", "error": str(exc)[:200]}
    if out.exists() and out.stat().st_size > 1024:
        return _ok(out, "system", exe_name(cmd), {"warning": "OS voice — quality is basic"})
    return {"ok": False, "provider": "system",
            "error": res.get("stderr") or res.get("error") or "no audio was produced"}


def exe_name(cmd: Tuple[str, ...]) -> str:
    return Path(cmd[0]).name


tts_engine = TTSEngine()
