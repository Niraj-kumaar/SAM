"""
backend.app.browser.engine
==========================

The Browser Agent's automation engine.

Two transports:

``playwright``  full automation: launch a real browser profile, navigate, read
                the DOM, extract structured data, fill forms, click, download.
``cdp``         attach to a Chrome/Edge instance the user already started with
                ``--remote-debugging-port=9222`` — this keeps the user's real
                logged-in sessions and never hands credentials to SAM.

Session policy (from the spec): browser operations stay inside the user's own
authenticated session and permissions. SAM never asks for, stores, or types a
password unless the user explicitly enables ``browser.credentials`` and
confirms each time.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse

from backend.app.config import settings
from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger

log = get_logger("browser.engine")


@dataclass
class PageSnapshot:
    url: str = ""
    title: str = ""
    text: str = ""
    html_length: int = 0
    links: List[Dict[str, str]] = field(default_factory=list)
    headings: List[str] = field(default_factory=list)
    tables: List[List[List[str]]] = field(default_factory=list)
    forms: List[Dict[str, Any]] = field(default_factory=list)
    images: List[Dict[str, str]] = field(default_factory=list)
    meta: Dict[str, Any] = field(default_factory=dict)
    screenshot: Optional[str] = None
    took_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url, "title": self.title, "text_length": len(self.text),
            "text": self.text[:20000], "html_length": self.html_length,
            "links": self.links[:80], "headings": self.headings[:40],
            "tables": self.tables[:10], "forms": self.forms[:10],
            "images": self.images[:20], "meta": self.meta,
            "screenshot": self.screenshot, "took_ms": self.took_ms,
        }


class BrowserEngine:
    """Lazy-initialised Playwright/CDP controller."""

    def __init__(self) -> None:
        self._pw: Any = None
        self._browser: Any = None
        self._context: Any = None
        self._page: Any = None
        self._lock = asyncio.Lock()
        self._started = False
        self.history: List[Dict[str, Any]] = []
        self.last_error: str = ""

    # ------------------------------------------------------------------ life
    async def start(self) -> Dict[str, Any]:
        if not settings.browser_enabled:
            return {"ok": False, "error": "browser layer disabled (BROWSER_ENABLED=false)"}
        async with self._lock:
            if self._started and self._browser is not None:
                return {"ok": True, "already_running": True, "transport": settings.browser_provider}
            try:
                from playwright.async_api import async_playwright
            except ImportError:
                self.last_error = ("Playwright is not installed. Run: "
                                   "pip install playwright && playwright install chromium")
                return {"ok": False, "error": self.last_error}

            try:
                self._pw = await async_playwright().start()
                if settings.browser_provider == "cdp" and settings.browser_cdp_url:
                    self._browser = await self._pw.chromium.connect_over_cdp(settings.browser_cdp_url)
                    self._context = self._browser.contexts[0] if self._browser.contexts else \
                        await self._browser.new_context()
                    transport = "cdp"
                else:
                    profile = Path(settings.browser_user_data_dir)
                    profile.mkdir(parents=True, exist_ok=True)
                    launch_kwargs: Dict[str, Any] = {
                        "headless": settings.browser_headless,
                        "args": ["--disable-blink-features=AutomationControlled",
                                 "--no-first-run", "--no-default-browser-check"],
                    }
                    browser_type = self._pw.chromium
                    if settings.browser_channel and settings.browser_channel != "chromium":
                        launch_kwargs["channel"] = settings.browser_channel
                    try:
                        self._browser = await browser_type.launch(**launch_kwargs)
                    except Exception:
                        launch_kwargs.pop("channel", None)
                        self._browser = await browser_type.launch(**launch_kwargs)
                    self._context = await self._browser.new_context(
                        viewport={"width": 1440, "height": 900},
                        locale="en-US",
                        user_agent=None,
                    )
                    transport = "playwright"

                pages = self._context.pages
                self._page = pages[0] if pages else await self._context.new_page()
                self._started = True
                self.last_error = ""
                emit(Topics.DEVICE_ONLINE, device="browser", transport=transport)
                log.info("browser started (%s)", transport)
                return {"ok": True, "transport": transport,
                        "headless": settings.browser_headless,
                        "url": self._page.url if self._page else ""}
            except Exception as exc:
                self.last_error = str(exc)
                log.warning("browser start failed: %s", exc)
                await self._teardown()
                hint = ""
                if "Executable doesn't exist" in str(exc) or "browsers" in str(exc).lower():
                    hint = " Run: playwright install chromium"
                return {"ok": False, "error": f"{exc}{hint}"}

    async def stop(self) -> Dict[str, Any]:
        async with self._lock:
            await self._teardown()
        emit(Topics.DEVICE_OFFLINE, device="browser")
        return {"ok": True}

    async def _teardown(self) -> None:
        for closer in (self._context, self._browser):
            try:
                if closer is not None:
                    await closer.close()
            except Exception:
                pass
        try:
            if self._pw is not None:
                await self._pw.stop()
        except Exception:
            pass
        self._context = self._browser = self._page = self._pw = None
        self._started = False

    async def status(self) -> Dict[str, Any]:
        running = self._started and self._browser is not None
        info: Dict[str, Any] = {
            "ok": True, "running": running, "enabled": settings.browser_enabled,
            "provider": settings.browser_provider, "headless": settings.browser_headless,
            "channel": settings.browser_channel, "history": self.history[-20:],
            "last_error": self.last_error,
        }
        if running and self._page is not None:
            try:
                info["url"] = self._page.url
                info["title"] = await self._page.title()
                info["tabs"] = [p.url for p in self._context.pages]
            except Exception:
                pass
        return info

    async def _ensure(self) -> Optional[str]:
        """Return an error string if the browser cannot be started."""
        if self._started and self._page is not None:
            return None
        res = await self.start()
        return None if res.get("ok") else res.get("error", "browser unavailable")

    # ------------------------------------------------------------------ nav
    async def navigate(self, url: str, *, wait: str = "domcontentloaded",
                       timeout: int = 45_000) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        url = normalize_url(url)
        t0 = time.time()
        try:
            response = await self._page.goto(url, wait_until=wait, timeout=timeout)
            title = await self._page.title()
            final = self._page.url
            self._record("navigate", final, title)
            return {
                "ok": True, "url": final, "requested": url, "title": title,
                "status": response.status if response else None,
                "took_ms": int((time.time() - t0) * 1000),
            }
        except Exception as exc:
            self.last_error = str(exc)
            return {"ok": False, "error": str(exc)[:400], "url": url}

    async def reload(self) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            await self._page.reload(wait_until="domcontentloaded")
            return {"ok": True, "url": self._page.url}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    async def back(self) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            await self._page.go_back(wait_until="domcontentloaded")
            return {"ok": True, "url": self._page.url}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    # ----------------------------------------------------------------- tabs
    async def tabs(self) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        out = []
        for i, p in enumerate(self._context.pages):
            try:
                out.append({"index": i, "url": p.url, "title": await p.title(),
                            "active": p is self._page})
            except Exception:
                out.append({"index": i, "url": "", "title": ""})
        return {"ok": True, "count": len(out), "tabs": out}

    async def new_tab(self, url: str = "") -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            page = await self._context.new_page()
            self._page = page
            if url:
                return await self.navigate(url)
            return {"ok": True, "url": page.url}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    async def switch_tab(self, index: int) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        pages = self._context.pages
        if not 0 <= index < len(pages):
            return {"ok": False, "error": f"tab index {index} out of range (0..{len(pages) - 1})"}
        self._page = pages[index]
        await self._page.bring_to_front()
        return {"ok": True, "index": index, "url": self._page.url}

    async def close_tab(self, index: Optional[int] = None) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        pages = self._context.pages
        if len(pages) <= 1:
            return {"ok": False, "error": "cannot close the last tab"}
        target = pages[index] if index is not None else self._page
        try:
            await target.close()
            self._page = self._context.pages[-1]
            return {"ok": True, "remaining": len(self._context.pages)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    # ----------------------------------------------------------------- read
    async def snapshot(self, *, include_screenshot: bool = False,
                       max_text: int = 200_000) -> PageSnapshot:
        err = await self._ensure()
        snap = PageSnapshot()
        if err:
            snap.meta = {"error": err}
            return snap
        t0 = time.time()
        page = self._page
        snap.url = page.url
        try:
            snap.title = await page.title()
        except Exception:
            pass
        try:
            data = await page.evaluate(
                """() => {
  const clean = (s) => (s || '').replace(/\\s+/g, ' ').trim();
  const skip = new Set(['SCRIPT','STYLE','NOSCRIPT','TEMPLATE','SVG','CANVAS']);
  const text = clean(document.body ? document.body.innerText : '');
  const headings = Array.from(document.querySelectorAll('h1,h2,h3')).slice(0,60)
      .map(h => ({ level: h.tagName, text: clean(h.innerText) })).filter(h => h.text);
  const links = Array.from(document.querySelectorAll('a[href]')).slice(0,300)
      .map(a => ({ text: clean(a.innerText).slice(0,120), href: a.href }))
      .filter(l => l.href && !l.href.startsWith('javascript'));
  const images = Array.from(document.querySelectorAll('img[src]')).slice(0,60)
      .map(i => ({ src: i.src, alt: clean(i.alt).slice(0,120) }));
  const tables = Array.from(document.querySelectorAll('table')).slice(0,10).map(t =>
      Array.from(t.rows).slice(0,60).map(r =>
          Array.from(r.cells).slice(0,20).map(c => clean(c.innerText).slice(0,200))));
  const forms = Array.from(document.querySelectorAll('form')).slice(0,10).map(f => ({
      action: f.action || '', method: f.method || 'GET',
      fields: Array.from(f.querySelectorAll('input,textarea,select')).slice(0,40).map(el => ({
          tag: el.tagName.toLowerCase(), type: el.type || '', name: el.name || '',
          id: el.id || '', placeholder: el.placeholder || '',
          label: clean((el.labels && el.labels[0] && el.labels[0].innerText) || ''),
          required: !!el.required, value: (el.type === 'password' ? '' : (el.value || '').slice(0,80))
      }))
  }));
  const meta = {};
  document.querySelectorAll('meta[name],meta[property]').forEach(m => {
      const k = m.getAttribute('name') || m.getAttribute('property');
      if (k && ['description','keywords','author','og:title','og:description','twitter:title']
          .includes(k)) meta[k] = clean(m.getAttribute('content')).slice(0,400);
  });
  return { text, headings, links, images, tables, forms, meta,
           htmlLength: document.documentElement.outerHTML.length,
           scrollHeight: document.documentElement.scrollHeight };
}"""
            )
            snap.text = (data.get("text") or "")[:max_text]
            snap.headings = [f"{h['level']}: {h['text']}" for h in data.get("headings", [])]
            snap.links = data.get("links", [])
            snap.images = data.get("images", [])
            snap.tables = data.get("tables", [])
            snap.forms = data.get("forms", [])
            snap.meta = data.get("meta", {})
            snap.meta["scroll_height"] = data.get("scrollHeight")
            snap.html_length = data.get("htmlLength", 0)
        except Exception as exc:
            snap.meta["evaluate_error"] = str(exc)[:300]

        if include_screenshot:
            try:
                shot_dir = settings.sam_data_dir / "cache" / "browser"
                shot_dir.mkdir(parents=True, exist_ok=True)
                path = shot_dir / f"page_{int(time.time() * 1000)}.png"
                await page.screenshot(path=str(path), full_page=False)
                snap.screenshot = str(path)
            except Exception as exc:
                snap.meta["screenshot_error"] = str(exc)[:200]

        snap.took_ms = int((time.time() - t0) * 1000)
        self._record("snapshot", snap.url, snap.title)
        return snap

    async def extract(self, *, selector: str = "", kind: str = "text",
                      limit: int = 200) -> Dict[str, Any]:
        """Pull structured data out of the current page."""
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        page = self._page
        try:
            if selector:
                elements = await page.query_selector_all(selector)
                out: List[Any] = []
                for el in elements[:limit]:
                    if kind == "html":
                        out.append(await el.inner_html())
                    elif kind == "attribute":
                        out.append(await el.get_attribute("href") or await el.get_attribute("src"))
                    else:
                        out.append((await el.inner_text()).strip())
                return {"ok": True, "selector": selector, "count": len(out), "items": out}

            if kind == "links":
                data = await page.evaluate(
                    """() => Array.from(document.querySelectorAll('a[href]'))
                        .map(a => ({ text: (a.innerText||'').trim().slice(0,150), href: a.href }))
                        .filter(x => x.href && !x.href.startsWith('javascript'))"""
                )
                return {"ok": True, "kind": "links", "count": len(data), "items": data[:limit]}
            if kind == "table":
                data = await page.evaluate(
                    """() => {
      const t = document.querySelector('table'); if (!t) return null;
      return Array.from(t.rows).map(r => Array.from(r.cells).map(c => (c.innerText||'').trim()));
    }"""
                )
                return {"ok": True, "kind": "table", "rows": len(data or []), "items": data or []}
            if kind == "json_ld":
                data = await page.evaluate(
                    """() => Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
                        .map(s => s.textContent).slice(0, 20)"""
                )
                parsed = []
                for raw in data or []:
                    try:
                        parsed.append(json.loads(raw))
                    except Exception:
                        continue
                return {"ok": True, "kind": "json_ld", "count": len(parsed), "items": parsed}

            text = await page.evaluate("() => (document.body ? document.body.innerText : '')")
            return {"ok": True, "kind": "text", "length": len(text), "text": text[:200_000]}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:400]}

    # ------------------------------------------------------------- interact
    async def click(self, *, selector: str = "", text: str = "", index: int = 0,
                    timeout: int = 15_000) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        page = self._page
        try:
            if selector:
                loc = page.locator(selector).nth(index)
                await loc.click(timeout=timeout)
                target = selector
            elif text:
                loc = page.get_by_text(text, exact=False).nth(index)
                await loc.click(timeout=timeout)
                target = f"text='{text}'"
            else:
                return {"ok": False, "error": "click needs a selector or text"}
            await page.wait_for_load_state("domcontentloaded", timeout=timeout)
            self._record("click", page.url, target)
            return {"ok": True, "target": target, "url": page.url}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:400]}

    async def type_text(self, *, selector: str, text: str = "", fill: bool = True,
                        press_enter: bool = False, clear: bool = True) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        page = self._page
        try:
            loc = page.locator(selector).first
            if fill:
                await loc.fill("" if clear else text)
                if not clear:
                    await loc.type(text, delay=15)
            else:
                if clear:
                    await loc.fill("")
                await loc.type(text, delay=15)
            if press_enter:
                await loc.press("Enter")
                await page.wait_for_load_state("domcontentloaded")
            self._record("type", page.url, selector)
            return {"ok": True, "selector": selector, "chars": len(text), "entered": press_enter,
                    "url": page.url}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:400]}

    async def fill_form(self, fields: Dict[str, str], *, submit: bool = False,
                        submit_selector: str = "") -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        page = self._page
        filled, failed = [], []
        for selector, value in fields.items():
            try:
                loc = page.locator(selector).first
                tag = (await loc.evaluate("el => el.tagName") or "").lower()
                if tag == "select":
                    await loc.select_option(label=str(value))
                elif await loc.get_attribute("type") in ("checkbox", "radio"):
                    if str(value).lower() in ("true", "1", "yes", "on", "check"):
                        await loc.check()
                    else:
                        await loc.uncheck()
                else:
                    await loc.fill(str(value))
                filled.append(selector)
            except Exception as exc:
                failed.append({"selector": selector, "error": str(exc)[:200]})
        submitted = False
        if submit:
            try:
                if submit_selector:
                    await page.locator(submit_selector).first.click()
                else:
                    await page.locator("form button[type=submit], form input[type=submit]").first.click()
                await page.wait_for_load_state("domcontentloaded", timeout=20_000)
                submitted = True
            except Exception as exc:
                failed.append({"selector": "<submit>", "error": str(exc)[:200]})
        self._record("fill_form", page.url, ",".join(filled))
        return {"ok": not failed, "filled": filled, "failed": failed, "submitted": submitted,
                "url": page.url}

    async def select_option(self, selector: str, *, value: str = "", label: str = "",
                            index: Optional[int] = None) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            loc = self._page.locator(selector).first
            if label:
                await loc.select_option(label=label)
            elif index is not None:
                await loc.select_option(index=index)
            else:
                await loc.select_option(value=value)
            return {"ok": True, "selector": selector, "chosen": label or value or index}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    async def scroll(self, direction: str = "down", amount: int = 800) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        delta = abs(amount) * (1 if direction == "down" else -1)
        try:
            await self._page.evaluate(f"window.scrollBy(0, {delta})")
            pos = await self._page.evaluate("() => window.scrollY")
            return {"ok": True, "direction": direction, "scroll_y": pos}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    async def press(self, key: str) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            await self._page.keyboard.press(key)
            return {"ok": True, "key": key}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    async def wait_for(self, selector: str = "", state: str = "visible",
                       timeout: int = 20_000, text: str = "") -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            if selector:
                await self._page.wait_for_selector(selector, state=state, timeout=timeout)
            if text:
                await self._page.wait_for_function(
                    f"document.body && document.body.innerText.includes({json.dumps(text)})",
                    timeout=timeout,
                )
            return {"ok": True, "selector": selector, "text": text}
        except Exception as exc:
            return {"ok": False, "error": f"timed out waiting: {str(exc)[:250]}"}

    async def screenshot(self, full_page: bool = False) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            shot_dir = settings.sam_data_dir / "cache" / "browser"
            shot_dir.mkdir(parents=True, exist_ok=True)
            path = shot_dir / f"shot_{int(time.time() * 1000)}.png"
            await self._page.screenshot(path=str(path), full_page=full_page)
            return {"ok": True, "path": str(path), "bytes": path.stat().st_size,
                    "url": self._page.url, "full_page": full_page}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    async def download(self, selector: str = "", url: str = "",
                       save_dir: Optional[str] = None) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        target = Path(save_dir or (settings.allowed_roots[0] if settings.allowed_roots
                                   else Path.home() / "Downloads"))
        target.mkdir(parents=True, exist_ok=True)
        try:
            if url:
                async with self._page.expect_download(timeout=60_000) as info:
                    await self._page.evaluate(f"window.location.href = {json.dumps(url)}")
                download = await info.value
            elif selector:
                async with self._page.expect_download(timeout=60_000) as info:
                    await self._page.locator(selector).first.click()
                download = await info.value
            else:
                return {"ok": False, "error": "download needs a selector or url"}
            suggested = download.suggested_filename or f"download_{int(time.time())}"
            path = target / suggested
            await download.save_as(str(path))
            self._record("download", str(path), suggested)
            return {"ok": True, "path": str(path), "bytes": path.stat().st_size,
                    "suggested_filename": suggested}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:400]}

    async def bookmarks(self, action: str = "list", *, title: str = "", url: str = "",
                        folder: str = "") -> Dict[str, Any]:
        """Read/add bookmarks in a SAM-managed JSON file (browser-safe)."""
        store = settings.sam_data_dir / "browser-profile" / "sam_bookmarks.json"
        store.parent.mkdir(parents=True, exist_ok=True)
        data: List[Dict[str, Any]] = []
        if store.exists():
            try:
                data = json.loads(store.read_text(encoding="utf-8"))
            except Exception:
                data = []
        action = action.lower()
        if action == "add":
            if not url:
                err = await self._ensure()
                if err:
                    return {"ok": False, "error": err}
                url = self._page.url
                title = title or await self._page.title()
            data.append({"title": title or url, "url": url, "folder": folder or "SAM",
                         "added": time.strftime("%Y-%m-%dT%H:%M:%S")})
            store.write_text(json.dumps(data, indent=2), encoding="utf-8")
            return {"ok": True, "action": "add", "count": len(data), "entry": data[-1]}
        if action == "remove":
            before = len(data)
            data = [b for b in data if b.get("url") != url and b.get("title") != title]
            store.write_text(json.dumps(data, indent=2), encoding="utf-8")
            return {"ok": True, "action": "remove", "removed": before - len(data)}
        return {"ok": True, "action": "list", "count": len(data), "bookmarks": data}

    async def page_info(self) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            info = await self._page.evaluate(
                """() => ({ url: location.href, title: document.title,
      description: (document.querySelector('meta[name=description]')||{}).content || '',
      canonical: (document.querySelector('link[rel=canonical]')||{}).href || '',
      language: document.documentElement.lang || '',
      wordCount: ((document.body && document.body.innerText || '').split(/\\s+/).length),
      links: document.querySelectorAll('a').length,
      images: document.querySelectorAll('img').length,
      readyState: document.readyState })"""
            )
            return {"ok": True, **info}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    async def evaluate_js(self, expression: str) -> Dict[str, Any]:
        err = await self._ensure()
        if err:
            return {"ok": False, "error": err}
        try:
            value = await self._page.evaluate(expression)
            return {"ok": True, "result": _json_safe(value)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:400]}

    # -------------------------------------------------------------- helpers
    def _record(self, action: str, url: str, detail: str = "") -> None:
        entry = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "action": action,
                 "url": url[:300], "detail": str(detail)[:200]}
        self.history.append(entry)
        if len(self.history) > 200:
            self.history = self.history[-200:]
        emit(Topics.DEVICE_STATE, device="browser", action=action, url=url[:200])


def _json_safe(value: Any) -> Any:
    try:
        json.dumps(value)
        return value
    except Exception:
        return str(value)


SEARCH_ENGINES = {
    "google": "https://www.google.com/search?q={q}",
    "bing": "https://www.bing.com/search?q={q}",
    "duckduckgo": "https://duckduckgo.com/?q={q}",
    "ddg": "https://duckduckgo.com/?q={q}",
    "youtube": "https://www.youtube.com/results?search_query={q}",
    "github": "https://github.com/search?q={q}",
    "wikipedia": "https://en.wikipedia.org/w/index.php?search={q}",
    "wiki": "https://en.wikipedia.org/w/index.php?search={q}",
    "arxiv": "https://arxiv.org/abs/{q}",
    "stackoverflow": "https://stackoverflow.com/search?q={q}",
    "reddit": "https://www.reddit.com/search/?q={q}",
    "amazon": "https://www.amazon.in/s?k={q}",
    "news": "https://news.google.com/search?q={q}",
    "scholar": "https://scholar.google.com/scholar?q={q}",
    "maps": "https://www.google.com/maps/search/{q}",
}


def normalize_url(url: str) -> str:
    """Turn "github" or "search python" into a real URL."""
    url = (url or "").strip()
    if not url:
        return "about:blank"
    if url in ("about:blank", "chrome://newtab"):
        return url
    # engine:query  /  engine query
    m = re.match(r"^(google|bing|duckduckgo|ddg|youtube|github|wikipedia|wiki|arxiv|"
                 r"stackoverflow|reddit|amazon|news|scholar|maps)\s*[:\-]?\s+(.+)$", url, re.I)
    if m:
        engine, query = m.group(1).lower(), m.group(2)
        template = SEARCH_ENGINES.get(engine)
        if template:
            from urllib.parse import quote_plus

            return template.format(q=quote_plus(query))
    if re.match(r"^https?://", url, re.I):
        return url
    if re.match(r"^[\w-]+(\.[\w-]+)+(/.*)?$", url):
        return "https://" + url
    # bare words -> search
    from urllib.parse import quote_plus

    return SEARCH_ENGINES["google"].format(q=quote_plus(url))


def readable_text(html: str) -> str:
    """Strip HTML to readable text without a headless browser."""
    html = re.sub(r"(?is)<(script|style|noscript|template|svg)[^>]*>.*?</\1>", " ", html)
    html = re.sub(r"(?i)<br\s*/?>", "\n", html)
    html = re.sub(r"(?i)</(p|div|li|h[1-6]|tr|section|article)>", "\n", html)
    html = re.sub(r"(?i)<li[^>]*>", "• ", html)
    text = re.sub(r"<[^>]+>", " ", html)
    import html as _html

    text = _html.unescape(text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
    return text.strip()


browser_engine = BrowserEngine()
