"""
backend.app.files.file_ops
==========================

Low-level, safety-checked file operations.

Every function validates the path against the **allowed roots** and the
**denied patterns** from ``.env`` before touching anything, so even a bug in an
agent cannot make SAM read ``~/.ssh/id_rsa``.

    FILES_ALLOWED_ROOTS=~/Documents,~/Downloads,~/Desktop,~/Pictures
    FILES_DENIED_PATTERNS=**/.ssh/**,**/.aws/**,**/wallet*.dat
"""

from __future__ import annotations

import fnmatch
import hashlib
import mimetypes
import os
import re
import shutil
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger

log = get_logger("files.ops")


class FileSecurityError(PermissionError):
    """Raised when a path is outside the sandbox or matches a deny pattern."""


# ---------------------------------------------------------------------------
# Path safety
# ---------------------------------------------------------------------------
def _project_root() -> Path:
    return settings.sam_data_dir.parent


def is_allowed(path: str | Path, *, for_write: bool = False) -> Tuple[bool, str]:
    """Return ``(allowed, reason)``."""
    try:
        p = Path(path).expanduser()
        resolved = p.resolve()
    except Exception as exc:
        return False, f"path could not be resolved: {exc}"

    posix = resolved.as_posix()
    for pattern in settings.denied_patterns:
        if fnmatch.fnmatch(posix, pattern) or fnmatch.fnmatch(resolved.name, pattern):
            return False, f"blocked by deny pattern {pattern}"

    roots: List[Path] = list(settings.allowed_roots)
    # SAM's own workspace is always writable
    roots.append(_project_root())
    roots.append(settings.sam_data_dir)

    for r in roots:
        try:
            rr = r.resolve()
        except Exception:
            continue
        if resolved == rr or rr in resolved.parents:
            return True, ""
        if resolved in rr.parents and not for_write:
            # reading a parent directory listing of an allowed root is fine
            return True, ""

    return False, (
        f"path is outside the allowed roots: {', '.join(str(r) for r in settings.allowed_roots)}"
    )


def assert_allowed(path: str | Path, *, for_write: bool = False) -> Path:
    ok, reason = is_allowed(path, for_write=for_write)
    if not ok:
        raise FileSecurityError(reason)
    return Path(path).expanduser().resolve()


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------
def human_size(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} PB"


@dataclass
class FileInfo:
    path: Path
    name: str
    ext: str
    size: int
    modified: float
    created: float
    is_dir: bool
    mime: str = ""
    sha256: str = ""

    def to_dict(self, *, include_hash: bool = False) -> Dict[str, Any]:
        d = {
            "path": str(self.path),
            "name": self.name,
            "ext": self.ext,
            "size": self.size,
            "size_human": human_size(self.size),
            "modified": datetime.fromtimestamp(self.modified, tz=timezone.utc).isoformat(),
            "created": datetime.fromtimestamp(self.created, tz=timezone.utc).isoformat(),
            "modified_ago": _ago(self.modified),
            "is_dir": self.is_dir,
            "mime": self.mime,
        }
        if include_hash:
            d["sha256"] = self.sha256
        return d


def _ago(ts: float) -> str:
    delta = max(0, int(time.time() - ts))
    for limit, unit in ((60, "second"), (3600, "minute"), (86400, "hour"), (604800, "day"),
                        (2592000, "week"), (31536000, "month")):
        if delta < limit:
            break
    else:
        unit = "year"
        limit = 31536000
    value = max(1, delta // (limit // (60 if unit == "minute" else 1)) if False else delta)
    if unit == "second":
        value = delta
    elif unit == "minute":
        value = delta // 60
    elif unit == "hour":
        value = delta // 3600
    elif unit == "day":
        value = delta // 86400
    elif unit == "week":
        value = delta // 604800
    elif unit == "month":
        value = delta // 2592000
    else:
        value = delta // 31536000
    return f"{value} {unit}{'s' if value != 1 else ''} ago"


def stat_path(path: str | Path, *, include_hash: bool = False) -> FileInfo:
    p = Path(path).expanduser()
    st = p.stat()
    mime = "" if st.st_mode & 0o170000 == 0o040000 else (mimetypes.guess_type(p.name)[0] or "")
    info = FileInfo(
        path=p.resolve(), name=p.name, ext=p.suffix.lower(), size=st.st_size,
        modified=st.st_mtime, created=getattr(st, "st_birthtime", st.st_ctime),
        is_dir=p.is_dir(), mime=mime,
    )
    if include_hash and not info.is_dir and info.size < 512 * 1024 * 1024:
        info.sha256 = file_hash(p)
    return info


def file_hash(path: str | Path, algo: str = "sha256", chunk: int = 1 << 20) -> str:
    h = hashlib.new(algo)
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Traversal
# ---------------------------------------------------------------------------
SKIP_DIRS = {
    "node_modules", ".git", ".venv", "venv", "__pycache__", ".mypy_cache", ".pytest_cache",
    ".ruff_cache", ".next", ".nuxt", ".output", "dist", "build", "target", ".gradle",
    ".idea", ".vscode", "AppData", ".cache", ".npm", ".tox", "coverage", ".turbo",
}


def walk(root: str | Path, *, include_hidden: bool = False, max_files: int = 50_000,
         follow_symlinks: bool = False) -> Iterable[Path]:
    """Yield files under ``root``, skipping VCS/dependency noise."""
    base = Path(root).expanduser()
    if not base.exists():
        return
    if base.is_file():
        yield base
        return

    count = 0
    stack: List[Path] = [base]
    seen_real: set = set()
    while stack and count < max_files:
        current = stack.pop()
        try:
            real = current.resolve()
        except Exception:
            continue
        if real in seen_real:
            continue
        seen_real.add(real)
        try:
            entries = list(current.iterdir())
        except (PermissionError, OSError):
            continue
        for entry in entries:
            name = entry.name
            if not include_hidden and name.startswith("."):
                continue
            try:
                is_dir = entry.is_dir()
            except OSError:
                continue
            if is_dir:
                if name in SKIP_DIRS:
                    continue
                if entry.is_symlink() and not follow_symlinks:
                    continue
                stack.append(entry)
            else:
                count += 1
                yield entry


# ---------------------------------------------------------------------------
# Text extraction (used by content search + semantic index)
# ---------------------------------------------------------------------------
TEXT_EXTS = {
    ".txt", ".md", ".markdown", ".rst", ".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".yaml",
    ".yml", ".toml", ".ini", ".cfg", ".conf", ".html", ".htm", ".css", ".scss", ".less",
    ".xml", ".csv", ".tsv", ".log", ".sh", ".bash", ".zsh", ".ps1", ".bat", ".cmd", ".sql",
    ".java", ".kt", ".kts", ".c", ".h", ".cpp", ".hpp", ".cs", ".go", ".rs", ".rb", ".php",
    ".swift", ".m", ".r", ".scala", ".pl", ".lua", ".vue", ".svelte", ".env", ".gitignore",
    ".tex", ".bib", ".gradle", ".properties",
}
MAX_TEXT_BYTES = 2_000_000


def extract_text(path: str | Path, *, max_chars: int = 200_000) -> str:
    """
    Best-effort plain text from any supported document.

    Supported: plain text/code, PDF, DOCX, PPTX, XLSX/CSV, Markdown, HTML,
    images (OCR when Tesseract is installed).
    """
    p = Path(path).expanduser()
    ext = p.suffix.lower()
    try:
        if ext == ".pdf":
            return _pdf_text(p, max_chars)
        if ext == ".docx":
            return _docx_text(p, max_chars)
        if ext == ".pptx":
            return _pptx_text(p, max_chars)
        if ext in (".xlsx", ".xlsm"):
            return _xlsx_text(p, max_chars)
        if ext == ".csv":
            return _csv_text(p, max_chars)
        if ext in (".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".webp"):
            return _image_text(p, max_chars)
        if ext in (".doc", ".ppt", ".xls"):
            return _legacy_office_text(p, max_chars)
        if ext in TEXT_EXTS or ext == "":
            return _plain_text(p, max_chars)
    except Exception as exc:
        log.debug("text extraction failed for %s: %s", p, exc)
        return ""
    return ""


def _plain_text(p: Path, max_chars: int) -> str:
    if p.stat().st_size > MAX_TEXT_BYTES:
        return ""
    for encoding in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            data = p.read_text(encoding=encoding, errors="strict")
            return data[:max_chars]
        except (UnicodeDecodeError, LookupError):
            continue
        except Exception:
            return ""
    try:
        return p.read_bytes().decode("utf-8", errors="replace")[:max_chars]
    except Exception:
        return ""


def _pdf_text(p: Path, max_chars: int) -> str:
    try:
        from pypdf import PdfReader

        reader = PdfReader(str(p))
        parts: List[str] = []
        total = 0
        for i, page in enumerate(reader.pages):
            if i > 400:
                break
            chunk = page.extract_text() or ""
            parts.append(chunk)
            total += len(chunk)
            if total > max_chars:
                break
        return "\n".join(parts)[:max_chars]
    except ImportError:
        log.debug("pypdf not installed — PDF text unavailable")
        return ""
    except Exception as exc:
        log.debug("pdf parse failed: %s", exc)
        return ""


def _docx_text(p: Path, max_chars: int) -> str:
    try:
        import docx  # python-docx

        d = docx.Document(str(p))
        parts = [para.text for para in d.paragraphs]
        for table in d.tables:
            for row in table.rows:
                parts.append(" | ".join(cell.text.strip() for cell in row.cells))
        return "\n".join(parts)[:max_chars]
    except ImportError:
        return _zip_xml_text(p, "word/document.xml", max_chars)
    except Exception:
        return ""


def _pptx_text(p: Path, max_chars: int) -> str:
    try:
        from pptx import Presentation

        prs = Presentation(str(p))
        parts: List[str] = []
        for i, slide in enumerate(prs.slides, start=1):
            parts.append(f"--- Slide {i} ---")
            for shape in slide.shapes:
                if shape.has_text_frame:
                    parts.append(shape.text_frame.text)
                if getattr(shape, "has_table", False) and shape.has_table:
                    for row in shape.table.rows:
                        parts.append(" | ".join(c.text for c in row.cells))
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                parts.append("[notes] " + slide.notes_slide.notes_text_frame.text)
        return "\n".join(parts)[:max_chars]
    except ImportError:
        return ""
    except Exception:
        return ""


def _xlsx_text(p: Path, max_chars: int) -> str:
    try:
        import openpyxl

        wb = openpyxl.load_workbook(str(p), read_only=True, data_only=True)
        parts: List[str] = []
        for ws in wb.worksheets[:20]:
            parts.append(f"--- Sheet: {ws.title} ---")
            rows = 0
            for row in ws.iter_rows(values_only=True):
                rows += 1
                if rows > 2000:
                    parts.append("... [truncated]")
                    break
                cells = ["" if c is None else str(c) for c in row]
                if any(cells):
                    parts.append(" | ".join(cells))
        wb.close()
        return "\n".join(parts)[:max_chars]
    except ImportError:
        return ""
    except Exception:
        return ""


def _csv_text(p: Path, max_chars: int) -> str:
    import csv

    parts: List[str] = []
    total = 0
    with open(p, "r", encoding="utf-8", errors="replace", newline="") as fh:
        for i, row in enumerate(csv.reader(fh)):
            if i > 5000:
                parts.append("... [truncated]")
                break
            line = " | ".join(row)
            parts.append(line)
            total += len(line)
            if total > max_chars:
                break
    return "\n".join(parts)[:max_chars]


def _image_text(p: Path, max_chars: int) -> str:
    try:
        import pytesseract  # type: ignore
        from PIL import Image

        with Image.open(p) as im:
            return (pytesseract.image_to_string(im) or "")[:max_chars]
    except Exception:
        return ""


def _legacy_office_text(p: Path, max_chars: int) -> str:
    """Very rough fallback for .doc/.ppt/.xls when no converter exists."""
    try:
        data = p.read_bytes()
    except Exception:
        return ""
    text = re.sub(rb"[^\x20-\x7e\n\r\t]", b" ", data).decode("ascii", errors="ignore")
    words = [w for w in re.split(r"\s{2,}", text) if len(w) > 3]
    return " ".join(words)[:max_chars]


def _zip_xml_text(p: Path, member: str, max_chars: int) -> str:
    import zipfile

    try:
        with zipfile.ZipFile(p) as z:
            if member not in z.namelist():
                return ""
            raw = z.read(member).decode("utf-8", errors="replace")
        text = re.sub(r"<[^>]+>", " ", raw)
        return re.sub(r"\s+", " ", text).strip()[:max_chars]
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Operations
# ---------------------------------------------------------------------------
def safe_copy(src: str | Path, dst: str | Path, *, overwrite: bool = False) -> Dict[str, Any]:
    s = assert_allowed(src)
    d = assert_allowed(dst, for_write=True)
    if not s.exists():
        return {"ok": False, "error": f"source does not exist: {s}"}
    if d.exists() and not overwrite:
        return {"ok": False, "error": f"destination exists: {d}", "needs_overwrite": True}
    d.parent.mkdir(parents=True, exist_ok=True)
    if s.is_dir():
        shutil.copytree(s, d, dirs_exist_ok=overwrite)
    else:
        shutil.copy2(s, d)
    return {"ok": True, "src": str(s), "dst": str(d), "size": (s.stat().st_size if s.is_file() else None)}


def safe_move(src: str | Path, dst: str | Path, *, overwrite: bool = False) -> Dict[str, Any]:
    s = assert_allowed(src)
    d = assert_allowed(dst, for_write=True)
    if not s.exists():
        return {"ok": False, "error": f"source does not exist: {s}"}
    if d.exists() and not overwrite:
        return {"ok": False, "error": f"destination exists: {d}", "needs_overwrite": True}
    d.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(s), str(d))
    return {"ok": True, "src": str(s), "dst": str(d)}


def safe_rename(path: str | Path, new_name: str) -> Dict[str, Any]:
    p = assert_allowed(path)
    if not p.exists():
        return {"ok": False, "error": f"does not exist: {p}"}
    new_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", new_name.strip())
    if not new_name:
        return {"ok": False, "error": "empty new name"}
    target = p.with_name(new_name)
    assert_allowed(target, for_write=True)
    if target.exists():
        return {"ok": False, "error": f"already exists: {target}"}
    p.rename(target)
    return {"ok": True, "src": str(p), "dst": str(target)}


def safe_delete(path: str | Path, *, to_trash: bool = True) -> Dict[str, Any]:
    p = assert_allowed(path, for_write=True)
    if not p.exists():
        return {"ok": False, "error": f"does not exist: {p}"}
    # never let SAM delete its own database or the project root
    protected = {_project_root(), settings.sam_data_dir, settings.db_path.parent}
    if p in protected or settings.db_path == p:
        return {"ok": False, "error": "refusing to delete a protected SAM path"}

    if to_trash:
        try:
            import send2trash  # type: ignore

            send2trash.send2trash(str(p))
            return {"ok": True, "deleted": str(p), "method": "trash"}
        except ImportError:
            pass
        except Exception as exc:
            log.debug("send2trash failed: %s", exc)

    trash_dir = settings.sam_data_dir / "cache" / "trash"
    trash_dir.mkdir(parents=True, exist_ok=True)
    stamp = int(time.time() * 1000)
    dest = trash_dir / f"{stamp}_{p.name}"
    try:
        shutil.move(str(p), str(dest))
        return {"ok": True, "deleted": str(p), "method": "sam-trash", "recoverable_at": str(dest)}
    except Exception as exc:
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        return {"ok": True, "deleted": str(p), "method": "permanent", "error_note": str(exc)}


def safe_write(path: str | Path, content: str | bytes, *, mode: str = "w") -> Dict[str, Any]:
    p = assert_allowed(path, for_write=True)
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, bytes):
        p.write_bytes(content)
        size = len(content)
    else:
        p.write_text(content, encoding="utf-8")
        size = len(content.encode("utf-8"))
    return {"ok": True, "path": str(p), "bytes": size}


def safe_read(path: str | Path, *, max_chars: int = 100_000, as_text: bool = True) -> Dict[str, Any]:
    p = assert_allowed(path)
    if not p.exists():
        return {"ok": False, "error": f"does not exist: {p}"}
    info = stat_path(p).to_dict()
    if p.is_dir():
        entries = []
        for child in sorted(p.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower()))[:500]:
            try:
                entries.append({"name": child.name, "is_dir": child.is_dir(),
                                "size": child.stat().st_size if child.is_file() else None})
            except OSError:
                entries.append({"name": child.name, "is_dir": child.is_dir(), "size": None})
        return {"ok": True, **info, "entries": entries, "entry_count": len(entries)}

    if not as_text or p.suffix.lower() not in TEXT_EXTS:
        text = extract_text(p, max_chars=max_chars)
    else:
        text = _plain_text(p, max_chars)
    return {"ok": True, **info, "text": text, "truncated": len(text) >= max_chars,
            "sha256": file_hash(p) if info["size"] < 50 * 1024 * 1024 else ""}


# ---------------------------------------------------------------------------
# Archives
# ---------------------------------------------------------------------------
def make_archive(sources: List[str | Path], output: str | Path,
                 fmt: str = "zip") -> Dict[str, Any]:
    out = assert_allowed(output, for_write=True)
    out.parent.mkdir(parents=True, exist_ok=True)
    paths = [assert_allowed(s) for s in sources]
    missing = [str(p) for p in paths if not p.exists()]
    if missing:
        return {"ok": False, "error": f"missing sources: {missing[:5]}"}

    if fmt == "zip":
        import zipfile

        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            for p in paths:
                if p.is_file():
                    z.write(p, arcname=p.name)
                else:
                    for f in walk(p, max_files=20_000):
                        z.write(f, arcname=f.relative_to(p.parent).as_posix())
    elif fmt in ("tar", "tar.gz", "tgz", "tar.bz2"):
        import tarfile

        mode = {"tar": "w", "tar.gz": "w:gz", "tgz": "w:gz", "tar.bz2": "w:bz2"}[fmt]
        with tarfile.open(out, mode) as t:
            for p in paths:
                t.add(p, arcname=p.name)
    else:
        return {"ok": False, "error": f"unsupported archive format '{fmt}'"}

    return {"ok": True, "archive": str(out), "format": fmt,
            "size": out.stat().st_size, "sources": [str(p) for p in paths]}


def extract_archive(archive: str | Path, dest: str | Path) -> Dict[str, Any]:
    src = assert_allowed(archive)
    out_dir = assert_allowed(dest, for_write=True)
    if not src.exists():
        return {"ok": False, "error": f"archive does not exist: {src}"}
    out_dir.mkdir(parents=True, exist_ok=True)

    import tarfile
    import zipfile

    try:
        if zipfile.is_zipfile(src):
            with zipfile.ZipFile(src) as z:
                for member in z.namelist():
                    target = (out_dir / member).resolve()
                    if not str(target).startswith(str(out_dir.resolve())):
                        return {"ok": False, "error": f"unsafe path inside archive: {member}"}
                z.extractall(out_dir)
                return {"ok": True, "archive": str(src), "dest": str(out_dir),
                        "members": len(z.namelist())}
        if tarfile.is_tarfile(src):
            with tarfile.open(src) as t:
                for m in t.getmembers():
                    target = (out_dir / m.name).resolve()
                    if not str(target).startswith(str(out_dir.resolve())):
                        return {"ok": False, "error": f"unsafe path inside archive: {m.name}"}
                if hasattr(tarfile, "data_filter"):
                    t.extractall(out_dir, filter="data")
                else:
                    t.extractall(out_dir)
                return {"ok": True, "archive": str(src), "dest": str(out_dir),
                        "members": len(t.getmembers())}
    except Exception as exc:
        return {"ok": False, "error": f"extraction failed: {exc}"}
    return {"ok": False, "error": "not a recognised zip/tar archive"}


# ---------------------------------------------------------------------------
# Duplicates
# ---------------------------------------------------------------------------
def find_duplicates(roots: List[str | Path], *, max_files: int = 20_000,
                    min_size: int = 1024) -> Dict[str, Any]:
    """Two-pass duplicate detection: size buckets first, then hashes."""
    by_size: Dict[int, List[Path]] = {}
    scanned = 0
    for root in roots:
        try:
            assert_allowed(root)
        except FileSecurityError as exc:
            return {"ok": False, "error": str(exc)}
        for f in walk(root, max_files=max_files):
            scanned += 1
            if scanned > max_files:
                break
            try:
                size = f.stat().st_size
            except OSError:
                continue
            if size < min_size:
                continue
            by_size.setdefault(size, []).append(f)

    groups: List[Dict[str, Any]] = []
    wasted = 0
    hashed = 0
    for size, files in by_size.items():
        if len(files) < 2:
            continue
        by_hash: Dict[str, List[Path]] = {}
        for f in files:
            if hashed > max_files:
                break
            try:
                h = file_hash(f)
                hashed += 1
                by_hash.setdefault(h, []).append(f)
            except OSError:
                continue
        for h, dupes in by_hash.items():
            if len(dupes) > 1:
                wasted += size * (len(dupes) - 1)
                groups.append({
                    "sha256": h, "size": size, "size_human": human_size(size),
                    "count": len(dupes), "wasted_bytes": size * (len(dupes) - 1),
                    "files": [str(d) for d in sorted(dupes, key=lambda p: p.stat().st_mtime)],
                })

    groups.sort(key=lambda g: g["wasted_bytes"], reverse=True)
    return {"ok": True, "scanned": scanned, "hashed": hashed, "duplicate_groups": len(groups),
            "wasted_bytes": wasted, "wasted_human": human_size(wasted), "groups": groups[:200]}
