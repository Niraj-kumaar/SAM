"""
backend.app.files.semantic_index
================================

The local **semantic index** behind "search by meaning".

Pipeline::

    allowed roots -> walk -> extract text -> chunk -> embed -> SQLite table

Storage is a single table inside SAM's own database
(``data/db/sam.db`` -> ``file_chunks``). Nothing is uploaded anywhere: when no
embedding model is reachable, SAM falls back to its deterministic hashed
bag-of-words vectors so search still degrades gracefully instead of failing.

Build it with the ``files.index`` tool or ``POST /api/v1/files/index``.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.files.file_ops import FileSecurityError, assert_allowed, extract_text, walk

log = get_logger("files.semantic")

CHUNK_CHARS = 1200
CHUNK_OVERLAP = 150
MAX_FILE_BYTES = 40 * 1024 * 1024


@dataclass
class Chunk:
    path: str
    name: str
    ext: str
    chunk_index: int
    text: str
    vector: List[float]
    size: int
    modified: float
    fingerprint: str


def cosine(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


class SemanticIndex:
    """File-backed vector index (JSON store, no external vector DB required)."""

    def __init__(self) -> None:
        self._router: Any = None
        self._path = settings.sam_data_dir / "memory" / "semantic_index.jsonl"
        self._meta_path = settings.sam_data_dir / "memory" / "semantic_index.meta.json"
        self._records: List[Chunk] = []
        self._loaded = False
        self._lock = asyncio.Lock()

    def attach_router(self, router: Any) -> None:
        self._router = router

    # ------------------------------------------------------------------- io
    async def load(self) -> int:
        if self._loaded:
            return len(self._records)
        self._records = []
        if not self._path.exists():
            self._loaded = True
            return 0
        loop = asyncio.get_running_loop()

        def _read() -> List[Chunk]:
            out: List[Chunk] = []
            try:
                with open(self._path, "r", encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            d = json.loads(line)
                            out.append(Chunk(**d))
                        except Exception:
                            continue
            except Exception as exc:
                log.debug("index load failed: %s", exc)
            return out

        self._records = await loop.run_in_executor(None, _read)
        self._loaded = True
        log.info("semantic index loaded: %d chunks", len(self._records))
        return len(self._records)

    async def flush(self) -> int:
        """Persist the index to disk. Returns the number of chunks written."""
        async with self._lock:
            await self._flush()
        return len(self._records)

    async def _flush(self) -> None:
        loop = asyncio.get_running_loop()
        self._path.parent.mkdir(parents=True, exist_ok=True)

        def _write() -> None:
            with open(self._path, "w", encoding="utf-8") as fh:
                for c in self._records:
                    fh.write(json.dumps(c.__dict__) + "\n")

        await loop.run_in_executor(None, _write)
        meta = {
            "chunks": len(self._records),
            "files": len({c.path for c in self._records}),
            "built_at": datetime.now(timezone.utc).isoformat(),
            "embedding": "ollama" if (self._router and settings.ollama_enabled) else "hash-bow",
            "dim": len(self._records[0].vector) if self._records else 0,
        }
        self._meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    # ----------------------------------------------------------------- build
    async def build(self, roots: List[str], *, limit: int = 2000,
                    extensions: Optional[List[str]] = None) -> Dict[str, Any]:
        """Index files under ``roots``. Incremental: unchanged files are skipped."""
        if not settings.files_index_enabled:
            return {"ok": False, "error": "indexing disabled (FILES_INDEX_ENABLED=false)"}
        await self.load()
        exts = {e.lower() if e.startswith(".") else "." + e.lower() for e in (extensions or [])}
        existing = {c.path: c.fingerprint for c in self._records}

        t0 = time.time()
        indexed = skipped = failed = 0
        new_records: List[Chunk] = [c for c in self._records]
        seen_paths: set = set()

        for raw_root in roots:
            try:
                root = assert_allowed(raw_root)
            except FileSecurityError as exc:
                return {"ok": False, "error": str(exc)}
            if not root.exists():
                continue

            batch_texts: List[str] = []
            batch_meta: List[Tuple[Path, int, str]] = []

            for path in walk(root, max_files=50_000):
                if indexed >= limit:
                    break
                ext = path.suffix.lower()
                if exts and ext not in exts:
                    continue
                try:
                    st = path.stat()
                except OSError:
                    continue
                if st.st_size > MAX_FILE_BYTES or st.st_size == 0:
                    continue

                fingerprint = f"{int(st.st_mtime)}:{st.st_size}"
                seen_paths.add(str(path))
                if existing.get(str(path)) == fingerprint:
                    skipped += 1
                    continue

                loop = asyncio.get_running_loop()
                try:
                    text = await loop.run_in_executor(None, extract_text, path, 40_000)
                except Exception as exc:
                    failed += 1
                    log.debug("extract failed %s: %s", path, exc)
                    continue
                if not text or not text.strip():
                    skipped += 1
                    continue

                chunks = _chunk_text(text)
                for i, chunk in enumerate(chunks):
                    batch_texts.append(chunk)
                    batch_meta.append((path, i, fingerprint))
                indexed += 1

                if len(batch_texts) >= 32:
                    vecs = await self._embed_batch(batch_texts)
                    new_records = _merge_records(new_records, batch_meta, batch_texts, vecs)
                    batch_texts, batch_meta = [], []

            if batch_texts:
                vecs = await self._embed_batch(batch_texts)
                new_records = _merge_records(new_records, batch_meta, batch_texts, vecs)

        # drop records whose files vanished from the scanned roots
        stale = {p for p in existing if p not in seen_paths}
        before = len(new_records)
        if stale:
            new_records = [c for c in new_records if c.path not in stale]
        removed = before - len(new_records)

        async with self._lock:
            self._records = new_records
            await self._flush()

        return {
            "ok": True,
            "files_indexed": indexed,
            "files_skipped_unchanged": skipped,
            "files_failed": failed,
            "chunks": len(self._records),
            "removed_stale_chunks": max(0, removed),
            "roots": roots,
            "duration_seconds": round(time.time() - t0, 1),
            "index_path": str(self._path),
            "embedding": "ollama" if (self._router and settings.ollama_enabled) else "hash-bow",
        }

    async def _embed_batch(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []
        if self._router is not None:
            try:
                vecs = await asyncio.wait_for(self._router.embed(texts), timeout=60.0)
                if vecs and len(vecs) == len(texts) and any(any(v) for v in vecs):
                    return vecs
            except Exception as exc:
                log.debug("batch embedding failed (%s) — falling back to hashed BoW", exc)
        from backend.app.models.router import _hash_embedding

        return [_hash_embedding(t) for t in texts]

    # ---------------------------------------------------------------- search
    async def search(self, query: str, *, limit: int = 10,
                     root: Optional[str] = None) -> Dict[str, Any]:
        if not query or not query.strip():
            return {"ok": False, "error": "empty query", "hits": []}
        await self.load()
        if not self._records:
            return {"ok": True, "hits": [], "count": 0,
                    "note": "the semantic index is empty — run files.index first"}

        q_vecs = await self._embed_batch([query])
        q_vec = q_vecs[0]
        q_tokens = set(re.findall(r"[a-zA-Z\u0900-\u097F\u0C80-\u0CFF]{3,}", query.lower()))

        scored: List[Tuple[float, Chunk, float, float]] = []
        for c in self._records:
            if root and root.lower() not in c.path.lower():
                continue
            sem = cosine(q_vec, c.vector)
            ctokens = set(re.findall(r"[a-zA-Z\u0900-\u097F\u0C80-\u0CFF]{3,}", c.text.lower()))
            lex = len(q_tokens & ctokens) / max(1, len(q_tokens))
            score = sem * 0.65 + lex * 0.35
            if score < 0.15:
                continue
            scored.append((score, c, sem, lex))

        scored.sort(key=lambda x: x[0], reverse=True)
        top = scored[:limit]

        # collapse chunks that come from the same file
        files: Dict[str, Dict[str, Any]] = {}
        for score, c, sem, lex in top:
            entry = files.setdefault(c.path, {
                "path": c.path, "name": c.name, "ext": c.ext, "size": c.size,
                "modified": datetime.fromtimestamp(c.modified, tz=timezone.utc).isoformat(),
                "score": 0.0, "semantic": 0.0, "lexical": 0.0, "chunks": [],
            })
            entry["score"] = max(entry["score"], round(score, 4))
            entry["semantic"] = max(entry["semantic"], round(sem, 4))
            entry["lexical"] = max(entry["lexical"], round(lex, 4))
            if len(entry["chunks"]) < 3:
                entry["chunks"].append(_snippet(c.text, query))

        hits = sorted(files.values(), key=lambda d: d["score"], reverse=True)[:limit]
        answer = ""
        if hits:
            answer = self._answer(query, hits)
        return {
            "ok": True, "query": query, "count": len(hits), "hits": hits,
            "indexed_chunks": len(self._records), "answer": answer,
        }

    @staticmethod
    def _answer(query: str, hits: List[Dict[str, Any]]) -> str:
        lines = [f"Most relevant local documents for “{query}”:"]
        for h in hits[:5]:
            lines.append(f"- {h['name']} (score {h['score']})")
            for c in h["chunks"][:1]:
                lines.append(f"    {c}")
        return "\n".join(lines)

    # ----------------------------------------------------------------- admin
    async def clear(self) -> int:
        async with self._lock:
            n = len(self._records)
            self._records = []
            if self._path.exists():
                self._path.unlink()
            if self._meta_path.exists():
                self._meta_path.unlink()
            self._loaded = True
        return n

    async def stats(self) -> Dict[str, Any]:
        await self.load()
        files = {c.path for c in self._records}
        meta = {}
        if self._meta_path.exists():
            try:
                meta = json.loads(self._meta_path.read_text(encoding="utf-8"))
            except Exception:
                meta = {}
        return {
            "chunks": len(self._records),
            "files": len(files),
            "bytes": self._path.stat().st_size if self._path.exists() else 0,
            "enabled": settings.files_index_enabled,
            "embedding": meta.get("embedding", "hash-bow"),
            "built_at": meta.get("built_at"),
            "dimension": len(self._records[0].vector) if self._records else 0,
        }


def _chunk_text(text: str) -> List[str]:
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not text:
        return []
    chunks: List[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + CHUNK_CHARS)
        # try to break on a sentence boundary
        if end < len(text):
            boundary = max(text.rfind(". ", start, end), text.rfind("\n", start, end))
            if boundary > start + CHUNK_CHARS // 2:
                end = boundary + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - CHUNK_OVERLAP if end < len(text) else end
        if len(chunks) > 200:
            break
    return chunks


def _snippet(text: str, needle: str = "", width: int = 300) -> str:
    flat = re.sub(r"\s+", " ", text).strip()
    if needle:
        tokens = [t for t in re.split(r"\s+", needle.lower()) if len(t) > 2]
        for t in tokens:
            idx = flat.lower().find(t)
            if idx != -1:
                start = max(0, idx - width // 3)
                return ("..." if start else "") + flat[start : start + width] + "..."
    return flat[:width] + ("..." if len(flat) > width else "")


def _merge_records(records: List[Chunk], batch_meta: List[Tuple[Path, int, str]],
                   batch_texts: List[str], vecs: List[List[float]]) -> List[Chunk]:
    """Replace the chunks listed in ``batch_meta`` with freshly embedded ones."""
    keep_paths = {str(m[0]) for m in batch_meta}
    replace_idx = {(str(m[0]), m[1]) for m in batch_meta}

    by_path: Dict[str, List[Chunk]] = {}
    for r in records:
        if r.path in keep_paths and (r.path, r.chunk_index) in replace_idx:
            continue                      # superseded
        by_path.setdefault(r.path, []).append(r)

    for (path, idx, fingerprint), text, vec in zip(batch_meta, batch_texts, vecs):
        key = str(path)
        try:
            st = path.stat()
            size, modified = st.st_size, st.st_mtime
        except OSError:
            continue
        by_path.setdefault(key, []).append(
            Chunk(
                path=key, name=path.name, ext=path.suffix.lower(), chunk_index=idx,
                text=text[: CHUNK_CHARS + CHUNK_OVERLAP], vector=vec,
                size=size, modified=modified, fingerprint=fingerprint,
            )
        )

    out: List[Chunk] = []
    for chunks in by_path.values():
        chunks.sort(key=lambda c: c.chunk_index)
        out.extend(chunks)
    return out


semantic_index = SemanticIndex()
