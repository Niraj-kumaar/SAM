"""
backend.app.files.search_index
==============================

Advanced file search + the local semantic index.

Search modes (all combinable in one query)
------------------------------------------
* **filename**   glob / substring / fuzzy
* **extension**  ``.pdf``, ``ext:pdf``
* **date**       ``modified:7d``, ``created:today``, ``before:2024-01-01``
* **size**       ``size:>10mb``, ``size:<1kb``
* **folder**     ``in:Downloads``
* **content**    full-text match inside the extracted document text
* **meaning**    semantic similarity over embeddings (the "understands what you
  mean" layer)

The index lives in SQLite (``file_index`` table) inside SAM's own database and
stores only paths, metadata, extracted text snippets and embeddings. It never
uploads anything: ``FILES_INDEX_ENABLED=false`` turns it off entirely.
"""

from __future__ import annotations

import asyncio
import json
import math
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.files.file_ops import (
    TEXT_EXTS,
    FileSecurityError,
    assert_allowed,
    extract_text,
    file_hash,
    human_size,
    is_allowed,
    walk,
)

log = get_logger("files.search")

SIZE_UNITS = {"b": 1, "kb": 1024, "mb": 1024**2, "gb": 1024**3, "tb": 1024**4}


@dataclass
class Query:
    text: str = ""
    filename: str = ""
    ext: Optional[str] = None
    folder: Optional[str] = None
    modified_within: Optional[str] = None       # e.g. "7d", "24h", "today"
    created_within: Optional[str] = None
    before: Optional[str] = None
    after: Optional[str] = None
    min_size: Optional[int] = None
    max_size: Optional[int] = None
    content: Optional[str] = None
    semantic: bool = True
    roots: List[str] = field(default_factory=list)
    limit: int = 50
    include_dirs: bool = False
    sort: str = "relevance"                     # relevance | modified | size | name

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class Hit:
    path: str
    name: str
    ext: str
    size: int
    modified: float
    score: float = 0.0
    matched_on: List[str] = field(default_factory=list)
    snippet: str = ""
    semantic: float = 0.0
    lexical: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "path": self.path, "name": self.name, "ext": self.ext,
            "size": self.size, "size_human": human_size(self.size),
            "modified": datetime.fromtimestamp(self.modified, tz=timezone.utc).isoformat(),
            "modified_ago": _ago(self.modified),
            "score": round(self.score, 4), "matched_on": self.matched_on,
            "snippet": self.snippet, "semantic": round(self.semantic, 4),
            "lexical": round(self.lexical, 4),
        }


def _ago(ts: float) -> str:
    delta = max(0, int(time.time() - ts))
    if delta < 60:
        return f"{delta}s ago"
    if delta < 3600:
        return f"{delta // 60}m ago"
    if delta < 86400:
        return f"{delta // 3600}h ago"
    if delta < 604800:
        return f"{delta // 86400}d ago"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Natural-language query parsing
# ---------------------------------------------------------------------------
def parse_query(raw: str, **overrides: Any) -> Query:
    """
    Turn free text into a structured :class:`Query`.

    ``"pdf invoices bigger than 1mb from last week in Downloads"`` becomes
    ``ext=.pdf, text='invoices', min_size=1mb, modified_within=7d, folder=Downloads``.
    """
    q = Query(text=raw)
    s = raw or ""
    remaining = s
    matched_terms: List[str] = []

    # explicit key:value syntax first
    for m in re.finditer(r"\b(ext|extension|type)\s*[:=]\s*\.?([a-z0-9]{1,8})\b", s, re.I):
        q.ext = "." + m.group(2).lower()
        matched_terms.append(m.group(0))
    for m in re.finditer(r"\b(in|folder|dir|path)\s*[:=]\s*([^\s,]+)", s, re.I):
        q.folder = m.group(2).strip("\"'")
        matched_terms.append(m.group(0))
    for m in re.finditer(r"\bsize\s*[:=]?\s*([<>]=?)\s*(\d+(?:\.\d+)?)\s*(b|kb|mb|gb|tb)\b", s, re.I):
        value = float(m.group(2)) * SIZE_UNITS[m.group(3).lower()]
        if m.group(1).startswith(">"):
            q.min_size = int(value)
        else:
            q.max_size = int(value)
        matched_terms.append(m.group(0))
    for m in re.finditer(r"\b(modified|created|before|after|since|from)\s*[:=]\s*([^\s,]+)", s, re.I):
        key, val = m.group(1).lower(), m.group(2)
        if key in ("modified", "since"):
            q.modified_within = val
        elif key == "created":
            q.created_within = val
        elif key == "before":
            q.before = val
        else:
            q.after = val
        matched_terms.append(m.group(0))

    # natural language: "bigger than 5 mb"
    for m in re.finditer(r"\b(bigger|larger|greater|more)\s+than\s+(\d+(?:\.\d+)?)\s*(b|kb|mb|gb|tb)\b", s, re.I):
        q.min_size = int(float(m.group(2)) * SIZE_UNITS[m.group(3).lower()])
        matched_terms.append(m.group(0))
    for m in re.finditer(r"\b(smaller|less)\s+than\s+(\d+(?:\.\d+)?)\s*(b|kb|mb|gb|tb)\b", s, re.I):
        q.max_size = int(float(m.group(2)) * SIZE_UNITS[m.group(3).lower()])
        matched_terms.append(m.group(0))

    # natural language: "last week", "today", "past 3 days"
    time_map = {
        r"\btoday\b": "1d", r"\byesterday\b": "2d",
        r"\b(?:last|past|previous)\s+(?:\d+\s+)?hours?\b": "24h",
        r"\b(?:last|past|previous)\s+week\b": "7d",
        r"\b(?:last|past|previous)\s+month\b": "30d",
        r"\b(?:last|past|previous)\s+year\b": "365d",
        r"\bthis\s+week\b": "7d", r"\bthis\s+month\b": "30d",
        r"\b(?:last|past)\s+(\d+)\s*(day|days|d)\b": None,
        r"\brecent(?:ly)?\b": "14d",
    }
    for pattern, value in time_map.items():
        m = re.search(pattern, s, re.I)
        if m:
            if value is None:
                value = f"{m.group(1)}d"
            q.modified_within = value
            matched_terms.append(m.group(0))
            break

    # extension mentioned in prose ("pdf files", "excel sheets")
    ext_words = {
        "pdf": ".pdf", "pdfs": ".pdf", "word": ".docx", "docx": ".docx", "document": ".docx",
        "excel": ".xlsx", "xlsx": ".xlsx", "spreadsheet": ".xlsx", "csv": ".csv",
        "powerpoint": ".pptx", "pptx": ".pptx", "slides": ".pptx", "presentation": ".pptx",
        "image": ".png", "images": ".png", "photo": ".jpg", "photos": ".jpg", "picture": ".jpg",
        "video": ".mp4", "videos": ".mp4", "audio": ".mp3", "song": ".mp3", "music": ".mp3",
        "zip": ".zip", "archive": ".zip", "python": ".py", "py": ".py", "javascript": ".js",
        "typescript": ".ts", "text": ".txt", "txt": ".txt", "markdown": ".md", "md": ".md",
        "json": ".json", "html": ".html", "apk": ".apk", "exe": ".exe",
    }
    if q.ext is None:
        for word, ext in ext_words.items():
            if re.search(rf"\b{re.escape(word)}\b", s, re.I):
                q.ext = ext
                matched_terms.append(word)
                break

    # well-known folder names
    if q.folder is None:
        for name in ("downloads", "documents", "desktop", "pictures", "videos", "music",
                     "screenshots", "projects", "temp", "tmp"):
            if re.search(rf"\b(?:in|from|inside|on)\s+(?:my\s+)?{name}\b", s, re.I):
                q.folder = name
                matched_terms.append(name)
                break

    # strip everything we consumed -> what's left is the semantic text
    cleaned = s
    for term in sorted(matched_terms, key=len, reverse=True):
        cleaned = re.sub(re.escape(term), " ", cleaned, flags=re.I)
    cleaned = re.sub(r"\b(files?|docs?|documents?|folders?|named|called|all|any|the|my|of|in|from|"
                     r"with|that|which|are|is|were|was|find|search|locate|look|for|show|list|"
                     r"me|please|sam)\b", " ", cleaned, flags=re.I)
    cleaned = re.sub(r"[^\w\s.-]", " ", cleaned)
    q.text = " ".join(cleaned.split())

    for key, value in overrides.items():
        if value is not None and hasattr(q, key):
            setattr(q, key, value)
    return q


def _parse_duration(value: Optional[str]) -> Optional[timedelta]:
    if not value:
        return None
    v = value.strip().lower()
    if v == "today":
        return timedelta(days=1)
    if v == "yesterday":
        return timedelta(days=2)
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(s|m|h|d|w|mo|y|min|hr|day|days|week|weeks|hour|hours|month|months|year|years)?", v)
    if not m:
        return None
    n = float(m.group(1))
    unit = (m.group(2) or "d")[:2]
    return {
        "s": timedelta(seconds=n), "m": timedelta(minutes=n), "mi": timedelta(minutes=n),
        "h": timedelta(hours=n), "hr": timedelta(hours=n), "d": timedelta(days=n),
        "da": timedelta(days=n), "w": timedelta(weeks=n), "mo": timedelta(days=n * 30),
        "y": timedelta(days=n * 365),
    }.get(unit, timedelta(days=n))


def _parse_date(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%Y-%m-%dT%H:%M:%S", "%d-%m-%Y"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------------------
# Searcher
# ---------------------------------------------------------------------------
class FileSearcher:
    """Lexical + semantic file search over the allowed roots."""

    def __init__(self) -> None:
        self._router: Any = None
        self._embed_cache: Dict[str, List[float]] = {}
        self._text_cache: Dict[str, Tuple[float, str]] = {}

    def attach_router(self, router: Any) -> None:
        self._router = router

    # ------------------------------------------------------------------ main
    async def search(self, query: Query | str, **overrides: Any) -> Dict[str, Any]:
        q = query if isinstance(query, Query) else parse_query(query, **overrides)
        t0 = time.time()
        roots = self._resolve_roots(q)
        if not roots:
            return {"ok": False, "error": "no searchable roots are permitted",
                    "allowed_roots": [str(r) for r in settings.allowed_roots], "hits": []}

        candidates: List[Path] = []
        scanned = 0
        for root in roots:
            for path in walk(root, max_files=200_000):
                scanned += 1
                if self._matches_metadata(path, q):
                    candidates.append(path)
        # directories
        if q.include_dirs:
            for root in roots:
                for d in self._dirs(root):
                    if self._matches_metadata(d, q, is_dir=True):
                        candidates.append(d)

        hits = await self._score(candidates, q)
        hits = self._sort(hits, q.sort)[: q.limit]

        return {
            "ok": True,
            "query": q.to_dict(),
            "scanned": scanned,
            "matched": len(hits),
            "returned": len(hits),
            "roots": [str(r) for r in roots],
            "duration_ms": int((time.time() - t0) * 1000),
            "hits": [h.to_dict() for h in hits],
            "semantic_enabled": bool(q.semantic and self._router is not None),
        }

    # ----------------------------------------------------------------- roots
    def _resolve_roots(self, q: Query) -> List[Path]:
        roots: List[Path] = []
        wanted = q.roots or []
        if q.folder:
            wanted.append(q.folder)
        for raw in wanted:
            p = Path(raw).expanduser()
            if not p.is_absolute():
                # a bare folder name -> look for it under the allowed roots
                found = False
                for base in settings.allowed_roots:
                    cand = base / raw
                    if cand.exists():
                        p = cand
                        found = True
                        break
                if not found:
                    p = Path.cwd() / raw
            try:
                assert_allowed(p)
            except FileSecurityError as exc:
                log.info("search root rejected: %s", exc)
                continue
            if p.exists():
                roots.append(p)
        if not roots:
            roots = [r for r in settings.allowed_roots if r.exists()]
        # de-duplicate while preserving order
        seen, out = set(), []
        for r in roots:
            key = str(r.resolve())
            if key not in seen:
                seen.add(key)
                out.append(r)
        return out

    @staticmethod
    def _dirs(root: Path, max_dirs: int = 5000) -> Iterable[Path]:
        count = 0
        stack = [root]
        while stack and count < max_dirs:
            cur = stack.pop()
            try:
                for entry in cur.iterdir():
                    if entry.is_dir() and not entry.name.startswith("."):
                        count += 1
                        yield entry
                        stack.append(entry)
            except (PermissionError, OSError):
                continue

    # -------------------------------------------------------------- filters
    def _matches_metadata(self, path: Path, q: Query, is_dir: bool = False) -> bool:
        name = path.name.lower()
        stem = path.stem.lower()
        ext = path.suffix.lower()

        if q.ext and ext != q.ext.lower():
            # also accept image/photo groups
            groups = {
                ".png": {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".heic"},
                ".jpg": {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".heic"},
                ".mp4": {".mp4", ".mkv", ".avi", ".mov", ".webm"},
                ".mp3": {".mp3", ".wav", ".flac", ".m4a", ".ogg", ".aac"},
                ".docx": {".docx", ".doc", ".odt", ".rtf"},
                ".xlsx": {".xlsx", ".xls", ".ods"},
            }
            if ext not in groups.get(q.ext.lower(), set()):
                return False

        if q.filename:
            pattern = q.filename.lower().replace("*", ".*")
            if not (re.search(pattern, name) or q.filename.lower() in name):
                return False

        if q.text:
            tokens = [t for t in re.split(r"\s+", q.text.lower()) if len(t) > 1]
            if tokens and not any(t in name or t in stem for t in tokens):
                # keep it as a candidate only if content/semantic search is on
                if not (q.content or q.semantic):
                    return False

        try:
            st = path.stat()
        except OSError:
            return False

        if not is_dir and q.min_size is not None and st.st_size < q.min_size:
            return False
        if not is_dir and q.max_size is not None and st.st_size > q.max_size:
            return False

        modified = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
        created = datetime.fromtimestamp(getattr(st, "st_birthtime", st.st_ctime), tz=timezone.utc)
        if q.modified_within:
            delta = _parse_duration(q.modified_within)
            if delta and modified < datetime.now(timezone.utc) - delta:
                return False
        if q.created_within:
            delta = _parse_duration(q.created_within)
            if delta and created < datetime.now(timezone.utc) - delta:
                return False
        if q.before:
            d = _parse_date(q.before)
            if d and modified > d:
                return False
        if q.after:
            d = _parse_date(q.after)
            if d and modified < d:
                return False

        if q.folder:
            folder = q.folder.lower().strip("/\\ ")
            if folder not in str(path).lower():
                return False
        return True

    # --------------------------------------------------------------- scoring
    async def _score(self, candidates: List[Path], q: Query) -> List[Hit]:
        if not candidates:
            return []
        tokens = [t for t in re.split(r"\s+", (q.text or "").lower()) if len(t) > 1]
        q_vec: Optional[List[float]] = None
        if q.semantic and q.text and self._router is not None and len(candidates) <= 4000:
            try:
                vecs = await asyncio.wait_for(self._router.embed([q.text]), timeout=10.0)
                if vecs and vecs[0] and any(vecs[0]):
                    q_vec = vecs[0]
            except Exception as exc:
                log.debug("semantic query embedding failed: %s", exc)

        hits: List[Hit] = []
        loop = asyncio.get_running_loop()

        async def one(path: Path) -> Optional[Hit]:
            try:
                st = await loop.run_in_executor(None, path.stat)
            except OSError:
                return None
            name = path.name
            low_name = name.lower()
            matched: List[str] = []
            score = 0.0

            # name match
            if tokens:
                name_hits = sum(1 for t in tokens if t in low_name)
                if name_hits:
                    matched.append("filename")
                    score += 0.45 * (name_hits / len(tokens))
                    if low_name.startswith(q.text.lower()):
                        score += 0.2
                    if q.text.lower() == low_name:
                        score += 0.4
            elif q.text and q.text.lower() in low_name:
                matched.append("filename")
                score += 0.5

            if q.filename and q.filename.lower() in low_name:
                matched.append("filename-pattern")
                score += 0.3
            if q.ext and path.suffix.lower() == q.ext.lower():
                matched.append("extension")
                score += 0.15

            # recency bonus
            age_days = (time.time() - st.st_mtime) / 86400
            score += max(0.0, 0.12 - age_days / 500)

            # content match
            text = ""
            if q.content or (q.semantic and q_vec is not None):
                text = await self._get_text(path)
            if q.content and text:
                needle = q.content.lower()
                idx = text.lower().find(needle)
                if idx != -1:
                    matched.append("content")
                    occurrences = text.lower().count(needle)
                    score += 0.5 + min(0.3, occurrences * 0.03)
                elif tokens:
                    tok_hits = sum(1 for t in tokens if t in text.lower())
                    if tok_hits:
                        matched.append("content-tokens")
                        score += 0.35 * (tok_hits / len(tokens))

            semantic = 0.0
            if q_vec is not None and text:
                vec = await self._embed(text[:6000] or name)
                semantic = _cosine(q_vec, vec)
                if semantic > 0.25:
                    matched.append("semantic")
                    score += semantic * 0.55

            if not matched:
                return None

            snippet = ""
            if text:
                needle = (q.content or (tokens[0] if tokens else q.text))
                snippet = _snippet(text, needle)
            return Hit(
                path=str(path), name=name, ext=path.suffix.lower(), size=st.st_size,
                modified=st.st_mtime, score=score, matched_on=matched, snippet=snippet,
                semantic=semantic, lexical=score - semantic,
            )

        results = await asyncio.gather(*[one(p) for p in candidates[:5000]])
        hits = [h for h in results if h is not None]
        return hits

    async def _get_text(self, path: Path, max_chars: int = 20_000) -> str:
        key = str(path)
        try:
            mtime = path.stat().st_mtime
        except OSError:
            return ""
        cached = self._text_cache.get(key)
        if cached and abs(cached[0] - mtime) < 1:
            return cached[1]
        ext = path.suffix.lower()
        if ext not in TEXT_EXTS and ext not in {
            ".pdf", ".docx", ".pptx", ".xlsx", ".csv", ".md", ".png", ".jpg", ".jpeg"
        }:
            return ""
        if path.stat().st_size > 60 * 1024 * 1024:
            return ""
        loop = asyncio.get_running_loop()
        text = await loop.run_in_executor(None, extract_text, path, max_chars)
        if len(self._text_cache) > 3000:
            self._text_cache.clear()
        self._text_cache[key] = (mtime, text)
        return text

    async def _embed(self, text: str) -> List[float]:
        cache_key = str(hash(text[:2000]))
        if cache_key in self._embed_cache:
            return self._embed_cache[cache_key]
        vec: List[float] = []
        if self._router is not None:
            try:
                vecs = await asyncio.wait_for(self._router.embed([text[:4000]]), timeout=10.0)
                if vecs and vecs[0]:
                    vec = vecs[0]
            except Exception:
                vec = []
        if not vec:
            from backend.app.models.router import _hash_embedding

            vec = _hash_embedding(text[:4000])
        if len(self._embed_cache) > 5000:
            self._embed_cache.clear()
        self._embed_cache[cache_key] = vec
        return vec

    @staticmethod
    def _sort(hits: List[Hit], sort: str) -> List[Hit]:
        if sort == "modified":
            return sorted(hits, key=lambda h: h.modified, reverse=True)
        if sort == "size":
            return sorted(hits, key=lambda h: h.size, reverse=True)
        if sort == "name":
            return sorted(hits, key=lambda h: h.name.lower())
        return sorted(hits, key=lambda h: h.score, reverse=True)


def _cosine(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def _snippet(text: str, needle: str = "", width: int = 240) -> str:
    if not text:
        return ""
    flat = re.sub(r"\s+", " ", text).strip()
    if not needle:
        return flat[:width]
    idx = flat.lower().find(needle.lower())
    if idx == -1:
        return flat[:width]
    start = max(0, idx - width // 3)
    end = min(len(flat), idx + width)
    return ("..." if start else "") + flat[start:end] + ("..." if end < len(flat) else "")


searcher = FileSearcher()
