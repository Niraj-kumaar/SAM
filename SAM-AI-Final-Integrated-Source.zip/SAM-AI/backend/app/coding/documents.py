"""
backend.app.coding.documents
============================

The **Document System**: create, read and convert Word, PowerPoint, Excel, PDF,
CSV and Markdown deliverables.

Everything is generated with real libraries (``python-docx``, ``python-pptx``,
``openpyxl``, ``reportlab``/``pypdf``) so the output opens correctly in
Microsoft Office, LibreOffice and any PDF reader — and so the desktop app's
file viewer can preview it.

Markdown is SAM's internal canonical format: agents produce Markdown, and this
module renders it into whichever format the user asked for.
"""

from __future__ import annotations

import csv
import io
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.app.config import settings
from backend.app.core.logging_config import get_logger

log = get_logger("coding.documents")

OUT_DIR = settings.sam_data_dir / "documents"


# ---------------------------------------------------------------------------
# Markdown parsing
# ---------------------------------------------------------------------------
def parse_markdown(md: str) -> Dict[str, Any]:
    """Split Markdown into a structured document model."""
    lines = (md or "").replace("\r\n", "\n").split("\n")
    title = ""
    sections: List[Dict[str, Any]] = []
    current: Dict[str, Any] = {"heading": "", "level": 0, "blocks": []}

    def flush() -> None:
        if current["heading"] or current["blocks"]:
            sections.append(dict(current))
        current.clear()
        current.update({"heading": "", "level": 0, "blocks": []})

    in_code = False
    code_lang = ""
    code_buf: List[str] = []
    list_buf: List[str] = []
    ordered = False

    def flush_list() -> None:
        nonlocal list_buf, ordered
        if list_buf:
            current["blocks"].append({"type": "ordered_list" if ordered else "list",
                                      "items": list(list_buf)})
            list_buf = []

    for raw in lines:
        line = raw.rstrip()
        if line.strip().startswith("```"):
            if in_code:
                current["blocks"].append({"type": "code", "lang": code_lang, "text": "\n".join(code_buf)})
                code_buf, in_code, code_lang = [], False, ""
            else:
                flush_list()
                in_code = True
                code_lang = line.strip()[3:].strip()
            continue
        if in_code:
            code_buf.append(raw)
            continue

        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush_list()
            level = len(m.group(1))
            text = m.group(2).strip()
            if level == 1 and not title:
                title = text
                continue
            if current["heading"] or current["blocks"]:
                flush()
            current["heading"] = text
            current["level"] = level
            continue

        if re.match(r"^\s*(?:[-*+]|\u2022)\s+", line):
            list_buf.append(re.sub(r"^\s*(?:[-*+]|\u2022)\s+", "", line))
            ordered = False
            continue
        m = re.match(r"^\s*(\d+)[.)]\s+(.*)$", line)
        if m:
            list_buf.append(m.group(2))
            ordered = True
            continue
        flush_list()

        if re.match(r"^\s*\|.*\|\s*$", line):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c or "-") for c in cells):
                continue
            if current["blocks"] and current["blocks"][-1]["type"] == "table":
                current["blocks"][-1]["rows"].append(cells)
            else:
                current["blocks"].append({"type": "table", "rows": [cells]})
            continue

        if line.strip() in ("---", "***", "___"):
            current["blocks"].append({"type": "hr"})
            continue
        if line.strip().startswith("> "):
            current["blocks"].append({"type": "quote", "text": line.strip()[2:]})
            continue
        if not line.strip():
            continue
        current["blocks"].append({"type": "para", "text": line.strip()})

    if in_code and code_buf:
        current["blocks"].append({"type": "code", "lang": code_lang, "text": "\n".join(code_buf)})
    flush_list()
    flush()

    return {"title": title or "Untitled document", "sections": sections}


def clean_inline(text: str) -> str:
    """Strip inline Markdown for plain-text renderers (DOCX runs, PDF)."""
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"\*\*([^*]*)\*\*", r"\1", text)
    text = re.sub(r"(?<!\*)\*([^*]*)\*(?!\*)", r"\1", text)
    text = re.sub(r"__([^_]*)__", r"\1", text)
    text = re.sub(r"_([^_]*)_", r"\1", text)
    text = re.sub(r"\[([^\]]*)\]\(([^)]*)\)", r"\1 (\2)", text)
    text = re.sub(r"~~([^~]*)~~", r"\1", text)
    return text.strip()


def _out_path(name: str, ext: str, output: Optional[str]) -> Path:
    if output:
        p = Path(output).expanduser()
        if not p.suffix:
            p = p.with_suffix("." + ext)
        return p
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^\w\-. ]+", "_", name)[:80].strip() or "document"
    return OUT_DIR / f"{safe}_{int(time.time())}.{ext}"


# ---------------------------------------------------------------------------
# DOCX
# ---------------------------------------------------------------------------
def markdown_to_docx(md: str, output: Optional[str] = None,
                     title: Optional[str] = None) -> Dict[str, Any]:
    try:
        import docx
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Pt, RGBColor
    except ImportError:
        return {"ok": False, "error": "python-docx is not installed (pip install python-docx)"}

    doc_model = parse_markdown(md)
    document = docx.Document()

    # base style
    style = document.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    heading = title or doc_model["title"]
    h = document.add_heading(heading, level=0)
    h.alignment = WD_ALIGN_PARAGRAPH.LEFT

    for section in doc_model["sections"]:
        if section["heading"]:
            document.add_heading(section["heading"], level=min(section.get("level") or 2, 4))
        for block in section["blocks"]:
            btype = block["type"]
            if btype == "para":
                document.add_paragraph(clean_inline(block["text"]))
            elif btype == "list":
                for item in block["items"]:
                    document.add_paragraph(clean_inline(item), style="List Bullet")
            elif btype == "ordered_list":
                for item in block["items"]:
                    document.add_paragraph(clean_inline(item), style="List Number")
            elif btype == "quote":
                p = document.add_paragraph(clean_inline(block["text"]))
                p.paragraph_format.left_indent = Pt(24)
                p.runs[0].italic = True if p.runs else None
            elif btype == "code":
                p = document.add_paragraph()
                run = p.add_run(block["text"])
                run.font.name = "Consolas"
                run.font.size = Pt(9)
            elif btype == "table":
                rows = block["rows"]
                if not rows:
                    continue
                table = document.add_table(rows=len(rows), cols=max(len(r) for r in rows))
                table.style = "Light Grid Accent 1"
                for i, row in enumerate(rows):
                    for j, cell in enumerate(row):
                        if j < len(table.rows[i].cells):
                            table.rows[i].cells[j].text = clean_inline(cell)
                document.add_paragraph("")
            elif btype == "hr":
                document.add_paragraph("_" * 60)

    path = _out_path(heading, "docx", output)
    path.parent.mkdir(parents=True, exist_ok=True)
    document.save(str(path))
    return {"ok": True, "format": "docx", "path": str(path), "bytes": path.stat().st_size,
            "title": heading, "sections": len(doc_model["sections"])}


# ---------------------------------------------------------------------------
# PPTX
# ---------------------------------------------------------------------------
def markdown_to_pptx(md: str, output: Optional[str] = None,
                     title: Optional[str] = None) -> Dict[str, Any]:
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt
    except ImportError:
        return {"ok": False, "error": "python-pptx is not installed (pip install python-pptx)"}

    doc_model = parse_markdown(md)
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    heading = title or doc_model["title"]

    # title slide
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    slide.shapes.title.text = heading
    if slide.placeholders and len(slide.placeholders) > 1:
        slide.placeholders[1].text = "Generated by SAM"

    blank = prs.slide_layouts[6]
    title_only = prs.slide_layouts[5]

    for section in doc_model["sections"]:
        body_blocks = section["blocks"]
        # split long sections across slides (max ~7 bullets each)
        chunks: List[List[Dict[str, Any]]] = [[]]
        for b in body_blocks:
            if b["type"] in ("list", "ordered_list"):
                items = b["items"]
                for i in range(0, len(items), 7):
                    if len(chunks[-1]) >= 1:
                        chunks.append([])
                    chunks[-1].append({"type": b["type"], "items": items[i : i + 7]})
            else:
                if sum(1 for x in chunks[-1] if x["type"] == "para") >= 4:
                    chunks.append([])
                chunks[-1].append(b)
        if not body_blocks:
            chunks = [[]]

        for ci, chunk in enumerate(chunks):
            layout = title_only if section["heading"] else blank
            s = prs.slides.add_slide(layout)
            if section["heading"] and s.shapes.title is not None:
                s.shapes.title.text = section["heading"] + (f" ({ci + 1})" if ci else "")
                top = Inches(1.6)
            else:
                top = Inches(0.7)
            box = s.shapes.add_textbox(Inches(0.7), top, Inches(12.0), Inches(5.4))
            tf = box.text_frame
            tf.word_wrap = True
            first = True
            for b in chunk:
                if b["type"] == "para":
                    p = tf.paragraphs[0] if first else tf.add_paragraph()
                    p.text = clean_inline(b["text"])
                    p.font.size = Pt(18)
                elif b["type"] in ("list", "ordered_list"):
                    for item in b["items"]:
                        p = tf.paragraphs[0] if first else tf.add_paragraph()
                        prefix = "•  " if b["type"] == "list" else ""
                        p.text = prefix + clean_inline(item)
                        p.font.size = Pt(17)
                        p.level = 0
                elif b["type"] == "quote":
                    p = tf.paragraphs[0] if first else tf.add_paragraph()
                    p.text = f"“{clean_inline(b['text'])}”"
                    p.font.size = Pt(18)
                    p.font.italic = True
                elif b["type"] == "code":
                    p = tf.paragraphs[0] if first else tf.add_paragraph()
                    p.text = b["text"][:900]
                    p.font.size = Pt(12)
                    p.font.name = "Consolas"
                elif b["type"] == "table":
                    rows = b["rows"][:8]
                    if rows:
                        cols = max(len(r) for r in rows)
                        tbl = s.shapes.add_table(len(rows), cols, Inches(0.7),
                                                 top, Inches(12.0), Inches(0.5 * len(rows))).table
                        for i, row in enumerate(rows):
                            for j, cell in enumerate(row[:cols]):
                                tbl.cell(i, j).text = clean_inline(cell)
                                tbl.cell(i, j).text_frame.paragraphs[0].font.size = Pt(12)
                    continue
                first = False

    path = _out_path(heading, "pptx", output)
    path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(path))
    return {"ok": True, "format": "pptx", "path": str(path), "bytes": path.stat().st_size,
            "title": heading, "slides": len(prs.slides.__iter__.__self__._sldIdLst)}


# ---------------------------------------------------------------------------
# XLSX / CSV
# ---------------------------------------------------------------------------
def markdown_to_xlsx(md: str, output: Optional[str] = None,
                     title: Optional[str] = None) -> Dict[str, Any]:
    try:
        import openpyxl
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        return {"ok": False, "error": "openpyxl is not installed (pip install openpyxl)"}

    doc_model = parse_markdown(md)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = (title or doc_model["title"])[:31] or "Sheet1"

    header_fill = PatternFill("solid", fgColor="1F2937")
    header_font = Font(bold=True, color="FFFFFF")
    row = 1

    def write_line(values: List[Any], bold: bool = False, fill: bool = False) -> None:
        nonlocal row
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=_coerce(value))
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if bold or fill:
                cell.font = header_font if fill else Font(bold=True)
                if fill:
                    cell.fill = header_fill
        row += 1

    for section in doc_model["sections"]:
        if section["heading"]:
            write_line([section["heading"]], bold=True)
        for block in section["blocks"]:
            if block["type"] == "table":
                for i, r in enumerate(block["rows"]):
                    write_line(r, fill=(i == 0))
                row += 1
            elif block["type"] in ("list", "ordered_list"):
                for item in block["items"]:
                    write_line(["•" if block["type"] == "list" else "", clean_inline(item)])
            elif block["type"] == "para":
                write_line([clean_inline(block["text"])])
            elif block["type"] == "code":
                write_line([block["text"]])
        row += 1

    # column widths
    for col in range(1, ws.max_column + 1):
        longest = 0
        for r in range(1, min(ws.max_row, 200) + 1):
            v = ws.cell(row=r, column=col).value
            longest = max(longest, len(str(v)) if v is not None else 0)
        ws.column_dimensions[get_column_letter(col)].width = min(60, max(12, longest + 2))
    ws.freeze_panes = "A2"

    path = _out_path(doc_model["title"], "xlsx", output)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(path))
    return {"ok": True, "format": "xlsx", "path": str(path), "bytes": path.stat().st_size,
            "rows": ws.max_row, "columns": ws.max_column}


def _coerce(value: Any) -> Any:
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    s = clean_inline(str(value))
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    if re.fullmatch(r"-?\d*\.\d+", s):
        return float(s)
    return s


def tables_to_csv(rows: List[List[Any]], output: Optional[str] = None,
                  name: str = "export") -> Dict[str, Any]:
    path = _out_path(name, "csv", output)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        for r in rows:
            writer.writerow([clean_inline(str(c)) for c in r])
    return {"ok": True, "format": "csv", "path": str(path), "bytes": path.stat().st_size,
            "rows": len(rows)}


def data_to_xlsx(rows: List[List[Any]], output: Optional[str] = None,
                 name: str = "dataset", sheet: str = "Data") -> Dict[str, Any]:
    """Write a 2-D dataset (first row = header) to xlsx."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        return {"ok": False, "error": "openpyxl is not installed"}
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet[:31]
    for i, r in enumerate(rows, start=1):
        for j, v in enumerate(r, start=1):
            cell = ws.cell(row=i, column=j, value=_coerce(v))
            if i == 1:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1F2937")
    ws.freeze_panes = "A2"
    path = _out_path(name, "xlsx", output)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(path))
    return {"ok": True, "format": "xlsx", "path": str(path), "bytes": path.stat().st_size,
            "rows": len(rows), "columns": max((len(r) for r in rows), default=0)}


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------
def markdown_to_pdf(md: str, output: Optional[str] = None,
                    title: Optional[str] = None) -> Dict[str, Any]:
    doc_model = parse_markdown(md)
    heading = title or doc_model["title"]
    path = _out_path(heading, "pdf", output)
    path.parent.mkdir(parents=True, exist_ok=True)

    # --- route 1: reportlab (pure python, always available-ish) -----------
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import mm
        from reportlab.platypus import (
            HRFlowable, ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer, Table,
            TableStyle, Preformatted,
        )

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle("T", parent=styles["Title"], fontSize=22, leading=26,
                                     spaceAfter=14, textColor=colors.HexColor("#0F172A"))
        h_style = ParagraphStyle("H", parent=styles["Heading2"], fontSize=14, leading=18,
                                 spaceBefore=12, spaceAfter=6, textColor=colors.HexColor("#1E293B"))
        body = ParagraphStyle("B", parent=styles["BodyText"], fontSize=10.5, leading=15,
                              spaceAfter=6)
        code = ParagraphStyle("C", parent=styles["Code"], fontSize=8.5, leading=11,
                              backColor=colors.HexColor("#F1F5F9"), leftIndent=6, rightIndent=6,
                              spaceBefore=4, spaceAfter=8)
        quote = ParagraphStyle("Q", parent=body, leftIndent=14, textColor=colors.HexColor("#475569"))

        story: List[Any] = [Paragraph(_esc(heading), title_style)]
        for section in doc_model["sections"]:
            if section["heading"]:
                story.append(Paragraph(_esc(section["heading"]), h_style))
            for block in section["blocks"]:
                t = block["type"]
                if t == "para":
                    story.append(Paragraph(_md_inline(_esc(block["text"])), body))
                elif t in ("list", "ordered_list"):
                    items = [ListItem(Paragraph(_md_inline(_esc(i)), body),
                                      leftIndent=14) for i in block["items"]]
                    story.append(ListFlowable(items, bulletType="bullet" if t == "list" else "1",
                                              start="•", leftIndent=14))
                elif t == "quote":
                    story.append(Paragraph(_esc(block["text"]), quote))
                elif t == "code":
                    story.append(Preformatted(block["text"][:4000], code))
                elif t == "table":
                    rows = [[Paragraph(_md_inline(_esc(c)), body) for c in r] for r in block["rows"][:40]]
                    if rows:
                        cols = max(len(r) for r in rows)
                        rows = [r + [""] * (cols - len(r)) for r in rows]
                        tbl = Table(rows, repeatRows=1, hAlign="LEFT")
                        tbl.setStyle(TableStyle([
                            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F2937")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CBD5E1")),
                            ("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("FONTSIZE", (0, 0), (-1, -1), 9),
                            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
                             [colors.white, colors.HexColor("#F8FAFC")]),
                            ("LEFTPADDING", (0, 0), (-1, -1), 5),
                            ("TOPPADDING", (0, 0), (-1, -1), 4),
                            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                        ]))
                        story.append(tbl)
                        story.append(Spacer(1, 8))
                elif t == "hr":
                    story.append(HRFlowable(width="100%", thickness=0.6,
                                            color=colors.HexColor("#CBD5E1"), spaceAfter=8))

        def footer(canvas, doc):
            canvas.saveState()
            canvas.setFont("Helvetica", 8)
            canvas.setFillColor(colors.HexColor("#94A3B8"))
            canvas.drawString(20 * mm, 12 * mm, f"SAM · {heading[:60]}")
            canvas.drawRightString(A4[0] - 20 * mm, 12 * mm, f"Page {doc.page}")
            canvas.restoreState()

        SimpleDocTemplate(str(path), pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                          topMargin=18 * mm, bottomMargin=18 * mm,
                          title=heading, author="SAM").build(story, onFirstPage=footer,
                                                              onLaterPages=footer)
        return {"ok": True, "format": "pdf", "path": str(path), "bytes": path.stat().st_size,
                "title": heading, "engine": "reportlab"}
    except ImportError:
        pass
    except Exception as exc:
        log.warning("reportlab PDF failed: %s", exc)

    # --- route 2: wkhtmltopdf / LibreOffice headless ----------------------
    tmp_md = path.with_suffix(".md")
    tmp_md.write_text(md, encoding="utf-8")
    tmp_html = path.with_suffix(".html")
    tmp_html.write_text(_md_to_html(md, heading), encoding="utf-8")

    import shutil
    import subprocess

    for cmd in (["wkhtmltopdf", "--quiet", str(tmp_html), str(path)],
                ["weasyprint", str(tmp_html), str(path)]):
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, check=True, timeout=120, capture_output=True)
                if path.exists():
                    return {"ok": True, "format": "pdf", "path": str(path),
                            "bytes": path.stat().st_size, "engine": cmd[0]}
            except Exception as exc:
                log.debug("%s failed: %s", cmd[0], exc)

    if shutil.which("soffice") or shutil.which("libreoffice"):
        exe = shutil.which("soffice") or shutil.which("libreoffice")
        try:
            subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir",
                            str(path.parent), str(tmp_html)], check=True, timeout=180,
                           capture_output=True)
            produced = path.parent / (tmp_html.stem + ".pdf")
            if produced.exists():
                produced.replace(path)
                return {"ok": True, "format": "pdf", "path": str(path),
                        "bytes": path.stat().st_size, "engine": "libreoffice"}
        except Exception as exc:
            log.debug("libreoffice failed: %s", exc)

    # --- route 3: fpdf-free minimal text PDF ------------------------------
    try:
        ok = _minimal_text_pdf(md, heading, path)
        if ok:
            return {"ok": True, "format": "pdf", "path": str(path), "bytes": path.stat().st_size,
                    "engine": "sam-minimal",
                    "note": "install reportlab for a fully styled PDF"}
    except Exception as exc:
        log.debug("minimal pdf failed: %s", exc)

    return {"ok": False, "error": "no PDF engine available — pip install reportlab",
            "html_fallback": str(tmp_html) if tmp_html.exists() else None}


def _esc(text: str) -> str:
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _md_inline(escaped: str) -> str:
    """Turn already-escaped Markdown inline syntax into reportlab markup."""
    out = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", escaped)
    out = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", out)
    out = re.sub(r"`([^`]+)`", r'<font face="Courier">\1</font>', out)
    return out


def _md_to_html(md: str, title: str) -> str:
    try:
        import markdown as mdlib

        body = mdlib.markdown(md or "", extensions=["tables", "fenced_code", "toc", "sane_lists"])
    except ImportError:
        body = "<pre>" + _esc(md or "") + "</pre>"
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{_esc(title)}</title>
<style>
 body{{font-family:'Segoe UI',Helvetica,Arial,sans-serif;margin:40px;color:#0f172a;line-height:1.6}}
 h1{{font-size:26px;border-bottom:2px solid #e2e8f0;padding-bottom:8px}}
 h2{{font-size:19px;margin-top:26px;color:#1e293b}} h3{{font-size:16px}}
 code,pre{{font-family:Consolas,monospace;background:#f1f5f9;padding:2px 5px;border-radius:4px}}
 pre{{padding:12px;overflow:auto}} table{{border-collapse:collapse;width:100%}}
 th,td{{border:1px solid #cbd5e1;padding:6px 9px;text-align:left;font-size:13px}}
 th{{background:#1f2937;color:#fff}} blockquote{{border-left:4px solid #cbd5e1;margin-left:0;
   padding-left:14px;color:#475569}}
</style></head><body>{body}</body></html>"""


def markdown_to_html(md: str, output: Optional[str] = None, title: Optional[str] = None) -> Dict[str, Any]:
    doc_model = parse_markdown(md)
    heading = title or doc_model["title"]
    path = _out_path(heading, "html", output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_md_to_html(md, heading), encoding="utf-8")
    return {"ok": True, "format": "html", "path": str(path), "bytes": path.stat().st_size}


def _minimal_text_pdf(md: str, title: str, path: Path) -> bool:
    """Hand-rolled single-font PDF so SAM can always produce *something*."""
    lines: List[str] = [title, ""]
    for section in parse_markdown(md)["sections"]:
        if section["heading"]:
            lines += [section["heading"].upper(), ""]
        for block in section["blocks"]:
            if block["type"] == "para":
                lines += _wrap(clean_inline(block["text"]), 95) + [""]
            elif block["type"] in ("list", "ordered_list"):
                for i, item in enumerate(block["items"], 1):
                    prefix = "  • " if block["type"] == "list" else f"  {i}. "
                    lines += [prefix + w for w in _wrap(clean_inline(item), 91)]
                lines.append("")
            elif block["type"] == "code":
                lines += ["    " + l for l in block["text"].splitlines()[:60]] + [""]
            elif block["type"] == "table":
                for r in block["rows"][:40]:
                    lines.append("  | " + " | ".join(clean_inline(str(c)) for c in r))
                lines.append("")

    content_lines = []
    y = 780
    for line in lines[:400]:
        safe = line.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")
        size = 14 if (line and line == title) else (11 if line.isupper() and line else 10)
        content_lines.append(f"BT /F1 {size} Tf 50 {y} Td ({safe[:120]}) Tj ET")
        y -= size + 6
        if y < 40:
            break
    stream = "\n".join(content_lines).encode("latin-1", "replace")

    objs: List[bytes] = []
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources "
                b"<< /Font << /F1 5 0 R >> >> /Contents 4 0 R >>")
    objs.append(b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")

    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = []
    for i, body in enumerate(objs, start=1):
        offsets.append(out.tell())
        out.write(f"{i} 0 obj\n".encode() + body + b"\nendobj\n")
    xref_pos = out.tell()
    out.write(f"xref\n0 {len(objs) + 1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF".encode())
    path.write_bytes(out.getvalue())
    return path.exists() and path.stat().st_size > 200


def _wrap(text: str, width: int) -> List[str]:
    words = text.split()
    if not words:
        return []
    out, cur = [], ""
    for w in words:
        if len(cur) + len(w) + 1 <= width:
            cur = (cur + " " + w).strip()
        else:
            out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    return out


# ---------------------------------------------------------------------------
# Conversion dispatcher
# ---------------------------------------------------------------------------
def convert_document(src: str, to: str, output: Optional[str] = None) -> Dict[str, Any]:
    """Convert an existing file to another format."""
    p = Path(src).expanduser()
    if not p.exists():
        return {"ok": False, "error": f"source does not exist: {p}"}
    from backend.app.files.file_ops import extract_text

    text = extract_text(p, max_chars=400_000)
    if not text and p.suffix.lower() not in {".png", ".jpg", ".jpeg"}:
        return {"ok": False, "error": f"could not extract text from {p.name}"}
    if p.suffix.lower() in {".md", ".markdown", ".txt"} and not text.startswith("#"):
        text = p.read_text(encoding="utf-8", errors="replace")

    stem = p.stem
    to = to.lower().lstrip(".")
    if to in ("docx", "word"):
        return markdown_to_docx(text, output or None, title=stem)
    if to == "pdf":
        return markdown_to_pdf(text, output or None, title=stem)
    if to == "pptx":
        return markdown_to_pptx(text, output or None, title=stem)
    if to in ("xlsx", "excel"):
        return markdown_to_xlsx(text, output or None, title=stem)
    if to in ("html", "htm"):
        return markdown_to_html(text, output or None, title=stem)
    if to in ("md", "markdown"):
        out = _out_path(stem, "md", output)
        out.write_text(text, encoding="utf-8")
        return {"ok": True, "format": "md", "path": str(out), "bytes": out.stat().st_size}
    if to == "txt":
        out = _out_path(stem, "txt", output)
        out.write_text(clean_inline(text), encoding="utf-8")
        return {"ok": True, "format": "txt", "path": str(out), "bytes": out.stat().st_size}
    if to == "csv":
        rows = [[c.strip() for c in line.split("|")] for line in text.splitlines() if "|" in line]
        if not rows:
            rows = [[l] for l in text.splitlines() if l.strip()]
        return tables_to_csv(rows, output, name=stem)
    if to in ("png", "jpg", "jpeg", "webp"):
        try:
            from PIL import Image

            with Image.open(p) as im:
                out = _out_path(stem, to, output)
                if to in ("jpg", "jpeg") and im.mode in ("RGBA", "P"):
                    im = im.convert("RGB")
                im.save(str(out))
                return {"ok": True, "format": to, "path": str(out), "bytes": out.stat().st_size}
        except ImportError:
            return {"ok": False, "error": "Pillow is not installed (pip install Pillow)"}
        except Exception as exc:
            return {"ok": False, "error": f"image conversion failed: {exc}"}
    return {"ok": False, "error": f"unsupported target format '{to}'",
            "supported": ["docx", "pdf", "pptx", "xlsx", "html", "md", "txt", "csv",
                          "png", "jpg", "webp"]}


def render(fmt: str, content: str, title: Optional[str] = None,
           output: Optional[str] = None) -> Dict[str, Any]:
    """Render Markdown ``content`` into the requested format."""
    fmt = (fmt or "md").lower().lstrip(".")
    if fmt in ("docx", "word"):
        return markdown_to_docx(content, output, title)
    if fmt == "pdf":
        return markdown_to_pdf(content, output, title)
    if fmt in ("pptx", "slides", "presentation"):
        return markdown_to_pptx(content, output, title)
    if fmt in ("xlsx", "excel", "spreadsheet"):
        return markdown_to_xlsx(content, output, title)
    if fmt in ("html", "htm"):
        return markdown_to_html(content, output, title)
    if fmt == "csv":
        rows = [[c.strip() for c in l.split("|")] for l in content.splitlines() if "|" in l]
        return tables_to_csv(rows or [[l] for l in content.splitlines()], output, title or "export")
    # markdown / text
    out = _out_path(title or "document", fmt if fmt in ("md", "txt") else "md", output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content, encoding="utf-8")
    return {"ok": True, "format": out.suffix.lstrip("."), "path": str(out),
            "bytes": out.stat().st_size}


# ---------------------------------------------------------------------------
# Introspection — what the document pipeline can actually produce right now
# ---------------------------------------------------------------------------
def engine_status() -> Dict[str, Any]:
    """
    Report the supported formats and which rendering engine is installed.

    The UI shows this on the CREATIVE page so the user knows *why* a format
    failed instead of guessing.
    """
    def have(module: str) -> bool:
        import importlib.util

        try:
            return importlib.util.find_spec(module) is not None
        except (ImportError, ValueError):
            return False

    def exe(name: str) -> bool:
        import shutil

        return shutil.which(name) is not None

    pdf_engines = [
        {"engine": "reportlab", "available": have("reportlab")},
        {"engine": "wkhtmltopdf", "available": exe("wkhtmltopdf")},
        {"engine": "weasyprint", "available": have("weasyprint")},
        {"engine": "libreoffice", "available": exe("soffice") or exe("libreoffice")},
        {"engine": "sam-minimal-text-pdf", "available": True,
         "note": "built-in fallback: plain text PDF, always works"},
    ]
    return {
        "formats": ["md", "txt", "csv", "html", "docx", "pptx", "xlsx", "pdf", "png", "jpg", "webp"],
        "libraries": {
            "python-docx": have("docx"),
            "python-pptx": have("pptx"),
            "openpyxl": have("openpyxl"),
            "reportlab": have("reportlab"),
            "markdown": have("markdown"),
            "pypdf": have("pypdf"),
            "Pillow": have("PIL"),
            "pandas": have("pandas"),
        },
        "pdf_engines": pdf_engines,
        "pdf_engine": next((e["engine"] for e in pdf_engines if e["available"]), "none"),
        "converters": {
            "docx": have("docx"), "pptx": have("pptx"), "xlsx": have("openpyxl"),
            "pdf": any(e["available"] for e in pdf_engines),
            "html": True, "md": True, "txt": True, "csv": True,
            "png": have("PIL"), "jpg": have("PIL"), "webp": have("PIL"),
        },
        "missing_install_hint": "pip install python-docx python-pptx openpyxl reportlab "
                                "markdown pypdf Pillow pandas",
        "output_dir": str(Path(settings.sam_data_dir) / "documents"),
    }
