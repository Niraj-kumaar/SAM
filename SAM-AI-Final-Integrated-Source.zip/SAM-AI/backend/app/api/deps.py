"""
backend.app.api.deps
=====================

Shared FastAPI dependencies.

Every mutating endpoint goes through :func:`tool_call`, which is the *same*
path a chat request takes: ``registry.execute()`` → ``guard()`` →
permission → risk → confirmation → run → verify → audit. The HTTP layer never
calls a tool function directly, so the UI cannot be used to bypass security.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import Depends, HTTPException, Request, WebSocket, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.config import settings
from backend.app.core.database import get_session
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, ToolExecutionError, registry

log = get_logger("api.deps")

bearer = HTTPBearer(auto_error=False, description="Optional SAM API token")


async def db_session() -> AsyncSession:  # pragma: no cover - FastAPI wiring
    async for session in get_session():
        yield session


def check_token(request: Request,
                credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer)) -> Optional[str]:
    """
    Token gate. Enabled only when ``SAM_API_TOKEN`` is set in ``.env``.

    SAM runs on the user's own machine, bound to localhost by default, so the
    token is opt-in — but when it is set, every REST and WS call must carry it.
    """
    expected = getattr(settings, "sam_api_token", "") or ""
    if not expected:
        return None
    provided = credentials.credentials if credentials else ""
    if not provided:
        provided = request.headers.get("x-sam-token", "") or \
            request.query_params.get("token", "")
    if provided != expected:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="invalid or missing SAM API token",
                            headers={"WWW-Authenticate": "Bearer"})
    return provided


def ws_token_ok(ws: WebSocket) -> bool:
    expected = getattr(settings, "sam_api_token", "") or ""
    if not expected:
        return True
    provided = ws.headers.get("x-sam-token", "") or ws.query_params.get("token", "")
    if provided:
        return provided == expected
    auth = ws.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip() == expected
    return False


def tool_context(request: Optional[Request], *, agent: str = "core", device: str = "pc",
                 conversation_id: Optional[str] = None, user_text: str = "",
                 language: str = "en", meta: Optional[Dict[str, Any]] = None) -> ToolContext:
    """Build a :class:`ToolContext` for an HTTP-initiated action."""
    client = "local"
    if request is not None and getattr(request, "client", None):
        client = request.client.host
    return ToolContext(
        agent=agent, device=device, conversation_id=conversation_id,
        user_text=user_text, language=language,
        meta={"source": "api", "client": client, **(meta or {})},
    )


async def tool_call(name: str, ctx: ToolContext, **params: Any) -> Dict[str, Any]:
    """
    Execute a registered tool through the guard and shape the result for HTTP.

    * a denial (permission / risk / confirmation) becomes **HTTP 200 with
      ``ok=false``** plus a ``confirmation`` block — the UI must be able to show
      "SAM is asking you to approve this", not swallow it as a 4xx.
    * an unknown tool becomes **404**.
    """
    tool = registry.get(name)
    if tool is None:
        raise HTTPException(status_code=404, detail=f"unknown tool: {name}")
    if not tool.is_available():
        raise HTTPException(status_code=409,
                            detail=f"tool {name} is not available on this platform")
    ctx.params = {**(ctx.params or {}), **params}
    try:
        value = await registry.execute(name, ctx, **params)
    except ToolExecutionError as exc:
        payload: Dict[str, Any] = {"ok": False, "tool": name, "error": str(exc),
                                   "denied_by": exc.denied_by, "risk": exc.risk}
        if exc.confirmation_id:
            payload["confirmation"] = {"id": exc.confirmation_id, "risk": exc.risk,
                                       "required": True}
        log.info("tool %s blocked by %s: %s", name, exc.denied_by, str(exc))
        return payload
    except PermissionError as exc:
        return {"ok": False, "tool": name, "error": str(exc), "denied_by": "permission"}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:  # pragma: no cover
        log.exception("tool %s crashed", name)
        return {"ok": False, "tool": name, "error": f"{type(exc).__name__}: {exc}"[:400]}

    if not isinstance(value, dict):
        value = {"ok": True, "value": value}
    value.setdefault("ok", True)
    value["tool"] = name
    return value


def unwrap(result: Any) -> Any:
    """Tools sometimes return ``{"ok": true, "value": {...}}``; flatten it."""
    if isinstance(result, dict) and "value" in result and len(result) <= 3:
        inner = result["value"]
        if isinstance(inner, dict):
            merged = {**inner}
            merged.setdefault("ok", result.get("ok", True))
            return merged
    return result
