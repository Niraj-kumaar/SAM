"""
backend.app.api.ws
==================

SAM's realtime surface. Four WebSocket endpoints:

``/ws/events``
    The firehose. Every event-bus topic (task progress, agent start/finish,
    risk assessments, confirmations, notifications, device state, chat) is
    pushed here. Supports ``{"action":"subscribe","topics":[...]}`` to narrow
    it, and ``{"action":"replay","since":<epoch>}`` for catch-up after a
    reconnect.

``/ws/chat``
    A conversational channel: send ``{"message": "..."}``, receive ``plan``,
    ``step``, ``progress``, ``confirmation``, ``reply`` and ``done`` frames.

``/ws/voice``
    Full-duplex voice. The client streams microphone audio frames as binary
    messages; SAM streams back ``{"type":"transcript"}``, ``{"type":"reply"}``
    and ``{"type":"audio","file":...}`` frames. Text messages configure the
    session (mode, language, wake word, push-to-talk).

``/ws/phone``
    The Android companion app's control channel (owned by
    :mod:`backend.app.devices.phone_bridge`). Pairing, RPC and state updates.

Every socket is closed cleanly on error and never leaks a subscription.
"""

from __future__ import annotations

import asyncio
import base64
import json
import time
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, status

from backend.app.api.deps import ws_token_ok
from backend.app.core.event_bus import Topics, bus, emit
from backend.app.core.logging_config import get_logger

log = get_logger("api.ws")

router = APIRouter()


def _send_json(ws: WebSocket, payload: Dict[str, Any]) -> Any:
    return ws.send_text(json.dumps(payload, default=str, ensure_ascii=False))


# ===========================================================================
# /ws/events
# ===========================================================================
@router.websocket("/ws/events")
async def ws_events(ws: WebSocket) -> None:
    """Push every SAM event to the UI."""
    if not ws_token_ok(ws):
        await ws.close(code=status.WS_1008_POLICY_VIOLATION)
        return
    await ws.accept()
    topics: List[str] = ["*"]
    sub = bus.subscribe(*topics)
    client = ws.client.host if ws.client else "local"
    log.info("events socket open (%s)", client)

    async def reader() -> None:
        """Handle control frames from the client."""
        nonlocal topics, sub
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except ValueError:
                await _send_json(ws, {"type": "error", "error": "invalid JSON"})
                continue
            action = str(msg.get("action") or "").lower()
            if action == "ping":
                await _send_json(ws, {"type": "pong", "ts": time.time()})
            elif action == "subscribe":
                wanted = msg.get("topics") or ["*"]
                bus.unsubscribe(sub)
                topics = list(wanted)
                sub = bus.subscribe(*topics)
                await _send_json(ws, {"type": "subscribed", "topics": topics})
            elif action == "replay":
                since = float(msg.get("since") or 0)
                events = bus.replay(since_ts=since,
                                    topics=None if "*" in topics else topics)
                await _send_json(ws, {"type": "replay", "count": len(events),
                                      "events": [e.to_dict() for e in events]})
            elif action == "snapshot":
                from backend.app.core.task_store import task_store
                from backend.app.security.confirmation_engine import confirmation_engine

                await _send_json(ws, {
                    "type": "snapshot", "ts": time.time(),
                    "tasks": [t.model_dump(mode="json") for t in task_store.active()],
                    "counts": task_store.counts(),
                    "confirmations": confirmation_engine.pending(),
                    "bus": bus.snapshot(),
                })
            else:
                await _send_json(ws, {"type": "error", "error": f"unknown action '{action}'",
                                      "actions": ["ping", "subscribe", "replay", "snapshot"]})

    reader_task = asyncio.create_task(reader())
    try:
        await _send_json(ws, {"type": "hello", "product": "SAM", "ts": time.time(),
                              "topics": topics, "buffered": bus.snapshot()["buffered"]})
        while True:
            try:
                event = await asyncio.wait_for(sub.queue.get(), timeout=15.0)
            except asyncio.TimeoutError:
                await _send_json(ws, {"type": "ping", "ts": time.time()})
                continue
            await _send_json(ws, {"type": "event", **event.to_dict()})
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # pragma: no cover
        log.debug("events socket error: %s", exc)
    finally:
        reader_task.cancel()
        bus.unsubscribe(sub)
        log.info("events socket closed (%s)", client)


# ===========================================================================
# /ws/chat
# ===========================================================================
@router.websocket("/ws/chat")
async def ws_chat(ws: WebSocket) -> None:
    """Conversational channel with live plan/step/progress frames."""
    if not ws_token_ok(ws):
        await ws.close(code=status.WS_1008_POLICY_VIOLATION)
        return
    await ws.accept()
    conversation_id: Optional[str] = None
    log.info("chat socket open")
    try:
        await _send_json(ws, {"type": "hello", "ts": time.time(),
                              "conversation_id": conversation_id})
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except ValueError:
                await _send_json(ws, {"type": "error", "error": "invalid JSON"})
                continue

            if str(msg.get("action") or "").lower() in ("ping", ""):
                if msg.get("action") == "ping":
                    await _send_json(ws, {"type": "pong", "ts": time.time()})
                    continue

            text = str(msg.get("message") or msg.get("text") or "").strip()
            if not text:
                await _send_json(ws, {"type": "error", "error": "empty message"})
                continue
            conversation_id = msg.get("conversation_id") or conversation_id

            await _run_chat_turn(ws, text, conversation_id, msg)
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # pragma: no cover
        log.exception("chat socket crashed")
        try:
            await _send_json(ws, {"type": "error", "error": str(exc)[:300]})
        except Exception:
            pass
    finally:
        log.info("chat socket closed")


async def _run_chat_turn(ws: WebSocket, text: str, conversation_id: Optional[str],
                         msg: Dict[str, Any]) -> None:
    from backend.app.core.orchestrator import orchestrator

    sub = bus.subscribe("task.*", "agent.*", "security.*", "chat.*", "model.*")
    queue = asyncio.Queue()

    async def pump() -> None:
        try:
            while True:
                event = await sub.queue.get()
                await queue.put(event)
        except asyncio.CancelledError:
            raise

    pump_task = asyncio.create_task(pump())
    turn = asyncio.create_task(orchestrator.handle_text(
        text, conversation_id=conversation_id,
        language=msg.get("language") or "auto",
        channel="ws", dry_run=bool(msg.get("dry_run")),
        max_steps=int(msg.get("max_steps") or 12),
    ))
    try:
        await _send_json(ws, {"type": "accepted", "message": text[:200], "ts": time.time()})
        while not turn.done():
            try:
                event = await asyncio.wait_for(queue.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            await _send_json(ws, {"type": "event", **event.to_dict()})
        result = turn.result()
        await _send_json(ws, {
            "type": "reply", "conversation_id": result.conversation_id,
            "message_id": result.message_id, "reply": result.reply,
            "language": result.language, "model": result.model, "agent": result.agent,
            "intent": result.intent, "confidence": result.confidence,
            "task_id": result.task.id if result.task else None,
            "task": result.task.model_dump(mode="json") if result.task else None,
            "sources": result.sources, "actions": result.actions,
            "confirmations": result.confirmations, "took_ms": result.took_ms,
            "ok": result.ok,
        })
        await _send_json(ws, {"type": "done", "ok": result.ok,
                              "conversation_id": result.conversation_id})
    except Exception as exc:  # pragma: no cover
        await _send_json(ws, {"type": "error", "error": str(exc)[:300]})
    finally:
        pump_task.cancel()
        bus.unsubscribe(sub)
        if not turn.done():
            turn.cancel()


# ===========================================================================
# /ws/voice
# ===========================================================================
@router.websocket("/ws/voice")
async def ws_voice(ws: WebSocket) -> None:
    """
    Full-duplex voice.

    Client → SAM: binary frames of microphone audio (16 kHz mono 16-bit PCM or
    any container the STT provider accepts), or JSON control frames.
    SAM → client: ``state``, ``listening``, ``transcript``, ``reply``, ``audio``,
    ``done``, ``error`` frames.
    """
    if not ws_token_ok(ws):
        await ws.close(code=status.WS_1008_POLICY_VIOLATION)
        return
    await ws.accept()

    from backend.app.voice.engine import voice_engine
    from backend.app.voice.modes import voice_modes
    from backend.app.voice.wake import wake_listener

    buffer = bytearray()
    collecting = False
    conversation_id: Optional[str] = None
    wake_only = bool(wake_listener.enabled)

    async def flush() -> None:
        nonlocal buffer, conversation_id
        if len(buffer) < 2048:
            buffer = bytearray()
            return
        audio = bytes(buffer)
        buffer = bytearray()
        await _send_json(ws, {"type": "listening", "bytes": len(audio), "ts": time.time()})
        result = await voice_engine.voice_turn(audio=audio, filename="mic.wav",
                                               conversation_id=conversation_id,
                                               wake_filter=wake_only)
        conversation_id = result.get("conversation_id") or conversation_id
        if result.get("stt"):
            await _send_json(ws, {"type": "transcript", **{
                k: result["stt"].get(k) for k in
                ("text", "language", "confidence", "provider", "latency_ms")}})
        if result.get("wake") is False:
            await _send_json(ws, {"type": "wake", "detected": False,
                                  "heard": result.get("heard", "")})
            return
        await _send_json(ws, {"type": "reply", "text": result.get("reply", ""),
                              "agent": result.get("agent"), "intent": result.get("intent"),
                              "task_id": result.get("task_id"),
                              "actions": result.get("actions"),
                              "confirmations": result.get("confirmations"),
                              "language": result.get("language"),
                              "timings": result.get("timings")})
        audio_out = result.get("audio") or {}
        if audio_out.get("ok"):
            await _send_json(ws, {"type": "audio",
                                  "url": result.get("audio_url"),
                                  "file": audio_out.get("file"),
                                  "provider": audio_out.get("provider"),
                                  "voice": audio_out.get("voice"),
                                  "duration_ms": audio_out.get("duration_ms")})
        await _send_json(ws, {"type": "done", "ok": bool(result.get("ok")),
                              "conversation_id": conversation_id})

    try:
        await _send_json(ws, {"type": "state", **voice_engine.state(),
                              "wake_only": wake_only,
                              "modes": [m["key"] for m in voice_modes.list_modes()]})
        while True:
            message = await ws.receive()
            if message.get("type") == "websocket.disconnect":
                break
            if (data := message.get("bytes")) is not None:
                buffer.extend(data)
                collecting = True
                continue
            raw = message.get("text")
            if raw is None:
                continue
            # a JSON frame means the utterance ended
            if collecting and buffer:
                await flush()
                collecting = False
            try:
                msg = json.loads(raw)
            except ValueError:
                await _send_json(ws, {"type": "error", "error": "invalid JSON"})
                continue
            action = str(msg.get("action") or "").lower()
            if action == "start":
                collecting = True
                await _send_json(ws, {"type": "listening", "state": "ready"})
            elif action == "stop":
                await flush()
                collecting = False
                await _send_json(ws, {"type": "stopped"})
            elif action == "cancel":
                buffer = bytearray()
                collecting = False
                voice_engine.stop_speaking()
                await _send_json(ws, {"type": "cancelled"})
            elif action == "barge_in":
                voice_engine.stop_speaking()
                await _send_json(ws, {"type": "barge_in", "ok": True})
            elif action == "speak":
                out = await voice_engine.speak(str(msg.get("text") or ""))
                await _send_json(ws, {"type": "audio", "url": (
                    f"/api/v1/voice/audio/{out['file']}" if out.get("file") else None),
                    "ok": out.get("ok"), "error": out.get("error")})
            elif action == "config":
                values = {k: v for k, v in msg.items() if k != "action"}
                state = voice_engine.configure(**values)
                await _send_json(ws, {"type": "state", **state})
            elif action == "mode":
                state = voice_modes.set_mode(str(msg.get("mode") or "standard"))
                await _send_json(ws, {"type": "state", **voice_engine.state()})
            elif action == "wake":
                out = await wake_listener.check_transcript(str(msg.get("text") or ""))
                await _send_json(ws, {"type": "wake", **out})
            elif action == "text":
                conversation_id = msg.get("conversation_id") or conversation_id
                await _send_json(ws, {"type": "accepted", "message": str(msg.get("text"))[:200]})
                result = await voice_engine.voice_turn(text=str(msg.get("text") or ""),
                                                       conversation_id=conversation_id,
                                                       speak_reply=msg.get("speak"))
                conversation_id = result.get("conversation_id") or conversation_id
                await _send_json(ws, {"type": "reply", "text": result.get("reply", ""),
                                      "actions": result.get("actions"),
                                      "task_id": result.get("task_id")})
                if result.get("audio_url"):
                    await _send_json(ws, {"type": "audio", "url": result["audio_url"]})
                await _send_json(ws, {"type": "done", "ok": bool(result.get("ok"))})
            elif action == "ping":
                await _send_json(ws, {"type": "pong", "ts": time.time()})
            else:
                await _send_json(ws, {"type": "error",
                                      "error": f"unknown action '{action}'",
                                      "actions": ["start", "stop", "cancel", "barge_in", "speak",
                                                  "config", "mode", "wake", "text", "ping"]})
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # pragma: no cover
        log.exception("voice socket crashed")
        try:
            await _send_json(ws, {"type": "error", "error": str(exc)[:300]})
        except Exception:
            pass
    finally:
        log.info("voice socket closed (buffered %d bytes dropped)", len(buffer))


# ===========================================================================
# /ws/phone  — the Android companion app's control channel
# ===========================================================================
@router.websocket("/ws/phone")
async def ws_phone(ws: WebSocket) -> None:
    """
    Companion-app channel.

    Handshake (first JSON frame from the phone)::

        {"type": "hello", "protocol": "1.0", "device_id": "...", "name": "...",
         "model": "...", "android_version": "...", "code": "ABCD-EFGH",
         "signature": "<hmac>", "capabilities": [...], "permissions": {...}}

    SAM replies ``{"type":"hello_ok", ...}`` or ``{"type":"error", ...}``.
    Then SAM sends ``{"type":"request","id":..,"method":..,"params":..}`` and the
    phone replies ``{"type":"response","id":..,"ok":..,"result":..}``.
    The phone may also push ``{"type":"event","event":..,"data":..}``.
    """
    from backend.app.devices.phone_bridge import PROTOCOL_VERSION, phone_bridge
    from backend.app.devices.registry import device_registry
    from backend.app.devices.sync import sync_engine

    await ws.accept()
    device_id = ""
    try:
        raw = await asyncio.wait_for(ws.receive_text(), timeout=30.0)
        hello = json.loads(raw)
    except (asyncio.TimeoutError, ValueError, WebSocketDisconnect):
        await _send_json(ws, {"type": "error", "error": "expected a JSON hello frame"})
        await ws.close()
        return

    if hello.get("type") != "hello":
        await _send_json(ws, {"type": "error", "error": "first frame must be type=hello"})
        await ws.close()
        return
    if str(hello.get("protocol") or "") not in ("", PROTOCOL_VERSION):
        await _send_json(ws, {"type": "error",
                              "error": f"protocol mismatch: phone {hello.get('protocol')}, "
                                       f"SAM {PROTOCOL_VERSION}"})
        await ws.close()
        return

    code = str(hello.get("code") or "").upper().strip()
    signature = str(hello.get("signature") or "")
    device_id = str(hello.get("device_id") or "").strip() or f"phone-{int(time.time())}"

    # pairing must be approved by the user on the PC side
    if code and signature and not phone_bridge.verify_handshake(code, signature):
        await _send_json(ws, {"type": "error", "error": "handshake signature rejected",
                              "reason": "PHONE_PAIRING_SECRET differs on the two sides"})
        await ws.close()
        return
    if code and code in phone_bridge.pairing_offers:
        await phone_bridge.accept_pairing(code, device_id, str(hello.get("name") or ""))
    elif code:
        await _send_json(ws, {"type": "error", "error": "unknown or expired pairing code",
                              "hint": "create a fresh code on the PC: POST /api/v1/phone/pairing"})
        await ws.close()
        return

    session = await phone_bridge.register(device_id, ws, hello)
    await device_registry.register(device_id, name=session.name or "Android phone",
                                   kind="phone", platform_name=f"Android {session.android_version}",
                                   address=ws.client.host if ws.client else "",
                                   capabilities=session.capabilities or None,
                                   state={"permissions": session.permissions})
    await _send_json(ws, {"type": "hello_ok", "protocol": PROTOCOL_VERSION,
                          "device_id": device_id, "name": session.name,
                          "sam_version": "1.0.0", "ts": time.time(),
                          "server_time": time.strftime("%Y-%m-%dT%H:%M:%S"),
                          "requests": ["battery.get", "wifi.state", "wifi.set", "bluetooth.set",
                                       "media.volume", "display.brightness", "notifications.list",
                                       "notifications.post", "alarm.create", "apps.list",
                                       "apps.launch", "media.control", "media.camera",
                                       "screen.capture", "calendar.list", "calendar.create",
                                       "message.prepare", "message.send", "call.dial",
                                       "contacts.search", "files.list", "clipboard.set",
                                       "clipboard.get", "file.receive", "system.state"]})
    log.info("phone paired: %s (%s)", device_id, session.name)

    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except ValueError:
                await _send_json(ws, {"type": "error", "error": "invalid JSON"})
                continue
            kind = str(msg.get("type") or "").lower()
            phone_bridge.touch(device_id)

            if kind == "response":
                phone_bridge.resolve(device_id, str(msg.get("id") or ""), {
                    "ok": bool(msg.get("ok", True)),
                    "result": msg.get("result"),
                    "error": msg.get("error"),
                    "permission_denied": bool(msg.get("permission_denied")),
                })
            elif kind == "event":
                event = str(msg.get("event") or "")
                data = msg.get("data") or {}
                phone_bridge.update_state(device_id, data if isinstance(data, dict) else {})
                await device_registry.update_state(device_id, data if isinstance(data, dict) else {})
                emit(Topics.PHONE_EVENT, device_id=device_id, event=event, data=data)
                if event in ("battery_low", "battery_full", "charging"):
                    await scheduler_trigger(event)
            elif kind == "state":
                data = msg.get("state") or {}
                phone_bridge.update_state(device_id, data)
                await device_registry.update_state(device_id, data)
            elif kind == "permissions":
                perms = msg.get("permissions") or {}
                session.permissions = perms
                await device_registry.update_state(device_id, {"permissions": perms})
                await _send_json(ws, {"type": "permissions_ok", "count": len(perms)})
            elif kind == "ping":
                await _send_json(ws, {"type": "pong", "ts": time.time()})
            elif kind == "file.push":
                result = await sync_engine.receive_file(str(msg.get("name") or "phone-file"),
                                                        str(msg.get("data") or ""))
                await _send_json(ws, {"type": "file.result", **result})
            else:
                await _send_json(ws, {"type": "error", "error": f"unknown frame type '{kind}'"})
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # pragma: no cover
        log.warning("phone socket error: %s", exc)
    finally:
        await phone_bridge.unregister(device_id)
        await device_registry.set_online(device_id, False)
        emit(Topics.DEVICE_OFFLINE, device_id=device_id, kind="phone")
        log.info("phone disconnected: %s", device_id)


async def scheduler_trigger(event: str) -> None:
    from backend.app.automation.scheduler import scheduler

    try:
        await scheduler.trigger_event(event)
    except Exception as exc:  # pragma: no cover
        log.debug("event trigger %s failed: %s", event, exc)
