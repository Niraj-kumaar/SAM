"""
backend.app.api.v1.markets
==========================

The **MARKET ANALYZER** page API (forex · binary options · crypto · stocks ·
indices · commodities).

Design rules — the same ones the rest of SAM follows:

1. Every endpoint that *does* something goes through :func:`tool_call`, i.e.
   ``registry.execute()`` → ``guard()`` → permission → risk → confirmation →
   run → audit. The HTTP layer never calls a market function directly, so the
   dashboard cannot be used to bypass the security model.
2. A denial is **HTTP 200 with ``ok=false``** plus a ``confirmation`` block, so
   the UI can show "SAM needs your approval" instead of swallowing a 4xx.
3. Read-only endpoints are GET so the dashboard can poll them cheaply; anything
   that writes (journal, alerts, paper trades) is POST/DELETE.
4. No endpoint can place a real order. Live execution is not exposed over HTTP
   at all — ``/broker`` only *reports* that policy.

Endpoint map
------------
=============================  ==============================================
``GET  /status``               the brain's own health report
``GET  /feeds``                which data sources are reachable
``GET  /quote``                live price for any symbol
``POST /candles``              OHLCV history
``GET  /forex``                FX cross table
``GET  /crypto``               crypto screener
``POST /watchlist``            watchlist quotes + signals
``POST /indicators``           full technical snapshot
``POST /signal``               scored bias + confidence + reasons
``POST /report``               multi-timeframe Markdown report
``POST /plan``                 entry / stop / targets / lot size
``POST /binary``               expiry-aware binary analysis + payout maths
``POST /regime``               trending / ranging / squeezing
``POST /screener``             rank many symbols by setup quality
``POST /multi-timeframe``      higher-timeframe alignment
``GET  /levels``               support / resistance / pivots / Fibonacci
``GET  /patterns``             candlestick + chart patterns
``POST /volatility``           ATR, historical vol, expected move
``POST /correlation``          correlation matrix
``POST /compare``              side-by-side comparison
``GET  /sentiment``            news-driven sentiment
``GET  /calendar``             market risk events
``POST /risk``                 sizing, pip value, Kelly, ruin, drawdown, …
``POST /backtest``             strategy replay + walk-forward + binary test
``GET/POST /journal``          list / add journal trades
``POST /journal/close``        close a journal trade
``GET  /journal/stats``        journal statistics + lessons
``POST /journal/review``       attach a review
``GET/POST /alerts``           list / create price alerts
``DELETE /alerts/{id}``        remove an alert
``POST /alerts/check``         evaluate every alert now
``GET  /alerts/poller``        background poller state
``GET  /paper``                paper portfolio
``POST /paper/trade``          open a virtual position
``POST /paper/close``          close a virtual position
``POST /paper/reset``          reset the virtual account
``GET  /explain``              explain a concept / indicator / product
``GET  /topics``               the offline glossary (for UI autocomplete)
``GET  /broker``               live-trading policy status
=============================  ==============================================
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.config import settings
from backend.app.core.logging_config import get_logger

log = get_logger("api.markets")

router = APIRouter(prefix="/markets", tags=["markets"], dependencies=[Depends(check_token)])

_TIMEFRAMES = {"1m", "2m", "5m", "15m", "30m", "1h", "2h", "4h", "1d", "5d", "1wk", "1mo"}


def _ctx(user_text: str = "") -> Any:
    return tool_context(None, agent="markets", device="cloud", user_text=user_text[:300])


def _require_enabled() -> None:
    if not settings.market_enabled:
        raise HTTPException(status_code=403,
                            detail="the Market Analyzer is disabled (MARKET_ENABLED=false)")


def _require_web() -> None:
    _require_enabled()
    if not settings.web_enabled:
        raise HTTPException(status_code=403,
                            detail="market data needs the network: web access is disabled by "
                                   "Privacy Mode (WEB_ENABLED=false)")


def _tf(interval: str, default: str = "1h") -> str:
    return interval if interval in _TIMEFRAMES else default


# ---------------------------------------------------------------------------
# request bodies
# ---------------------------------------------------------------------------
class SymbolBody(BaseModel):
    symbol: str = Field(..., min_length=1, description="EURUSD, bitcoin, nifty, gold, AAPL …")
    interval: str = Field("1h", description="1m 5m 15m 30m 1h 4h 1d 1wk 1mo")
    limit: int = Field(300, ge=10, le=2000)


class CandlesBody(SymbolBody):
    pass


class SignalBody(SymbolBody):
    pass


class ReportBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    timeframes: List[str] = Field(default_factory=lambda: ["15m", "1h", "4h"])
    style: str = Field("standard", description="brief | standard | detailed")
    save: bool = Field(False, description="also save the report as a Markdown document")


class PlanBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    interval: str = "1h"
    balance: float = Field(0.0, ge=0, description="account balance; 0 = the configured default")
    risk_percent: float = Field(1.0, ge=0.05, le=5.0)
    rr: float = Field(2.0, ge=0.5, le=20.0)
    htf: str = Field("", description="higher timeframe for the bias, e.g. 4h")
    account_currency: str = "USD"


class BinaryBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    interval: str = "5m"
    expiry_minutes: int = Field(5, ge=1, le=1440)
    payout_percent: float = Field(80.0, ge=1.0, le=200.0)
    side: str = Field("", description="up | down | '' = let the analysis decide")


class ScreenerBody(BaseModel):
    symbols: List[str] = Field(default_factory=list,
                               description="empty = the universe for that asset class")
    universe: str = Field("forex", description="forex | crypto | indices | commodities | stocks")
    interval: str = "1h"
    min_confidence: float = Field(0.4, ge=0.0, le=1.0)
    direction: str = Field("any", description="any | long | short")


class SymbolsBody(BaseModel):
    symbols: List[str] = Field(..., min_length=2, max_length=8)
    interval: str = "1d"
    lookback: int = Field(90, ge=20, le=500)


class VolatilityBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    interval: str = "1h"
    horizon_candles: int = Field(5, ge=1, le=200)


class RiskBody(BaseModel):
    operation: str = Field(..., description="position_size | pip_value | risk_reward | kelly | "
                                            "risk_of_ruin | drawdown_math | margin_required | "
                                            "portfolio_risk | expectancy | stake_plan | "
                                            "martingale_check")
    params: Dict[str, Any] = Field(default_factory=dict)


class BacktestBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    strategy: str = Field("ma_cross")
    interval: str = "1d"
    limit: int = Field(600, ge=100, le=2000)
    params: Dict[str, Any] = Field(default_factory=dict)
    capital: float = Field(10000.0, gt=0)
    commission_percent: float = Field(0.0, ge=0, le=2)
    slippage_percent: float = Field(0.02, ge=0, le=2)
    walk_forward: bool = False
    expiry_candles: int = Field(5, ge=1, le=96)
    payout_percent: float = Field(80.0, ge=1, le=200)
    stake: float = Field(100.0, gt=0)


class JournalAddBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    direction: str = Field("long", description="long | short | up | down")
    product: str = Field("spot", description="spot | binary | cfd | option | paper")
    asset_class: str = Field("forex")
    entry: Optional[float] = None
    stop: Optional[float] = None
    targets: List[float] = Field(default_factory=list)
    units: float = Field(0.0, ge=0)
    stake: float = Field(0.0, ge=0)
    timeframe: str = "1h"
    strategy: str = ""
    notes: str = ""
    tags: str = ""
    expiry_minutes: int = Field(0, ge=0, le=1440)
    payout_percent: float = Field(0.0, ge=0, le=200)


class JournalCloseBody(BaseModel):
    trade_id: int = Field(..., ge=1)
    exit_price: float = Field(..., gt=0)
    result: str = Field("", description="win | loss | tie | '' = derive from P&L")
    fees: float = Field(0.0, ge=0)
    notes: str = ""
    review: str = ""


class JournalReviewBody(BaseModel):
    trade_id: int = Field(..., ge=1)
    review: str = Field(..., min_length=1)
    tags: str = ""


class AlertBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    condition: str = Field("above", description="above | below | cross_up | cross_down | "
                                                "percent_change | rsi_above | rsi_below | "
                                                "atr_spike | signal_flip")
    threshold: float = Field(0.0)
    timeframe: str = "1h"
    window_minutes: int = Field(60, ge=1, le=10080)
    message: str = ""
    channel: str = Field("desktop", description="desktop | notification | voice | phone")
    once: bool = True
    cooldown_minutes: int = Field(60, ge=1, le=10080)


class PaperTradeBody(BaseModel):
    symbol: str = Field(..., min_length=1)
    direction: str = Field("long", description="long | short")
    entry: Optional[float] = Field(None, gt=0)
    units: Optional[float] = Field(None, gt=0)
    stop: Optional[float] = Field(None, gt=0)
    risk_percent: float = Field(1.0, ge=0.05, le=5.0)
    targets: List[float] = Field(default_factory=list)
    notes: str = ""


class PaperCloseBody(BaseModel):
    position_id: Optional[int] = Field(None, ge=1)
    symbol: str = ""
    exit_price: Optional[float] = Field(None, gt=0)
    notes: str = ""


class PaperResetBody(BaseModel):
    starting_balance: float = Field(10000.0, gt=0, le=10_000_000)
    currency: str = "USD"


# ---------------------------------------------------------------------------
# status + data
# ---------------------------------------------------------------------------
@router.get("/status", summary="Market Analyzer health")
async def status(deep: bool = False) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.status", _ctx(), deep=deep))


@router.get("/feeds", summary="Which market data sources are reachable")
async def feeds() -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.feed_status", _ctx()))


@router.get("/quote", summary="Live quote for any symbol")
async def quote(symbol: str) -> Dict[str, Any]:
    _require_web()
    if not symbol.strip():
        raise HTTPException(status_code=400, detail="symbol is required")
    return unwrap(await tool_call("market.quote", _ctx(symbol), symbol=symbol))


@router.post("/candles", summary="OHLCV history")
async def candles(body: CandlesBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.candles", _ctx(body.symbol), symbol=body.symbol,
                                  interval=_tf(body.interval), limit=body.limit))


@router.get("/forex", summary="FX cross table for a base currency")
async def forex(base: str = "USD", quotes: str = "") -> Dict[str, Any]:
    _require_web()
    currencies = [c.strip().upper() for c in quotes.split(",") if c.strip()] or None
    return unwrap(await tool_call("market.forex_rates", _ctx(base), base=base.upper()[:3],
                                  currencies=currencies))


@router.get("/crypto", summary="Crypto screener (top / gainers / losers)")
async def crypto(limit: int = 15, sort: str = "market_cap", vs: str = "usd") -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.crypto_screener", _ctx(), limit=max(1, min(limit, 100)),
                                  sort=sort, vs=vs))


@router.post("/watchlist", summary="Watchlist quotes + signals")
async def watchlist(symbols: Optional[List[str]] = None, interval: str = "1h",
                    with_signal: bool = True) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.watchlist", _ctx(), symbols=symbols or None,
                                  interval=_tf(interval), with_signal=with_signal))


# ---------------------------------------------------------------------------
# analysis
# ---------------------------------------------------------------------------
@router.post("/indicators", summary="Full technical snapshot")
async def indicators(body: SymbolBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.indicators", _ctx(body.symbol), symbol=body.symbol,
                                  interval=_tf(body.interval), limit=body.limit))


@router.post("/signal", summary="Scored bias, confidence and the reasons behind it")
async def signal(body: SignalBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.signal", _ctx(body.symbol), symbol=body.symbol,
                                  interval=_tf(body.interval), limit=body.limit))


@router.post("/report", summary="Multi-timeframe Markdown report")
async def report(body: ReportBody) -> Dict[str, Any]:
    _require_web()
    frames = [f for f in body.timeframes if f in _TIMEFRAMES] or ["15m", "1h", "4h"]
    return unwrap(await tool_call("market.technical_report", _ctx(body.symbol),
                                  symbol=body.symbol, timeframes=frames[:4], style=body.style,
                                  save=body.save))


@router.post("/plan", summary="Forex trade plan: entry, stop, targets, lot size")
async def plan(body: PlanBody) -> Dict[str, Any]:
    _require_web()
    balance = body.balance or float(settings.market_paper_balance or 0)
    return unwrap(await tool_call("market.forex_plan", _ctx(body.symbol), symbol=body.symbol,
                                  interval=_tf(body.interval), balance=balance,
                                  risk_percent=body.risk_percent, rr=body.rr, htf=body.htf,
                                  account_currency=body.account_currency.upper()[:3]))


@router.post("/binary", summary="Binary-options analysis (expiry-aware, analysis only)")
async def binary(body: BinaryBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.binary_analysis", _ctx(body.symbol),
                                  symbol=body.symbol, interval=_tf(body.interval, "5m"),
                                  expiry_minutes=body.expiry_minutes,
                                  payout_percent=body.payout_percent, side=body.side))


@router.post("/regime", summary="Trending / ranging / squeezing + what suits it")
async def regime(body: SymbolBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.regime", _ctx(body.symbol), symbol=body.symbol,
                                  interval=_tf(body.interval)))


@router.post("/screener", summary="Rank many symbols by setup quality")
async def screener(body: ScreenerBody) -> Dict[str, Any]:
    _require_web()
    params: Dict[str, Any] = {"interval": _tf(body.interval),
                              "min_confidence": body.min_confidence, "direction": body.direction}
    if body.symbols:
        params["symbols"] = body.symbols[:20]
    else:
        # no symbols given → use the tool's own universe handling
        params["symbols"] = None
        params["request"] = f"scan the {body.universe} universe"
    return unwrap(await tool_call("market.screener", _ctx(), **params))


@router.post("/multi-timeframe", summary="Higher-timeframe alignment")
async def multi_timeframe(body: ReportBody) -> Dict[str, Any]:
    _require_web()
    frames = [f for f in body.timeframes if f in _TIMEFRAMES] or ["15m", "1h", "4h"]
    return unwrap(await tool_call("market.multi_timeframe", _ctx(body.symbol), symbol=body.symbol,
                                  timeframes=frames[:4]))


@router.get("/levels", summary="Support / resistance / pivots / Fibonacci")
async def levels(symbol: str, interval: str = "1d", pivot_type: str = "classic") -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.levels", _ctx(symbol), symbol=symbol,
                                  interval=_tf(interval, "1d"), pivot_type=pivot_type))


@router.get("/patterns", summary="Candlestick + chart patterns")
async def patterns(symbol: str, interval: str = "1d") -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.patterns", _ctx(symbol), symbol=symbol,
                                  interval=_tf(interval, "1d")))


@router.post("/volatility", summary="ATR, historical volatility, expected move")
async def volatility(body: VolatilityBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.volatility", _ctx(body.symbol), symbol=body.symbol,
                                  interval=_tf(body.interval),
                                  horizon_candles=body.horizon_candles))


@router.post("/correlation", summary="Correlation matrix between symbols")
async def correlation(body: SymbolsBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.correlation", _ctx(), symbols=body.symbols,
                                  interval=_tf(body.interval, "1d"), lookback=body.lookback))


@router.post("/compare", summary="Side-by-side comparison of symbols")
async def compare(body: SymbolsBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.compare", _ctx(), symbols=body.symbols,
                                  interval=_tf(body.interval, "1d"), lookback=body.lookback))


@router.get("/sentiment", summary="News-driven sentiment for an asset")
async def sentiment(symbol: str, limit: int = 10) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.sentiment", _ctx(symbol), symbol=symbol,
                                  limit=max(1, min(limit, 30))))


@router.get("/calendar", summary="Market-moving news and risk events")
async def calendar(topic: str, limit: int = 10) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.calendar", _ctx(topic), topic=topic,
                                  limit=max(1, min(limit, 30))))


@router.post("/risk", summary="Position sizing, pip value, Kelly, ruin, drawdown …")
async def risk(body: RiskBody) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.risk", _ctx(body.operation), operation=body.operation,
                                  params=body.params or None))


@router.post("/backtest", summary="Replay a strategy on history, with costs")
async def backtest(body: BacktestBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.backtest", _ctx(body.symbol), symbol=body.symbol,
                                  strategy=body.strategy, interval=_tf(body.interval, "1d"),
                                  limit=body.limit, params=body.params or None,
                                  capital=body.capital,
                                  commission_percent=body.commission_percent,
                                  slippage_percent=body.slippage_percent,
                                  walk_forward=body.walk_forward,
                                  expiry_candles=body.expiry_candles,
                                  payout_percent=body.payout_percent, stake=body.stake))


# ---------------------------------------------------------------------------
# journal
# ---------------------------------------------------------------------------
@router.get("/journal", summary="List journal trades")
async def journal_list(limit: int = 25, status: str = "", symbol: str = "",
                       product: str = "", days: Optional[int] = None) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.journal.list", _ctx(), limit=max(1, min(limit, 200)),
                                  status=status, symbol=symbol, product=product, days=days))


@router.post("/journal", summary="Add a trade to the journal")
async def journal_add(body: JournalAddBody) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.journal.add", _ctx(body.symbol), **body.model_dump()))


@router.post("/journal/close", summary="Close a journal trade and record the lesson")
async def journal_close(body: JournalCloseBody) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.journal.close", _ctx(), **body.model_dump()))


@router.get("/journal/stats", summary="Journal statistics + honest lessons")
async def journal_stats(days: Optional[int] = None, symbol: str = "",
                        product: str = "") -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.journal.stats", _ctx(), days=days, symbol=symbol,
                                  product=product))


@router.post("/journal/review", summary="Attach a review to a trade")
async def journal_review(body: JournalReviewBody) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.journal.review", _ctx(), **body.model_dump()))


# ---------------------------------------------------------------------------
# alerts
# ---------------------------------------------------------------------------
@router.get("/alerts", summary="List price alerts")
async def alerts_list(symbol: str = "", enabled_only: bool = False,
                      check_now: bool = False) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.alert.list", _ctx(), symbol=symbol,
                                  enabled_only=enabled_only, check_now=check_now))


@router.post("/alerts", summary="Create a price alert")
async def alerts_add(body: AlertBody) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.alert.set", _ctx(body.symbol), **body.model_dump()))


@router.delete("/alerts/{alert_id}", summary="Remove a price alert")
async def alerts_remove(alert_id: int, disable_only: bool = False) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.alert.remove", _ctx(), alert_id=alert_id,
                                  disable_only=disable_only))


@router.post("/alerts/check", summary="Evaluate every alert right now")
async def alerts_check() -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.alert.check", _ctx()))


@router.get("/alerts/poller", summary="Background alert poller state")
async def alerts_poller() -> Dict[str, Any]:
    _require_enabled()
    from backend.app.markets.journal import alert_poller_status
    return {"ok": True, **alert_poller_status(),
            "configured_seconds": int(settings.market_alert_poll_seconds),
            "enabled": bool(settings.market_alerts_enabled and settings.market_enabled)}


@router.post("/alerts/poller/start", summary="Start the background alert poller")
async def alerts_poller_start() -> Dict[str, Any]:
    _require_enabled()
    from backend.app.markets.alerts import alert_poller
    started = alert_poller.start()
    return {"ok": bool(started), "started": bool(started), **alert_poller.status()}


@router.post("/alerts/poller/stop", summary="Stop the background alert poller")
async def alerts_poller_stop() -> Dict[str, Any]:
    _require_enabled()
    from backend.app.markets.alerts import alert_poller
    await alert_poller.stop()
    return {"ok": True, **alert_poller.status()}


# ---------------------------------------------------------------------------
# paper trading (virtual money only)
# ---------------------------------------------------------------------------
@router.get("/paper", summary="Paper portfolio + virtual balance")
async def paper_portfolio(status: str = "open") -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.paper.portfolio", _ctx(), status=status))


@router.post("/paper/trade", summary="Open a VIRTUAL position (no real order)")
async def paper_trade(body: PaperTradeBody) -> Dict[str, Any]:
    _require_web()
    payload = body.model_dump()
    payload["targets"] = payload.get("targets") or None
    return unwrap(await tool_call("market.paper.trade", _ctx(body.symbol), **payload))


@router.post("/paper/close", summary="Close a VIRTUAL position")
async def paper_close(body: PaperCloseBody) -> Dict[str, Any]:
    _require_web()
    return unwrap(await tool_call("market.paper.close", _ctx(body.symbol), **body.model_dump()))


@router.post("/paper/reset", summary="Reset the virtual account")
async def paper_reset(body: PaperResetBody) -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.paper.reset", _ctx(), **body.model_dump()))


# ---------------------------------------------------------------------------
# education + policy
# ---------------------------------------------------------------------------
@router.get("/explain", summary="Explain an indicator, concept or product")
async def explain(topic: str, level: str = "intermediate",
                  with_example: bool = True) -> Dict[str, Any]:
    _require_enabled()
    if not topic.strip():
        raise HTTPException(status_code=400, detail="topic is required")
    return unwrap(await tool_call("market.explain", _ctx(topic), topic=topic,
                                  level=level if level in ("beginner", "intermediate", "advanced")
                                  else "intermediate",
                                  with_example=with_example))


@router.get("/topics", summary="Concepts SAM can explain offline (UI autocomplete)")
async def topics() -> Dict[str, Any]:
    _require_enabled()
    from backend.app.tools.market_tools import _OFFLINE_GLOSSARY
    return {"ok": True, "count": len(_OFFLINE_GLOSSARY),
            "topics": sorted(_OFFLINE_GLOSSARY.keys())}


@router.get("/broker", summary="Live-trading policy status")
async def broker() -> Dict[str, Any]:
    _require_enabled()
    return unwrap(await tool_call("market.broker.status", _ctx()))


@router.get("/disclaimers", summary="The warnings SAM always attaches")
async def disclaimers() -> Dict[str, Any]:
    from backend.app.markets import signals as sig
    return {"ok": True,
            "no_advice": sig.NO_ADVICE,
            "forex": sig.FOREX_WARNING,
            "binary": sig.BINARY_WARNING,
            "live_trading_enabled": bool(settings.market_allow_live_trading),
            "policy": "SAM analyses, backtests and paper-trades. It never places a real order."}
