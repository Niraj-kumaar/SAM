"""
backend.app.api.v1.automation
=============================

The AUTOMATION page API — scheduled jobs, WHEN → IF → DO → VERIFY rules and the
calendar.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.automation.calendar_store import calendar_store
from backend.app.automation.executor import evaluate_condition, execute_rule
from backend.app.automation.rules import WHEN_TYPES, AutomationRule, rule_store
from backend.app.automation.scheduler import scheduler
from backend.app.core.logging_config import get_logger

log = get_logger("api.automation")

router = APIRouter(prefix="/automation", tags=["automation"], dependencies=[Depends(check_token)])


class RuleBody(BaseModel):
    instruction: str = ""
    name: str = ""
    when: str = ""
    condition: str = ""
    action: str = ""
    verify: str = ""
    enabled: bool = True
    priority: str = "normal"


class ScheduleBody(BaseModel):
    instruction: str = Field(..., min_length=1)
    when: str = ""
    at: str = ""
    every: str = ""
    on: str = ""
    name: str = ""
    priority: str = "normal"
    device: str = "pc"
    enabled: bool = True


class EventBody(BaseModel):
    title: str = Field(..., min_length=1)
    start: str = ""
    end: str = ""
    when: str = ""
    at: str = ""
    duration_minutes: int = 60
    location: str = ""
    notes: str = ""
    reminder_minutes: int = 15
    all_day: bool = False
    event_id: str = ""


# ---------------------------------------------------------------------------
# scheduler
# ---------------------------------------------------------------------------
@router.get("/scheduler", summary="Scheduled jobs + engine status")
async def scheduler_status(include_disabled: bool = True) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    data = unwrap(await tool_call("scheduler.list", ctx, include_disabled=include_disabled))
    data["engine"] = scheduler.status()
    return data


@router.post("/scheduler", summary="Create a scheduled job")
async def scheduler_create(body: ScheduleBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning", user_text=body.instruction)
    return unwrap(await tool_call("scheduler.create", ctx, instruction=body.instruction,
                                  when=body.when, at=body.at, every=body.every, on=body.on,
                                  name=body.name, priority=body.priority, device=body.device,
                                  enabled=body.enabled))


@router.patch("/scheduler/{job_id}", summary="Change, enable, disable or reschedule a job")
async def scheduler_update(job_id: str, when: str = "", at: str = "", every: str = "",
                           on: str = "", enabled: Optional[bool] = None, priority: str = "",
                           instruction: str = "", title: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("scheduler.update", ctx, job_id=job_id, when=when, at=at,
                                  every=every, on=on, enabled=enabled, priority=priority,
                                  instruction=instruction, title=title))


@router.post("/scheduler/{job_id}/run", summary="Run a job now")
async def scheduler_run(job_id: str) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("scheduler.run_now", ctx, job_id=job_id))


@router.delete("/scheduler/{job_id}", summary="Cancel a job")
async def scheduler_delete(job_id: str) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("scheduler.remove", ctx, job_id=job_id))


@router.post("/scheduler/events/{event}", summary="Fire an event trigger manually")
async def trigger_event(event: str) -> Dict[str, Any]:
    results = await scheduler.trigger_event(event)
    return {"ok": True, "event": event, "fired": len(results), "results": results,
            "listeners": scheduler.event_listeners()}


# ---------------------------------------------------------------------------
# rules
# ---------------------------------------------------------------------------
@router.get("/rules", summary="List automation rules")
async def list_rules(include_disabled: bool = True, search: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    data = unwrap(await tool_call("automation.list", ctx, include_disabled=include_disabled,
                                  search=search))
    data["when_types"] = sorted(WHEN_TYPES)
    return data


@router.post("/rules", summary="Build a rule from a sentence")
async def create_rule(body: RuleBody) -> Dict[str, Any]:
    if not body.instruction and not (body.when and body.action):
        raise HTTPException(status_code=400,
                            detail="describe the automation in 'instruction', "
                                   "or give 'when' + 'action'")
    ctx = tool_context(None, agent="planning", user_text=body.instruction)
    return unwrap(await tool_call("automation.create", ctx, instruction=body.instruction,
                                  name=body.name, when=body.when, condition=body.condition,
                                  action=body.action, verify=body.verify,
                                  enabled=body.enabled, priority=body.priority))


@router.get("/rules/{rule_id}", summary="One rule in detail")
async def get_rule(rule_id: str) -> Dict[str, Any]:
    data = await rule_store.get(rule_id)
    if data is None:
        raise HTTPException(status_code=404, detail=f"no rule with id {rule_id}")
    condition = await evaluate_condition(AutomationRule.from_dict(data))
    data["condition_now"] = condition
    return {"ok": True, **data}


@router.post("/rules/{rule_id}/test", summary="Dry-run a rule (executes nothing)")
async def test_rule(rule_id: str) -> Dict[str, Any]:
    data = await rule_store.get(rule_id)
    if data is None:
        raise HTTPException(status_code=404, detail=f"no rule with id {rule_id}")
    return await execute_rule(AutomationRule.from_dict(data), dry_run=True, manual=True)


@router.post("/rules/{rule_id}/run", summary="Run a rule now")
async def run_rule(rule_id: str) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("automation.run", ctx, rule_id=rule_id))


@router.patch("/rules/{rule_id}", summary="Enable, disable, rename or reprioritise a rule")
async def update_rule(rule_id: str, enabled: Optional[bool] = None, name: str = "",
                      priority: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("automation.toggle", ctx, rule_id=rule_id, enabled=enabled,
                                  name=name, priority=priority))


@router.delete("/rules/{rule_id}", summary="Delete a rule")
async def delete_rule(rule_id: str) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("automation.toggle", ctx, rule_id=rule_id, delete=True))


# ---------------------------------------------------------------------------
# calendar
# ---------------------------------------------------------------------------
@router.get("/calendar", summary="List calendar events")
async def list_events(days: int = 7, date: str = "", include_past: bool = False,
                      search: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("calendar.list", ctx, days=days, date=date,
                                  include_past=include_past, search=search))


@router.post("/calendar", summary="Create or update an event")
async def upsert_event(body: EventBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning", user_text=body.title)
    return unwrap(await tool_call("calendar.upsert", ctx, title=body.title, start=body.start,
                                  end=body.end, when=body.when, at=body.at,
                                  duration_minutes=body.duration_minutes,
                                  location=body.location, notes=body.notes,
                                  reminder_minutes=body.reminder_minutes,
                                  all_day=body.all_day, event_id=body.event_id))


@router.delete("/calendar/{event_id}", summary="Delete an event")
async def delete_event(event_id: str) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning")
    return unwrap(await tool_call("calendar.remove", ctx, event_id=event_id))


@router.get("/calendar/upcoming", summary="Events starting soon (Proactive mode)")
async def upcoming(minutes: int = 60) -> Dict[str, Any]:
    events = await calendar_store.upcoming(minutes=int(minutes))
    return {"ok": True, "count": len(events), "events": events, "window_minutes": minutes}
