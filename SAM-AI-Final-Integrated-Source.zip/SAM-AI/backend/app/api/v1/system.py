"""
backend.app.api.v1.system
=========================

Root-level API: health, the HOME dashboard aggregate, live system state,
notifications, logs and graceful shutdown.
"""

from __future__ import annotations

import platform
import time
from collections import deque
from typing import Any, Deque, Dict, List, Optional

import psutil
from fastapi import APIRouter, Depends, HTTPException

from backend.app.agents.base import agents
from backend.app.api.deps import check_token
from backend.app.automation.scheduler import scheduler
from backend.app.config import PROJECT_ROOT, settings
from backend.app.core.event_bus import bus
from backend.app.core.logging_config import get_logger
from backend.app.core.orchestrator import orchestrator
from backend.app.core.schemas import HealthResponse
from backend.app.core.task_store import task_store
from backend.app.devices.registry import device_registry
from backend.app.devices.sync import sync_engine
from backend.app.memory.store import memory_store
from backend.app.models.router import router as model_router
from backend.app.security.confirmation_engine import confirmation_engine
from backend.app.tools.registry import registry
from backend.app.voice.engine import voice_engine
from backend.app.voice.modes import voice_modes

log = get_logger("api.system")

router = APIRouter(tags=["system"])

STARTED_AT = time.time()
VERSION = "1.0.0"


@router.get("/health", response_model=HealthResponse, summary="Liveness probe")
async def health() -> HealthResponse:
    return HealthResponse(
        status="ok", product="SAM", version=VERSION, mode=settings.sam_mode,
        uptime_seconds=round(time.time() - STARTED_AT, 1),
        components={
            "database": "ok",
            "router": "ok" if model_router.providers else "bootstrapping",
            "scheduler": "running" if scheduler.running else "stopped",
            "tools": f"{len(registry.names())} registered",
            "agents": f"{len(agents.enabled())}/{len(agents.all())} enabled",
            "voice": "on" if settings.voice_enabled else "off",
            "browser": settings.browser_provider if settings.browser_enabled else "off",
            "phone": "on" if settings.phone_enabled else "off",
        },
    )


@router.get("/dashboard", summary="Everything the HOME dashboard renders",
            dependencies=[Depends(check_token)])
async def dashboard() -> Dict[str, Any]:
    tasks = task_store.all()
    counts = task_store.counts()
    active = task_store.active()
    audit_stats = None
    try:
        from backend.app.security.audit import audit_trail

        audit_stats = await audit_trail.stats()
    except Exception as exc:  # pragma: no cover
        audit_stats = {"error": str(exc)[:120]}

    tools = registry.all()
    usable = [t for t in tools if t.is_available()
              and _granted(t.capability)]
    providers = model_router.status().get("providers") or {}
    battery = psutil.sensors_battery()
    mem = psutil.virtual_memory()
    try:
        disk = psutil.disk_usage("/")
    except OSError:
        disk = None

    now = time.time()
    return {
        "ok": True,
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "version": VERSION,
        "uptime_seconds": round(now - STARTED_AT, 1),
        "greeting": _greeting(),
        "mode": {"sam_mode": settings.sam_mode, "cloud_enabled": settings.cloud_enabled,
                 "web_enabled": settings.web_enabled, "risk_mode": settings.security_risk_mode,
                 "proactive_level": settings.proactive_level},
        "system": {
            "os": f"{platform.system()} {platform.release()}",
            "hostname": platform.node(),
            "python": platform.python_version(),
            "cpu_percent": psutil.cpu_percent(interval=0.15),
            "cpu_cores": psutil.cpu_count(),
            "ram_percent": round(mem.percent, 1),
            "ram_used_gb": round(mem.used / (1024 ** 3), 1),
            "ram_total_gb": round(mem.total / (1024 ** 3), 1),
            "disk_free_gb": round(disk.free / (1024 ** 3), 1) if disk else None,
            "disk_percent": round(disk.percent, 1) if disk else None,
            "battery": {"percent": round(battery.percent), "plugged": battery.power_plugged}
                       if battery else None,
        },
        "tasks": {
            "total": len(tasks), "active": len(active), "counts": counts,
            "recent": [t.model_dump(mode="json") for t in tasks[:6]],
            "running": [{"id": t.id, "title": t.title, "progress": t.progress,
                         "current_action": t.current_action, "agent": t.agent.value}
                        for t in active[:8]],
        },
        "agents": {"summary": agents.summary(),
                   "top": sorted(agents.snapshot(), key=lambda a: -a["stats"]["calls"])[:6]},
        "tools": {"total": len(tools), "usable": len(usable),
                  "by_agent": registry.stats()["by_agent"],
                  "calls": registry.stats()["calls"], "failures": registry.stats()["failures"]},
        "models": {"providers": {k: {"available": v.get("available"), "local": v.get("local"),
                                     "models": v.get("models")} for k, v in providers.items()},
                   "roles": model_router.status().get("roles"),
                   "pins": model_router.pins()},
        "devices": {"summary": device_registry.summary(),
                    "phone_connected": len([d for d in device_registry.all(kind="phone",
                                                                           online_only=True)]),
                    "sync_running": sync_engine.state.enabled},
        "voice": {"enabled": settings.voice_enabled, "mode": voice_modes.mode,
                  "voice": voice_engine.state()["tts"]["voice"],
                  "wake_word": {"phrase": settings.voice_wake_word,
                                "enabled": settings.voice_wake_word_enabled},
                  "tts_providers": {k: v["available"]
                                    for k, v in voice_engine.state()["tts"]["providers"].items()}},
        "memory": await _memory_summary(),
        "security": {"pending_confirmations": confirmation_engine.pending(),
                     "audit": audit_stats,
                     "permissions": _permission_summary()},
        "scheduler": scheduler.status(),
        "suggestions": _suggestions(counts, usable, providers),
        "bus": bus.snapshot(),
    }


def _granted(capability: str) -> bool:
    from backend.app.security.permissions import permission_engine

    return permission_engine.granted(capability)


def _permission_summary() -> Dict[str, Any]:
    from backend.app.security.permissions import permission_engine

    caps = permission_engine.state()
    granted = sum(1 for c in caps if c["granted"])
    return {"total": len(caps), "granted": granted, "denied": len(caps) - granted,
            "groups": permission_engine.summary()}


async def _memory_summary() -> Dict[str, Any]:
    try:
        stats = await memory_store.stats()
        from backend.app.files.semantic_index import semantic_index

        stats["semantic_index"] = await semantic_index.stats()
        return stats
    except Exception as exc:  # pragma: no cover
        return {"error": str(exc)[:160]}


def _greeting() -> str:
    hour = time.localtime().tm_hour
    if hour < 5:
        return "It's late — SAM is here if you need it."
    if hour < 12:
        return "Good morning."
    if hour < 17:
        return "Good afternoon."
    if hour < 21:
        return "Good evening."
    return "Good night."


def _suggestions(counts: Dict[str, int], usable: List[Any],
                 providers: Dict[str, Any]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    if not any(p.get("available") for p in providers.values() if p.get("provider") != "heuristic") \
            and "heuristic" in providers:
        out.append({"kind": "warning", "title": "No AI model is connected",
                    "text": "SAM is running on its offline rule engine. Add an API key to .env or "
                            "start Ollama, then open MODELS → Refresh.",
                    "action": "/models"})
    if counts.get("WAITING", 0):
        out.append({"kind": "approval", "title": f"{counts['WAITING']} action(s) need your approval",
                    "text": "SAM stopped before doing something risky and is waiting for you.",
                    "action": "/tasks"})
    if not [t for t in usable if t.name.startswith("phone.")]:
        out.append({"kind": "info", "title": "No phone is paired",
                    "text": "Install the SAM Companion app and pair it to control your Android "
                            "device from here.", "action": "/phone"})
    if not [t for t in usable if t.name.startswith("browser.")]:
        out.append({"kind": "info", "title": "Browser control needs a permission",
                    "text": "Grant browser.open in SECURITY to let SAM drive a browser session.",
                    "action": "/security"})
    if not scheduler.running:
        out.append({"kind": "warning", "title": "The scheduler is not running",
                    "text": "Scheduled jobs and automations will not fire until it starts.",
                    "action": "/automation"})
    out.append({"kind": "tip", "title": "Try: “find invoices from last month and convert to PDF”",
                "text": "SAM will plan it, show you the steps, ask before writing, then verify.",
                "action": "/chat"})
    return out[:6]


@router.get("/system", summary="Live system state", dependencies=[Depends(check_token)])
async def system_state(processes: int = 0) -> Dict[str, Any]:
    data: Dict[str, Any] = {
        "ok": True, "os": platform.system(), "release": platform.release(),
        "machine": platform.machine(), "hostname": platform.node(),
        "python": platform.python_version(),
        "cpu_percent": psutil.cpu_percent(interval=0.2),
        "cpu_per_core": psutil.cpu_percent(interval=0.1, percpu=True),
        "cpu_cores": psutil.cpu_count(), "cpu_freq": _freq(),
        "memory": _memory(), "disks": _disks(), "network": _network(),
        "boot_time": psutil.boot_time(),
        "uptime_seconds": round(time.time() - psutil.boot_time()),
        "sam_uptime_seconds": round(time.time() - STARTED_AT, 1),
        "battery": _battery(),
        "time": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
    }
    if processes:
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                procs.append(p.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        data["processes"] = sorted(procs, key=lambda x: -(x.get("cpu_percent") or 0))[:processes]
    return data


def _freq() -> Optional[Dict[str, Any]]:
    try:
        f = psutil.cpu_freq()
        return {"current": round(f.current), "min": round(f.min), "max": round(f.max)} if f else None
    except Exception:
        return None


def _memory() -> Dict[str, Any]:
    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    return {"total_gb": round(vm.total / (1024 ** 3), 1),
            "used_gb": round(vm.used / (1024 ** 3), 1),
            "available_gb": round(vm.available / (1024 ** 3), 1),
            "percent": round(vm.percent, 1),
            "swap_total_gb": round(sw.total / (1024 ** 3), 1),
            "swap_percent": round(sw.percent, 1)}


def _disks() -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for part in psutil.disk_partitions(all=False):
        if part.mountpoint in seen:
            continue
        seen.add(part.mountpoint)
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except OSError:
            continue
        out.append({"device": part.device, "mount": part.mountpoint, "fstype": part.fstype,
                    "total_gb": round(usage.total / (1024 ** 3), 1),
                    "used_gb": round(usage.used / (1024 ** 3), 1),
                    "free_gb": round(usage.free / (1024 ** 3), 1),
                    "percent": round(usage.percent, 1)})
    return out


def _network() -> Dict[str, Any]:
    counters = psutil.net_io_counters()
    addrs = []
    for nic, entries in psutil.net_if_addrs().items():
        for entry in entries:
            if entry.family.name == "AF_INET":
                addrs.append({"interface": nic, "address": entry.address})
    return {"bytes_sent": counters.bytes_sent, "bytes_recv": counters.bytes_recv,
            "sent_gb": round(counters.bytes_sent / (1024 ** 3), 2),
            "recv_gb": round(counters.bytes_recv / (1024 ** 3), 2),
            "connections": len(psutil.net_connections(kind="inet"))
            if hasattr(psutil, "net_connections") else None,
            "addresses": addrs}


def _battery() -> Optional[Dict[str, Any]]:
    batt = psutil.sensors_battery()
    if not batt:
        return None
    seconds = batt.secsleft
    return {"percent": round(batt.percent), "plugged": batt.power_plugged,
            "seconds_left": None if seconds in (psutil.POWER_TIME_UNLIMITED,
                                                 psutil.POWER_TIME_UNKNOWN) else int(seconds),
            "human": _battery_human(batt)}


def _battery_human(batt: Any) -> str:
    if batt.power_plugged:
        return f"Charging — {round(batt.percent)}%"
    if batt.secsleft in (psutil.POWER_TIME_UNLIMITED, psutil.POWER_TIME_UNKNOWN):
        return f"{round(batt.percent)}% remaining"
    hours, minutes = divmod(int(batt.secsleft) // 60, 60)
    return f"{round(batt.percent)}% — about {hours}h {minutes}m left"


@router.get("/logs", summary="Recent log lines", dependencies=[Depends(check_token)])
async def logs(limit: int = 200, level: str = "") -> Dict[str, Any]:
    from backend.app.core.logging_config import recent_logs

    rows = recent_logs(limit=min(limit, 2000), level=level or None)
    return {"ok": True, "count": len(rows), "logs": rows,
            "file": str(settings.sam_data_dir / "logs" / "sam.log")}


@router.get("/notifications", summary="Recent notifications", dependencies=[Depends(check_token)])
async def notifications(limit: int = 50) -> Dict[str, Any]:
    events = bus.replay(since_ts=time.time() - 86400, topics=["notification.new"])
    rows = [e.to_dict() for e in events][-limit:]
    return {"ok": True, "count": len(rows), "notifications": rows}


@router.post("/shutdown", summary="Stop SAM gracefully", dependencies=[Depends(check_token)])
async def shutdown(confirm: str = "") -> Dict[str, Any]:
    """Requires ``confirm=SAM`` — a stray click must not power off the assistant."""
    if confirm != "SAM":
        raise HTTPException(status_code=400,
                            detail="send confirm=SAM to shut SAM down (it stops the scheduler, "
                                   "browser and database cleanly)")
    log.warning("shutdown requested through the API")

    async def _do() -> None:
        await scheduler.stop()
        try:
            from backend.app.browser.engine import browser_engine

            await browser_engine.stop()
        except Exception:
            pass
        try:
            await model_router.aclose()
        except Exception:
            pass
        import asyncio

        await asyncio.sleep(0.4)
        import os
        import signal

        os.kill(os.getpid(), signal.SIGTERM)

    import asyncio

    asyncio.create_task(_do())
    return {"ok": True, "shutting_down": True,
            "message": "SAM is stopping the scheduler, browser and database, then exiting."}
