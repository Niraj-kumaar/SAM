"""
backend.app.api.v1.voice
========================

The VOICE page API — voice modes, voices, TTS/STT status, transcription,
speaking, barge-in, wake word and audio delivery.

The microphone lives in the desktop app (browser/Electron), which posts audio
here; SAM can also record on the backend machine when ``sounddevice`` is
installed.
"""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token
from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.voice.engine import voice_engine
from backend.app.voice.modes import detect_language, language_mix, voice_modes
from backend.app.voice.stt import stt_engine
from backend.app.voice.tts import OUT_DIR, VOICES, pick_voice, tts_engine
from backend.app.voice.wake import wake_listener

log = get_logger("api.voice")

router = APIRouter(prefix="/voice", tags=["voice"], dependencies=[Depends(check_token)])


class VoiceConfigBody(BaseModel):
    mode: Optional[str] = None
    voice_id: Optional[str] = None
    gender: Optional[str] = None
    language: Optional[str] = None
    speed: Optional[float] = Field(None, ge=0.5, le=2.0)
    pitch: Optional[str] = None
    volume: Optional[str] = None
    enabled: Optional[bool] = None
    wake_word_enabled: Optional[bool] = None
    wake_word: Optional[str] = None
    sensitivity: Optional[float] = Field(None, ge=0.0, le=1.0)
    push_to_talk: Optional[bool] = None
    auto_speak: Optional[bool] = None
    personality: Optional[Dict[str, Any]] = None


class SpeakBody(BaseModel):
    text: str = Field(..., min_length=1)
    voice_id: str = ""
    language: str = ""
    speed: Optional[float] = None


class WakeBody(BaseModel):
    text: str = Field(..., min_length=1)


@router.get("/status", summary="Everything the VOICE dashboard needs")
async def status() -> Dict[str, Any]:
    data = voice_engine.state()
    data["ok"] = True
    data["language_detected"] = detect_language(data["session"].get("last_transcript") or "")
    return data


@router.patch("/config", summary="Change voice mode, voice, speed, wake word, personality")
async def configure(body: VoiceConfigBody) -> Dict[str, Any]:
    values = {k: v for k, v in body.model_dump().items() if v is not None}
    if not values:
        raise HTTPException(status_code=400, detail="nothing to change")
    data = voice_engine.configure(**values)
    data["ok"] = True
    return data


@router.get("/modes", summary="The eight voice modes")
async def modes() -> Dict[str, Any]:
    return {"ok": True, "active": voice_modes.mode, "modes": voice_modes.list_modes(),
            "proactive_level": voice_modes.proactive_level(),
            "system_modifier": voice_modes.system_modifier()}


@router.post("/modes/{mode}", summary="Switch voice mode")
async def set_mode(mode: str) -> Dict[str, Any]:
    known = {m["key"] for m in voice_modes.list_modes()}
    if mode.lower() not in known:
        raise HTTPException(status_code=404,
                            detail=f"unknown voice mode '{mode}'. Known: {', '.join(sorted(known))}")
    data = voice_modes.set_mode(mode.lower())
    data["ok"] = True
    return data


@router.get("/voices", summary="Every voice SAM can use")
async def voices(language: str = "", gender: str = "", provider: str = "") -> Dict[str, Any]:
    items = tts_engine.voices(language=language, gender=gender, provider=provider)
    return {"ok": True, "count": len(items), "voices": items,
            "active": tts_engine.voice_id,
            "languages": sorted({v["language"] for v in items}),
            "providers": tts_engine.provider_status()}


@router.post("/voices/{voice_id}/preview", summary="Hear one voice")
async def preview_voice(voice_id: str, text: str = "") -> Dict[str, Any]:
    if voice_id not in {v.id for v in VOICES}:
        raise HTTPException(status_code=404, detail=f"unknown voice '{voice_id}'")
    data = await voice_engine.preview_voice(voice_id=voice_id, text=text)
    if data.get("ok") and data.get("file"):
        data["url"] = f"/api/v1/voice/audio/{data['file']}"
    return data


@router.post("/speak", summary="Turn text into speech")
async def speak(body: SpeakBody) -> Dict[str, Any]:
    data = await voice_engine.speak(body.text, voice_id=body.voice_id, language=body.language,
                                    speed=body.speed)
    if data.get("ok") and data.get("file"):
        data["url"] = f"/api/v1/voice/audio/{data['file']}"
        data["audio_b64"] = _small_b64(data["path"])
    return data


def _small_b64(path: str, limit: int = 900_000) -> Optional[str]:
    """Inline the audio for small clips so the UI needs no second request."""
    try:
        p = Path(path)
        if p.stat().st_size <= limit:
            return base64.b64encode(p.read_bytes()).decode()
    except OSError:
        pass
    return None


@router.post("/stop", summary="Stop speaking (barge-in)")
async def stop() -> Dict[str, Any]:
    return voice_engine.stop_speaking()


@router.get("/audio/{filename}", summary="Serve generated speech audio")
async def audio(filename: str) -> FileResponse:
    safe = Path(filename).name
    target = (OUT_DIR / safe).resolve()
    if not str(target).startswith(str(OUT_DIR.resolve())) or not target.is_file():
        raise HTTPException(status_code=404, detail="audio not found")
    media = {"mp3": "audio/mpeg", "wav": "audio/wav", "ogg": "audio/ogg",
             "opus": "audio/ogg", "m4a": "audio/mp4", "flac": "audio/flac",
             "aiff": "audio/aiff"}.get(target.suffix.lstrip("."), "application/octet-stream")
    return FileResponse(str(target), media_type=media, filename=safe)


# ---------------------------------------------------------------------------
# STT
# ---------------------------------------------------------------------------
@router.post("/transcribe", summary="Transcribe uploaded audio")
async def transcribe(file: UploadFile, language: str = "", wake_filter: bool = False) -> Dict[str, Any]:
    audio = await file.read()
    if not audio:
        raise HTTPException(status_code=400, detail="the upload was empty")
    data = await voice_engine.transcribe(audio=audio, filename=file.filename or "audio.wav",
                                         language=language, wake_filter=wake_filter)
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/transcribe/b64", summary="Transcribe base64 audio (from the browser recorder)")
async def transcribe_b64(audio_b64: str, language: str = "", filename: str = "audio.wav",
                         wake_filter: bool = False) -> Dict[str, Any]:
    if not audio_b64:
        raise HTTPException(status_code=400, detail="no audio_b64 given")
    data = await voice_engine.transcribe(b64=audio_b64, filename=filename, language=language,
                                         wake_filter=wake_filter)
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/listen", summary="Record from the backend machine's microphone")
async def listen(seconds: float = 5.0, device: str = "", transcribe: bool = True) -> Dict[str, Any]:
    data = await voice_engine.listen(seconds=seconds, device=device, transcribe=transcribe)
    data["ok"] = bool(data.get("ok"))
    return data


@router.get("/devices", summary="Microphones and speakers available to the backend")
async def audio_devices() -> Dict[str, Any]:
    return voice_engine.devices()


@router.post("/turn", summary="One full voice turn: audio in → action → audio out")
async def turn(audio_b64: str = "", text: str = "", language: str = "",
               conversation_id: str = "", speak: Optional[bool] = None,
               wake_filter: bool = False) -> Dict[str, Any]:
    if not (audio_b64 or text):
        raise HTTPException(status_code=400, detail="send audio_b64 or text")
    audio = base64.b64decode(audio_b64.split(",", 1)[1] if audio_b64.startswith("data:")
                             else audio_b64) if audio_b64 else b""
    data = await voice_engine.voice_turn(text=text, audio=audio, language=language,
                                         conversation_id=conversation_id or None,
                                         speak_reply=speak, wake_filter=wake_filter)
    if data.get("audio_url") is None and data.get("audio", {}).get("file"):
        data["audio_url"] = f"/api/v1/voice/audio/{data['audio']['file']}"
    return data


# ---------------------------------------------------------------------------
# wake word
# ---------------------------------------------------------------------------
@router.get("/wake", summary="Wake word state")
async def wake_status() -> Dict[str, Any]:
    data = wake_listener.state()
    data["ok"] = True
    return data


@router.post("/wake/start", summary="Start listening for the wake word")
async def wake_start() -> Dict[str, Any]:
    data = wake_listener.start()
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/wake/stop", summary="Stop listening for the wake word")
async def wake_stop() -> Dict[str, Any]:
    return wake_listener.stop()


@router.post("/wake/check", summary="Ask SAM whether a transcript contains the wake phrase")
async def wake_check(body: WakeBody) -> Dict[str, Any]:
    return await wake_listener.check_transcript(body.text)


# ---------------------------------------------------------------------------
# language
# ---------------------------------------------------------------------------
@router.get("/languages", summary="Supported languages and mixed-language detection")
async def languages(sample: str = "") -> Dict[str, Any]:
    langs = sorted({v.language for v in VOICES})
    data: Dict[str, Any] = {"ok": True, "tts_languages": langs,
                            "stt_languages": "auto-detected by Whisper (99 languages)",
                            "indic_scripts": ["hi", "kn", "ta", "te", "ml", "bn", "gu", "mr", "pa", "ur"],
                            "code_mixing": "SAM detects Latin + Indic script mixing and romanised "
                                           "Hindi/Kannada ('mera phone kholo', 'nan phone terego')"}
    if sample:
        data["sample"] = {"text": sample[:200], "detected": detect_language(sample),
                          "mix": language_mix(sample)}
    return data
