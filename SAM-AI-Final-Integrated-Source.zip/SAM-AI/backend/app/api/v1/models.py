"""
backend.app.api.v1.models
=========================

The MODELS dashboard API: the multi-model router, its roles, providers,
catalogue, usage statistics and health.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token
from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.models.router import ROLE_TO_SETTING, router

log = get_logger("api.models")

api = APIRouter(prefix="/models", tags=["models"], dependencies=[Depends(check_token)])


class RoleConfig(BaseModel):
    role: str
    model: str = "auto"


class TestRequest(BaseModel):
    role: str = "primary"
    prompt: str = "Reply with the single word READY."
    max_tokens: int = Field(64, ge=8, le=2048)


@api.get("", summary="Router status: providers, roles, mode")
async def status() -> Dict[str, Any]:
    data = router.status()
    data["ok"] = True
    data["roles_configured"] = {role: getattr(settings, key, "auto")
                                for role, key in ROLE_TO_SETTING.items()}
    data["privacy"] = {"cloud_ai_blocked": settings.privacy_cloud_ai,
                       "local_models_only": settings.sam_mode == "local",
                       "local_memory": settings.privacy_local_memory}
    return data


@api.get("/catalogue", summary="Every model SAM knows about")
async def catalogue(provider: str = "", role: str = "") -> Dict[str, Any]:
    items = router.catalogue()
    if provider:
        items = [m for m in items if m.get("provider") == provider]
    if role:
        items = [m for m in items if role in (m.get("roles") or [])]
    return {"ok": True, "count": len(items), "models": items,
            "providers": sorted({m.get("provider") for m in items if m.get("provider")})}


@api.get("/plan", summary="Show which model a role would use, without calling it")
async def plan(role: str = "primary", complexity: str = "medium",
               prefer_local: Optional[bool] = None) -> Dict[str, Any]:
    if role not in ROLE_TO_SETTING:
        raise HTTPException(status_code=400,
                            detail=f"unknown role '{role}'. Known: {', '.join(sorted(ROLE_TO_SETTING))}")
    decision = router.plan(role, complexity=complexity, prefer_local=prefer_local)
    return {"ok": True, **decision.to_dict()}


@api.post("/test", summary="Send a one-shot prompt through a role")
async def test(body: TestRequest) -> Dict[str, Any]:
    if body.role not in ROLE_TO_SETTING:
        raise HTTPException(status_code=400, detail=f"unknown role '{body.role}'")
    res = await router.ask(body.prompt, role=body.role, temperature=0.0,
                           max_tokens=body.max_tokens)
    return {"ok": res.ok, "role": body.role, "text": res.text[:2000], "model": res.model,
            "provider": res.provider, "local": res.local, "latency_ms": res.latency_ms,
            "tokens": {"prompt": res.prompt_tokens, "completion": res.completion_tokens,
                       "total": res.total_tokens},
            "error": res.error, "finish_reason": res.finish_reason}


@api.get("/health", summary="Provider health check")
async def health() -> Dict[str, Any]:
    rows = await router.health()
    return {"ok": True, "providers": rows,
            "healthy": sum(1 for r in rows if r.get("ok")), "total": len(rows)}


@api.get("/usage", summary="Token and latency usage per role")
async def usage(hours: int = 24) -> Dict[str, Any]:
    data = await router.usage_stats(hours=int(hours))
    data["ok"] = True
    return data


@api.post("/roles", summary="Pin a role to a specific model (or back to auto)")
async def set_role(body: RoleConfig) -> Dict[str, Any]:
    """
    Writes the pin into the router's runtime overrides *and* tells the user how
    to make it permanent (``.env``), because SAM never silently edits ``.env``.
    """
    role = body.role.lower()
    if role not in ROLE_TO_SETTING:
        raise HTTPException(status_code=400, detail=f"unknown role '{role}'")
    router.pin(role, body.model)
    env_key = ROLE_TO_SETTING[role].upper()
    log.info("model role %s pinned to %s", role, body.model)
    return {"ok": True, "role": role, "model": body.model, "env_key": env_key,
            "env_line": f"{env_key}={body.model}",
            "note": f"Applied for this session. To make it permanent add "
                    f"`{env_key}={body.model}` to SAM-AI/.env and restart SAM.",
            "plan": router.plan(role).to_dict()}


@api.post("/refresh", summary="Re-probe providers (e.g. after starting Ollama)")
async def refresh() -> Dict[str, Any]:
    data = await router.refresh()
    data["ok"] = True
    return data
