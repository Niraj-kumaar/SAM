"""
backend.app.api.v1.research
===========================

The RESEARCH page API.

The pipeline from the specification — Question → Search → Sources → Read →
Compare → Cross-check → Extract → Summarize → Cite — is exposed step by step so
the UI can show each stage, and as one ``/deep`` call that runs the whole thing.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.config import settings
from backend.app.core.logging_config import get_logger

log = get_logger("api.research")

router = APIRouter(prefix="/research", tags=["research"], dependencies=[Depends(check_token)])


class SearchBody(BaseModel):
    query: str = Field(..., min_length=1)
    limit: int = Field(8, ge=1, le=30)
    engines: List[str] = Field(default_factory=list)
    news: bool = False


class ReadBody(BaseModel):
    url: str = ""
    urls: List[str] = Field(default_factory=list)
    max_chars: int = Field(40000, ge=1000, le=400000)


class CompareBody(BaseModel):
    claim: str = Field(..., min_length=3)
    options: List[str] = Field(default_factory=list)


class SummariseBody(BaseModel):
    question: str = Field(..., min_length=3)
    urls: List[str] = Field(default_factory=list)
    max_sources: int = Field(6, ge=1, le=20)
    style: str = "brief"


class DeepBody(BaseModel):
    question: str = Field(..., min_length=3)
    depth: str = "standard"          # quick | standard | deep
    max_sources: int = Field(10, ge=1, le=30)
    language: str = "auto"
    include_citations: bool = True


@router.get("/status", summary="Which search backends are configured")
async def status() -> Dict[str, Any]:
    return {
        "ok": True,
        "web_enabled": settings.web_enabled,
        "privacy_external_web": settings.privacy_external_web,
        "engines": {
            "duckduckgo": {"available": settings.web_enabled, "key_required": False},
            "wikipedia": {"available": settings.web_enabled, "key_required": False},
            "arxiv": {"available": settings.web_enabled, "key_required": False},
            "brave": {"available": bool(settings.brave_api_key) and settings.web_enabled,
                      "key_required": True},
            "tavily": {"available": bool(settings.tavily_api_key) and settings.web_enabled,
                       "key_required": True},
            "bing": {"available": bool(settings.bing_api_key) and settings.web_enabled,
                     "key_required": True},
            "newsapi": {"available": bool(settings.news_api_key) and settings.web_enabled,
                        "key_required": True},
        },
        "note": "SAM works with no keys at all (DuckDuckGo + Wikipedia + arXiv). "
                "Add a key for better recall.",
    }


@router.post("/search", summary="Search the web and return ranked sources")
async def search(body: SearchBody) -> Dict[str, Any]:
    if not settings.web_enabled:
        raise HTTPException(status_code=403,
                            detail="web access is disabled by Privacy Mode "
                                   "(PRIVACY_EXTERNAL_WEB=true)")
    ctx = tool_context(None, agent="research", user_text=body.query)
    engines = list(body.engines)
    if body.news and "news" not in engines:
        engines.append("news")
    return unwrap(await tool_call("research.search", ctx, query=body.query, limit=body.limit,
                                  engines=engines or None))


@router.post("/read", summary="Fetch and extract the readable text of pages")
async def read(body: ReadBody) -> Dict[str, Any]:
    if not settings.web_enabled:
        raise HTTPException(status_code=403, detail="web access is disabled by Privacy Mode")
    urls = body.urls or ([body.url] if body.url else [])
    if not urls:
        raise HTTPException(status_code=400, detail="give a url or urls")
    ctx = tool_context(None, agent="research", user_text=" ".join(urls)[:200])
    return unwrap(await tool_call("research.read", ctx, urls=urls[:10],
                                  max_chars=body.max_chars))


@router.get("/fetch", summary="Fetch one page")
async def fetch(url: str, max_chars: int = 40000) -> Dict[str, Any]:
    if not settings.web_enabled:
        raise HTTPException(status_code=403, detail="web access is disabled by Privacy Mode")
    ctx = tool_context(None, agent="research")
    return unwrap(await tool_call("research.fetch", ctx, url=url, max_chars=max_chars))


@router.post("/compare", summary="Cross-check a claim and label each fact")
async def compare(body: CompareBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="reasoning",
                       user_text=body.claim + " " + " ".join(body.options))
    claim = body.claim
    if body.options:
        claim += "\nOptions: " + "; ".join(body.options)
    return unwrap(await tool_call("research.compare", ctx, claim=claim))


@router.post("/summarise", summary="Summarise with numbered citations")
async def summarise(body: SummariseBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="research", user_text=body.question)
    question = body.question
    if body.urls:
        question += "\nSources to use: " + ", ".join(body.urls[: body.max_sources])
    if body.style == "detailed":
        max_words = 1200
    elif body.style == "bullet":
        max_words = 300
    else:
        max_words = 500
    result = unwrap(await tool_call("research.summarise", ctx, question=question,
                                    citations=True, max_words=max_words))
    result["style"] = body.style
    return result


@router.post("/deep", summary="Run the full research pipeline end to end")
async def deep(body: DeepBody) -> Dict[str, Any]:
    """Question → Search → Sources → Read → Compare → Extract → Summarize → Cite."""
    if not settings.web_enabled:
        raise HTTPException(status_code=403, detail="web access is disabled by Privacy Mode")
    ctx = tool_context(None, agent="research", user_text=body.question)
    result = unwrap(await tool_call("research.deep", ctx, question=body.question,
                                    depth=body.depth, max_sources=body.max_sources))
    result["include_citations"] = body.include_citations
    if result.get("ok") and result.get("report"):
        result.setdefault("markdown", result["report"])
    return result


@router.post("/translate", summary="Translate text (auto-detects the source language)")
async def translate(text: str, target: str = "en") -> Dict[str, Any]:
    ctx = tool_context(None, agent="communication", user_text=text[:200])
    return unwrap(await tool_call("core.translate", ctx, text=text, target=target))
