"""
backend.app.api.v1.files
========================

The FILES page API: browse, search, read, write, move, organise, convert,
archive, de-duplicate, back up and clean — all through the tool layer so every
call is permission-checked, risk-scored, confirmed when needed and audited.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.files.file_ops import FileSecurityError, assert_allowed, human_size, stat_path

log = get_logger("api.files")

router = APIRouter(prefix="/files", tags=["files"], dependencies=[Depends(check_token)])

UPLOAD_DIR = settings.sam_data_dir / "uploads"


class FileWrite(BaseModel):
    path: str
    content: str = ""
    mode: str = "w"


class FileMove(BaseModel):
    source: str
    destination: str
    overwrite: bool = False


class FileDelete(BaseModel):
    paths: List[str] = Field(default_factory=list)
    path: str = ""


class ArchiveBody(BaseModel):
    sources: List[str]
    output: str = ""
    format: str = "zip"
    extract_to: str = ""


class OrganiseBody(BaseModel):
    folder: str
    strategy: str = "type"
    apply: bool = False
    recursive: bool = False
    dry_run: bool = True


class ConvertBody(BaseModel):
    source: str
    to: str
    output: str = ""


class BackupBody(BaseModel):
    path: str
    label: str = ""
    keep: int = 5


class SearchBody(BaseModel):
    query: str
    roots: List[str] = Field(default_factory=list)
    limit: int = 40
    semantic: bool = False


@router.get("/roots", summary="The folders SAM is allowed to touch")
async def roots() -> Dict[str, Any]:
    allowed = []
    for root in settings.allowed_roots:
        allowed.append({"path": str(root), "exists": root.exists(),
                        "writable": _writable(root)})
    return {"ok": True, "roots": allowed, "denied_patterns": settings.denied_patterns,
            "index_enabled": settings.files_index_enabled,
            "index_extensions": settings.index_extensions,
            "upload_dir": str(UPLOAD_DIR),
            "max_upload_mb": settings.files_max_upload_mb}


def _writable(path: Path) -> bool:
    try:
        assert_allowed(path, for_write=True)
        return True
    except FileSecurityError:
        return False


@router.get("/browse", summary="List one folder")
async def browse(path: str = "", show_hidden: bool = False, limit: int = 500) -> Dict[str, Any]:
    target = Path(path).expanduser() if path else \
        (settings.allowed_roots[0] if settings.allowed_roots else Path.home())
    try:
        target = assert_allowed(target)
    except FileSecurityError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    if not target.exists():
        raise HTTPException(status_code=404, detail=f"not found: {target}")
    if target.is_file():
        return {"ok": True, "path": str(target), "is_file": True, "info": stat_path(target),
                "entries": []}

    entries: List[Dict[str, Any]] = []
    try:
        for child in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
            if not show_hidden and child.name.startswith("."):
                continue
            try:
                st = child.stat()
            except OSError:
                continue
            entries.append({
                "name": child.name, "path": str(child), "is_dir": child.is_dir(),
                "bytes": 0 if child.is_dir() else st.st_size,
                "size": "" if child.is_dir() else human_size(st.st_size),
                "modified": st.st_mtime, "ext": child.suffix.lower().lstrip("."),
                "allowed": _writable(child) if child.is_dir() else True,
            })
            if len(entries) >= limit:
                break
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=f"OS refused: {exc}")

    dirs = [e for e in entries if e["is_dir"]]
    files = [e for e in entries if not e["is_dir"]]
    return {"ok": True, "path": str(target), "parent": str(target.parent)
            if str(target.parent) != str(target) else None,
            "is_file": False, "count": len(entries), "dirs": len(dirs), "files": len(files),
            "total_bytes": sum(f["bytes"] for f in files),
            "total_size": human_size(sum(f["bytes"] for f in files)),
            "entries": entries, "breadcrumb": _breadcrumb(target)}


def _breadcrumb(path: Path) -> List[Dict[str, str]]:
    parts: List[Dict[str, str]] = []
    for parent in reversed([path, *path.parents]):
        parts.append({"name": parent.name or str(parent), "path": str(parent)})
    return parts


@router.get("/info", summary="Stat one path (optionally with a hash)")
async def info(path: str, hash: bool = False) -> Dict[str, Any]:
    try:
        target = assert_allowed(path)
    except FileSecurityError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    if not target.exists():
        raise HTTPException(status_code=404, detail=f"not found: {target}")
    return {"ok": True, **stat_path(target, include_hash=hash)}


@router.post("/search", summary="Search by name, type, date, size, content or meaning")
async def search(body: SearchBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files", user_text=body.query)
    if body.semantic:
        result = await tool_call("memory.semantic_search", ctx, query=body.query,
                                 limit=body.limit)
    else:
        params: Dict[str, Any] = {"query": body.query, "limit": body.limit}
        if body.roots:
            params["roots"] = body.roots
        result = await tool_call("files.search", ctx, **params)
    return unwrap(result)


@router.get("/read", summary="Read a text file")
async def read(path: str, max_chars: int = Query(100000, le=2000000)) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    result = await tool_call("files.read", ctx, path=path, max_chars=max_chars)
    return unwrap(result)


@router.post("/write", summary="Write or append to a text file")
async def write(body: FileWrite) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files", user_text=f"write {body.path}")
    result = await tool_call("files.write", ctx, path=body.path, content=body.content,
                             mode=body.mode)
    return unwrap(result)


@router.post("/copy", summary="Copy a file or folder")
async def copy(body: FileMove) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.copy", ctx, source=body.source,
                                  destination=body.destination, overwrite=body.overwrite))


@router.post("/move", summary="Move a file or folder")
async def move(body: FileMove) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.move", ctx, src=body.source,
                                  dst=body.destination, overwrite=body.overwrite))


@router.post("/rename", summary="Rename a file or folder")
async def rename(path: str, new_name: str) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.rename", ctx, path=path, new_name=new_name))


@router.post("/delete", summary="Delete (to the recycle bin)")
async def delete(body: FileDelete) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    paths = body.paths or ([body.path] if body.path else [])
    if not paths:
        raise HTTPException(status_code=400, detail="no paths given")
    results = [await tool_call("files.delete", ctx, path=p) for p in paths[:50]]
    ok = all(r.get("ok") for r in results)
    return {"ok": ok, "deleted": sum(1 for r in results if r.get("ok")),
            "results": [unwrap(r) for r in results]}


@router.post("/archive", summary="Compress paths into an archive")
async def archive(body: ArchiveBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.archive", ctx, action="create", sources=body.sources,
                                  output=body.output, fmt=body.format))


@router.post("/extract", summary="Extract an archive")
async def extract(body: ArchiveBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    source = body.sources[0] if body.sources else body.output
    if not source:
        raise HTTPException(status_code=400, detail="give the archive path in sources[0]")
    return unwrap(await tool_call("files.archive", ctx, action="extract", source=source,
                                  dest=body.extract_to))


@router.post("/duplicates", summary="Find duplicate files")
async def duplicates(roots: List[str] = Query(default=[]), min_size_kb: int = 64,
                     limit: int = 200) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    folder = roots[0] if roots else ""
    return unwrap(await tool_call("files.duplicates", ctx, folder=folder,
                                  min_size=f"{max(1, min_size_kb)}kb", max_files=limit * 100))


@router.post("/organise/plan", summary="Preview an organise plan (changes nothing)")
async def organise_plan(body: OrganiseBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.plan_organise", ctx, folder=body.folder,
                                  strategy=body.strategy))


@router.post("/organise", summary="Apply an organise plan")
async def organise(body: OrganiseBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files", user_text=f"organise {body.folder}")
    return unwrap(await tool_call("files.organise", ctx, folder=body.folder,
                                  strategy=body.strategy,
                                  dry_run=body.dry_run and not body.apply))


@router.post("/convert", summary="Convert a document or image")
async def convert(body: ConvertBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.convert", ctx, path=body.source, to=body.to,
                                  output=body.output))


@router.post("/backup", summary="Back up a file or folder")
async def backup(body: BackupBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files", user_text=f"back up {body.path}")
    return unwrap(await tool_call("files.backup", ctx, path=body.path, label=body.label,
                                  keep=body.keep))


@router.get("/backups", summary="List existing backups")
async def backups() -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.restore", ctx, list_backups=True))


@router.post("/restore", summary="Restore a backup")
async def restore(backup: str, destination: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="files", user_text=f"restore {backup}")
    return unwrap(await tool_call("files.restore", ctx, backup=backup,
                                  destination=destination, list_backups=False))


@router.post("/clean", summary="Find or clear junk files")
async def clean(folder: str = "", apply: bool = False, min_age_days: int = 1,
                max_mb: int = 2000) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files", user_text="clean junk files")
    return unwrap(await tool_call("files.clean", ctx, folder=folder, apply=apply,
                                  min_age_days=min_age_days, max_mb=max_mb))


@router.post("/index", summary="Build or refresh the semantic file index")
async def index(folder: str = "", limit: int = 2000) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.index", ctx, folder=folder, limit=limit))


@router.get("/index/stats", summary="Semantic index statistics")
async def index_stats() -> Dict[str, Any]:
    from backend.app.files.semantic_index import semantic_index

    data = await semantic_index.stats()
    data["ok"] = True
    return data


@router.get("/scan", summary="Scan a folder tree and report what is in it")
async def scan(folder: str = "", limit: int = 500) -> Dict[str, Any]:
    ctx = tool_context(None, agent="files")
    return unwrap(await tool_call("files.scan", ctx, folder=folder, limit=limit))


@router.post("/upload", summary="Upload a file into SAM's upload folder")
async def upload(file: UploadFile, folder: str = "") -> Dict[str, Any]:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    limit = int(settings.files_max_upload_mb) * 1024 * 1024
    target_dir = Path(folder).expanduser() if folder else UPLOAD_DIR
    try:
        target_dir = assert_allowed(target_dir, for_write=True)
    except FileSecurityError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    target_dir.mkdir(parents=True, exist_ok=True)

    name = Path(file.filename or "upload.bin").name
    target = target_dir / name
    written = 0
    try:
        with open(target, "wb") as fh:
            while chunk := await file.read(1024 * 256):
                written += len(chunk)
                if written > limit:
                    fh.close()
                    target.unlink(missing_ok=True)
                    raise HTTPException(
                        status_code=413,
                        detail=f"file exceeds the {settings.files_max_upload_mb} MB upload limit")
                fh.write(chunk)
    except HTTPException:
        raise
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"could not write the upload: {exc}")
    return {"ok": True, "path": str(target), "name": name, "bytes": written,
            "size": human_size(written), "verified": target.exists()}


@router.get("/download", summary="Download a file SAM is allowed to read")
async def download(path: str) -> FileResponse:
    try:
        target = assert_allowed(path)
    except FileSecurityError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"not a file: {target}")
    return FileResponse(str(target), filename=target.name)


@router.get("/artifact/{category}/{name}", summary="Serve a generated artefact")
async def artifact(category: str, name: str) -> FileResponse:
    """
    Serves screenshots, documents, charts, creative images and voice audio from
    SAM's own data directory. Restricted to those folders on purpose — this is
    not a general file server.
    """
    allowed = {"screenshots": settings.sam_data_dir / "cache" / "screenshots",
               "documents": settings.sam_data_dir / "documents",
               "creative": settings.sam_data_dir / "creative",
               "images": settings.sam_data_dir / "creative" / "images",
               "charts": settings.sam_data_dir / "creative" / "charts",
               "browser": settings.sam_data_dir / "cache" / "browser",
               "backups": settings.sam_data_dir / "backups",
               "transfers": settings.sam_data_dir / "transfers",
               "uploads": UPLOAD_DIR,
               # generated by code.artifact / code.qrcode / code.snippet
               "artifacts": settings.sam_data_dir / "artifacts",
               "code": settings.sam_data_dir / "artifacts" / "code",
               "reports": settings.sam_data_dir / "artifacts" / "reports",
               "data": settings.sam_data_dir / "artifacts" / "data"}
    base = allowed.get(category)
    if base is None:
        raise HTTPException(status_code=404,
                            detail=f"unknown artefact category '{category}'. "
                                   f"Known: {', '.join(sorted(allowed))}")
    safe = Path(name).name
    target = (base / safe).resolve()
    if not str(target).startswith(str(base.resolve())) or not target.is_file():
        raise HTTPException(status_code=404, detail="artefact not found")
    return FileResponse(str(target), filename=safe)
