"""
backend.app.api.v1.devices
==========================

The DEVICES page API — the unified device dashboard, cross-device routing and
the PC ⇄ Phone sync engine.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token
from backend.app.core.logging_config import get_logger
from backend.app.devices.registry import device_registry
from backend.app.devices.sync import sync_engine

log = get_logger("api.devices")

router = APIRouter(prefix="/devices", tags=["devices"], dependencies=[Depends(check_token)])


class SyncConfig(BaseModel):
    enabled: Optional[bool] = None
    clipboard_bridge: Optional[bool] = None
    notification_mirror: Optional[bool] = None
    file_bridge: Optional[bool] = None
    auto_state_sync: Optional[bool] = None


class ClipboardBody(BaseModel):
    text: str = ""
    direction: str = "pc_to_phone"


class FileSendBody(BaseModel):
    path: str = Field(..., min_length=1)
    direction: str = "pc_to_phone"
    device_id: str = ""


class HandoffBody(BaseModel):
    instruction: str = Field(..., min_length=2)
    to_device: str = "phone"


@router.get("", summary="Every device SAM knows about")
async def list_devices(kind: str = "", online_only: bool = False) -> Dict[str, Any]:
    return {"ok": True, "summary": device_registry.summary(),
            "devices": device_registry.all(kind=kind, online_only=online_only)}


@router.get("/snapshot", summary="Live dashboard snapshot (PC + phone + browser)")
async def snapshot() -> Dict[str, Any]:
    return await device_registry.snapshot()


@router.post("/route", summary="Ask SAM where a request should run")
async def route(request: str, needs: List[str] = []) -> Dict[str, Any]:
    data = device_registry.route(request, needs)
    data["ok"] = True
    return data


@router.post("/resolve", summary="Map a loose device name to a registry id")
async def resolve(device: str) -> Dict[str, Any]:
    return {"ok": True, "input": device, "device_id": device_registry.resolve(device)}


@router.delete("/{device_id}", summary="Unpair a device")
async def unpair(device_id: str) -> Dict[str, Any]:
    if device_id == "pc-local":
        raise HTTPException(status_code=400, detail="this PC cannot be unpaired")
    ok = await device_registry.remove(device_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"no device with id {device_id}")
    return {"ok": True, "removed": device_id}


# ---------------------------------------------------------------------------
# sync engine
# ---------------------------------------------------------------------------
@router.get("/sync", summary="Sync engine state")
async def sync_status() -> Dict[str, Any]:
    data = await sync_engine.status()
    data["ok"] = True
    return data


@router.patch("/sync", summary="Configure the sync engine")
async def sync_config(body: SyncConfig) -> Dict[str, Any]:
    values = {k: v for k, v in body.model_dump().items() if v is not None}
    if not values:
        raise HTTPException(status_code=400, detail="nothing to change")
    data = sync_engine.configure(**values)
    data["ok"] = True
    return data


@router.post("/sync/start", summary="Start the sync loop")
async def sync_start() -> Dict[str, Any]:
    data = sync_engine.start()
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/sync/stop", summary="Stop the sync loop")
async def sync_stop() -> Dict[str, Any]:
    return sync_engine.stop()


@router.post("/sync/now", summary="Run one mirror cycle immediately")
async def sync_now(device_id: str = "") -> Dict[str, Any]:
    data = await sync_engine.sync_once(device_id)
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/sync/clipboard", summary="Push clipboard text between PC and phone")
async def clipboard(body: ClipboardBody) -> Dict[str, Any]:
    if not body.text:
        raise HTTPException(status_code=400, detail="clipboard text is empty")
    data = await sync_engine.push_clipboard(body.text, direction=body.direction)
    data["ok"] = bool(data.get("ok"))
    return data


@router.get("/sync/clipboard", summary="Pull the clipboard from the other device")
async def clipboard_pull(direction: str = "phone_to_pc") -> Dict[str, Any]:
    data = await sync_engine.pull_clipboard(direction=direction)
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/sync/file", summary="Send a file to the phone")
async def send_file(body: FileSendBody) -> Dict[str, Any]:
    data = await sync_engine.send_file(body.path, direction=body.direction,
                                       device_id=body.device_id)
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/sync/notifications", summary="Mirror phone notifications onto the PC")
async def mirror_notifications(limit: int = 20) -> Dict[str, Any]:
    data = await sync_engine.mirror_notifications(limit=limit)
    data["ok"] = bool(data.get("ok"))
    return data


@router.post("/handoff", summary="Continue a request on another device")
async def handoff(body: HandoffBody) -> Dict[str, Any]:
    data = await sync_engine.handoff(body.instruction, to_device=body.to_device)
    data["ok"] = bool(data.get("ok"))
    return data
