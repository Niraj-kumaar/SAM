"""
backend.app.api.v1.coding
=========================

The CODING page API — the full development pipeline, one endpoint per stage,
plus ``/pipeline`` which runs the whole chain and reports every stage.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.core.logging_config import get_logger
from backend.app.files.file_ops import FileSecurityError, assert_allowed

log = get_logger("api.coding")

router = APIRouter(prefix="/coding", tags=["coding"], dependencies=[Depends(check_token)])


class AnalyseBody(BaseModel):
    goal: str = Field(..., min_length=3)
    language: str = ""
    project_path: str = ""


class GenerateBody(BaseModel):
    goal: str = ""
    language: str = ""
    files: List[Dict[str, Any]] = Field(default_factory=list)


class WriteBody(BaseModel):
    project_path: str = ""
    files: List[Dict[str, Any]] = Field(default_factory=list)
    overwrite: bool = True


class RunBody(BaseModel):
    project_path: str = Field(..., min_length=1)
    command: str = ""
    language: str = ""


class ExplainBody(BaseModel):
    path: str = ""
    code: str = ""
    depth: str = "standard"


class ProjectBody(BaseModel):
    name: str = ""
    kind: str = "python-cli"
    path: str = ""
    goal: str = ""


class PipelineBody(BaseModel):
    goal: str = Field(..., min_length=5)
    language: str = ""
    project_path: str = ""
    write_files: bool = True
    run_tests: bool = True
    document: bool = True
    repair_rounds: int = Field(1, ge=0, le=3)


@router.post("/analyse", summary="Stage 1 — requirement analysis")
async def analyse(body: AnalyseBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=body.goal)
    return unwrap(await tool_call("coding.analyse", ctx, goal=body.goal,
                                  language=body.language, project_path=body.project_path))


@router.post("/architecture", summary="Stage 2 — architecture plan")
async def architecture(body: AnalyseBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="reasoning", user_text=body.goal)
    return unwrap(await tool_call("coding.architecture", ctx, goal=body.goal,
                                  language=body.language, project_path=body.project_path))


@router.post("/generate", summary="Stage 3 — code generation")
async def generate(body: GenerateBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=body.goal)
    return unwrap(await tool_call("coding.generate", ctx, goal=body.goal,
                                  language=body.language, files=body.files or None))


@router.post("/write", summary="Stage 4 — write files into a project")
async def write_files(body: WriteBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=f"write files to {body.project_path}")
    return unwrap(await tool_call("coding.write_files", ctx, project_path=body.project_path,
                                  files=body.files or None, overwrite=body.overwrite))


@router.post("/run-tests", summary="Stages 5-6 — execute and test")
async def run_tests(body: RunBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=f"run tests in {body.project_path}")
    return unwrap(await tool_call("coding.run_tests", ctx, project_path=body.project_path,
                                  command=body.command, language=body.language))


@router.post("/diagnose", summary="Stage 7 — error analysis")
async def diagnose(error: str = "", project_path: str = "") -> Dict[str, Any]:
    if not error:
        raise HTTPException(status_code=400, detail="give the error text to diagnose")
    ctx = tool_context(None, agent="reasoning", user_text=error[:300])
    return unwrap(await tool_call("coding.analyse_error", ctx, error=error,
                                  project_path=project_path))


@router.post("/repair", summary="Stage 8 — apply a fix")
async def repair(project_path: str = "", fix: str = "",
                 files: List[Dict[str, Any]] = []) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=fix[:300] or "repair the project")
    return unwrap(await tool_call("coding.repair", ctx, project_path=project_path, fix=fix,
                                  files=files or None))


@router.post("/explain", summary="Explain code or a project")
async def explain(body: ExplainBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=body.path or body.code[:200])
    return unwrap(await tool_call("coding.explain", ctx, path=body.path, code=body.code,
                                  depth=body.depth))


@router.post("/document", summary="Stage 10 — generate a README")
async def document(project_path: str = "", write: bool = True) -> Dict[str, Any]:
    ctx = tool_context(None, agent="writing", user_text=f"document {project_path}")
    return unwrap(await tool_call("coding.document", ctx, project_path=project_path,
                                  write=write))


@router.post("/project", summary="Scaffold a new project")
async def create_project(body: ProjectBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=body.goal or body.name)
    return unwrap(await tool_call("coding.project.create", ctx, name=body.name,
                                  kind=body.kind, path=body.path, goal=body.goal))


@router.post("/pipeline", summary="Run the whole coding pipeline")
async def pipeline(body: PipelineBody) -> Dict[str, Any]:
    """
    Requirement → Architecture → Generate → Write → Test → Diagnose → Repair →
    Retest → Document. Each stage is recorded, and a stage failure stops the
    chain with the reason instead of silently continuing.
    """
    stages: List[Dict[str, Any]] = []
    ctx = tool_context(None, agent="coding", user_text=body.goal)
    project = body.project_path

    def record(name: str, result: Any) -> Any:
        stages.append({"stage": name, "ok": bool(result.get("ok")),
                       "error": result.get("error"),
                       "summary": _stage_summary(name, result)})
        return result

    requirements = record("requirements", await tool_call(
        "coding.analyse", ctx, goal=body.goal, language=body.language, project_path=project))
    if not requirements.get("ok"):
        return {"ok": False, "stage_failed": "requirements", "stages": stages,
                "error": requirements.get("error")}

    architecture = record("architecture", await tool_call(
        "coding.architecture", ctx, goal=body.goal,
        language=requirements.get("language") or body.language, project_path=project))

    generated = record("generation", await tool_call(
        "coding.generate", ctx, goal=body.goal,
        language=architecture.get("language") or body.language,
        files=architecture.get("files") or None))
    if not generated.get("ok"):
        return {"ok": False, "stage_failed": "generation", "stages": stages,
                "requirements": requirements, "architecture": architecture}

    written: Dict[str, Any] = {"ok": False, "skipped": True}
    if body.write_files:
        written = record("write", await tool_call(
            "coding.write_files", ctx, project_path=project, files=generated.get("files"),
            overwrite=True))
        project = written.get("root") or project
        if not written.get("ok") and not written.get("files"):
            return {"ok": False, "stage_failed": "write", "stages": stages,
                    "generated": generated, "error": written.get("error")}

    tests: Dict[str, Any] = {"ok": True, "skipped": True}
    repairs: List[Dict[str, Any]] = []
    if body.run_tests and project:
        tests = record("tests", await tool_call("coding.run_tests", ctx, project_path=project))
        rounds = 0
        while not tests.get("ok") and rounds < max(0, body.repair_rounds):
            rounds += 1
            diagnosis = record(f"diagnose#{rounds}", await tool_call(
                "coding.analyse_error", ctx,
                error=(tests.get("stderr") or "") + "\n" + str(tests.get("tests") or ""),
                project_path=project))
            fix = record(f"repair#{rounds}", await tool_call(
                "coding.repair", ctx, project_path=project,
                fix=diagnosis.get("fix", ""), files=None))
            repairs.append({"round": rounds, "diagnosis": diagnosis, "repair": fix})
            if not fix.get("ok"):
                break
            tests = record(f"retest#{rounds}", await tool_call(
                "coding.run_tests", ctx, project_path=project))

    docs: Dict[str, Any] = {"ok": True, "skipped": True}
    if body.document and project:
        docs = record("documentation", await tool_call("coding.document", ctx,
                                                       project_path=project, write=True))

    ok = bool(tests.get("ok", True)) and bool(written.get("ok", True) or written.get("skipped"))
    return {
        "ok": ok, "goal": body.goal, "project_path": project, "stages": stages,
        "requirements": requirements, "architecture": architecture,
        "generated": {"files": generated.get("files"), "total_lines": generated.get("total_lines")},
        "written": written, "tests": tests, "repairs": repairs, "documentation": docs,
        "answer": _pipeline_answer(ok, project, tests, repairs, stages),
    }


def _stage_summary(name: str, result: Dict[str, Any]) -> str:
    if result.get("skipped"):
        return "skipped"
    if not result.get("ok"):
        return str(result.get("error") or "failed")[:200]
    if name == "requirements":
        return f"{len(result.get('requirements') or [])} requirements"
    if name == "architecture":
        return f"{len(result.get('files') or [])} files planned"
    if name == "generation":
        return f"{result.get('total_lines', 0)} lines generated"
    if name == "write":
        return f"{result.get('written', 0)} files written to {result.get('root')}"
    if name.startswith("tests") or name.startswith("retest"):
        t = result.get("tests") or {}
        return f"passed={t.get('passed')} failed={t.get('failed')} rc={result.get('returncode')}"
    if name.startswith("diagnose"):
        return str(result.get("root_cause") or "")[:160]
    if name.startswith("repair"):
        return f"{result.get('files_changed', 0)} file(s) changed"
    if name == "documentation":
        return result.get("written") or f"{result.get('word_count', 0)} words"
    return "ok"


def _pipeline_answer(ok: bool, project: str, tests: Dict[str, Any],
                     repairs: List[Dict[str, Any]], stages: List[Dict[str, Any]]) -> str:
    lines = [f"Coding pipeline {'succeeded' if ok else 'did not fully succeed'}."
             if project else "Coding pipeline finished (nothing was written to disk)."]
    if project:
        lines.append(f"Project: {project}")
    for stage in stages:
        mark = "✓" if stage["ok"] else "✗"
        lines.append(f"{mark} {stage['stage']}: {stage['summary']}")
    if repairs:
        lines.append(f"Repair rounds: {len(repairs)}")
    t = tests.get("tests") or {}
    if t:
        lines.append(f"Tests: {t.get('passed') or 0} passed, {t.get('failed') or 0} failed")
    return "\n".join(lines)


@router.get("/project", summary="Inspect a project on disk")
async def inspect_project(path: str, depth: int = 3) -> Dict[str, Any]:
    try:
        root = assert_allowed(path)
    except FileSecurityError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    if not root.exists():
        raise HTTPException(status_code=404, detail=f"not found: {root}")
    ctx = tool_context(None, agent="coding")
    return unwrap(await tool_call("files.scan", ctx, folder=str(root), limit=500, depth=depth))


@router.get("/dev-environment", summary="Detect installed dev tooling")
async def dev_environment() -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding")
    return unwrap(await tool_call("pc.dev.detect", ctx))


@router.post("/terminal", summary="Run a terminal command (risk-gated)")
async def terminal(command: str, cwd: str = "", timeout: int = 120) -> Dict[str, Any]:
    ctx = tool_context(None, agent="coding", user_text=command[:200])
    return unwrap(await tool_call("pc.terminal", ctx, command=command, cwd=cwd,
                                  timeout=timeout))


@router.post("/git", summary="Run a git command in a repository")
async def git(args: str = "status", cwd: str = "") -> Dict[str, Any]:
    """``args`` is everything after ``git``, e.g. ``status``, ``log --oneline -5``."""
    ctx = tool_context(None, agent="coding", user_text=f"git {args}")
    return unwrap(await tool_call("coding.git", ctx, args=args, cwd=cwd))
