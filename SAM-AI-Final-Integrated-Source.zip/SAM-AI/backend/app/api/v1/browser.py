"""
backend.app.api.v1.browser
==========================

The BROWSER page API — a live view of, and control over, the user's own browser
session.

Two transports (chosen in ``.env`` with ``BROWSER_PROVIDER``):

* ``playwright`` — SAM launches a browser with its own profile
  (``data/browser-profile``); you sign in once inside it and SAM keeps that
  session.
* ``cdp`` — SAM attaches to *your* running Chrome/Edge started with
  ``--remote-debugging-port=9222``, so it uses your existing logins directly.

Either way SAM refuses checkout / banking / sign-in pages and any password, OTP,
CVV or PIN field. That guard lives in the tool layer, so this API cannot bypass it.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.browser.engine import browser_engine, normalize_url
from backend.app.config import settings
from backend.app.core.logging_config import get_logger

log = get_logger("api.browser")

router = APIRouter(prefix="/browser", tags=["browser"], dependencies=[Depends(check_token)])


class NavigateBody(BaseModel):
    url: str = Field(..., min_length=1)
    wait: str = "domcontentloaded"
    new_tab: bool = False


class ExtractBody(BaseModel):
    selector: str = ""
    kind: str = "text"      # text | links | table | images | list | meta | html
    limit: int = Field(200, ge=1, le=2000)
    query: str = ""


class ClickBody(BaseModel):
    selector: str = ""
    text: str = ""
    index: int = 0


class FormBody(BaseModel):
    fields: Dict[str, str] = Field(default_factory=dict)
    submit: bool = False
    submit_selector: str = ""


class TabsBody(BaseModel):
    action: str = "list"    # list | new | switch | close
    index: Optional[int] = None
    url: str = ""


class WaitBody(BaseModel):
    selector: str = ""
    text: str = ""
    timeout: int = Field(20000, ge=500, le=120000)


@router.get("/status", summary="Browser engine state")
async def status() -> Dict[str, Any]:
    data = await browser_engine.status()
    data["ok"] = True
    data["config"] = {"provider": settings.browser_provider, "headless": settings.browser_headless,
                      "channel": settings.browser_channel, "cdp_url": settings.browser_cdp_url,
                      "profile": str(settings.browser_user_data_dir),
                      "enabled": settings.browser_enabled}
    data["cdp_hint"] = ('Start Chrome with: chrome.exe --remote-debugging-port=9222 '
                        '--user-data-dir="C:\\sam-chrome-profile" then set '
                        'BROWSER_PROVIDER=cdp and BROWSER_CDP_URL=http://127.0.0.1:9222')
    if not settings.browser_enabled:
        data["warning"] = "browser control is disabled (BROWSER_ENABLED=false)"
    return data


@router.post("/start", summary="Launch or attach the browser")
async def start() -> Dict[str, Any]:
    if not settings.browser_enabled:
        raise HTTPException(status_code=403, detail="browser control is disabled")
    data = await browser_engine.start()
    data["ok"] = bool(data.get("ok", True))
    return data


@router.post("/stop", summary="Close the browser SAM controls")
async def stop() -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    return unwrap(await tool_call("browser.stop", ctx))


@router.post("/navigate", summary="Go to a URL (or a shortcut like 'github')")
async def navigate(body: NavigateBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser", user_text=body.url)
    return unwrap(await tool_call("browser.navigate", ctx, url=body.url, wait=body.wait))


@router.post("/reload", summary="Reload the current page")
async def reload_page() -> Dict[str, Any]:
    data = await browser_engine.reload()
    data["ok"] = bool(data.get("ok", True))
    return data


@router.post("/back", summary="Go back")
async def back() -> Dict[str, Any]:
    data = await browser_engine.back()
    data["ok"] = bool(data.get("ok", True))
    return data


@router.get("/page", summary="Read the current page (text, links, headings, screenshot)")
async def read_page(screenshot: bool = False, max_text: int = 200000) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    result = unwrap(await tool_call("browser.read_page", ctx, screenshot=screenshot,
                                    max_text=max_text))
    if result.get("screenshot"):
        from pathlib import Path

        result["screenshot_url"] = f"/api/v1/files/artifact/browser/{Path(result['screenshot']).name}"
    return result


@router.post("/extract", summary="Extract structured data from the page")
async def extract(body: ExtractBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser", user_text=body.query or body.selector)
    return unwrap(await tool_call("browser.extract", ctx, selector=body.selector,
                                  kind=body.kind, limit=body.limit, query=body.query))


@router.post("/click", summary="Click an element")
async def click(body: ClickBody) -> Dict[str, Any]:
    if not body.selector and not body.text:
        raise HTTPException(status_code=400, detail="give a selector or link text")
    ctx = tool_context(None, agent="browser", user_text=body.text or body.selector)
    return unwrap(await tool_call("browser.click", ctx, selector=body.selector,
                                  text=body.text, index=body.index))


@router.post("/form", summary="Fill a form (password/OTP fields are always refused)")
async def form(body: FormBody) -> Dict[str, Any]:
    if not body.fields:
        raise HTTPException(status_code=400, detail="no fields given")
    ctx = tool_context(None, agent="browser", user_text="fill form")
    return unwrap(await tool_call("browser.form_fill", ctx, fields=body.fields,
                                  submit=body.submit, submit_selector=body.submit_selector))


@router.post("/tabs", summary="List, open, switch or close tabs")
async def tabs(body: TabsBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    return unwrap(await tool_call("browser.tabs", ctx, action=body.action, index=body.index,
                                  url=body.url))


@router.post("/screenshot", summary="Screenshot the page")
async def screenshot(full_page: bool = False) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    result = unwrap(await tool_call("browser.screenshot", ctx, full_page=full_page))
    if result.get("path"):
        from pathlib import Path

        result["url"] = f"/api/v1/files/artifact/browser/{Path(result['path']).name}"
    return result


@router.post("/download", summary="Download a file or click a download link")
async def download(selector: str = "", url: str = "", save_dir: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser", user_text=url or selector)
    return unwrap(await tool_call("browser.download", ctx, selector=selector, url=url,
                                  save_dir=save_dir))


@router.post("/scroll", summary="Scroll the page")
async def scroll(direction: str = "down", amount: int = 800) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    return unwrap(await tool_call("browser.scroll", ctx, direction=direction, amount=amount))


@router.post("/wait", summary="Wait for an element or text")
async def wait(body: WaitBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    return unwrap(await tool_call("browser.wait", ctx, selector=body.selector, text=body.text,
                                  timeout=body.timeout))


@router.get("/page-info", summary="Title, URL, favicon and metadata of the current page")
async def page_info() -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    return unwrap(await tool_call("browser.page_info", ctx))


@router.get("/bookmarks", summary="SAM's bookmark store")
async def bookmarks() -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    return unwrap(await tool_call("browser.bookmarks", ctx, action="list"))


@router.post("/bookmarks", summary="Add a bookmark")
async def add_bookmark(title: str = "", url: str = "", folder: str = "") -> Dict[str, Any]:
    target = url or title
    if not target:
        raise HTTPException(status_code=400, detail="give a title or url")
    resolved = normalize_url(target) if not url else url
    ctx = tool_context(None, agent="browser", user_text=resolved)
    return unwrap(await tool_call("browser.bookmarks", ctx, action="add",
                                  title=title or resolved, url=resolved, folder=folder))


@router.delete("/bookmarks", summary="Remove a bookmark")
async def remove_bookmark(url: str) -> Dict[str, Any]:
    ctx = tool_context(None, agent="browser")
    return unwrap(await tool_call("browser.bookmarks", ctx, action="remove", url=url))


@router.get("/history", summary="What SAM did in the browser this session")
async def history(limit: int = 50) -> Dict[str, Any]:
    return {"ok": True, "count": len(browser_engine.history[-limit:]),
            "history": list(browser_engine.history)[-limit:]}


@router.get("/shortcuts", summary="The URL shortcut vocabulary SAM understands")
async def shortcuts() -> Dict[str, Any]:
    samples = ["github", "google:quantum computing", "youtube", "gmail", "stackoverflow",
               "arxiv", "wikipedia:Bangalore", "https://example.com"]
    return {"ok": True, "examples": [{"input": s, "resolved": normalize_url(s)} for s in samples],
            "note": "Bare words become a search; known names become their site."}
