"""
backend.app.api.v1.phone
========================

The PHONE page API — pairing, live state and every phone action.

Android's permission model is authoritative here: every operation is a request
to the SAM Companion app, which answers ``permission_denied`` when the user has
not granted the Android permission. SAM surfaces that instead of working around
it. SMS, calls, contacts and Accessibility are additionally gated by
``PHONE_ALLOW_*`` flags in ``.env`` and are **off by default**.

Sending a message or making a call always follows
Prepare → Preview → user confirmation → Send.
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.devices.phone_bridge import phone_bridge

log = get_logger("api.phone")

router = APIRouter(prefix="/phone", tags=["phone"], dependencies=[Depends(check_token)])


class MessageBody(BaseModel):
    to: str = Field(..., min_length=1)
    body: str = Field(..., min_length=1)
    app: str = "sms"            # sms | whatsapp | telegram
    send: bool = False          # False = prepare/preview only
    device_id: str = ""


class CallBody(BaseModel):
    number: str = ""
    contact: str = ""
    device_id: str = ""


class AlarmBody(BaseModel):
    minutes: Optional[int] = None
    at: str = ""
    label: str = "SAM alarm"
    device_id: str = ""


class CalendarBody(BaseModel):
    action: str = "list"
    title: str = ""
    start: str = ""
    days: int = 7
    device_id: str = ""


class DispatchBody(BaseModel):
    request: str = Field(..., min_length=2)
    device_id: str = ""


@router.get("/status", summary="Connection state, transport and permissions")
async def status() -> Dict[str, Any]:
    data = phone_bridge.status()
    data["ok"] = True
    data["policy"] = {
        "allow_sms": settings.phone_allow_sms,
        "allow_calls": settings.phone_allow_calls,
        "allow_contacts": settings.phone_allow_contacts,
        "allow_accessibility": settings.phone_allow_accessibility,
        "privacy_phone_sync": settings.privacy_phone_sync,
    }
    now = time.time()
    data["pairing_offers"] = [{"code": o.code, "expires_in": int(o.expires_at - now),
                               "accepted": o.accepted, "fingerprint": o.fingerprint}
                              for o in phone_bridge.pairing_offers.values()]
    data["adb"] = {"path": settings.adb_path, "available": phone_bridge.adb_available,
                   "note": "ADB is a read-only fallback for battery/Wi-Fi/storage/apps when no "
                           "companion app is connected"}
    return data


@router.post("/pairing", summary="Create a pairing code + QR payload")
async def pairing(device_hint: str = "", ttl: int = 300) -> Dict[str, Any]:
    if not settings.phone_enabled:
        raise HTTPException(status_code=403, detail="phone support is disabled "
                                                    "(PHONE_ENABLED=false)")
    offer = phone_bridge.create_pairing_code(device_hint, ttl=max(30, min(3600, ttl)))
    qr = phone_bridge.pairing_qr_payload(offer)
    return {"ok": True, "code": offer.code, "fingerprint": offer.fingerprint,
            "expires_in": int(offer.expires_at - offer.created_at),
            "qr": qr, "qr_text": __import__("json").dumps(qr, separators=(",", ":")),
            "secret_configured": bool(settings.phone_pairing_secret),
            "instructions": [
                "1. Install the SAM Companion app on the Android phone (android/SAMCompanion).",
                "2. Both devices must be on the same Wi-Fi network.",
                f"3. In the app tap “Pair” and enter {offer.code}, or scan the QR code.",
                "4. The phone shows its permissions screen — grant only what you want SAM to do.",
                "5. Approve the request here (POST /phone/pairing/approve) if SAM asks.",
                "6. If SAM cannot be reached, check the Windows/Linux firewall allows "
                f"TCP {settings.sam_port}.",
            ],
            "warning": None if settings.phone_pairing_secret else
                       "PHONE_PAIRING_SECRET is empty — set it in .env so the handshake is signed.",
            }


@router.post("/pairing/approve", summary="Approve a phone's pairing request")
async def approve_pairing(code: str, device_id: str, device_name: str = "") -> Dict[str, Any]:
    ok = await phone_bridge.accept_pairing(code, device_id, device_name)
    if not ok:
        raise HTTPException(status_code=404, detail="unknown or expired pairing code")
    return {"ok": True, "device_id": device_id, "name": device_name, "paired": True}


@router.get("/pairing/verify", summary="Verify a phone's handshake signature")
async def verify_handshake(code: str, signature: str) -> Dict[str, Any]:
    ok = phone_bridge.verify_handshake(code, signature)
    return {"ok": ok, "valid": ok,
            "error": None if ok else "signature does not match — wrong PHONE_PAIRING_SECRET"}


@router.get("/adb", summary="List devices visible to adb")
async def adb_devices() -> Dict[str, Any]:
    data = await phone_bridge.adb_devices()
    data["ok"] = bool(data.get("ok", True))
    return data


@router.get("/devices", summary="Connected phones")
async def devices() -> Dict[str, Any]:
    sessions = [s.to_dict() for s in phone_bridge.sessions.values()]
    return {"ok": True, "count": len(sessions), "devices": sessions,
            "connected": sum(1 for s in sessions if s["online"]),
            "primary": phone_bridge.first_device_id()}


@router.post("/dispatch", summary="Natural-language phone command router")
async def dispatch(body: DispatchBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone", user_text=body.request)
    return unwrap(await tool_call("phone.dispatch", ctx, request=body.request,
                                  device_id=body.device_id))


@router.get("/state", summary="Battery, storage, network, display — one call")
async def state(device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.system_state", ctx, device_id=device_id))


@router.get("/battery", summary="Battery level and charging state")
async def battery(device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.battery", ctx, device_id=device_id))


@router.get("/apps", summary="Installed apps")
async def apps(search: str = "", device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.apps.list", ctx, search=search, device_id=device_id))


@router.post("/apps/launch", summary="Open an app")
async def launch_app(app: str = "", package: str = "", deep_link: str = "",
                     device_id: str = "") -> Dict[str, Any]:
    if not (app or package or deep_link):
        raise HTTPException(status_code=400, detail="give app, package or deep_link")
    ctx = tool_context(None, agent="phone", device="phone", user_text=app or package)
    return unwrap(await tool_call("phone.apps.launch", ctx, app=app, package=package,
                                  deep_link=deep_link, device_id=device_id))


@router.post("/wifi", summary="Read or change Wi-Fi state")
async def wifi(enabled: Optional[bool] = None, device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.wifi", ctx, enabled=enabled, device_id=device_id))


@router.post("/bluetooth", summary="Read or change Bluetooth state")
async def bluetooth(enabled: Optional[bool] = None, device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.bluetooth", ctx, enabled=enabled, device_id=device_id))


@router.post("/volume", summary="Set or change the media volume")
async def volume(percent: Optional[int] = None, delta: Optional[int] = None,
                 stream: str = "music", device_id: str = "") -> Dict[str, Any]:
    """``percent`` 0-100 sets it, ``delta`` raises/lowers it, ``percent=0`` mutes."""
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.volume", ctx, percent=percent, delta=delta,
                                  stream=stream, device_id=device_id))


@router.post("/brightness", summary="Set the screen brightness")
async def brightness(percent: Optional[int] = None, device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.brightness", ctx, percent=percent, device_id=device_id))


@router.get("/notifications", summary="Read phone notifications")
async def notifications(limit: int = 25, app: str = "", device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.notifications.list", ctx, limit=limit, app=app,
                                  device_id=device_id))


@router.post("/notify", summary="Send a notification to the phone")
async def notify(title: str = "SAM", body: str = "", device_id: str = "") -> Dict[str, Any]:
    if not body:
        raise HTTPException(status_code=400, detail="notification body is empty")
    ctx = tool_context(None, agent="phone", device="phone", user_text=body[:120])
    return unwrap(await tool_call("phone.notify", ctx, title=title, body=body,
                                  device_id=device_id))


@router.post("/alarm", summary="Set an alarm or timer on the phone")
async def alarm(body: AlarmBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone", user_text=body.label)
    minutes = body.minutes
    if minutes is None and body.at:
        minutes = _minutes_from(body.at)
    if minutes is None:
        raise HTTPException(status_code=400, detail="give minutes or an 'at' time")
    return unwrap(await tool_call("phone.alarm", ctx, minutes=minutes, label=body.label,
                                  device_id=body.device_id))


def _minutes_from(at: str) -> Optional[int]:
    from datetime import datetime

    try:
        target = datetime.fromisoformat(at)
    except ValueError:
        try:
            now = datetime.now()
            hour, minute = (int(x) for x in at.split(":")[:2])
            target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if target <= now:
                target = target.replace(day=target.day + 1)
        except Exception:
            return None
    delta = (target - datetime.now()).total_seconds() / 60
    return max(1, int(delta))


@router.post("/message/prepare", summary="Prepare a message (preview, sends nothing)")
async def message_prepare(body: MessageBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="communication", device="phone", user_text=body.body[:200])
    return unwrap(await tool_call("phone.message.prepare", ctx, to=body.to, body=body.body,
                                  app=body.app, request=body.body))


@router.post("/message/send", summary="Send a prepared message (confirmation required)")
async def message_send(body: MessageBody) -> Dict[str, Any]:
    if not settings.phone_allow_sms:
        raise HTTPException(status_code=403,
                            detail="sending messages from the phone is disabled. "
                                   "Set PHONE_ALLOW_SMS=true in .env if you want this.")
    ctx = tool_context(None, agent="communication", device="phone", user_text=body.body[:200])
    if not body.send:
        return unwrap(await tool_call("phone.message.prepare", ctx, to=body.to, body=body.body,
                                      app=body.app, request=body.body))
    return unwrap(await tool_call("phone.message.send", ctx, to=body.to, body=body.body,
                                  app=body.app, device_id=body.device_id))


@router.post("/call", summary="Dial a number or contact (confirmation required)")
async def call(body: CallBody) -> Dict[str, Any]:
    if not settings.phone_allow_calls:
        raise HTTPException(status_code=403,
                            detail="placing calls from the phone is disabled. "
                                   "Set PHONE_ALLOW_CALLS=true in .env if you want this.")
    if not body.number and not body.contact:
        raise HTTPException(status_code=400, detail="give a number or a contact")
    ctx = tool_context(None, agent="communication", device="phone",
                       user_text=body.number or body.contact)
    return unwrap(await tool_call("phone.call", ctx, number=body.number, contact=body.contact,
                                  device_id=body.device_id))


@router.get("/contacts", summary="Search contacts")
async def contacts(query: str = "", limit: int = 20, device_id: str = "") -> Dict[str, Any]:
    if not settings.phone_allow_contacts:
        raise HTTPException(status_code=403,
                            detail="reading phone contacts is disabled. "
                                   "Set PHONE_ALLOW_CONTACTS=true in .env if you want this.")
    ctx = tool_context(None, agent="communication", device="phone", user_text=query)
    return unwrap(await tool_call("phone.contacts", ctx, query=query, limit=limit,
                                  device_id=device_id))


@router.post("/calendar", summary="Read or create phone calendar events")
async def calendar(body: CalendarBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="planning", device="phone", user_text=body.title)
    return unwrap(await tool_call("phone.calendar", ctx, action=body.action, title=body.title,
                                  start=body.start, days=body.days, device_id=body.device_id))


@router.post("/media", summary="Media playback control")
async def media(command: str = "play_pause", device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.media", ctx, command=command, device_id=device_id))


@router.get("/files", summary="List phone storage")
async def files(folder: str = "Download", limit: int = 100, device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.files.list", ctx, folder=folder, limit=limit,
                                  device_id=device_id))


@router.post("/screenshot", summary="Capture the phone screen")
async def screenshot(device_id: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="phone", device="phone")
    return unwrap(await tool_call("phone.screen.capture", ctx, device_id=device_id))


@router.post("/accessibility", summary="Accessibility actions (tap/swipe/back/home)")
async def accessibility(action: str = "tap", text: str = "", x: Optional[int] = None,
                        y: Optional[int] = None, device_id: str = "") -> Dict[str, Any]:
    if not settings.phone_allow_accessibility:
        raise HTTPException(status_code=403,
                            detail="Accessibility control is disabled. Set "
                                   "PHONE_ALLOW_ACCESSIBILITY=true in .env — and only after you "
                                   "understand that it lets SAM drive any app on the phone.")
    ctx = tool_context(None, agent="phone", device="phone", user_text=f"{action} {text}")
    return unwrap(await tool_call("phone.accessibility.tap", ctx, action=action, text=text,
                                  x=x, y=y, device_id=device_id))


@router.get("/history", summary="Recent phone RPC traffic")
async def history(limit: int = 50) -> Dict[str, Any]:
    return {"ok": True, "count": len(phone_bridge.history[-limit:]),
            "history": list(phone_bridge.history)[-limit:]}
