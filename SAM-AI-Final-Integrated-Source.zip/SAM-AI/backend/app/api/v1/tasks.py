"""
backend.app.api.v1.tasks
========================

The Task Control Center API.

Everything the specification asks the TASKS page to show and do:
task id, status, priority, agent, device, progress, current action, step logs,
errors, result, timestamps — plus Start / Pause / Resume / Cancel / Restart /
Prioritise / Retry.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token
from backend.app.core.logging_config import get_logger
from backend.app.core.schemas import TaskStatus
from backend.app.core.task_store import task_store

log = get_logger("api.tasks")

router = APIRouter(prefix="/tasks", tags=["tasks"], dependencies=[Depends(check_token)])


class TaskCreate(BaseModel):
    request: str = Field(..., min_length=1)
    title: str = ""
    device: str = "pc"
    priority: int = 5
    agent: str = ""
    conversation_id: Optional[str] = None
    dry_run: bool = False
    wait: bool = False
    max_steps: int = 12


class PriorityBody(BaseModel):
    priority: int = Field(..., ge=1, le=10)


@router.get("", summary="List tasks (the Task Control Center table)")
async def list_tasks(status: str = "", agent: str = "", device: str = "", limit: int = 50,
                     active_only: bool = False) -> Dict[str, Any]:
    tasks = task_store.active() if active_only else task_store.all()
    if status:
        wanted = {s.strip().upper() for s in status.split(",")}
        tasks = [t for t in tasks if t.status.value.upper() in wanted]
    if agent:
        tasks = [t for t in tasks if t.agent.value == agent.lower()]
    if device:
        tasks = [t for t in tasks if t.device.value == device.lower()]
    tasks = sorted(tasks, key=lambda t: (-t.priority, t.created_at), reverse=False)
    tasks = sorted(tasks, key=lambda t: -t.priority)[:max(1, min(limit, 500))]
    return {"ok": True, "count": len(tasks), "counts": task_store.counts(),
            "tasks": [t.model_dump(mode="json") for t in tasks]}


@router.get("/stats", summary="Task statistics for the dashboard tiles")
async def task_stats() -> Dict[str, Any]:
    tasks = task_store.all()
    counts = task_store.counts()
    finished = [t for t in tasks if t.finished_at and t.started_at]
    durations = [(t.finished_at - t.started_at).total_seconds() for t in finished]
    failed = [t for t in tasks if t.status == TaskStatus.FAILED]
    return {
        "ok": True, "total": len(tasks), "counts": counts,
        "active": len(task_store.active()),
        "completed": counts.get("COMPLETED", 0), "failed": counts.get("FAILED", 0),
        "waiting_confirmation": counts.get("WAITING", 0),
        "success_rate": round(100 * counts.get("COMPLETED", 0) /
                              max(1, counts.get("COMPLETED", 0) + counts.get("FAILED", 0)), 1),
        "avg_seconds": round(sum(durations) / len(durations), 2) if durations else 0,
        "last_failures": [{"id": t.id, "title": t.title, "error": t.error}
                          for t in failed[-5:]],
    }


@router.post("", summary="Create and run a task from an instruction")
async def create_task(body: TaskCreate) -> Dict[str, Any]:
    """
    Runs the instruction through the full pipeline (planner → brains → tools →
    verification). With ``wait=false`` it returns immediately and you follow the
    task through ``/tasks/{id}`` or the event WebSocket.
    """
    from backend.app.core.orchestrator import orchestrator

    if body.wait:
        result = await orchestrator.handle_text(
            body.request, conversation_id=body.conversation_id, dry_run=body.dry_run,
            max_steps=body.max_steps, device=body.device, channel="task",
        )
        payload = result.to_chat_response().model_dump(mode="json")
        payload["ok"] = result.ok
        return payload

    task_id_holder: Dict[str, str] = {}

    async def run() -> None:
        try:
            result = await orchestrator.handle_text(
                body.request, conversation_id=body.conversation_id, dry_run=body.dry_run,
                max_steps=body.max_steps, device=body.device, channel="task",
            )
            if result.task:
                task_id_holder["id"] = result.task.id
        except Exception as exc:  # pragma: no cover
            log.exception("background task failed")
            task_id_holder["error"] = str(exc)[:300]

    handle = asyncio.create_task(run())
    # give the planner a moment so we can return the real task id
    for _ in range(40):
        if task_id_holder:
            break
        newest = task_store.all()
        if newest:
            candidate = max(newest, key=lambda t: t.created_at)
            if candidate.request == body.request:
                task_id_holder["id"] = candidate.id
                break
        await asyncio.sleep(0.05)
    return {"ok": True, "started": True, "task_id": task_id_holder.get("id"),
            "background": True, "running": not handle.done(),
            "note": "follow progress on GET /tasks/{id} or the /ws/events stream"}


@router.get("/{task_id}", summary="Full task detail with steps")
async def get_task(task_id: str) -> Dict[str, Any]:
    task = task_store.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"no task with id {task_id}")
    data = task.model_dump(mode="json")
    data["paused"] = task_store.is_paused(task_id)
    data["cancelled"] = task_store.is_cancelled(task_id)
    data["timeline"] = _timeline(task)
    return {"ok": True, **data}


def _timeline(task: Any) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = [{"at": task.created_at.isoformat() if task.created_at else None,
                                   "event": "created", "detail": task.title}]
    if task.started_at:
        rows.append({"at": task.started_at.isoformat(), "event": "started"})
    for step in task.steps:
        rows.append({"at": (step.started_at or task.created_at).isoformat()
                     if (step.started_at or task.created_at) else None,
                     "event": f"step:{step.status.value.lower()}",
                     "detail": step.name, "agent": step.agent.value,
                     "tool": step.tool, "error": step.error})
    if task.finished_at:
        rows.append({"at": task.finished_at.isoformat(),
                     "event": task.status.value.lower(), "detail": task.result or task.error})
    return rows


@router.get("/{task_id}/logs", summary="Step-level logs for one task")
async def task_logs(task_id: str) -> Dict[str, Any]:
    task = task_store.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"no task with id {task_id}")
    steps = []
    for s in task.steps:
        steps.append({"id": s.id, "index": s.index, "name": s.name, "agent": s.agent.value,
                      "device": s.device.value, "tool": s.tool, "params": s.params,
                      "status": s.status.value, "risk": s.risk.value,
                      "requires_confirmation": s.requires_confirmation,
                      "started_at": s.started_at.isoformat() if s.started_at else None,
                      "finished_at": s.finished_at.isoformat() if s.finished_at else None,
                      "duration_ms": int((s.finished_at - s.started_at).total_seconds() * 1000)
                      if s.started_at and s.finished_at else None,
                      "output": s.output, "error": s.error})
    return {"ok": True, "task_id": task_id, "status": task.status.value,
            "progress": task.progress, "current_action": task.current_action,
            "steps": steps, "result": task.result, "error": task.error}


@router.post("/{task_id}/pause", summary="Pause a running task")
async def pause_task(task_id: str) -> Dict[str, Any]:
    ok = await task_store.pause(task_id)
    if not ok:
        raise HTTPException(status_code=409, detail="task cannot be paused (not running?)")
    return {"ok": True, "task_id": task_id, "status": "PAUSED"}


@router.post("/{task_id}/resume", summary="Resume a paused task")
async def resume_task(task_id: str) -> Dict[str, Any]:
    ok = await task_store.resume(task_id)
    if not ok:
        raise HTTPException(status_code=409, detail="task was not paused")
    return {"ok": True, "task_id": task_id, "status": "RUNNING"}


@router.post("/{task_id}/cancel", summary="Cancel a task")
async def cancel_task(task_id: str) -> Dict[str, Any]:
    ok = await task_store.cancel(task_id)
    if not ok:
        raise HTTPException(status_code=409, detail="task cannot be cancelled (already finished?)")
    return {"ok": True, "task_id": task_id, "status": "CANCELLED"}


@router.post("/{task_id}/restart", summary="Restart a task from the beginning")
async def restart_task(task_id: str) -> Dict[str, Any]:
    fresh = await task_store.restart(task_id)
    if fresh is None:
        raise HTTPException(status_code=404, detail=f"no task with id {task_id}")
    from backend.app.core.orchestrator import orchestrator

    asyncio.create_task(orchestrator.execute_task(fresh))
    return {"ok": True, "task": fresh.model_dump(mode="json"), "restarted": True}


@router.post("/{task_id}/priority", summary="Change a task's priority")
async def prioritise_task(task_id: str, body: PriorityBody) -> Dict[str, Any]:
    ok = await task_store.reprioritise(task_id, body.priority)
    if not ok:
        raise HTTPException(status_code=404, detail=f"no task with id {task_id}")
    task = task_store.get(task_id)
    return {"ok": True, "task_id": task_id, "priority": task.priority if task else body.priority}


@router.delete("/{task_id}", summary="Remove a finished task from the store")
async def delete_task(task_id: str) -> Dict[str, Any]:
    task = task_store.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"no task with id {task_id}")
    if task.status in (TaskStatus.RUNNING, TaskStatus.QUEUED):
        raise HTTPException(status_code=409, detail="cancel the task before removing it")
    removed = task_store.discard(task_id)
    return {"ok": removed, "task_id": task_id}


@router.post("/purge", summary="Purge old finished tasks")
async def purge_tasks(keep_days: int = Query(30, ge=1, le=365)) -> Dict[str, Any]:
    n = await task_store.purge(keep_days=int(keep_days))
    return {"ok": True, "purged": n, "keep_days": keep_days}
