"""
backend.app.api.v1.security
===========================

The SECURITY dashboard API: permissions, risk engine, confirmations, audit log
and the full security posture report.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token
from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.security.audit import audit_trail
from backend.app.security.confirmation_engine import confirmation_engine
from backend.app.security.permissions import BY_NAME, CAPABILITIES, permission_engine
from backend.app.security.risk_engine import risk_engine

log = get_logger("api.security")

router = APIRouter(prefix="/security", tags=["security"], dependencies=[Depends(check_token)])


class PermissionBody(BaseModel):
    capability: str
    granted: bool
    requires_confirmation: Optional[bool] = None
    note: str = ""


class GroupBody(BaseModel):
    prefix: str
    granted: bool


class RiskBody(BaseModel):
    capability: str = ""
    action: str = ""
    target: str = ""
    params: Dict[str, Any] = Field(default_factory=dict)


@router.get("/report", summary="Full security posture report")
async def report() -> Dict[str, Any]:
    from backend.app.tools.registry import registry

    tools = registry.all()
    caps = permission_engine.state()
    granted = [c for c in caps if c["granted"]]
    usable_tools = [t.name for t in tools
                    if t.is_available() and permission_engine.granted(t.capability)]
    audit = await audit_trail.stats()
    groups = permission_engine.summary()
    return {
        "ok": True,
        "risk_mode": settings.security_risk_mode,
        "audit_enabled": settings.security_audit_enabled,
        "confirm_medium": settings.security_require_confirmation_medium,
        "confirmation_timeout_seconds": settings.security_confirmation_timeout_seconds,
        "sam_mode": settings.sam_mode,
        "privacy": {
            "cloud_ai": settings.privacy_cloud_ai,
            "external_web": settings.privacy_external_web,
            "phone_sync": settings.privacy_phone_sync,
            "telemetry": settings.privacy_telemetry,
            "local_models": settings.privacy_local_models,
            "local_memory": settings.privacy_local_memory,
        },
        "capabilities": {"total": len(caps), "granted": len(granted),
                         "denied": len(caps) - len(granted)},
        "groups": groups,
        "tools": {"total": len(tools), "usable": len(usable_tools),
                  "unusable_examples": [t.name for t in tools
                                        if t.is_available()
                                        and not permission_engine.granted(t.capability)][:12]},
        "audit": audit,
        "pending_confirmations": confirmation_engine.pending(),
        "confirmation_rules": len(getattr(confirmation_engine, "_rules", {})),
        "dangerous_blocked": _blocked_patterns(),
        "allowed_file_roots": [str(p) for p in settings.allowed_roots],
        "denied_file_patterns": settings.denied_patterns,
    }


def _blocked_patterns() -> List[str]:
    try:
        from backend.app.tools.terminal_tools import BLOCKED_PATTERNS

        return [p.pattern if hasattr(p, "pattern") else str(p) for p in BLOCKED_PATTERNS]
    except Exception:
        return []


@router.get("/permissions", summary="Every capability and its grant state")
async def permissions(category: str = "", search: str = "", group: str = "") -> Dict[str, Any]:
    caps = permission_engine.state()
    if category:
        caps = [c for c in caps if c["category"].lower() == category.lower()]
    if group:
        caps = [c for c in caps if c["capability"].startswith(group)]
    if search:
        s = search.lower()
        caps = [c for c in caps if s in c["capability"].lower() or s in c["description"].lower()]
    return {"ok": True, "count": len(caps), "capabilities": caps,
            "categories": sorted({c.category.value for c in CAPABILITIES}),
            "groups": permission_engine.summary()}


@router.post("/permissions", summary="Grant or revoke one capability")
async def set_permission(body: PermissionBody) -> Dict[str, Any]:
    if body.capability not in BY_NAME:
        near = [c for c in BY_NAME if body.capability.lower() in c][:10]
        raise HTTPException(status_code=404,
                            detail={"error": f"unknown capability '{body.capability}'",
                                    "did_you_mean": near})
    result = await permission_engine.set_grant(
        body.capability, granted=body.granted,
        requires_confirmation=body.requires_confirmation, note=body.note or None,
    )
    audit_trail.record(action="security.set_permission", target=body.capability,
                       result="ok", risk="HIGH", confirmation="approved", agent="security",
                       detail={"granted": body.granted})
    log.warning("permission changed: %s -> granted=%s", body.capability, body.granted)
    return {"ok": True, **result}


@router.post("/permissions/group", summary="Grant or revoke a whole group (pc.*, phone.*, …)")
async def set_permission_group(body: GroupBody) -> Dict[str, Any]:
    n = await permission_engine.grant_group(body.prefix, body.granted)
    audit_trail.record(action="security.set_permission_group", target=body.prefix,
                       result="ok", risk="HIGH", confirmation="approved", agent="security",
                       detail={"granted": body.granted, "count": n})
    return {"ok": True, "prefix": body.prefix, "granted": body.granted, "changed": n}


@router.post("/permissions/reset", summary="Reset every permission to its default")
async def reset_permissions() -> Dict[str, Any]:
    n = await permission_engine.reset()
    audit_trail.record(action="security.reset_permissions", target="all", result="ok",
                       risk="HIGH", confirmation="approved", agent="security",
                       detail={"changed": n})
    return {"ok": True, "reset": n, "groups": permission_engine.summary()}


@router.post("/risk", summary="Score a proposed action without running it")
async def score_risk(body: RiskBody) -> Dict[str, Any]:
    assessment = risk_engine.assess(capability=body.capability, action=body.action,
                                    target=body.target, params=body.params)
    permission = permission_engine.check(body.capability) if body.capability in BY_NAME else None
    return {"ok": True, "assessment": assessment.to_dict(),
            "explanation": risk_engine.explain(assessment),
            "permission": permission.to_dict() if permission else None,
            "blocked": risk_engine.is_blocked(assessment.level),
            "requires_confirmation": assessment.requires_confirmation,
            "confirmation_style": assessment.confirmation_style,
            "reversible": assessment.reversible}


@router.get("/audit", summary="Query the action history")
async def audit(limit: int = 100, offset: int = 0, device: str = "", agent: str = "",
                result: str = "", risk: str = "", since_hours: Optional[int] = None,
                search: str = "") -> Dict[str, Any]:
    data = await audit_trail.query(
        limit=min(int(limit), 1000), offset=int(offset), device=device or None,
        agent=agent or None, result=result or None, risk=risk or None,
        since_hours=since_hours, search=search or None,
    )
    data["ok"] = True
    data["stats"] = await audit_trail.stats()
    data["recent_in_memory"] = audit_trail.recent(20)
    return data


@router.delete("/audit", summary="Clear the audit log (itself audited)")
async def clear_audit(older_than_days: Optional[int] = None) -> Dict[str, Any]:
    n = await audit_trail.clear(older_than_days=older_than_days)
    audit_trail.record(action="security.clear_audit", target="audit-log", result="ok",
                       risk="CRITICAL", confirmation="approved", agent="security",
                       detail={"cleared": n, "older_than_days": older_than_days})
    return {"ok": True, "cleared": n,
            "scope": "all" if older_than_days is None else f"older than {older_than_days} days"}


@router.get("/confirmations", summary="Pending and recent confirmations")
async def confirmations(limit: int = 30) -> Dict[str, Any]:
    return {"ok": True, "pending": confirmation_engine.pending(),
            "history": confirmation_engine.history(int(limit))}


@router.delete("/confirmations/rules", summary="Forget every 'always allow' rule")
async def clear_rules() -> Dict[str, Any]:
    n = confirmation_engine.clear_rules()
    return {"ok": True, "cleared": n,
            "note": "SAM will ask again for actions you previously chose to always allow"}
