"""
backend.app.api.v1.agents
=========================

The AGENTS dashboard API: the 17 brains, their status, tools, configuration,
statistics and last error.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from backend.app.agents.base import agents
from backend.app.api.deps import check_token
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import registry

log = get_logger("api.agents")

router = APIRouter(prefix="/agents", tags=["agents"], dependencies=[Depends(check_token)])


class AgentConfig(BaseModel):
    enabled: Optional[bool] = None
    model_role: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    auto_confirm_low_risk: Optional[bool] = None


@router.get("", summary="All 17 brains with live status")
async def list_agents() -> Dict[str, Any]:
    snapshot = agents.snapshot()
    return {"ok": True, "count": len(snapshot), "summary": agents.summary(),
            "agents": snapshot}


@router.get("/tools", summary="Every registered tool, grouped by agent")
async def list_tools(agent: str = "", available_only: bool = False) -> Dict[str, Any]:
    tools = registry.all()
    if agent:
        tools = [t for t in tools if t.agent == agent.lower()]
    if available_only:
        tools = [t for t in tools if t.is_available()]
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for t in tools:
        grouped.setdefault(t.agent, []).append(t.to_dict())
    return {"ok": True, "count": len(tools), "stats": registry.stats(), "by_agent": grouped}


@router.get("/tools/{tool_name:path}", summary="Inspect one tool")
async def get_tool(tool_name: str) -> Dict[str, Any]:
    tool = registry.get(tool_name)
    if tool is None:
        raise HTTPException(status_code=404, detail=f"unknown tool: {tool_name}")
    from backend.app.security.permissions import BY_NAME, permission_engine

    data = tool.to_dict()
    data["permission"] = (permission_engine.check(tool.capability).to_dict()
                          if tool.capability in BY_NAME else None)
    data["capability_description"] = (BY_NAME[tool.capability].description
                                      if tool.capability in BY_NAME else "")
    return {"ok": True, **data}


@router.get("/{agent_name}", summary="One brain in detail")
async def get_agent(agent_name: str) -> Dict[str, Any]:
    agent = agents.get(agent_name.lower())
    if agent is None:
        raise HTTPException(status_code=404,
                            detail=f"unknown agent '{agent_name}'. Known: {', '.join(agents.names())}")
    data = agent.to_dict()
    data["tools_detail"] = [registry.get(t).to_dict() for t in agent.spec.tools if registry.get(t)]
    data["system_prompt"] = agent.spec.system_prompt
    return {"ok": True, **data}


@router.patch("/{agent_name}", summary="Configure or enable/disable a brain")
async def configure_agent(agent_name: str, body: AgentConfig) -> Dict[str, Any]:
    agent = agents.get(agent_name.lower())
    if agent is None:
        raise HTTPException(status_code=404, detail=f"unknown agent '{agent_name}'")
    values = {k: v for k, v in body.model_dump().items() if v is not None}
    if not values:
        raise HTTPException(status_code=400, detail="nothing to change")
    if "temperature" in values:
        values["temperature"] = max(0.0, min(2.0, float(values["temperature"])))
    if "max_tokens" in values:
        values["max_tokens"] = max(64, min(32000, int(values["max_tokens"])))
    data = agent.set_config(**values)
    log.info("agent %s configured: %s", agent_name, values)
    return {"ok": True, "agent": data}


@router.post("/{agent_name}/test", summary="Run a one-line self-test for a brain")
async def test_agent(agent_name: str, prompt: str = "") -> Dict[str, Any]:
    """Proves a brain is wired up: it must reach a model and return something."""
    agent = agents.get(agent_name.lower())
    if agent is None:
        raise HTTPException(status_code=404, detail=f"unknown agent '{agent_name}'")
    from backend.app.models.router import router as model_router

    text = prompt or f"Reply with the single word READY and nothing else."
    res = await model_router.ask(f"{agent.spec.system_prompt}\n\n{text}",
                                role=agent.spec.model_role, temperature=0.0, max_tokens=64)
    return {"ok": res.ok, "agent": agent.name, "role": agent.spec.model_role,
            "model": res.model, "provider": res.provider, "reply": res.text[:300],
            "error": res.error, "latency_ms": res.latency_ms,
            "tools_available": len([t for t in agent.spec.tools
                                    if registry.get(t) and registry.get(t).is_available()]),
            "tools_total": len(agent.spec.tools)}
