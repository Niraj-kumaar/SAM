"""
backend.app.api.v1.creative
===========================

The CREATIVE workspace API: image generation and editing, social media packs,
video scripts, and document creation (Markdown in → DOCX / PPTX / XLSX / PDF /
HTML out).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.tools.creative_tools import ASPECTS, OUT_DIR

log = get_logger("api.creative")

router = APIRouter(prefix="/creative", tags=["creative"], dependencies=[Depends(check_token)])


class PromptBody(BaseModel):
    request: str = Field(..., min_length=2)
    style: str = ""
    aspect: str = "square"
    count: int = Field(3, ge=1, le=6)


class ImageBody(BaseModel):
    prompt: str = ""
    negative: str = ""
    aspect: str = "square"
    style: str = ""
    count: int = Field(1, ge=1, le=4)
    pack: Optional[Dict[str, Any]] = None


class EditBody(BaseModel):
    path: str = Field(..., min_length=1)
    action: str = "resize"        # resize | crop | rotate | flip | watermark | convert | thumbnail
    width: Optional[int] = None
    height: Optional[int] = None
    degrees: int = 0
    quality: int = Field(88, ge=10, le=100)
    text: str = ""
    output: str = ""


class SocialBody(BaseModel):
    topic: str = Field(..., min_length=2)
    platform: str = "instagram"
    tone: str = "professional"


class ScriptBody(BaseModel):
    topic: str = Field(..., min_length=2)
    duration_seconds: int = Field(60, ge=10, le=3600)
    style: str = ""


class DocumentBody(BaseModel):
    request: str = Field(..., min_length=3)
    format: str = "docx"          # docx | pptx | xlsx | pdf | html | md | txt | csv
    sections: int = Field(6, ge=1, le=20)
    word_target: int = Field(900, ge=50, le=20000)
    tone: str = "professional"
    outline: Optional[Dict[str, Any]] = None
    render: bool = True
    title: str = ""
    output: str = ""


class RenderBody(BaseModel):
    format: str = "docx"
    markdown: str = Field(..., min_length=1)
    title: str = ""
    output: str = ""


@router.get("/status", summary="Which image backends are configured")
async def status() -> Dict[str, Any]:
    return {
        "ok": True,
        "aspects": {k: {"width": v[0], "height": v[1]} for k, v in ASPECTS.items()},
        "image_provider": settings.image_provider,
        "backends": {
            "openai": {"available": bool(settings.openai_api_key), "model": "gpt-image-1"},
            "stability": {"available": bool(settings.stability_api_key),
                          "model": "stable-image-core"},
            "local_sd": {"available": True, "urls": [settings.stable_diffusion_url,
                                                     settings.comfyui_url],
                         "note": "SAM probes these; available only if a server is running"},
        },
        "offline_fallback": "With no backend, SAM returns a full prompt pack plus a real "
                            "SVG/PNG placeholder poster, so the workspace is never a dead end.",
        "workspace": str(OUT_DIR),
        "social_posting": "disabled — SAM never posts on your behalf (no social.post grant)",
    }


@router.post("/prompt", summary="Build a production prompt pack")
async def prompt(body: PromptBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="creative", user_text=body.request)
    return unwrap(await tool_call("creative.prompt", ctx, request=body.request,
                                  style=body.style, aspect=body.aspect, count=body.count))


@router.post("/image", summary="Generate an image")
async def image(body: ImageBody) -> Dict[str, Any]:
    if not body.prompt and not body.pack:
        raise HTTPException(status_code=400, detail="give a prompt (or a pack from /prompt)")
    ctx = tool_context(None, agent="creative", user_text=body.prompt[:200])
    result = unwrap(await tool_call("creative.image_generate", ctx, prompt=body.prompt,
                                    negative=body.negative, aspect=body.aspect,
                                    style=body.style, count=body.count, pack=body.pack))
    if result.get("path"):
        result["url"] = _artifact_url(result["path"])
    for item in result.get("images") or []:
        if isinstance(item, dict) and item.get("path"):
            item["url"] = _artifact_url(item["path"])
    return result


def _artifact_url(path: str) -> str:
    from pathlib import Path

    p = Path(path)
    return f"/api/v1/files/artifact/creative/{p.parent.name}/{p.name}" if p.parent.name != "creative" \
        else f"/api/v1/files/artifact/creative/{p.name}"


@router.post("/image/edit", summary="Edit an existing image")
async def edit_image(body: EditBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="creative", user_text=f"{body.action} {body.path}")
    result = unwrap(await tool_call("creative.image_edit", ctx, path=body.path,
                                    action=body.action, width=body.width, height=body.height,
                                    degrees=body.degrees, quality=body.quality,
                                    text=body.text, output=body.output))
    if result.get("path"):
        result["url"] = _artifact_url(result["path"])
    return result


@router.post("/social", summary="Build a social media content pack")
async def social(body: SocialBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="creative", user_text=body.topic)
    return unwrap(await tool_call("creative.social_pack", ctx, topic=body.topic,
                                  platform=body.platform, tone=body.tone))


@router.post("/script", summary="Write a video / reel script")
async def script(body: ScriptBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="creative", user_text=body.topic)
    return unwrap(await tool_call("creative.script", ctx, topic=body.topic,
                                  duration_seconds=body.duration_seconds, style=body.style))


@router.get("/workspace", summary="List the Creative workspace")
async def workspace(kind: str = "", limit: int = 60, search: str = "") -> Dict[str, Any]:
    ctx = tool_context(None, agent="creative")
    result = unwrap(await tool_call("creative.list", ctx, kind=kind, limit=limit, search=search))
    for item in result.get("items") or []:
        if item.get("is_image"):
            item["url"] = _artifact_url(item["path"])
    return result


@router.post("/save", summary="Save a brief, script or pack into the workspace")
async def save(content: str = "", title: str = "", kind: str = "brief",
               format: str = "md") -> Dict[str, Any]:
    if not content:
        raise HTTPException(status_code=400, detail="nothing to save")
    ctx = tool_context(None, agent="creative", user_text=title or content[:120])
    return unwrap(await tool_call("creative.save", ctx, content=content, title=title,
                                  kind=kind, format=format))


# ---------------------------------------------------------------------------
# documents
# ---------------------------------------------------------------------------
@router.post("/documents", summary="Create a document end to end (outline → write → render)")
async def document(body: DocumentBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="writing", user_text=body.request)
    outline = body.outline or unwrap(await tool_call(
        "documents.outline", ctx, request=body.request, format=body.format,
        sections=body.sections))
    if not outline.get("ok", True):
        return {"ok": False, "stage": "outline", "error": outline.get("error")}

    written = unwrap(await tool_call("documents.write", ctx, request=body.request,
                                     outline=outline, word_target=body.word_target,
                                     tone=body.tone))
    if not written.get("ok", True):
        return {"ok": False, "stage": "write", "error": written.get("error"),
                "outline": outline}

    markdown = written.get("markdown") or written.get("content") or ""
    payload: Dict[str, Any] = {"ok": True, "outline": outline, "written": written,
                               "markdown": markdown,
                               "word_count": len(markdown.split())}
    if body.render and markdown:
        rendered = unwrap(await tool_call("documents.render", ctx, format=body.format,
                                          markdown=markdown, title=body.title or
                                          str(outline.get("title") or "Document"),
                                          output=body.output))
        payload["rendered"] = rendered
        payload["ok"] = bool(rendered.get("ok"))
        if rendered.get("path"):
            payload["path"] = rendered["path"]
            from pathlib import Path as _P

            payload["url"] = f"/api/v1/files/artifact/documents/{_P(rendered['path']).name}"
            verify = unwrap(await tool_call("documents.verify", ctx, path=rendered["path"]))
            payload["verify"] = verify
    return payload


@router.post("/documents/outline", summary="Outline only")
async def outline(body: DocumentBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="writing", user_text=body.request)
    return unwrap(await tool_call("documents.outline", ctx, request=body.request,
                                  format=body.format, sections=body.sections))


@router.post("/documents/write", summary="Write Markdown only (no file)")
async def write_document(body: DocumentBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="writing", user_text=body.request)
    return unwrap(await tool_call("documents.write", ctx, request=body.request,
                                  outline=body.outline, word_target=body.word_target,
                                  tone=body.tone))


@router.post("/documents/render", summary="Render Markdown into a real file")
async def render_document(body: RenderBody) -> Dict[str, Any]:
    ctx = tool_context(None, agent="writing", user_text=body.title or body.format)
    result = unwrap(await tool_call("documents.render", ctx, format=body.format,
                                    markdown=body.markdown, title=body.title,
                                    output=body.output))
    if result.get("path"):
        from pathlib import Path

        result["url"] = f"/api/v1/files/artifact/documents/{Path(result['path']).name}"
        result["verify"] = unwrap(await tool_call("documents.verify", ctx,
                                                  path=result["path"]))
    return result


@router.get("/documents/formats", summary="Supported document formats and their engines")
async def formats() -> Dict[str, Any]:
    from backend.app.coding.documents import engine_status

    data = engine_status()
    data["ok"] = True
    return data
