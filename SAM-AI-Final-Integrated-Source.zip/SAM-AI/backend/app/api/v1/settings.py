"""
backend.app.api.v1.settings
===========================

The SETTINGS page API — modes, privacy toggles, model configuration, paths and
the ``.env`` writer.

SAM will edit ``.env`` **only** through ``POST /settings/env``, which shows the
user exactly which lines would change, keeps a timestamped backup, never logs a
secret value, and never touches a line it was not asked about.
"""

from __future__ import annotations

import re
import shutil
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token
from backend.app.config import PROJECT_ROOT, settings
from backend.app.core.logging_config import get_logger

log = get_logger("api.settings")

router = APIRouter(prefix="/settings", tags=["settings"], dependencies=[Depends(check_token)])

ENV_PATH = PROJECT_ROOT / ".env"
ENV_EXAMPLE = PROJECT_ROOT / ".env.example"
SECRET_KEYS = ("key", "secret", "token", "password")

# settings the UI may change at runtime without a restart
RUNTIME_EDITABLE = {
    "sam_mode", "sam_log_level", "sam_port",
    "privacy_cloud_ai", "privacy_external_web", "privacy_phone_sync", "privacy_telemetry",
    "privacy_local_models", "privacy_local_memory",
    "model_auto_routing", "voice_enabled", "voice_wake_word_enabled", "voice_tts_speed",
    "pc_control_enabled", "pc_screen_capture_enabled", "pc_power_control_enabled",
    "pc_terminal_enabled", "browser_enabled", "browser_headless", "phone_enabled",
    "files_enabled", "files_index_enabled", "security_risk_mode", "security_audit_enabled",
    "scheduler_enabled", "proactive_level", "proactive_check_interval_seconds",
    "email_enabled", "image_provider",
}


class EnvWrite(BaseModel):
    values: Dict[str, str] = Field(default_factory=dict)
    restart_required: bool = True


class ModeBody(BaseModel):
    mode: Optional[str] = None
    privacy: Optional[Dict[str, bool]] = None
    proactive_level: Optional[str] = None
    risk_mode: Optional[str] = None


@router.get("", summary="The full (redacted) configuration")
async def get_settings() -> Dict[str, Any]:
    data = settings.public_dict()
    data["ok"] = True
    data["paths"] = {
        "project_root": str(PROJECT_ROOT),
        "data_dir": str(settings.sam_data_dir),
        "database": str(settings.db_path),
        "env_file": str(ENV_PATH),
        "env_exists": ENV_PATH.exists(),
        "logs": str(settings.sam_data_dir / "logs"),
        "browser_profile": str(settings.browser_user_data_dir),
        "creative": str(settings.sam_data_dir / "creative"),
        "documents": str(settings.sam_data_dir / "documents"),
        "backups": str(settings.sam_data_dir / "backups"),
        "voices": str(settings.sam_data_dir / "voices"),
    }
    data["allowed_file_roots"] = [str(p) for p in settings.allowed_roots]
    data["denied_file_patterns"] = settings.denied_patterns
    data["runtime_editable"] = sorted(RUNTIME_EDITABLE)
    return data


@router.get("/env", summary="Read .env with every secret value masked")
async def read_env() -> Dict[str, Any]:
    if not ENV_PATH.exists():
        return {"ok": True, "exists": False, "path": str(ENV_PATH), "lines": [],
                "hint": "copy .env.example to .env and fill in your keys"}
    lines: List[Dict[str, Any]] = []
    for raw in ENV_PATH.read_text(encoding="utf-8").splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            lines.append({"raw": raw, "comment": True})
            continue
        m = re.match(r"^([A-Z0-9_]+)\s*=\s*(.*)$", stripped)
        if not m:
            lines.append({"raw": raw, "unknown": True})
            continue
        key, value = m.group(1), m.group(2)
        secret = any(s in key.lower() for s in SECRET_KEYS)
        lines.append({
            "key": key, "set": bool(value.strip()),
            "value": ("SET" if value.strip() else "") if secret else value,
            "secret": secret, "raw": raw,
        })
    return {"ok": True, "exists": True, "path": str(ENV_PATH), "count": len(lines),
            "lines": lines,
            "example_keys": _example_keys()}


def _example_keys() -> List[str]:
    if not ENV_EXAMPLE.exists():
        return []
    return sorted({m.group(1) for m in
                   re.finditer(r"^([A-Z0-9_]+)\s*=", ENV_EXAMPLE.read_text(encoding="utf-8"),
                               re.M)})


@router.post("/env/preview", summary="Show exactly what a .env write would change")
async def preview_env(body: EnvWrite) -> Dict[str, Any]:
    changes = _plan_changes(body.values)
    return {"ok": True, "changes": changes, "count": len(changes),
            "path": str(ENV_PATH),
            "warning": "Values containing secrets are never echoed back or logged."}


@router.post("/env", summary="Write values into .env (with a timestamped backup)")
async def write_env(body: EnvWrite) -> Dict[str, Any]:
    if not body.values:
        raise HTTPException(status_code=400, detail="no values given")
    unknown = [k for k in body.values if not re.fullmatch(r"[A-Z0-9_]+", k)]
    if unknown:
        raise HTTPException(status_code=400,
                            detail=f"invalid env keys: {', '.join(unknown)}")

    backup = None
    if ENV_PATH.exists():
        backup = ENV_PATH.with_suffix(f".env.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(ENV_PATH, backup)

    changes = _plan_changes(body.values)
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else \
        _example_lines()
    applied = _apply_changes(lines, body.values)
    header = (f"# SAM configuration\n"
              f"# Edited by SAM at {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
              f"# Secrets stay in this file only — never committed (see .gitignore)\n")
    ENV_PATH.write_text(header + "\n".join(applied) + "\n", encoding="utf-8")

    # apply the values that are safe to change without a restart
    restarted = False
    if not body.restart_required:
        restarted = _apply_runtime(body.values)

    log.warning("wrote %d value(s) to .env (backup: %s)", len(changes), backup)
    return {"ok": True, "written": len(changes), "changes": changes, "path": str(ENV_PATH),
            "backup": str(backup) if backup else None,
            "applied_without_restart": restarted,
            "restart_required": body.restart_required and not restarted,
            "restart_hint": "Restart SAM (start-sam.bat / start-sam.sh) for provider keys and "
                            "model mappings to take effect."}


def _example_lines() -> List[str]:
    if ENV_EXAMPLE.exists():
        return ENV_EXAMPLE.read_text(encoding="utf-8").splitlines()
    return []


def _plan_changes(values: Dict[str, str]) -> List[Dict[str, Any]]:
    current = {}
    if ENV_PATH.exists():
        for m in re.finditer(r"^([A-Z0-9_]+)\s*=\s*(.*)$",
                             ENV_PATH.read_text(encoding="utf-8"), re.M):
            current[m.group(1)] = m.group(2)
    out: List[Dict[str, Any]] = []
    for key, value in values.items():
        secret = any(s in key.lower() for s in SECRET_KEYS)
        old = current.get(key)
        out.append({
            "key": key, "action": "update" if key in current else "add",
            "old": ("SET" if (old or "").strip() else "(empty)") if secret else old,
            "new": ("SET" if str(value).strip() else "(empty)") if secret else str(value),
            "changed": (old or "") != str(value),
        })
    return out


def _apply_changes(lines: List[str], values: Dict[str, str]) -> List[str]:
    out: List[str] = []
    seen = set()
    for raw in lines:
        m = re.match(r"^\s*#?\s*([A-Z0-9_]+)\s*=\s*(.*)$", raw)
        if m and m.group(1) in values:
            key = m.group(1)
            out.append(f"{key}={values[key]}")
            seen.add(key)
        else:
            out.append(raw)
    for key, value in values.items():
        if key not in seen:
            out.append(f"{key}={value}")
    return out


def _apply_runtime(values: Dict[str, Any]) -> bool:
    """Set the values that SAM can pick up without a restart. Returns True if any applied."""
    applied = False
    for key, raw in values.items():
        field = key.lower()
        if field not in RUNTIME_EDITABLE or not hasattr(settings, field):
            continue
        current = getattr(settings, field)
        try:
            if isinstance(current, bool):
                new = str(raw).strip().lower() in ("1", "true", "yes", "on")
            elif isinstance(current, int):
                new = int(raw)
            elif isinstance(current, float):
                new = float(raw)
            else:
                new = str(raw)
        except (TypeError, ValueError):
            continue
        object.__setattr__(settings, field, new)
        applied = True
        log.info("runtime setting %s -> %s", field, "SET" if any(s in field for s in SECRET_KEYS)
                 else new)
    return applied


@router.patch("/mode", summary="Switch SAM mode / privacy toggles / risk mode at runtime")
async def set_mode(body: ModeBody) -> Dict[str, Any]:
    applied: Dict[str, Any] = {}
    if body.mode:
        if body.mode not in ("online", "local", "hybrid"):
            raise HTTPException(status_code=400,
                                detail="mode must be online, local or hybrid")
        object.__setattr__(settings, "sam_mode", body.mode)
        applied["sam_mode"] = body.mode
    if body.proactive_level:
        if body.proactive_level not in ("off", "important_only", "normal", "proactive"):
            raise HTTPException(status_code=400,
                                detail="proactive_level must be off, important_only, normal "
                                       "or proactive")
        object.__setattr__(settings, "proactive_level", body.proactive_level)
        applied["proactive_level"] = body.proactive_level
    if body.risk_mode:
        if body.risk_mode not in ("strict", "balanced", "permissive"):
            raise HTTPException(status_code=400,
                                detail="risk_mode must be strict, balanced or permissive")
        object.__setattr__(settings, "security_risk_mode", body.risk_mode)
        applied["security_risk_mode"] = body.risk_mode
    if body.privacy:
        for key, value in body.privacy.items():
            field = f"privacy_{key}" if not key.startswith("privacy_") else key
            if hasattr(settings, field) and isinstance(getattr(settings, field), bool):
                object.__setattr__(settings, field, bool(value))
                applied[field] = bool(value)
            else:
                applied[f"ignored:{key}"] = "not a privacy toggle"

    # the router must re-plan now that cloud/local rules changed
    from backend.app.models.router import router as model_router

    await model_router.refresh()
    log.warning("settings changed at runtime: %s", applied)
    return {"ok": True, "applied": applied,
            "mode": settings.sam_mode,
            "privacy": {k: getattr(settings, k) for k in
                        ("privacy_cloud_ai", "privacy_external_web", "privacy_phone_sync",
                         "privacy_telemetry", "privacy_local_models", "privacy_local_memory")},
            "risk_mode": settings.security_risk_mode,
            "proactive_level": settings.proactive_level,
            "cloud_enabled": settings.cloud_enabled, "web_enabled": settings.web_enabled}


@router.get("/requirements", summary="Installed vs required Python packages")
async def requirements() -> Dict[str, Any]:
    import importlib.util

    required = {
        "fastapi": "web API", "uvicorn": "ASGI server", "pydantic": "validation",
        "pydantic-settings": ".env loading", "sqlalchemy": "database", "aiosqlite": "sqlite driver",
        "apscheduler": "scheduling", "httpx": "HTTP client", "websockets": "WS server",
        "psutil": "system state", "PIL": "images (Pillow)", "numpy": "numbers",
        "openai": "OpenAI-compatible providers", "anthropic": "Claude",
    }
    optional = {
        "playwright": "browser control", "edge_tts": "free neural TTS voices",
        "faster_whisper": "offline STT", "vosk": "offline STT (small)",
        "sounddevice": "server-side microphone", "pvporcupine": "accurate wake word",
        "docx": "DOCX output (python-docx)", "pptx": "PPTX output (python-pptx)",
        "openpyxl": "XLSX output", "reportlab": "PDF output", "pypdf": "PDF reading",
        "markdown": "Markdown → HTML", "pandas": "data analysis", "matplotlib": "charts",
        "pytesseract": "OCR", "cv2": "camera capture (opencv-python)",
        "pyautogui": "mouse/keyboard fallback", "pyperclip": "clipboard",
        "pywinauto": "Windows UI Automation", "send2trash": "recycle-bin deletes",
        "mutagen": "audio duration", "yaml": "YAML parsing", "jinja2": "templating",
        "piper": "offline TTS",
    }

    def check(table: Dict[str, str]) -> List[Dict[str, Any]]:
        rows = []
        for module, purpose in table.items():
            try:
                found = importlib.util.find_spec(module) is not None
            except (ImportError, ValueError):
                found = False
            version = ""
            if found:
                try:
                    from importlib.metadata import version as _v

                    pkg = {"docx": "python-docx", "pptx": "python-pptx", "cv2": "opencv-python",
                           "PIL": "Pillow", "yaml": "PyYAML"}.get(module, module)
                    version = _v(pkg)
                except Exception:
                    pass
            rows.append({"module": module, "purpose": purpose, "installed": found,
                         "version": version})
        return rows

    req_rows = check(required)
    opt_rows = check(optional)
    missing_required = [r["module"] for r in req_rows if not r["installed"]]
    missing_optional = [r["module"] for r in opt_rows if not r["installed"]]
    return {
        "ok": True, "required": req_rows, "optional": opt_rows,
        "missing_required": missing_required, "missing_optional": missing_optional,
        "install_all": "pip install -r backend/requirements.txt",
        "install_optional": "pip install playwright edge-tts faster-whisper python-docx "
                            "python-pptx openpyxl reportlab pypdf markdown pandas matplotlib "
                            "pytesseract opencv-python pyautogui pyperclip send2trash mutagen",
        "playwright_note": "after installing playwright run: python -m playwright install chromium",
    }
