"""
backend.app.api.v1.memory
=========================

The MEMORY page API — the user's full control over what SAM remembers:
view, search, add, edit, disable, erase, and clear everything.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context, unwrap
from backend.app.core.logging_config import get_logger
from backend.app.files.semantic_index import semantic_index
from backend.app.memory.store import MEMORY_KINDS, memory_store

log = get_logger("api.memory")

router = APIRouter(prefix="/memory", tags=["memory"], dependencies=[Depends(check_token)])


class MemoryWrite(BaseModel):
    content: str = Field(..., min_length=1)
    kind: str = "long_term"
    key: str = ""
    scope: str = "global"
    tags: List[str] = Field(default_factory=list)
    importance: float = Field(0.6, ge=0.0, le=1.0)


class MemoryUpdate(BaseModel):
    content: Optional[str] = None
    key: Optional[str] = None
    tags: Optional[List[str]] = None
    importance: Optional[float] = Field(None, ge=0.0, le=1.0)
    enabled: Optional[bool] = None
    scope: Optional[str] = None


class MemorySearch(BaseModel):
    query: str = Field(..., min_length=1)
    kind: Optional[str] = None
    scope: Optional[str] = None
    limit: int = Field(10, ge=1, le=100)


@router.get("", summary="List stored memory")
async def list_memory(kind: str = "", scope: str = "", search: str = "", limit: int = 100,
                      offset: int = 0) -> Dict[str, Any]:
    data = await memory_store.list_items(kind=kind or None, scope=scope or None,
                                         search=search, limit=min(limit, 1000), offset=offset)
    data["ok"] = True
    data["kinds"] = list(MEMORY_KINDS)
    data["stats"] = await memory_store.stats()
    from backend.app.config import settings

    data["privacy_local_memory"] = settings.privacy_local_memory
    return data


@router.get("/stats", summary="Memory usage statistics")
async def stats() -> Dict[str, Any]:
    data = await memory_store.stats()
    data["semantic_index"] = await semantic_index.stats()
    data["kinds"] = list(MEMORY_KINDS)
    data["ok"] = True
    return data


@router.post("", summary="Store a memory item")
async def write_memory(body: MemoryWrite) -> Dict[str, Any]:
    if body.kind not in MEMORY_KINDS:
        raise HTTPException(status_code=400,
                            detail=f"unknown kind '{body.kind}'. Known: {', '.join(MEMORY_KINDS)}")
    ctx = tool_context(None, agent="memory", user_text=body.content)
    return unwrap(await tool_call("memory.write", ctx, content=body.content, kind=body.kind,
                                  key=body.key, scope=body.scope, tags=body.tags,
                                  importance=body.importance))


@router.post("/search", summary="Recall memory by meaning")
async def search_memory(body: MemorySearch) -> Dict[str, Any]:
    ctx = tool_context(None, agent="memory", user_text=body.query)
    return unwrap(await tool_call("memory.search", ctx, query=body.query, kind=body.kind,
                                  scope=body.scope, limit=body.limit))


@router.post("/semantic-search", summary="Search indexed file contents by meaning")
async def semantic_search(query: str, limit: int = 10) -> Dict[str, Any]:
    data = await semantic_index.search(query, limit=min(limit, 100))
    data["ok"] = True
    return data


@router.patch("/{item_id}", summary="Edit a memory item")
async def update_memory(item_id: int, body: MemoryUpdate) -> Dict[str, Any]:
    values = {k: v for k, v in body.model_dump().items() if v is not None}
    if not values:
        raise HTTPException(status_code=400, detail="nothing to change")
    updated = await memory_store.update_item(int(item_id), **values)
    if updated is None:
        raise HTTPException(status_code=404, detail=f"no memory item with id {item_id}")
    if isinstance(updated, dict) and updated.get("ok") is False:
        return updated          # e.g. refused because the new content looks like a secret
    return {"ok": True, "item": updated}


@router.post("/{item_id}/toggle", summary="Disable or re-enable a memory item")
async def toggle_memory(item_id: int, enabled: bool = True) -> Dict[str, Any]:
    updated = await memory_store.update_item(int(item_id), enabled=bool(enabled))
    if updated is None:
        raise HTTPException(status_code=404, detail=f"no memory item with id {item_id}")
    return {"ok": True, "item": updated}


@router.delete("/{item_id}", summary="Erase one memory item")
async def forget_memory(item_id: int) -> Dict[str, Any]:
    ok = await memory_store.forget(int(item_id))
    if not ok:
        raise HTTPException(status_code=404, detail=f"no memory item with id {item_id}")
    return {"ok": True, "deleted": item_id}


@router.delete("", summary="Clear memory (all, or one kind / scope)")
async def clear_memory(kind: str = "", scope: str = "") -> Dict[str, Any]:
    n = await memory_store.clear(kind=kind or None, scope=scope or None)
    log.warning("memory cleared: %d item(s) (kind=%s scope=%s)", n, kind or "all", scope or "all")
    return {"ok": True, "cleared": n, "kind": kind or "all", "scope": scope or "all"}


@router.post("/reindex", summary="Rebuild the semantic file index")
async def reindex(roots: List[str] = [], limit: int = 2000) -> Dict[str, Any]:
    from backend.app.config import settings

    targets = roots or [str(r) for r in settings.allowed_roots if r.exists()]
    if not targets:
        raise HTTPException(status_code=400, detail="no folders to index")
    data = await semantic_index.build(targets, limit=int(limit),
                                      extensions=settings.index_extensions)
    data["ok"] = bool(data.get("ok", True))
    return data


@router.get("/context", summary="What SAM would feed a model for a query right now")
async def context(query: str, conversation_id: str = "") -> Dict[str, Any]:
    data = await memory_store.build_prompt_context(query, conversation_id or None)
    return {"ok": True, "query": query, **data}
