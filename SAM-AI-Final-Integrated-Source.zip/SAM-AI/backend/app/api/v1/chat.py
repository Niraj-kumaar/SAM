"""
backend.app.api.v1.chat
=======================

The CHAT page's API — the single door into SAM.

``POST /api/v1/chat`` is the whole product in one call: the orchestrator runs
Context Engine → Planner → brains → tools → Verification and returns the reply,
the task plan, the actions taken, the sources found and any confirmation SAM
needs from the user.

``POST /api/v1/chat/stream`` returns the same thing as a Server-Sent-Events
stream so the UI can show plan steps appear one by one.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from backend.app.api.deps import check_token, tool_call, tool_context
from backend.app.core.logging_config import get_logger
from backend.app.core.orchestrator import orchestrator
from backend.app.core.schemas import ChatRequest, ChatResponse, VoiceMode
from backend.app.memory.store import memory_store
from backend.app.security.confirmation_engine import confirmation_engine

log = get_logger("api.chat")

router = APIRouter(prefix="/chat", tags=["chat"], dependencies=[Depends(check_token)])


class ConfirmBody(BaseModel):
    # the id normally travels in the path (POST /confirmations/{id}); it is
    # accepted in the body too so a single JSON payload works for both shapes
    confirmation_id: str = ""
    approved: bool
    phrase: str = ""
    remember: bool = False
    note: str = ""


class VoiceTurn(BaseModel):
    text: Optional[str] = None
    audio_b64: Optional[str] = None
    audio_path: Optional[str] = None
    filename: str = "audio.wav"
    language: str = "auto"
    conversation_id: Optional[str] = None
    speak: Optional[bool] = None
    wake_filter: bool = False
    voice_mode: VoiceMode = VoiceMode.STANDARD


@router.post("", response_model=ChatResponse, summary="Send a message to SAM")
async def chat(body: ChatRequest) -> ChatResponse:
    """
    Full turn: plan, execute, verify, reply.

    Set ``dry_run=true`` to see the plan SAM *would* run without executing it.
    """
    result = await orchestrator.handle_text(
        body.message,
        conversation_id=body.conversation_id,
        language=body.language,
        attachments=body.attachments,
        channel=body.mode or "text",
        dry_run=body.dry_run,
        max_steps=body.max_steps,
        speak=False,
    )
    return result.to_chat_response()


@router.post("/plan", summary="Show the plan only (never executes)")
async def chat_plan(body: ChatRequest) -> Dict[str, Any]:
    result = await orchestrator.handle_text(
        body.message, conversation_id=body.conversation_id, language=body.language,
        dry_run=True, max_steps=body.max_steps,
    )
    task = result.task.model_dump(mode="json") if result.task else None
    return {"ok": result.ok, "reply": result.reply, "intent": result.intent,
            "confidence": result.confidence, "agent": result.agent, "task": task,
            "steps": (task or {}).get("steps", []), "took_ms": result.took_ms}


@router.post("/stream", summary="Stream a turn as Server-Sent Events")
async def chat_stream(body: ChatRequest) -> StreamingResponse:
    """
    Emits ``event``/``data`` pairs: ``plan``, ``step``, ``progress``, ``agent``,
    ``confirmation``, ``reply``, ``done``. The client renders them as they arrive.
    """

    async def gen():
        queue: asyncio.Queue = asyncio.Queue(maxsize=256)
        from backend.app.core.event_bus import bus

        sub = bus.subscribe("*")
        loop = asyncio.get_running_loop()

        async def pump() -> None:
            try:
                while True:
                    event = await sub.queue.get()
                    await queue.put({"event": event.topic, "data": event.payload})
            except asyncio.CancelledError:
                raise

        task = asyncio.create_task(orchestrator.handle_text(
            body.message, conversation_id=body.conversation_id, language=body.language,
            attachments=body.attachments, channel=body.mode or "text",
            dry_run=body.dry_run, max_steps=body.max_steps,
        ))
        pump_task = loop.create_task(pump())

        def sse(event: str, data: Any) -> str:
            return f"event: {event}\ndata: {json.dumps(data, default=str, ensure_ascii=False)}\n\n"

        try:
            yield sse("start", {"message": body.message[:200], "ts": time.time()})
            result = None
            while not task.done():
                try:
                    item = await asyncio.wait_for(queue.get(), timeout=0.25)
                except asyncio.TimeoutError:
                    yield sse("ping", {"ts": time.time()})
                    continue
                topic = item["event"]
                if topic.startswith(("task.", "agent.", "security.", "chat.")):
                    yield sse(topic, item["data"])
            result = task.result()
            yield sse("reply", {"reply": result.reply, "agent": result.agent,
                                "model": result.model, "language": result.language,
                                "intent": result.intent, "took_ms": result.took_ms,
                                "sources": result.sources, "actions": result.actions,
                                "confirmations": result.confirmations,
                                "task": result.task.model_dump(mode="json") if result.task else None})
            yield sse("done", {"ok": result.ok, "conversation_id": result.conversation_id})
        except Exception as exc:  # pragma: no cover
            log.exception("chat stream failed")
            yield sse("error", {"error": str(exc)[:400]})
        finally:
            pump_task.cancel()
            bus.unsubscribe(sub)
            if not task.done():
                task.cancel()

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no",
                                      "Connection": "keep-alive"})


@router.post("/voice", summary="One full voice turn (audio in, audio out)")
async def chat_voice(body: VoiceTurn) -> Dict[str, Any]:
    from backend.app.voice.engine import voice_engine
    from backend.app.voice.modes import voice_modes

    if body.voice_mode and body.voice_mode.value != voice_modes.mode:
        voice_modes.set_mode(body.voice_mode.value)
    if not (body.text or body.audio_b64 or body.audio_path):
        raise HTTPException(status_code=400, detail="send text, audio_b64 or audio_path")
    audio = b""
    if body.audio_b64:
        import base64

        raw = body.audio_b64
        if raw.startswith("data:") and "," in raw:
            raw = raw.split(",", 1)[1]
        try:
            audio = base64.b64decode(raw)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"bad base64 audio: {exc}")
    return await voice_engine.voice_turn(
        text=body.text or "", path=body.audio_path or "", audio=audio,
        filename=body.filename, language=body.language,
        conversation_id=body.conversation_id, speak_reply=body.speak,
        wake_filter=body.wake_filter,
    )


# ---------------------------------------------------------------------------
# confirmations — the Approval Center
# ---------------------------------------------------------------------------
@router.get("/confirmations", summary="Pending confirmations")
async def list_confirmations() -> Dict[str, Any]:
    return {"ok": True, "pending": confirmation_engine.pending(),
            "history": confirmation_engine.history(30)}


@router.post("/confirmations/{confirmation_id}", summary="Approve or refuse an action")
async def resolve_confirmation(confirmation_id: str, body: ConfirmBody) -> Dict[str, Any]:
    cid = (confirmation_id or body.confirmation_id or "").strip()
    if not cid:
        raise HTTPException(status_code=400, detail="a confirmation id is required")
    outcome = await confirmation_engine.resolve(
        cid, approved=body.approved, phrase=body.phrase,
        remember=body.remember, note=body.note,
    )
    if not outcome.get("ok") and "unknown" in str(outcome.get("error", "")):
        raise HTTPException(status_code=404, detail=str(outcome.get("error")))
    return outcome


@router.post("/confirmations/cancel", summary="Cancel every pending confirmation")
async def cancel_confirmations() -> Dict[str, Any]:
    n = await confirmation_engine.cancel_all("cancelled from the UI")
    return {"ok": True, "cancelled": n}


# ---------------------------------------------------------------------------
# conversations
# ---------------------------------------------------------------------------
@router.get("/conversations", summary="List conversations")
async def conversations(limit: int = 50) -> Dict[str, Any]:
    items = await memory_store.list_conversations(limit=int(limit))
    return {"ok": True, "count": len(items), "conversations": items}


@router.get("/conversations/{conversation_id}", summary="Read one conversation")
async def conversation(conversation_id: str, limit: int = 200) -> Dict[str, Any]:
    data = await memory_store.get_conversation(conversation_id, limit=int(limit))
    if data is None:
        raise HTTPException(status_code=404, detail="conversation not found")
    return {"ok": True, **data}


@router.delete("/conversations/{conversation_id}", summary="Delete a conversation")
async def delete_conversation(conversation_id: str) -> Dict[str, Any]:
    ok = await memory_store.delete_conversation(conversation_id)
    if not ok:
        raise HTTPException(status_code=404, detail="conversation not found")
    return {"ok": True, "deleted": conversation_id}


@router.get("/intents", summary="The intent classifier's full vocabulary")
async def intents() -> Dict[str, Any]:
    """What the Planner can recognise without a model — useful for the UI hints."""
    from backend.app.providers.heuristic import INTENT_PATTERNS

    return {"ok": True, "count": len(INTENT_PATTERNS),
            "intents": [{"intent": intent, "patterns": list(patterns)}
                        for intent, patterns in INTENT_PATTERNS]}
