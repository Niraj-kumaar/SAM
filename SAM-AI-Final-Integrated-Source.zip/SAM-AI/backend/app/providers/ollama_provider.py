"""
backend.app.providers.ollama_provider
=====================================

**SAM's offline brain.** Talks to a local `Ollama <https://ollama.com>`_
server so SAM keeps working with no internet and no data leaving the machine
(Local Mode / Privacy Mode).

Install on Windows::

    winget install Ollama.Ollama
    ollama pull llama3.1:8b
    ollama pull llama3.2:3b
    ollama pull qwen2.5-coder:7b
    ollama pull llava:7b
    ollama pull nomic-embed-text

The provider auto-discovers whatever models are actually pulled, so the
catalogue below is only a *preference list* used when Ollama is unreachable.
"""

from __future__ import annotations

import time
from typing import Any, AsyncIterator, Dict, List, Optional

import httpx

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.models.base import ModelInfo, ModelProvider, ModelRequest, ModelResponse

log = get_logger("providers.ollama")

PREFERRED = [
    ("llama3.1:8b", ["primary", "reasoning", "translation"], 128000, False, 4, 3),
    ("llama3.2:3b", ["fast", "translation"], 128000, False, 3, 5),
    ("llama3.2:1b", ["fast"], 128000, False, 2, 5),
    ("qwen2.5-coder:7b", ["coding"], 32000, False, 4, 4),
    ("qwen2.5-coder:32b", ["coding", "reasoning"], 32000, False, 5, 2),
    ("llava:7b", ["vision"], 4096, True, 3, 3),
    ("llama3.2-vision:11b", ["vision", "primary"], 128000, True, 4, 2),
    ("nomic-embed-text", ["embedding"], 8192, False, 4, 5),
    ("mistral:7b", ["primary", "fast"], 32000, False, 3, 4),
    ("gemma2:9b", ["primary"], 8192, False, 4, 3),
    ("phi3:mini", ["fast"], 128000, False, 3, 5),
]


class OllamaProvider(ModelProvider):
    name = "ollama"
    is_local = True
    priority = 10          # preferred in local/hybrid mode for privacy

    def __init__(self, base_url: Optional[str] = None) -> None:
        super().__init__()
        self.base_url = (base_url or settings.ollama_base_url).rstrip("/")
        self._client: Optional[httpx.AsyncClient] = None
        self._tags_cache: Optional[List[str]] = None
        self._tags_at: float = 0.0

    def available(self) -> bool:
        if not settings.ollama_enabled:
            return False
        if settings.sam_mode == "online" and not settings.privacy_local_models:
            return False
        return True

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=300.0)
        return self._client

    # ------------------------------------------------------------ discovery
    async def discover(self, max_age: float = 60.0) -> List[str]:
        """Ask the local daemon which models are pulled."""
        now = time.time()
        if self._tags_cache is not None and now - self._tags_at < max_age:
            return self._tags_cache
        try:
            client = await self._http()
            r = await client.get(f"{self.base_url}/api/tags", timeout=3.0)
            r.raise_for_status()
            names = [m.get("name", "") for m in r.json().get("models", []) if m.get("name")]
            self._tags_cache = names
            self._tags_at = now
            self.mark_success()
        except Exception as exc:
            self._tags_cache = []
            self._tags_at = now
            self.mark_failure(str(exc))
        return self._tags_cache or []

    def models(self) -> List[ModelInfo]:
        known = self._tags_cache or []
        out: List[ModelInfo] = []
        for name, roles, ctx, vision, quality, speed in PREFERRED:
            if not known or any(k == name or k.startswith(name.split(":")[0]) for k in known):
                out.append(ModelInfo("ollama", name, roles, ctx, vision, True, False, local=True,
                                     quality=quality, speed=speed, privacy=5))
        # include pulled models we don't know about
        seen = {m.model for m in out}
        for k in known:
            if k not in seen and "embed" not in k:
                out.append(ModelInfo("ollama", k, ["fast", "primary"], 8192, False, True, False,
                                     local=True, quality=3, speed=3, privacy=5))
            elif k not in seen:
                out.append(ModelInfo("ollama", k, ["embedding"], 8192, False, True, False,
                                     local=True, quality=3, speed=4, privacy=5))
        return out

    def _default_model(self, role: str) -> str:
        known = self._tags_cache or []
        for name, roles, *_ in PREFERRED:
            if role in roles and (not known or any(k.startswith(name.split(":")[0]) for k in known)):
                return name
        if known:
            return known[0]
        return {
            "primary": settings.model_local_default,
            "fast": settings.model_local_fast_default,
            "coding": settings.model_local_coding_default,
            "vision": settings.model_local_vision_default,
            "embedding": settings.model_local_embedding_default,
        }.get(role, settings.model_local_default)

    # -------------------------------------------------------------- payload
    def _payload(self, req: ModelRequest, model: str) -> Dict[str, Any]:
        msgs: List[Dict[str, Any]] = []
        for m in self.merge_system(req):
            entry: Dict[str, Any] = {"role": m.role, "content": m.content}
            if m.images:
                entry["images"] = [_to_b64(i) for i in m.images if _to_b64(i)]
            msgs.append(entry)
        payload: Dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "stream": bool(req.stream),
            "options": {
                "temperature": req.temperature,
                "top_p": req.top_p,
                "num_predict": req.max_tokens,
            },
        }
        if req.stop:
            payload["options"]["stop"] = req.stop
        if req.json_mode:
            payload["format"] = "json"
        return payload

    # ------------------------------------------------------------- complete
    async def complete(self, req: ModelRequest) -> ModelResponse:
        if not self.available():
            return ModelResponse(text="", provider=self.name, model="", role=req.role,
                                 error="ollama is disabled in configuration")
        model = req.model or self._default_model(req.role)
        t0 = time.perf_counter()
        try:
            client = await self._http()
            r = await client.post(f"{self.base_url}/api/chat", json=self._payload(req, model),
                                  timeout=req.timeout)
            if r.status_code >= 400:
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
            data = r.json()
        except Exception as exc:
            self.mark_failure(str(exc))
            return ModelResponse(text="", provider=self.name, model=model, role=req.role,
                                 error=f"ollama unreachable: {exc}", local=True)

        self.mark_success()
        msg = data.get("message", {}) or {}
        return ModelResponse(
            text=msg.get("content", "") or "",
            provider=self.name,
            model=data.get("model", model),
            role=req.role,
            prompt_tokens=int(data.get("prompt_eval_count", 0) or 0),
            completion_tokens=int(data.get("eval_count", 0) or 0),
            total_tokens=int(data.get("prompt_eval_count", 0) or 0) + int(data.get("eval_count", 0) or 0),
            latency_ms=int((time.perf_counter() - t0) * 1000),
            finish_reason=data.get("done_reason", "stop") or "stop",
            raw=data,
            local=True,
        )

    async def stream(self, req: ModelRequest) -> AsyncIterator[str]:
        if not self.available():
            res = await self.complete(req)
            if res.text:
                yield res.text
            return
        import json as _json

        model = req.model or self._default_model(req.role)
        payload = self._payload(req, model)
        payload["stream"] = True
        try:
            client = await self._http()
            async with client.stream("POST", f"{self.base_url}/api/chat", json=payload,
                                     timeout=req.timeout) as resp:
                if resp.status_code >= 400:
                    body = await resp.aread()
                    raise RuntimeError(f"HTTP {resp.status_code}: {body[:300]!r}")
                async for line in resp.aiter_lines():
                    if not line.strip():
                        continue
                    try:
                        obj = _json.loads(line)
                    except Exception:
                        continue
                    piece = (obj.get("message") or {}).get("content")
                    if piece:
                        yield piece
                    if obj.get("done"):
                        break
            self.mark_success()
        except Exception as exc:
            self.mark_failure(str(exc))
            log.debug("ollama stream failed: %s", exc)

    # ------------------------------------------------------------ embeddings
    async def embed(self, texts: List[str], model: Optional[str] = None) -> List[List[float]]:
        model = model or self._default_model("embedding")
        try:
            client = await self._http()
            r = await client.post(f"{self.base_url}/api/embed",
                                  json={"model": model, "input": texts}, timeout=60.0)
            r.raise_for_status()
            return r.json().get("embeddings", [])
        except Exception as exc:
            log.debug("ollama embed failed: %s", exc)
            return [[0.0] * 8 for _ in texts]

    async def health(self) -> Dict[str, Any]:
        base = await super().health()
        base["models"] = self._tags_cache or []
        base["url"] = self.base_url
        return base

    async def aclose(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


def _to_b64(value: str) -> str:
    """Accept a data URL, an http URL (returned empty) or a local file path."""
    import base64
    from pathlib import Path

    if value.startswith("data:"):
        return value.partition(",")[2]
    if value.startswith(("http://", "https://")):
        return ""
    try:
        return base64.b64encode(Path(value).expanduser().read_bytes()).decode()
    except Exception:
        return ""
