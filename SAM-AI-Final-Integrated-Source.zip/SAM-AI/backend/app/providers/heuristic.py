"""
backend.app.providers.heuristic
===============================

**SAM's zero-dependency brain.**

A deterministic, fully offline fallback provider. It contains no neural network —
it is a rule/intent engine that lets the whole platform work end-to-end before
the user has added a single API key or pulled a local model.

It is also the provider used for:

* model classification (what kind of request is this?)
* language detection
* summarisation of tool output
* friendly acknowledgements for device/file/PC actions

Every other provider failing => this one answers, so SAM never goes silent.
"""

from __future__ import annotations

import platform
import random
import re
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple

from backend.app.core.logging_config import get_logger
from backend.app.models.base import ModelInfo, ModelProvider, ModelRequest, ModelResponse

log = get_logger("providers.heuristic")


class HeuristicProvider(ModelProvider):
    name = "heuristic"
    is_local = True
    priority = 999          # always last resort

    def available(self) -> bool:
        return True

    def models(self) -> List[ModelInfo]:
        return [
            ModelInfo("heuristic", "sam-rules-v1",
                      ["primary", "fast", "fallback", "translation", "reasoning", "coding"],
                      8192, False, True, False, local=True, quality=2, speed=5, privacy=5),
        ]

    async def complete(self, req: ModelRequest) -> ModelResponse:
        import time

        t0 = time.perf_counter()
        prompt = self._last_user_text(req)
        system = (req.system or "") + " " + " ".join(
            m.content for m in req.messages if m.role == "system"
        )
        text = respond(prompt, system=system, json_mode=req.json_mode, role=req.role)
        return ModelResponse(
            text=text,
            provider=self.name,
            model="sam-rules-v1",
            role=req.role,
            prompt_tokens=len(prompt) // 4,
            completion_tokens=len(text) // 4,
            total_tokens=(len(prompt) + len(text)) // 4,
            latency_ms=int((time.perf_counter() - t0) * 1000),
            finish_reason="stop",
            local=True,
        )

    async def stream(self, req: ModelRequest) -> AsyncIterator[str]:
        import asyncio

        res = await self.complete(req)
        words = res.text.split(" ")
        for i in range(0, len(words), 6):
            yield " ".join(words[i : i + 6]) + (" " if i + 6 < len(words) else "")
            await asyncio.sleep(0.01)

    @staticmethod
    def _last_user_text(req: ModelRequest) -> str:
        for m in reversed(req.messages):
            if m.role == "user":
                return m.content
        return req.messages[0].content if req.messages else ""


# ===========================================================================
# Language detection
# ===========================================================================
_SCRIPTS: List[Tuple[str, str]] = [
    ("kn", r"[\u0C80-\u0CFF]"),   # Kannada
    ("hi", r"[\u0900-\u097F]"),   # Devanagari (Hindi/Marathi)
    ("ta", r"[\u0B80-\u0BFF]"),   # Tamil
    ("te", r"[\u0C00-\u0C7F]"),   # Telugu
    ("ml", r"[\u0D00-\u0D7F]"),   # Malayalam
    ("bn", r"[\u0980-\u09FF]"),   # Bengali
    ("gu", r"[\u0A80-\u0AFF]"),   # Gujarati
    ("pa", r"[\u0A00-\u0A7F]"),   # Gurmukhi
    ("ur", r"[\u0600-\u06FF]"),   # Arabic script (Urdu/Arabic)
    ("ar", r"[\u0600-\u06FF]"),
    ("ja", r"[\u3040-\u30FF]"),   # Hiragana/Katakana
    ("ko", r"[\uAC00-\uD7AF]"),
    ("zh", r"[\u4E00-\u9FFF]"),
    ("th", r"[\u0E00-\u0E7F]"),
    ("ru", r"[\u0400-\u04FF]"),
]

_LANG_WORDS: Dict[str, List[str]] = {
    "hi": ["kya", "hai", "karo", "nahi", "mujhe", "tum", "aap", "batao", "chahiye", "acha", "theek", "shukriya"],
    "kn": ["yenu", "madi", "beda", "nanage", "hegi", "gottilla", "dhanyavada", "sari"],
    "ta": ["enna", "seyya", "veண்டும்", "nan", "eppadi", "nandri"],
    "te": ["emi", "cheyyali", "naku", "ela", "dhanyavadalu"],
    "ml": ["enthu", "cheyyanam", "enikku", "eppane", "nandi"],
    "mr": ["kay", "ahe", "kara", "mala", "kase", "dhanyavad"],
    "bn": ["ki", "koro", "ami", "kemon", "dhonnobad"],
    "gu": ["shu", "karo", "mane", "kem", "aabhar"],
    "pa": ["ki", "karo", "mainu", "kiven", "dhanyavaad"],
    "es": ["que", "hola", "gracias", "por favor", "necesito", "abrir"],
    "fr": ["bonjour", "merci", "ouvrez", "s'il vous plait", "besoin"],
    "de": ["hallo", "danke", "offnen", "bitte", "brauche"],
    "pt": ["ola", "obrigado", "abra", "por favor", "preciso"],
}


def detect_language(text: str) -> str:
    """Return a BCP-47-ish code. Handles mixed (code-mixed) speech too."""
    if not text or not text.strip():
        return "en"
    for lang, pattern in _SCRIPTS:
        if re.search(pattern, text):
            # Devanagari is shared by Hindi + Marathi + Nepali
            if lang == "hi":
                lower = text.lower()
                if any(w in lower for w in _LANG_WORDS["mr"]):
                    return "mr"
                return "hi"
            if lang in ("ur", "ar"):
                # crude Urdu vs Arabic split
                return "ur" if re.search(r"[\u0679\u0688\u0691\u06BA\u06BE]", text) else "ar"
            return lang
    lower = f" {re.sub(r'[^a-z ]', ' ', text.lower())} "
    scores = {
        lang: sum(1 for w in words if f" {w} " in lower)
        for lang, words in _LANG_WORDS.items()
    }
    best = max(scores.items(), key=lambda kv: kv[1])
    if best[1] >= 2:
        return best[0]
    return "en"


# ===========================================================================
# Intent classification (used by the Planner/Router as a pre-filter)
# ===========================================================================
# anything that could be a tradable market — reused by the intent patterns below
_MKT_SYMBOLS = (
    r"eurusd|gbpusd|usdjpy|audusd|usdcad|usdchf|nzdusd|eurjpy|gbpjpy|usdinr|eurinr|gbpinr|"
    r"eur\s*/\s*usd|usd\s*/\s*inr|dollar\s*rupee|"
    r"bitcoin|\bbtc\b|ethereum|\beth\b|solana|\bsol\b|\bxrp\b|dogecoin|\bdoge\b|cardano|"
    r"\bada\b|litecoin|\bltc\b|shiba|crypto|cryptocurrency|"
    r"gold|silver|crude\s*oil|brent|copper|platinum|commodit\w+|"
    r"nifty|nifty\s*50|bank\s*nifty|sensex|\bvix\b|nse\b|bse\b|"
    r"reliance|\btcs\b|infosys|hdfc|icici|\bsbi\b|tata\s*motors|adani|wipro|"
    r"\baapl\b|\bmsft\b|\bgoogl?\b|\bamzn\b|\btsla\b|\bnvda\b|\bmeta\b|\bspy\b|\bqqq\b|"
    r"forex|\bfx\b|currency\s*pair|stock\s*market|share\s*price|\bdxy\b"
)

INTENT_PATTERNS: List[Tuple[str, List[str]]] = [
    # ---------------------------------------------------------------------
    # The code.* and text.* intents are checked FIRST: they are narrow (they
    # need a format or an editing verb) while some older intents are broad —
    # "redact the phone numbers" would otherwise look like phone.control and
    # "rewrite this to sound professional" would look like pc.volume.
    # ---------------------------------------------------------------------
    # =====================================================================
    # Developer-utility intents (the code.* toolbox)
    # =====================================================================
    ("code.regex", [
        r"\b(regex|regexp|regular\s+expression|pattern\s+match\w*|test\s+(?:this|my|a)\s+pattern|"
        r"capture\s+group|lookahead)\b",
    ]),
    ("code.jwt", [r"\b(jwt|json\s+web\s+token|decode\s+(?:this\s+)?token|bearer\s+token\s+decode)\b"]),
    ("code.uuid", [r"\b(uuid|guid|generate\s+(?:a\s+)?(?:unique|random)\s+id)\b"]),
    ("code.hash", [
        r"\b(sha\s*-?\s*(?:1|256|512)|md5|blake2|checksum|digest|hmac|hash\s*(?:this|of|the))\b",
    ]),
    ("code.encode", [
        r"\b(base\s*-?\s*(?:64|32|16)|b64|percent\s*encod\w*|url\s*encod\w*|url\s*decod\w*|"
        r"hex\s*(?:encod|decod|encode)|rot13|binary\s*(?:encod|decod)|encode\s+(?:this|to)|"
        r"decode\s+(?:this|from))\b",
    ]),
    ("code.color", [
        r"\b(hex\s*(?:to|2)\s*(?:rgb|hsl)|rgb\s*(?:to|2)\s*hex|colour|color)\b.*"
        r"\b(rgb|hsl|hex|contrast|palette|wcag|luminance|shade|tint)\b",
        r"\b(contrast\s*ratio|wcag|accessib\w+\s*(?:color|colour)|colour\s*palette|color\s*palette)\b",
    ]),
    ("code.cron", [r"\b(cron|crontab|cron\s+expression|schedule\s+expression)\b"]),
    ("code.timestamp", [
        r"\b(unix\s*(?:time|timestamp|epoch)|epoch\s*(?:time|converter|seconds)|timestamp\s*"
        r"(?:convert|to\s+(?:date|iso|human))|\d{10}\s+to\s+date|iso\s*8601)\b",
    ]),
    ("code.sql", [
        r"\b(run|execute|test)\s+(?:this\s+|my\s+|the\s+)?(?:sql|query|select)\b",
        r"\bsqlite\b.*\b(query|database|table|select)\b",
        r"\bselect\s+.+\s+from\s+\w+\b",
    ]),
    ("code.number_base", [
        r"\b(binary|hexadecimal|hex|octal|base\s*(?:2|8|10|16|36)|bitwise|ieee\s*754|float\s*bits)\b"
        r".*\b(of|for|convert|to|value|number)\b",
        r"\b(convert|what\s+is)\s+\d+\s*(?:to|in|as)\s*(?:binary|hex|octal|base\s*\d+)\b",
    ]),
    ("code.secret_scan", [
        r"\b(scan|check|find|look)\b.*\b(secrets?|leaked?|credentials?|api\s*keys?|tokens?)\b",
        r"\b(secret|credential|api\s*key)\s+scan\b",
    ]),
    ("code.complexity", [
        r"\b(cyclomatic|code\s*(?:complexity|metrics)|lines?\s+of\s+code|loc\b|nesting\s+depth)\b",
    ]),
    ("code.review", [
        r"\b(review|audit|lint|check)\s+(?:this|my|the)\s+(?:code|snippet|function|script|file)\b",
        r"\bcode\s+review\b|\bsecurity\s+review\b.*\bcode\b",
    ]),
    ("code.random_data", [
        r"\b(fake|mock|dummy|sample|test|synthetic|random)\s+(?:data|dataset|rows?|records?|"
        r"users?|orders?|events?)\b",
        r"\bgenerate\s+(?:some\s+)?(?:test|sample|mock|fake)\s+data\b",
    ]),
    ("code.qrcode", [r"\b(qr\s*code|qrcode|qr\s+for|scan\s+code)\b"]),
    ("code.format_convert", [
        r"\bconvert\b.*\b(json|yaml|yml|csv|tsv|toml|ini|xml|markdown\s+table)\b",
        r"\b(json|yaml|csv|tsv|toml|ini|xml)\b\s*(?:to|2|into)\s*(json|yaml|csv|tsv|toml|ini|xml|"
        r"markdown|python)\b",
    ]),
    ("code.json", [
        r"\b(json)\b.*\b(validate|format|pretty|prettify|minify|parse|query|flatten|repair|fix|"
        r"keys|structure|to\s+(?:csv|yaml|table))\b",
        r"\b(validate|format|pretty\s*print|minify|flatten|repair|fix|parse)\b.*\b(json)\b",
    ]),
    ("code.snippet", [
        r"\b(snippet|boilerplate|scaffold|starter\s+code|code\s+(?:for|to)\s+"
        r"(?:read|write|fetch|retry|connect))\b",
        r"\b(?:write|give|show)\s+me\s+(?:a\s+)?(?:code\s+)?snippet\b",
    ]),
    ("code.artifact", [
        r"\b(save|write|export)\s+(?:this|it|the)\s+(?:code|snippet|text|output|result)\s+"
        r"(?:to|as)\s+(?:a\s+)?file\b",
    ]),
    # =====================================================================
    # Text / writing intents (the text.* toolbox)
    # =====================================================================
    ("text.redact", [
        r"\b(redact|mask|anonymis\w+|anonymiz\w+|hide|scrub|remove)\b.*"
        r"\b(pii|personal|names?|emails?|phone|numbers?|sensitive|private)\b",
    ]),
    ("text.readability", [
        r"\b(readab\w+|flesch|kincaid|kincaide|gunning|fog\s+index|reading\s+(?:level|ease|score)|"
        r"grade\s+level|ari\b|smog)\b",
    ]),
    ("text.similarity", [
        r"\b(similar\w+|plagiar\w+|duplicate|compare)\b.*\b(texts?|paragraphs?|documents?|"
        r"articles?|strings?|two\s+versions)\b",
        r"\bhow\s+similar\s+(?:are|is)\b",
    ]),
    ("text.diff", [
        r"\b(diff|unified\s+diff|what\s+changed)\b",
        r"\b(differences?\s+between|compare|comparison\s+of)\b.*"
        r"\b(files?|texts?|versions?|documents?|paragraphs?|strings?)\b",
    ]),
    ("text.grammar", [
        r"\b(grammar|spell\s*check|spelling|proofread|typos?|fix\s+(?:the\s+)?"
        r"(?:english|writing|text)|correct\s+(?:this|the|my)\s+(?:text|sentence|english))\b",
    ]),
    ("text.rewrite", [
        r"\b(rewrite|rephrase|reword|paraphrase|polish|improve\s+(?:this|the|my)\s+"
        r"(?:text|writing|sentence|email|paragraph)|make\s+it\s+(?:shorter|longer|professional|"
        r"casual|formal|friendly|clear|better)|change\s+the\s+tone|more\s+(?:professional|"
        r"formal|casual|persuasive|concise))\b",
    ]),
    ("text.summarise", [
        r"\b(summar\w+|tl;?dr|shorten\s+this|condense|abstract\s+of|key\s+points?\s+from|"
        r"bullet\s+(?:this|the\s+points)|main\s+ideas?)\b",
    ]),
    ("text.bullets", [
        r"\b(bullet\s*(?:points?|list)|turn\s+(?:this|it)\s+into\s+(?:bullets|a\s+list)|"
        r"prose\s+to\s+bullets|bullets\s+to\s+prose)\b",
    ]),
    ("text.extract", [
        r"\b(extract|find|pull|list)\b.*\b(emails?|urls?|links?|phone\s*numbers?|dates?|"
        r"hashtags?|mentions?|ips?|amounts?|entities)\b.*\b(from|in|out\s+of)\b",
    ]),
    ("text.count", [
        r"\b(count|how\s+many)\b.*\b(words?|characters?|letters?|sentences?|paragraphs?)\b",
        r"\bword\s+count\b|\breading\s+time\b|\bcharacter\s+count\b",
    ]),
    ("text.sentiment", [
        r"\b(sentiment|tone)\b.*\b(of|in|analysis|score)\b.*\b(text|message|review|comment|"
        r"feedback|tweet|email)\b",
        r"\bsentiment\s+analys\w+\b",
    ]),
    ("text.keywords", [
        r"\b(keywords?|key\s+phrases?|tags?\s+for|seo\b|meta\s+description|topics?\s+of)\b.*"
        r"\b(text|article|blog|page|content|this)\b",
        r"\bextract\s+keywords\b",
    ]),
    ("text.template", [
        r"\b(fill|render|populate)\b.*\b(template|placeholders?|mail\s+merge)\b",
        r"\btemplate\b.*\b(variables?|placeholders?|values)\b",
    ]),
    ("text.table", [
        r"\b(make|build|convert|turn)\b.*\b(table|markdown\s+table|csv|grid)\b.*"
        r"\b(from|out\s+of|of)\b",
        r"\brows?\s+to\s+(?:a\s+)?table\b",
    ]),
    ("text.lines", [
        r"\b(dedup\w+|remove\s+duplicates?|sort|reverse|number|trim|filter)\b.*\blines?\b",
        r"\blines?\b.*\b(dedup\w+|sorted?|reversed?|numbered?|unique)\b",
    ]),
    ("text.slug", [r"\b(slug|url\s*friendly|permalink|seo\s*url)\b"]),
    ("text.title", [r"\b(title\s+case|heading\s+case|capitali[sz]e\s+(?:this|the|properly))\b"]),
    ("text.case", [
        r"\b(snake[\s_-]*case|camel[\s_-]*case|pascal[\s_-]*case|kebab[\s_-]*case|"
        r"constant[\s_-]*case|"
        r"sentence\s*case|upper\s*case|lower\s*case|convert\s+case)\b",
    ]),
    ("text.markdown", [
        r"\b(markdown|md)\b.*\b(to|2|into)\s*(html)\b",
        r"\b(html)\b.*\b(to|2|into)\s*(text|markdown|plain)\b",
    ]),
    ("text.lorem", [r"\b(lorem\s+ipsum|placeholder\s+(?:text|copy)|dummy\s+text|filler\s+text)\b"]),
    # browser intents are checked FIRST: "open chrome and go to X" is browsing,
    # not merely launching an app.
    ("browser.open", [
        r"\b(open|go\s*to|visit|browse|navigate)\b.*\b(https?://|www\.|\w+\.(com|org|net|io|in|dev|co)\b)",
        # "google" as a destination => browse. "google X" as a verb => search.
        # A desktop app name right after the verb must NOT be treated as browsing.
        r"\b(open|visit|browse)\s+(?!(?:the\s+)?(?:notepad|vs\s*code|code|word|excel|powerpoint|"
        r"terminal|cmd|powershell|calculator|paint|explorer|spotify|task\s*manager|settings)\b)"
        r"(?:the\s+)?(?:web|internet|google|youtube|github|wikipedia|browser|chrome|firefox|edge)\b",
        r"\bsearch\s+(?:the\s+)?(?:web|internet|google|youtube)\b",
        r"\b(search|google|look\s*up)\b.*\b(online|on\s+(the\s+)?(web|internet|google|youtube))\b",
    ]),
    ("browser.scrape", [r"\b(scrape|extract|read|summaris|summariz)\b.*\b(page|website|site|url|link)\b"]),
    ("phone.control", [
        r"\b(phone|mobile|android|smartphone|whatsapp|telegram)\b",
        r"\b(battery\s*saver|power\s*saver)\b",
        r"\b(my|the)\s+(phone|mobile)\b",
    ]),
    ("phone.notify", [r"(send|show|push).*(notification).*(phone|mobile)"]),
    ("pc.screen", [
        r"\b(screenshot|screen\s*shot|screen\s+capture|capture\s+the\s+screen)\b",
        r"\b(what\'?s|what\s+is)\s+on\s+my\s+screen\b",
        r"\b(describe|read|understand)\b.*\b(my\s+)?screen\b",
    ]),
    ("pc.app.launch", [r"\b(open|launch|start|run)\b.*\b(app|application|chrome|notepad|vs\s*code|code|explorer|word|excel|spotify|terminal|cmd|powershell|calculator|paint|task\s*manager)\b"]),
    ("pc.app.close", [r"\b(close|quit|kill|exit|terminate)\b.*\b(app|window|program|chrome|notepad|vs\s*code|terminal)\b"]),
    ("pc.power", [r"\b(lock|sleep|hibernate|restart|reboot|shutdown|shut\s*down|sign\s*out|log\s*out)\b.*\b(pc|computer|system|screen|laptop|windows)?\b"]),
    ("pc.system.info", [r"\b(cpu|ram|memory|disk|battery|storage|temperature|usage|system\s*(info|status|health)|how\s*much\s*(space|memory))\b"]),
    ("pc.window.manage", [r"\b(minimi[sz]e|maximi[sz]e|resize|move|focus|snap|arrange)\b.*\b(window|screen|app)\b"]),
    ("pc.volume", [r"\b(volume|mute|unmute|louder|quieter|sound)\b"]),
    ("pc.brightness", [r"\b(brightness|dimmer|brighter)\b"]),
    ("files.search", [
        r"\b(find|search|locate|look\s*for|where\s+(is|are))\b.*\b(file|files|folder|document|pdf|photo|image|download)s?\b",
        r"\b(find|search|locate|look\s*for|where\s+(is|are))\b.*\b(invoice|receipt|resume|cv|"
        r"screenshot|spreadsheet|presentation|contract|payslip|marksheet|ticket|bill|report|"
        r"notes?|assignment|wallpaper|song|video|zip|archive)s?\b",
        r"\ball\b.{0,30}\b(files?|pdfs?|photos?|images?|invoices?|documents?)\b",
        r"\bwhat\b.{0,40}\b(files?|pdfs?|photos?|images?|invoices?|documents?)\b.{0,40}"
        r"\b(downloaded?|created|modified|changed|added|saved)\b",
        r"\b(downloaded?|created|modified|changed|added|saved)\b.{0,40}"
        r"\b(files?|pdfs?|photos?|images?|invoices?|documents?)\b",
        r"\b(files?|pdfs?|photos?|images?|invoices?|documents?)\b.{0,30}"
        r"\b(did\s+i\s+)?(download|create|modif|chang|add|sav|receiv|open|edit)\w*\b",
    ]),
    ("files.organise", [
        r"\b(organis|organiz|tidy|sort|clean)(?:e|ed|ing)?\b(?:\s+up)?\s*"
        r"(?:my|the|all|these|those|this|that)?\s*"
        r"(?:\w+\s+){0,2}?(downloads?|desktop|documents?|pictures|photos|files|folders?)\b",
        r"\b(organis|organiz|clean\s*up|tidy|sort|arrange|dedup|duplicate)(?:e|ed|ing)?\b.*"
        r"\b(file|files|folder|folders|download|downloads|desktop|documents?|photos?|images?)?\b",
    ]),
    ("files.convert", [r"\b(convert|export|save\s*as)\b.*\b(pdf|docx|word|excel|csv|pptx|markdown|txt|png|jpg)\b"]),
    ("files.backup", [r"\b(backup|back\s*up|zip|compress|archive|extract|unzip)\b"]),
    ("terminal.run", [r"\b(run|execute)\b.*\b(command|terminal|powershell|cmd|script|shell)\b", r"^(git|npm|pip|python|node|docker|kubectl)\s"]),
    # plain conversation / arithmetic must NOT become a web research task
    ("core.help", [r"\b(what\s+can\s+you\s+do|what\s+are\s+your\s+(capabilities|features)|how\s+do\s+i\s+use\s+you|show\s+me\s+what\s+you\s+can\s+do|help\s+me\s+get\s+started)\b"]),
    # =====================================================================
    # Market Analyzer intents — checked before the generic question,
    # research and data intents so "technical analysis of EURUSD" is not
    # read as data.analyse and "price of gold" is not read as research.deep.
    # =====================================================================
    ("market.binary", [
        r"\b(binary\s*options?|binary\s*trad\w*|60\s*second\s*trad\w*|\d+\s*min(?:ute)?s?\s*expir\w*|"
        r"call\s*or\s*put|put\s*or\s*call|expiry\s*(?:time|price)|payout\s*(?:rate|percent)?)\b",
    ]),
    ("market.backtest", [
        r"\b(back\s*-?\s*tests?|backtesting|test\s+(?:this|my|the|a)\s+(?:strategy|rule|system)|"
        r"historical\s+(?:performance|results?)|walk\s*forward|did\s+this\s+strategy\s+work)\b",
    ]),
    ("market.journal", [
        r"\b(trade\s*journals?|trading\s*journals?|log\s+(?:my|this|a)\s+trad\w*|my\s+journals?|"
        r"review\s+my\s+trad\w*|journal\s*(?:stats|statistics|my)|close\s+(?:my|the)\s+trade|"
        r"how\s+(?:am\s*i|have\s+i)\s+(?:doing|performed)\s+(?:in|with)?\s*(?:my\s+)?trad\w*)\b",
    ]),
    ("market.paper", [
        r"\b(paper\s*trad\w*|demo\s*(?:trad\w*|account)|virtual\s*(?:trad\w*|portfolio|balance)|"
        r"simulat\w*\s+(?:trad\w*|position)|practice\s+(?:trad\w*|account))\b",
    ]),
    ("market.alert", [
        r"\b(price\s*alerts?|alerts?\s*(?:me|when|if|on)|notify\s*me\s*when|watch\s+(?:the\s+)?price|"
        r"tell\s*me\s*(?:when|if)|ping\s*me\s*when|when\s+[\w/]+\s+(?:reaches?|crosses?|hits?|goes?|"
        r"drops?|touches?|breaks?)\s*[\d.])\b",
        r"\b(?:my|the|price|open|active)\s+alerts?\b|\balerts?\s+(?:list|status|fired|triggered)\b|"
        r"\b(?:show|list|check|remove|delete|cancel)\b.{0,20}\balerts?\b",
    ]),
    ("market.screener", [
        r"\b(screeners?|scan\s+(?:the\s+)?market\w*|best\s+setups?|strongest\s+setups?|"
        r"top\s+(?:gainers|losers|movers|opportunities)|which\s+(?:pair|coin|stock|market)\s+"
        r"(?:should|is\s+(?:the\s+)?best|looks?)|what\s+should\s+i\s+trad\w*)\b",
    ]),
    ("market.watchlist", [
        r"\b(watch\s*-?\s*lists?|my\s+markets|track\s+(?:these|my|the)\s+(?:pairs|coins|stocks|"
        r"symbols|markets)|market\s+overview|how\s+(?:are|is)\s+(?:my|the)\s+(?:markets|pairs|"
        r"watchlist|portfolio\s+of\s+(?:pairs|coins)))\b",
    ]),
    ("market.sentiment", [
        r"\b(market\s*(?:news|sentiment|mood|buzz)|forex\s*news|crypto\s*news|economic\s*calendars?|"
        r"risk\s*events?|news\s*(?:on|about|for)\s*(?:gold|oil|bitcoin|btc|eth|usd|eur|inr|nifty|"
        r"sensex|dollar|rupee|the\s+market)|central\s*bank\s*(?:news|decision)|rbi\s+(?:news|rate))\b",
    ]),
    ("market.compare", [
        r"\b(correlat\w*|compar\w+|versus|vs\.?)\b.*\b(" + _MKT_SYMBOLS + r")\b",
        r"\b(" + _MKT_SYMBOLS + r")\b.*\b(and|vs|versus)\b.*\b(" + _MKT_SYMBOLS + r")\b",
    ]),
    ("market.risk", [
        r"\b(kelly|ruin|drawdown\s*(?:math|calculat\w*)|margin\s*required|position\s*siz\w*|"
        r"how\s*much\s*(?:can|should|do)\s*i\s*risk|stake\s*(?:plan|siz\w*)|martingale|"
        r"expected\s*move|value\s*at\s*risk|var\s*at\s*95|risk\s*(?:per|of)\s*trad\w*)\b",
    ]),
    ("market.forex_plan", [
        r"\b(lot\s*sizes?|pip\s*values?|stop\s*loss|take\s*profit|trade\s*plans?|risk\s*reward|"
        r"entry\s*(?:and|&)\s*(?:exit|stop)|where\s*(?:to|should\s+i)\s*(?:place|set|put)\s*my\s*stop|"
        r"how\s*many\s*(?:lots|units|pips))\b",
    ]),
    ("market.signal", [
        r"\b(should\s+i\s*(?:buy|sell|trad\w*|enter|go\s+(?:long|short))|buy\s*or\s*sell|"
        r"trad\w*\s*signals?|signals?\s*(?:for|on)\b|is\s*(?:it|this)\s*a\s*good\s*(?:time|entry)|"
        r"long\s*or\s*short|bullish\s*or\s*bearish|which\s*direction|up\s*or\s*down)\b",
    ]),
    ("market.explain", [
        r"\b(?:what\s*(?:is|are|does|do)\s*(?:a|an|the)?|explain\s*(?:me\s+)?(?:a|an|the)?|define)\s*"
        r"(?:rsi|macd|bollinger|atr\b|adx\b|vwap|obv|pips?|lots?\b|spreads?|leverage|margin|"
        r"cfds?|binary\s*options?|forex|candlesticks?|fibonacci|ichimoku|stochastic|kelly|"
        r"drawdowns?|slippage|hedg\w+|arbitrage|short\s*sell\w+|stop\s*loss|take\s*profit|"
        r"swing\s*trad\w+|scalp\w+|price\s*action|liquidity|order\s*blocks?|fundamental\s*analys\w+)\b",
        r"\bhow\s*(?:does|do)\s*(?:a\s*)?(?:indicator|leverage|margin|binary\s*option|forex|"
        r"short\s*selling|hedging)\s*work\b",
    ]),
    ("market.analysis", [
        r"\b(technical\s*analys\w*|chart\s*analys\w*|indicators?\b|rsi\b|macd\b|bollinger|"
        r"moving\s*averages?|\bema\b|\bsma\b|adx\b|stochastic|ichimoku|fibonacci|"
        r"support\s*(?:and|&|to)\s*resistance|pivot\s*points?|candlesticks?|price\s*action|"
        r"trend\s*(?:lines?|analys\w*|state)|\batr\b|vwap\b|obv\b|keltner|parabolic\s*sar|"
        r"chart\s*patterns?|multi\s*timeframes?|timeframe\s*alignment|market\s*regime|"
        r"volatility\b|overbought|oversold|divergenc\w*)\b",
    ]),
    ("market.quote", [
        r"\b(price|rate|rates|quote|cost|worth)\b.{0,25}\b(" + _MKT_SYMBOLS + r")\b",
        r"\b(" + _MKT_SYMBOLS + r")\b.{0,25}\b(price|rate|quote|now|today|currently|live|worth|"
        r"trading\s*at|at\s*what)\b",
        r"\bhow\s*much\s*(?:is|does|would)\b.{0,30}\b(dollar|rupee|euro|yen|pound|bitcoin|btc|eth|"
        r"gold|silver|1\s*(?:usd|eur|gbp))\b",
        r"\b(?:dollar|usd|euro|eur|pound|gbp|yen|jpy)\s*(?:to|in|vs|against|into)\s*"
        r"(?:rupee|inr|dollar|usd|euro|eur|yen|jpy|pound|gbp)\b",
        r"\b(exchange|conversion)\s*rate\s*(?:of|for|between)?\b",
    ]),
    # =====================================================================
    # General web / knowledge intents (the ChatGPT-style surface)
    # =====================================================================
    ("web.define", [
        r"\b(definition\s*of|define|meaning\s*of|what\s*does\s*[\w\s-]{2,30}\bmean\b|"
        r"synonyms?|antonyms?|opposite\s*of|how\s*(?:do\s*you|to)\s*spell|spelling\s*of|"
        r"words?\s*(?:that\s*)?means?|rhym\w+|homophone|thesaurus)\b",
    ]),
    ("web.weather", [
        r"\b(weather|temperature|forecast|rain\w*|humidit\w*|wind\s*speed|will\s*it\s*rain|"
        r"heat\s*wave|how\s*(?:hot|cold|warm)\s*(?:is|will)\b|uv\s*index|air\s*quality)\b",
    ]),
    ("web.exchange", [
        r"\b(exchange\s*rates?|currency\s*conver\w*|convert\s*\d[\d,.]*\s*"
        r"(?:usd|eur|inr|gbp|jpy|aud|cad|chf|aed|sgd)|how\s*many\s*(?:rupees|dollars|euros|"
        r"pounds|yen)\s*(?:is|are|in|for))\b",
    ]),
    ("web.time", [
        # NOTE: no trailing \b after the group — "time in tokyo" ends mid-word
        r"\btime\s+in\s+(?!(?:the\s+)?(?:gym|office|kitchen|morning|evening|afternoon|past|"
        r"future|meantime|world|end|my|his|her|their|our|some|any|no|free|quality|spend|kill|"
        r"pass|waste|good|trouble|a\s+(?:long|short|while))\b)[a-z][\w\s]{1,24}",
        r"\b(?:current|local|present)\s+time\b",
        r"\bwhat(?:'s|\s+is)?\s+the\s+time\b|\bwhat\s+time\s+is\s+it\b",
        r"\btime\s*zones?\b|\btimezone\s+conver\w+\b",
        r"\bconvert\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?\s*(?:to|in)\b",
        r"\b(?:ist|utc|gmt|est|pst|cet)\s+to\s+(?:ist|utc|gmt|est|pst|cet)\b",
        r"\bdays?\s+until\b|\bcountdown\s+to\b|\btime\s+difference\s+between\b",
    ]),
    ("web.news", [
        r"\b(latest\s*news|news\s*headlines?|headlines?|breaking\s*news|today'?s\s*news|"
        r"news\s*(?:about|on|for)\b|what'?s\s*happening\s*in)\b",
    ]),
    ("web.arxiv", [
        r"\b(arxiv|research\s*papers?|academic\s*papers?|peer\s*reviewed|scientific\s*papers?|"
        r"journal\s*articles?|scholarly)\b",
    ]),
    ("web.github", [
        r"\b(github|open\s*source\s*(?:projects?|repos?)|repositor\w+\s*(?:for|of|about)|"
        r"trending\s*repos?|code\s*search)\b",
    ]),
    ("web.wiki", [
        r"\b(wikipedia|who\s*(?:is|was|are)\b|history\s*of|biograph\w+|tell\s*me\s*about|"
        r"summar\w+\s+(?:the|a)\s+(?:book|topic|concept)|what\s*is\s*the\s*(?:capital|"
        r"population|president|ceo|founder))\b",
    ]),
    ("web.image", [
        r"\b(find|show|search|get|download|need)\b.{0,25}\b(images?|photos?|pictures?|"
        r"wallpapers?|clipart|stock\s*photos?|icons?)\b",
    ]),
    ("web.search", [
        r"\b(search|google|look\s*up|find\s*(?:me|out)|any\s*info(?:rmation)?\s*(?:on|about)|"
        r"quick\s*fact)\b",
    ]),
    # =====================================================================
    # Math / quantitative intents — before data.analyse, which would
    # otherwise claim anything containing "mean", "statistics" or "trend".
    # =====================================================================
    ("math.finance", [
        r"\b(emi|sip|compound\s*interest|simple\s*interest|loans?|gst\b|cagr|roi\b|"
        r"return\s*on\s*investment|amortis\w+|amortiz\w+|mutual\s*fund\s*returns?|npv|irr|"
        r"discount\s*rate|inflation\s*adjust\w*|present\s*value|future\s*value|annuit\w+)\b",
    ]),
    ("math.calculus", [
        r"\b(derivativ\w+|differentiat\w+|integrals?|integrat\w+|limits?\s*of|differentials?|"
        r"partial\s*derivativ\w+|taylor\s*series|d/dx|slope\s*of\s*(?:the\s*)?curve)\b",
    ]),
    ("math.algebra", [
        r"\b(solve\s*(?:for|this)?|equations?|quadratic|factoris\w+|factoriz\w+|expand|"
        r"simplif\w+\s*(?:the\s+)?(?:expression|equation)|polynomials?|simultaneous|"
        r"inequalit\w+|roots?\s*of|find\s*(?:the\s+)?(?:value\s*of\s*x|solution))\b",
        r"[a-z0-9\)\s]{0,20}=\s*[a-z0-9\(\)\+\-\*/\^\.\s]{2,}",
    ]),
    ("math.statistics", [
        r"^(?!.*\b(?:csv|xlsx|excel|spreadsheet|dataset|dataframe|file|folder|dark\s+mode|"
        r"night\s+mode|safe\s+mode|driving\s+mode)\b).*"
        r"\b(mean|median|standard\s*deviation|variance|percentil\w+|probabilit\w+|"
        r"regressions?|z\s*scores?|confidence\s*intervals?|distributions?|odds|"
        r"expected\s*value|dice|coin\s*flip|random\s*numbers?)\b",
        r"\b(?:the\s+)?mode\s+(?:of|is|for\s+the\s+data)\b|\bmean\s+(?:and|,)\s*"
        r"(?:the\s+)?(?:median|mode)\b|\baverag\w+\s+(?:of|the)\s+[\d\s,.]+\b",
    ]),
    ("math.matrix", [
        r"\b(matrix|matrices|determinants?|eigen\w*|inverse\s*(?:of\s*)?(?:a\s*)?matri\w+|"
        r"transpos\w+|linear\s*systems?|matrix\s*multiplicat\w+)\b",
    ]),
    ("math.geometry", [
        r"\b(area\s*of|volume\s*of|perimeters?|circumference|pythagoras|hypotenus\w+|"
        r"triangles?|circles?|spheres?|cylinders?|cones?|rectangles?|polygons?|"
        r"angle\s*between|surface\s*area)\b",
    ]),
    ("math.number", [
        r"\b(primes?|is\s*\d+\s*prime|gcd|hcf|lcm|factorials?|fibonacci|divisors?|"
        r"modul\w+|base\s*(?:2|8|16)|hex(?:adecimal)?\s*(?:of|value|convert)|"
        r"roman\s*numerals?|binary\s*(?:of|number|convert))\b",
    ]),
    ("math.date", [
        r"\b(days?\s*between|date\s*differenc\w*|how\s*old\s*(?:am|is|are)|age\s*calculat\w*|"
        r"weekday|day\s*of\s*the\s*week|add\s*\d+\s*(?:days?|weeks?|months?|years?)|"
        r"business\s*days?|leap\s*year|next\s*(?:birthday|anniversary))\b",
    ]),
    ("math.convert", [
        r"\b(convert|conver\w+|how\s*many)\b.{0,40}\b(km|kilomet\w*|metres?|meters?|miles?|"
        r"feet|foot|inch(?:es)?|kg|kilograms?|grams?|pounds?|ounces?|litres?|liters?|gallons?|"
        r"celsius|fahrenheit|kelvin|hours?|minutes?|seconds?|days?|weeks?|months?|years?|"
        r"bytes?|kb|mb|gb|tb|acres?|hectares?)\b",
        r"\b\d+(?:\.\d+)?\s*(?:km|mi|ft|in|kg|lb|oz|gal|gb|mb|tb|cm|mm|ml)\s*(?:to|in|into)\s*\w",
    ]),
    ("math.calculate", [
        r"^(?!.*\b(?:csv|xlsx|excel|spreadsheet|dataset|dataframe|file|folder)\b).*"
        r"\b(calculate|compute|work\s*out|evaluate|square\s*roots?|sqrt|percentage\s*of|"
        r"\d+\s*%\s*(?:of|increase|decrease)|round\s*(?:off|to)|significant\s*figures?|"
        r"what\s*(?:is|are)\s*[\d(])\b",
    ]),
    ("chat.general", [
        r"^\s*-?\d[\d,.\s]*(?:[+\-*/x×÷%^]|plus|minus|times|divided\s+by)\s*-?[\d,.]+",
        r"\bwhat\s+is\s+\d[\d,.\s]*(?:[+\-*/x×÷%^]|plus|minus|times)\b",
        r"\b(calculate|compute|how\s+much\s+is)\b.*\d",
        r"^(what|who|where|when|why|how)\b(?!.{0,80}\b(file|folder|document|invoice|photo|image|"
        r"pdf|download|desktop|email|mail|battery|cpu|ram|disk|storage|phone|mobile|wifi|"
        r"bluetooth|volume|brightness|notification|chrome|notepad|window|screen|git|npm|pip|"
        r"docker|error|errors|bug|bugs|exception|traceback|code|script|function|api|project|"
        r"invoice|receipt|resume|screenshot|csv|excel|spreadsheet|analyse|analyze|organise|organize|chart|graph|tests?)\b).{0,60}\?$",
        r"\b(tell\s+me\s+(about|a\s+story|a\s+joke)|explain\s+(?:it|that|this)|continue|go\s+on)\b",
    ]),
    ("research.deep", [
        r"\b(research|investigate|find\s*out|who\s+is|how\s+does|latest|news|price\s+of)\b",
        # a bare "what is/why" is research only when it is NOT about something
        # SAM can read locally (calendar, inbox, files, tasks, the PC, memory)
        r"\b(?:what\s+(?:is|are|was|were)|why)\b(?!.{0,60}\b(?:calendar|schedule|meeting|"
        r"appointment|reminder|email|emails|mail|inbox|message|messages|file|files|folder|"
        r"document|task|tasks|memory|screen|volume|battery|cpu|ram|disk|storage|phone|"
        r"notification|window|app|apps|journal|alert|alerts|watchlist|portfolio)\b)",
    ]),
    ("coding.test", [
        r"\b(run|execute|do)\b.{0,20}\b(tests?|test\s*suite|pytest|unittest|jest|specs?)\b",
        r"\b(test)\b.{0,15}\b(my|the|this)\b.{0,20}\b(code|project|app|changes?)\b",
    ]),
    ("coding.write", [r"\b(write|create|build|generate|make)\b.*\b(code|script|function|class|api|app|website|program|python|javascript|java|c\+\+|sql|regex|html|css)\b"]),
    ("coding.debug", [r"\b(debug|fix|error|bug|exception|traceback|not\s+working|failing|broken)\b.*"
                      r"\b(code|script|function|app|program|build|test|python|java|node|api)?\b",
                      r"\bwhy\s+(does|is|did)\b.*\b(fail|crash|break|error)\b"]),
    ("coding.explain", [r"\b(explain|understand|walk\s*me\s*through|what\s+does\s+this\s+code)\b"]),
    ("document.create", [r"\b(create|write|make|generate|draft)\b.*\b(document|report|resume|cv|letter|essay|article|blog|email|presentation|slides|ppt|spreadsheet|invoice|proposal)\b"]),
    ("data.analyse", [
        r"\b(analys|analyz|chart|graph|plot|pivot|statistics|mean|average|trend|correlat)(?:e|ed|ing|is|es)?\b",
        r"\b(csv|xlsx|excel|spreadsheet|dataset|dataframe)s?\b.*\b(analys|analyz|summar|chart|plot|clean)(?:e|ed|ing)?\b",
        r"\b(analys|analyz|summaris|summariz|chart|plot|clean)(?:e|ed|ing)?\b.{0,25}"
        r"\b(csv|xlsx|excel|spreadsheet|dataset|dataframe|table|numbers|sales|metrics)\b",
    ]),
    ("image.generate", [r"\b(generate|create|draw|design|make)\b.*\b(image|picture|logo|poster|thumbnail|wallpaper|illustration|icon|banner)\b"]),
    ("image.edit", [r"\b(edit|crop|resize|remove\s+background|enhance|retouch|upscale|filter)\b.*\b(image|photo|picture)\b"]),
    ("email.send", [
        r"\b(send|email|mail|reply)\b.*\b(email|mail|message|him|her|them|boss|client)\b",
        # "email john about the meeting", "mail the invoice to accounts"
        r"\b(email|mail)\s+[\w.+-]+@[\w.-]+\b",
        r"\b(email|mail|message|write\s+to)\s+(?:him|her|them|my\s+\w+|the\s+\w+|"
        r"[A-Z][a-z]{2,})\b.*\b(about|regarding|that|with|to|asking|saying)\b",
        r"\b(send|email)\b.*\b(about|regarding)\b.*\b(meeting|invoice|report|update|"
        r"deadline|quote|proposal|reminder)\b",
    ]),
    ("email.read", [
        r"\b(read|check|unread|inbox|summaris|summariz|show|list|any)\b.*\b(?:email|mail|inbox)s?\b",
        r"\b(?:my|the)\s+(?:inbox|emails?|mails?)\b",
    ]),
    ("calendar.manage", [r"\b(schedule|meeting|appointment|calendar|remind\s+me|reminder|event)\b"]),
    ("timer.set", [r"\b(set|start)\b.*\b(timer|alarm|countdown)\b", r"\bremind\s+me\s+(in|at|to)\b"]),
    ("memory.store", [r"\b(remember|note\s+that|save\s+this|keep\s+in\s+mind|don'?t\s+forget)\b"]),
    ("memory.recall", [r"\b(what\s+do\s+you\s+remember|recall|do\s+you\s+know\s+my|my\s+preference)\b"]),
    ("automation.create", [r"\b(every\s+(day|week|hour|morning|evening|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|automate|whenever|when\s+i)\b"]),
    ("security.status", [
        r"\b(permission|permissions|security|risk|audit|what\s+are\s+you\s+allowed)\b",
        r"\bwhat\s+(did|has|have)\s+(sam|you)\s+(do|did|done|run|execute|change)\b",
        r"\baction\s+history\b",
    ]),
    ("sam.status", [
        r"\b(status|health|how\s+are\s+you|are\s+you\s+(there|ok|online)|agents?\s+online|dashboard)\b",
        r"\b(?:my|the|open|running|pending|recent|all|active)\s+tasks?\b",
        r"\btask\s+(?:list|queue|center|centre|history)\b",
        r"\bwhat\s+(?:am\s+i|are\s+we)\s+(?:doing|running|waiting)\b",
    ]),
    ("translate", [r"\b(translate|translation|say\s+.*\s+in\s+(hindi|kannada|tamil|telugu|french|german|spanish|japanese))\b"]),
    ("greeting", [r"^(hi|hey|hello|yo|namaste|namaskara|good\s+(morning|afternoon|evening))\b"]),
    ("farewell", [r"\b(bye|goodbye|see\s+you|good\s+night|thanks?\b|thank\s+you|shukriya|dhanyavada)\b"]),
    ("help", [r"\b(help|what\s+can\s+you\s+do|how\s+do\s+i\s+use|commands?|capabilities)\b"]),
]


def classify_intent(text: str) -> Tuple[str, float]:
    """Return ``(intent, confidence)``. Confidence is heuristic 0..1."""
    if not text:
        return "chat.general", 0.0
    low = text.lower().strip()
    for intent, patterns in INTENT_PATTERNS:
        for p in patterns:
            m = re.search(p, low)
            if m:
                # longer, more specific matches score higher
                conf = min(0.95, 0.55 + 0.05 * len(m.group(0).split()))
                return intent, round(conf, 2)
    if low.endswith("?"):
        return "research.deep", 0.4
    return "chat.general", 0.3


def intent_to_agent(intent: str) -> str:
    table = {
        "pc.": "pc", "files.": "files", "terminal.": "pc", "browser.": "browser",
        "research.": "research", "coding.": "coding", "document.": "writing",
        "data.": "data", "image.": "creative", "email.": "communication",
        "calendar.": "planning", "timer.": "planning", "phone.": "phone",
        "memory.": "memory", "automation.": "planning", "security.": "security",
        "sam.": "core", "translate": "communication", "greeting": "communication",
        "farewell": "communication", "help": "core",
        "market.": "markets", "web.": "research", "math.": "reasoning",
    }
    for prefix, agent in table.items():
        if intent.startswith(prefix):
            return agent
    return "core"


def intent_to_device(intent: str) -> str:
    if intent.startswith("phone."):
        return "phone"
    if intent.startswith("browser."):
        return "browser"
    if intent.startswith(("research.", "web.", "market.")):
        return "cloud"          # needs the network: web lookups and live prices
    if intent.startswith("math."):
        return "pc"             # pure local computation
    return "pc"


# ===========================================================================
# Response synthesis
# ===========================================================================
GREETINGS = [
    "Hey — SAM online. What do you need?",
    "Hello. All agents are ready. What should I do?",
    "Hi there. Listening.",
]

HELP_TEXT = """I'm SAM — your personal AI operating platform. Here's what I can do:

PC        open/close apps, manage windows, keyboard + mouse automation,
          screenshots and UI understanding, system health, power control
FILES     search, organise, rename, convert, zip, back up, read PDF/DOCX/XLSX
TERMINAL  run PowerShell / cmd / git / python / npm with a risk check first
BROWSER   open pages, read and extract content, fill forms, download files
RESEARCH  multi-source search, cross-check, summarise with citations
CODING    scaffold projects, write and debug code, run tests, explain code
CREATIVE  images, logos, posters, slides, documents, social content
PHONE     battery/wifi/storage state, apps, alarms, notifications, messages
MEMORY    remember preferences, projects and facts you approve
AUTOMATE  schedules, recurring jobs, WHEN -> IF -> DO -> VERIFY rules
SECURITY  every action passes a permission + risk + confirmation + audit gate

Just say it in plain language — or ask for the dashboard you want to see."""

STATUS_TEMPLATE = """SAM status — {time}

Mode            {mode}
Host            {host}
Uptime          {uptime}
Providers       {providers}
Agents online   {agents}
Active tasks    {tasks}
Risk mode       {risk}
Memory items    {memory}

Everything nominal. Say the word and I'll start."""


def respond(prompt: str, system: str = "", json_mode: bool = False, role: str = "primary") -> str:
    """Produce a helpful offline answer for ``prompt``."""
    text = (prompt or "").strip()
    if not text:
        return "I didn't catch that — could you repeat it?"

    low = text.lower()
    lang = detect_language(text)
    intent, _conf = classify_intent(text)

    if json_mode:
        return _json_answer(text, intent, lang)

    # ---- localised short replies ---------------------------------------
    if lang == "hi":
        return _hindi_reply(intent, text)
    if lang == "kn":
        return _kannada_reply(intent, text)

    # ---- direct intents -------------------------------------------------
    if intent == "help":
        return HELP_TEXT
    if intent == "greeting":
        return random.choice(GREETINGS)
    if intent == "farewell":
        return "Anytime. I'm here when you need me."
    if intent == "security.status":
        return ("Every SAM action passes four gates: permission, risk scoring, "
                "confirmation and audit. Open the Security Center to see the full "
                "capability list and change what's allowed.")
    if intent.startswith("pc.power"):
        action = re.search(r"\b(lock|sleep|restart|reboot|shutdown|sign\s*out)\b", low)
        what = action.group(1) if action else "change the power state"
        return (f"That's a system power action ({what}). It needs PC_POWER_CONTROL_ENABLED=true "
                f"and your explicit confirmation. Say \"confirm {what}\" and I'll queue it.")
    if intent.startswith("files.search"):
        return ("I can search by filename, extension, date, size, full text content and meaning. "
                "Tell me the folder to search and what you're looking for and I'll build the query.")
    if intent.startswith("coding.write"):
        return ("I can scaffold that. Tell me the language, the framework and what it must do, "
                "and I'll generate the project, run it and fix the errors before handing it over.")
    if intent.startswith("research.deep"):
        return ("I'll research that across several sources, cross-check them and give you a summary "
                "with citations. Note: web access needs RESEARCH permission and internet connectivity.")
    if intent.startswith("image.generate"):
        return ("I can generate that image through the Creative Brain. Give me the subject, style, "
                "aspect ratio and mood, and I'll produce options for you to pick from.")
    if intent.startswith("document.create"):
        return ("I'll build that document. Confirm the format (DOCX, PDF, PPTX, XLSX or Markdown), "
                "the sections you want and the tone, and I'll draft it for your review.")
    if intent.startswith("automation.create"):
        return ("I can automate that with a WHEN -> IF -> DO -> VERIFY rule. Tell me the trigger "
                "(time, interval, event or condition) and the action, and I'll register it.")
    if intent.startswith("phone."):
        return ("That runs on your Android device through the SAM Companion app. It must be paired "
                "and the matching Android permission granted before I can act.")
    if intent.startswith("memory."):
        return ("I've noted that. Long-term memory only stores what you approve — you can view, edit "
                "or erase any of it from the Memory dashboard.")

    # ---- generic fallback ------------------------------------------------
    if intent == "research.deep" or low.endswith("?"):
        return _answer_question(text)

    return (
        f"I parsed that as intent `{intent}` in {lang.upper()}. "
        f"No cloud or local model is configured yet, so this is SAM's built-in offline engine answering. "
        f"Add a provider key to `.env` (or install Ollama) and I'll route this to a real model. "
        f"Meanwhile I can still run every tool: PC control, files, browser, coding, scheduling and research."
    )


def _answer_question(text: str) -> str:
    q = text.strip().rstrip("?")
    return (
        f"You asked: \"{q}\".\n\n"
        "I'm running on SAM's offline rule engine right now, so I won't guess at an answer.\n"
        "Two ways to get a real one:\n"
        "  1. Add a model key to .env (OpenAI / Anthropic / Groq / OpenRouter), or\n"
        "  2. Install Ollama and run `ollama pull llama3.1:8b` for a fully local brain.\n\n"
        "Once a model is available I'll research this across sources, cross-check and cite them."
    )


def _json_answer(text: str, intent: str, lang: str) -> str:
    import json

    return json.dumps(
        {
            "reply": respond(text),
            "intent": intent,
            "language": lang,
            "provider": "heuristic",
            "offline": True,
        },
        ensure_ascii=False,
        indent=2,
    )


def _hindi_reply(intent: str, text: str) -> str:
    if intent == "greeting":
        return "नमस्ते! SAM ऑनलाइन है। बताइए क्या करना है?"
    if intent == "help":
        return ("मैं SAM हूँ। मैं आपका PC, फ़ाइलें, ब्राउज़र, फ़ोन, कोडिंग, रिसर्च, डॉक्यूमेंट, "
                "इमेज और शेड्यूल — सब कुछ संभाल सकता हूँ। हर काम से पहले अनुमति और जोखिम जाँच होती है।")
    if intent == "farewell":
        return "ठीक है, धन्यवाद! ज़रूरत हो तो बुला लेना।"
    if intent.startswith("pc."):
        return f"समझ गया — यह PC पर करना है: \"{text}\". पुष्टि कर दीजिए, मैं चालू करता हूँ।"
    if intent.startswith("files."):
        return f"फ़ाइल का काम: \"{text}\". फ़ोल्डर और नाम बता दीजिए, मैं ढूँढ़ देता हूँ।"
    return (
        f"मैंने इसे हिंदी में समझा (intent: {intent})। अभी कोई AI मॉडल कॉन्फ़िगर नहीं है, "
        f"इसलिए SAM का ऑफ़लाइन इंजन जवाब दे रहा है। .env में key डालिए या Ollama इंस्टॉल कीजिए — "
        f"फिर मैं पूरा जवाब दे पाऊँगा।"
    )


def _kannada_reply(intent: str, text: str) -> str:
    if intent == "greeting":
        return "ನಮಸ್ಕಾರ! SAM ಆನ್‌ಲೈನ್ ಇದೆ. ಏನು ಮಾಡಲಿ?"
    if intent == "help":
        return ("ನಾನು SAM. ನಿಮ್ಮ PC, ಫೈಲ್‌ಗಳು, ಬ್ರೌಸರ್, ಫೋನ್, ಕೋಡಿಂಗ್, ರಿಸರ್ಚ್, ಡಾಕ್ಯುಮೆಂಟ್, "
                "ಇಮೇಜ್ ಮತ್ತು ಶೆಡ್ಯೂಲ್ — ಎಲ್ಲವನ್ನೂ ನಿಭಾಯಿಸುತ್ತೇನೆ.")
    if intent == "farewell":
        return "ಸರಿ, ಧನ್ಯವಾದಗಳು! ಬೇಕಾದಾಗ ಕರೆಯಿರಿ."
    return (
        f"ಇದನ್ನು ಕನ್ನಡದಲ್ಲಿ ಅರ್ಥಮಾಡಿಕೊಂಡೆ (intent: {intent}). ಇನ್ನೂ ಯಾವುದೇ AI ಮಾಡೆಲ್ ಸೆಟ್ ಆಗಿಲ್ಲ, "
        f"ಆದ್ದರಿಂದ SAM ನ ಆಫ್‌ಲೈನ್ ಎಂಜಿನ್ ಉತ್ತರಿಸುತ್ತಿದೆ."
    )


# ---------------------------------------------------------------------------
# Small utility used by several agents
# ---------------------------------------------------------------------------
def system_blurb() -> str:
    return (
        f"OS={platform.system()} {platform.release()} | Python={platform.python_version()} | "
        f"CPU={platform.processor() or platform.machine()} | host={platform.node()}"
    )


def summarize_text(text: str, max_sentences: int = 3) -> str:
    """Extractive summary used when no model is available."""
    if not text:
        return ""
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if s.strip()]
    if len(sentences) <= max_sentences:
        return " ".join(sentences)
    scored: List[Tuple[float, str]] = []
    freq: Dict[str, int] = {}
    for w in re.findall(r"[a-zA-Z\u0900-\u097F\u0C80-\u0CFF]{4,}", text.lower()):
        freq[w] = freq.get(w, 0) + 1
    for s in sentences:
        words = re.findall(r"[a-zA-Z\u0900-\u097F\u0C80-\u0CFF]{4,}", s.lower())
        if not words:
            continue
        scored.append((sum(freq.get(w, 0) for w in words) / len(words), s))
    scored.sort(reverse=True, key=lambda x: x[0])
    picked = scored[:max_sentences]
    order = {s: i for i, s in enumerate(sentences)}
    picked.sort(key=lambda x: order.get(x[1], 999))
    return " ".join(s for _, s in picked)
