"""
backend.app.providers.anthropic_provider
========================================

Claude via the Anthropic Messages API (streaming + tool use + vision).
Enabled automatically when ``ANTHROPIC_API_KEY`` is present in ``.env``.
"""

from __future__ import annotations

import json
import time
from typing import Any, AsyncIterator, Dict, List, Optional

import httpx

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.models.base import ChatMessage, ModelInfo, ModelProvider, ModelRequest, ModelResponse

log = get_logger("providers.anthropic")

CATALOG = [
    ModelInfo("anthropic", "claude-sonnet-4-5", ["primary", "reasoning", "coding", "vision"],
              200000, True, True, True, quality=5, speed=4, privacy=1),
    ModelInfo("anthropic", "claude-opus-4-1", ["reasoning", "coding"], 200000, True, True, True,
              quality=5, speed=2, privacy=1),
    ModelInfo("anthropic", "claude-haiku-4-5", ["fast", "translation", "vision"], 200000, True, True, True,
              quality=4, speed=5, privacy=1),
]


class AnthropicProvider(ModelProvider):
    name = "anthropic"
    is_local = False
    priority = 18

    def __init__(self, api_key: str = "") -> None:
        super().__init__()
        self.api_key = api_key or settings.anthropic_api_key
        self.base_url = settings.anthropic_base_url.rstrip("/")
        self._client: Optional[httpx.AsyncClient] = None

    def available(self) -> bool:
        return bool(self.api_key) and settings.cloud_enabled

    def models(self) -> List[ModelInfo]:
        return list(CATALOG)

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=180.0,
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
            )
        return self._client

    def _payload(self, req: ModelRequest, model: str) -> Dict[str, Any]:
        system_parts: List[str] = []
        messages: List[Dict[str, Any]] = []
        for m in self.merge_system(req):
            if m.role == "system":
                system_parts.append(m.content)
                continue
            if m.images:
                blocks: List[Dict[str, Any]] = []
                for img in m.images:
                    if img.startswith("data:"):
                        header, _, b64 = img.partition(",")
                        media_type = header[5:].split(";")[0] or "image/png"
                        blocks.append({"type": "image", "source":
                                       {"type": "base64", "media_type": media_type, "data": b64}})
                    else:
                        from backend.app.providers.openai_compat import _file_to_data_url
                        data_url = _file_to_data_url(img)
                        header, _, b64 = data_url.partition(",")
                        blocks.append({"type": "image", "source":
                                       {"type": "base64", "media_type": header[5:].split(";")[0], "data": b64}})
                if m.content:
                    blocks.append({"type": "text", "text": m.content})
                messages.append({"role": m.role, "content": blocks})
            else:
                messages.append({"role": m.role, "content": m.content})

        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "max_tokens": req.max_tokens,
            "temperature": req.temperature,
            "stream": bool(req.stream),
        }
        if system_parts:
            payload["system"] = "\n\n".join(system_parts)
        if req.stop:
            payload["stop_sequences"] = req.stop
        if req.tools:
            payload["tools"] = [
                {"name": t.get("function", {}).get("name", t.get("name", "")),
                 "description": t.get("function", {}).get("description", t.get("description", "")),
                 "input_schema": t.get("function", {}).get("parameters", t.get("parameters", {}))}
                for t in req.tools
            ]
        return payload

    def _default_model(self, role: str) -> str:
        for m in CATALOG:
            if role in m.roles:
                return m.model
        return CATALOG[0].model

    async def complete(self, req: ModelRequest) -> ModelResponse:
        if not self.available():
            return ModelResponse(text="", provider=self.name, model="", role=req.role,
                                 error="anthropic provider is not configured")
        model = req.model or self._default_model(req.role)
        t0 = time.perf_counter()
        try:
            client = await self._http()
            resp = await client.post(f"{self.base_url}/v1/messages",
                                     json=self._payload(req, model), timeout=req.timeout)
            if resp.status_code >= 400:
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:400]}")
            data = resp.json()
        except Exception as exc:
            self.mark_failure(str(exc))
            log.warning("anthropic completion failed: %s", exc)
            return ModelResponse(text="", provider=self.name, model=model, role=req.role, error=str(exc))

        self.mark_success()
        text_parts: List[str] = []
        tool_calls: List[Dict[str, Any]] = []
        for block in data.get("content", []):
            if block.get("type") == "text":
                text_parts.append(block.get("text", ""))
            elif block.get("type") == "tool_use":
                tool_calls.append({"id": block.get("id"), "name": block.get("name"),
                                   "arguments": json.dumps(block.get("input", {}))})
        usage = data.get("usage", {}) or {}
        return ModelResponse(
            text="".join(text_parts),
            provider=self.name,
            model=data.get("model", model),
            role=req.role,
            prompt_tokens=int(usage.get("input_tokens", 0) or 0),
            completion_tokens=int(usage.get("output_tokens", 0) or 0),
            total_tokens=int(usage.get("input_tokens", 0) or 0) + int(usage.get("output_tokens", 0) or 0),
            latency_ms=int((time.perf_counter() - t0) * 1000),
            finish_reason=data.get("stop_reason", "end_turn") or "stop",
            tool_calls=tool_calls,
            raw=data,
        )

    async def stream(self, req: ModelRequest) -> AsyncIterator[str]:
        if not self.available():
            res = await self.complete(req)
            if res.text:
                yield res.text
            return
        model = req.model or self._default_model(req.role)
        payload = self._payload(req, model)
        payload["stream"] = True
        try:
            client = await self._http()
            async with client.stream("POST", f"{self.base_url}/v1/messages",
                                     json=payload, timeout=req.timeout) as resp:
                if resp.status_code >= 400:
                    body = await resp.aread()
                    raise RuntimeError(f"HTTP {resp.status_code}: {body[:300]!r}")
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    try:
                        ev = json.loads(line[5:].strip())
                    except Exception:
                        continue
                    if ev.get("type") == "content_block_delta":
                        delta = ev.get("delta", {})
                        if delta.get("type") == "text_delta" and delta.get("text"):
                            yield delta["text"]
                    elif ev.get("type") == "message_stop":
                        break
            self.mark_success()
        except Exception as exc:
            self.mark_failure(str(exc))
            log.warning("anthropic stream failed: %s", exc)

    async def aclose(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
