"""
backend.app.providers.openai_compat
===================================

One provider class that speaks the OpenAI Chat Completions protocol, which is
also what Groq, OpenRouter, Mistral, Together, DeepSeek, LM Studio and
vLLM expose. Configure it per-vendor through ``.env``.

Works with the official ``openai`` SDK when installed, and falls back to a raw
``httpx`` implementation otherwise — so SAM keeps running in minimal setups.
"""

from __future__ import annotations

import json
from typing import Any, AsyncIterator, Dict, List, Optional

import httpx

from backend.app.config import settings
from backend.app.core.logging_config import get_logger
from backend.app.models.base import ChatMessage, ModelInfo, ModelProvider, ModelRequest, ModelResponse

log = get_logger("providers.openai")


class OpenAICompatProvider(ModelProvider):
    name = "openai"
    is_local = False
    priority = 20

    def __init__(
        self,
        *,
        name: str = "openai",
        api_key: str = "",
        base_url: str = "https://api.openai.com/v1",
        catalog: Optional[List[ModelInfo]] = None,
        priority: int = 20,
    ) -> None:
        super().__init__()
        self.name = name
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.priority = priority
        self._catalog = catalog or []
        self._client: Optional[httpx.AsyncClient] = None

    # ------------------------------------------------------------------ api
    def available(self) -> bool:
        return bool(self.api_key) and settings.cloud_enabled

    def models(self) -> List[ModelInfo]:
        return [m for m in self._catalog if m.enabled]

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=180.0, headers=self._headers())
        return self._client

    def _payload(self, req: ModelRequest, model: str) -> Dict[str, Any]:
        msgs: List[Dict[str, Any]] = []
        for m in self.merge_system(req):
            if m.images:
                content: List[Dict[str, Any]] = [{"type": "text", "text": m.content}]
                for img in m.images:
                    url = img if img.startswith(("http://", "https://", "data:")) else _file_to_data_url(img)
                    content.append({"type": "image_url", "image_url": {"url": url}})
                msgs.append({"role": m.role, "content": content})
            else:
                msgs.append({"role": m.role, "content": m.content})

        payload: Dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "temperature": req.temperature,
            "max_tokens": req.max_tokens,
            "top_p": req.top_p,
            "stream": bool(req.stream),
        }
        if req.stop:
            payload["stop"] = req.stop
        if req.json_mode:
            payload["response_format"] = {"type": "json_object"}
        if req.tools:
            payload["tools"] = req.tools
            payload["tool_choice"] = "auto"
        return payload

    # ------------------------------------------------------------- complete
    async def complete(self, req: ModelRequest) -> ModelResponse:
        import time

        if not self.available():
            return ModelResponse(text="", provider=self.name, model=req.model or "", role=req.role,
                                 error=f"{self.name} provider is not configured")

        model = req.model or self._default_model(req.role)
        t0 = time.perf_counter()
        try:
            client = await self._http()
            resp = await client.post(f"{self.base_url}/chat/completions",
                                     json=self._payload(req, model), timeout=req.timeout)
            if resp.status_code >= 400:
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:400]}")
            data = resp.json()
        except Exception as exc:
            self.mark_failure(str(exc))
            log.warning("%s completion failed: %s", self.name, exc)
            return ModelResponse(text="", provider=self.name, model=model, role=req.role, error=str(exc))

        self.mark_success()
        try:
            choice = data["choices"][0]
            msg = choice.get("message", {})
            usage = data.get("usage", {}) or {}
            return ModelResponse(
                text=msg.get("content") or "",
                provider=self.name,
                model=data.get("model", model),
                role=req.role,
                prompt_tokens=int(usage.get("prompt_tokens", 0) or 0),
                completion_tokens=int(usage.get("completion_tokens", 0) or 0),
                total_tokens=int(usage.get("total_tokens", 0) or 0),
                latency_ms=int((time.perf_counter() - t0) * 1000),
                finish_reason=choice.get("finish_reason", "stop"),
                tool_calls=msg.get("tool_calls") or [],
                raw=data,
                local=False,
            )
        except Exception as exc:
            return ModelResponse(text="", provider=self.name, model=model, role=req.role,
                                 error=f"malformed response: {exc}", raw=data)

    # --------------------------------------------------------------- stream
    async def stream(self, req: ModelRequest) -> AsyncIterator[str]:
        if not self.available():
            res = await self.complete(req)
            if res.text:
                yield res.text
            return

        model = req.model or self._default_model(req.role)
        payload = self._payload(req, model)
        payload["stream"] = True
        try:
            client = await self._http()
            async with client.stream("POST", f"{self.base_url}/chat/completions",
                                     json=payload, timeout=req.timeout) as resp:
                if resp.status_code >= 400:
                    body = await resp.aread()
                    raise RuntimeError(f"HTTP {resp.status_code}: {body[:300]!r}")
                async for line in resp.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == "[DONE]":
                        break
                    try:
                        obj = json.loads(chunk)
                    except Exception:
                        continue
                    delta = (obj.get("choices") or [{}])[0].get("delta", {})
                    piece = delta.get("content")
                    if piece:
                        yield piece
            self.mark_success()
        except Exception as exc:
            self.mark_failure(str(exc))
            log.warning("%s stream failed: %s", self.name, exc)

    # -------------------------------------------------------------- helpers
    def _default_model(self, role: str) -> str:
        for m in self._catalog:
            if role in m.roles:
                return m.model
        return self._catalog[0].model if self._catalog else "gpt-4o-mini"

    async def aclose(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


def _file_to_data_url(path: str) -> str:
    import base64
    import mimetypes
    from pathlib import Path

    p = Path(path).expanduser()
    mime = mimetypes.guess_type(p.name)[0] or "image/png"
    try:
        b64 = base64.b64encode(p.read_bytes()).decode()
        return f"data:{mime};base64,{b64}"
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Factory: build every OpenAI-compatible vendor the user has a key for
# ---------------------------------------------------------------------------
def build_openai_compat_providers() -> List[OpenAICompatProvider]:
    out: List[OpenAICompatProvider] = []

    if settings.openai_api_key:
        out.append(
            OpenAICompatProvider(
                name="openai",
                api_key=settings.openai_api_key,
                base_url=settings.openai_base_url,
                priority=20,
                catalog=[
                    ModelInfo("openai", "gpt-4o", ["primary", "vision", "reasoning"], 128000, True, True, True,
                              quality=5, speed=3, privacy=1),
                    ModelInfo("openai", "gpt-4o-mini", ["fast", "primary", "vision", "translation"], 128000,
                              True, True, True, quality=4, speed=4, privacy=1),
                    ModelInfo("openai", "o1-mini", ["reasoning", "coding"], 128000, False, True, False,
                              quality=5, speed=2, privacy=1),
                    ModelInfo("openai", "gpt-4.1-mini", ["coding", "fast"], 1000000, True, True, True,
                              quality=4, speed=4, privacy=1),
                    ModelInfo("openai", "text-embedding-3-small", ["embedding"], 8191, quality=4, speed=5, privacy=1),
                    ModelInfo("openai", "whisper-1", ["stt"], quality=5, speed=3, privacy=1),
                    ModelInfo("openai", "tts-1", ["tts"], quality=4, speed=4, privacy=1),
                    ModelInfo("openai", "gpt-image-1", ["image"], quality=5, speed=2, privacy=1),
                ],
            )
        )

    if settings.groq_api_key:
        out.append(
            OpenAICompatProvider(
                name="groq",
                api_key=settings.groq_api_key,
                base_url="https://api.groq.com/openai/v1",
                priority=15,   # extremely fast -> preferred for the FAST role
                catalog=[
                    ModelInfo("groq", "llama-3.3-70b-versatile", ["fast", "primary", "translation"], 128000,
                              quality=4, speed=5, privacy=1),
                    ModelInfo("groq", "llama-3.1-8b-instant", ["fast"], 128000, quality=3, speed=5, privacy=1),
                    ModelInfo("groq", "whisper-large-v3", ["stt"], quality=5, speed=5, privacy=1),
                ],
            )
        )

    if settings.openrouter_api_key:
        out.append(
            OpenAICompatProvider(
                name="openrouter",
                api_key=settings.openrouter_api_key,
                base_url="https://openrouter.ai/api/v1",
                priority=30,
                catalog=[
                    ModelInfo("openrouter", "anthropic/claude-3.5-sonnet", ["primary", "reasoning", "coding"],
                              200000, True, quality=5, speed=3, privacy=1),
                    ModelInfo("openrouter", "google/gemini-2.0-flash-001", ["fast", "vision"], 1000000,
                              True, quality=4, speed=5, privacy=1),
                    ModelInfo("openrouter", "deepseek/deepseek-chat", ["coding", "fast"], 64000,
                              quality=4, speed=4, privacy=1),
                ],
            )
        )

    if settings.mistral_api_key:
        out.append(
            OpenAICompatProvider(
                name="mistral",
                api_key=settings.mistral_api_key,
                base_url="https://api.mistral.ai/v1",
                priority=35,
                catalog=[
                    ModelInfo("mistral", "mistral-large-latest", ["primary", "reasoning"], 128000,
                              quality=5, speed=3, privacy=1),
                    ModelInfo("mistral", "ministral-8b-latest", ["fast", "translation"], 128000,
                              quality=3, speed=5, privacy=1),
                ],
            )
        )

    if settings.together_api_key:
        out.append(
            OpenAICompatProvider(
                name="together",
                api_key=settings.together_api_key,
                base_url="https://api.together.xyz/v1",
                priority=40,
                catalog=[
                    ModelInfo("together", "Qwen/Qwen2.5-Coder-32B-Instruct", ["coding"], 32000,
                              quality=5, speed=3, privacy=1),
                    ModelInfo("together", "meta-llama/Llama-3.3-70B-Instruct-Turbo", ["primary", "fast"],
                              128000, quality=4, speed=4, privacy=1),
                ],
            )
        )

    return out
