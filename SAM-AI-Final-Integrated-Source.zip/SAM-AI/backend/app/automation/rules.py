"""
backend.app.automation.rules
============================

The Automation Builder's data model and persistence.

A rule is exactly the structure the specification describes::

    WHEN   <trigger>       time | cron | interval | event | file | device | battery | manual
    IF     <condition>     optional extra test before acting
    DO     <actions>       one or more tool calls (or a natural-language instruction)
    VERIFY <check>         how SAM proves the rule worked

Rules are stored in the ``automations`` table so they survive a restart, and are
re-armed at startup by :mod:`backend.app.automation.scheduler`.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from backend.app.core.logging_config import get_logger
from backend.app.core.models import Automation
from backend.app.core.database import session_scope
from sqlalchemy import select

log = get_logger("automation.rules")

WHEN_TYPES = {
    "time", "cron", "interval", "event", "manual", "file", "device",
    "battery", "idle", "startup", "condition", "notification",
}


@dataclass
class AutomationAction:
    """One step of the DO clause."""

    tool: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    instruction: str = ""          # natural-language fallback when no tool matched
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Any) -> "AutomationAction":
        if isinstance(data, str):
            return cls(instruction=data, description=data[:120])
        if not isinstance(data, dict):
            return cls()
        return cls(tool=str(data.get("tool") or ""), params=dict(data.get("params") or {}),
                   instruction=str(data.get("instruction") or ""),
                   description=str(data.get("description") or ""))


@dataclass
class AutomationRule:
    id: str = ""
    name: str = ""
    description: str = ""
    when: str = "manual"                                   # human description of the trigger
    when_type: str = "manual"
    trigger: Dict[str, Any] = field(default_factory=dict)  # {"kind","cron","at","seconds","event"}
    condition: str = ""                                    # optional IF expression
    condition_data: Dict[str, Any] = field(default_factory=dict)
    actions: List[AutomationAction] = field(default_factory=list)
    verify: str = ""
    verify_data: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    priority: str = "normal"
    device: str = "pc"
    confirmation: str = "required"
    source: str = "user"
    runs: int = 0
    failures: int = 0
    last_run: Optional[str] = None
    last_result: str = ""
    created_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%S"))

    # ------------------------------------------------------------------ serde
    @property
    def action_description(self) -> str:
        return "; ".join(a.description or a.instruction or a.tool for a in self.actions) \
            or "(no action)"

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["actions"] = [a.to_dict() for a in self.actions]
        data["action_description"] = self.action_description
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AutomationRule":
        actions = [AutomationAction.from_dict(a) for a in (data.get("actions") or [])]
        known = set(cls.__dataclass_fields__)
        kwargs = {k: v for k, v in data.items() if k in known and k != "actions"}
        if data.get("action_description") and not actions:
            actions = [AutomationAction(instruction=str(data["action_description"]),
                                        description=str(data["action_description"])[:120])]
        return cls(actions=actions, **kwargs)

    # ------------------------------------------------------------ db mapping
    def to_row(self) -> Automation:
        return Automation(
            id=self.id,
            name=self.name,
            description=self.description,
            enabled=self.enabled,
            trigger_type=self.when_type,
            trigger_clause=self.when,
            trigger_json=json.dumps(self.trigger),
            condition_clause=self.condition,
            condition_json=json.dumps(self.condition_data),
            actions_json=json.dumps([a.to_dict() for a in self.actions]),
            verify_clause=self.verify,
            verify_json=json.dumps(self.verify_data),
            device=self.device,
            priority=self.priority,
            confirmation=self.confirmation,
            source=self.source,
            last_run_at=_parse_iso(self.last_run),
            last_result=self.last_result,
            run_count=self.runs,
            failure_count=self.failures,
        )

    @classmethod
    def from_row(cls, row: Automation) -> "AutomationRule":
        def load(raw: Optional[str], default: Any) -> Any:
            if not raw:
                return default
            try:
                value = json.loads(raw)
            except (ValueError, TypeError):
                return default
            return default if value is None else value

        actions = [AutomationAction.from_dict(a) for a in load(row.actions_json, [])]
        return cls(
            id=row.id,
            name=row.name,
            description=row.description or "",
            when=row.trigger_clause or row.trigger_type or "manual",
            when_type=row.trigger_type or "manual",
            trigger=load(row.trigger_json, {}),
            condition=row.condition_clause or "",
            condition_data=load(row.condition_json, {}),
            actions=actions,
            verify=row.verify_clause or "",
            verify_data=load(row.verify_json, {}),
            enabled=bool(row.enabled),
            priority=row.priority or "normal",
            device=row.device or "pc",
            confirmation=row.confirmation or "required",
            source=row.source or "user",
            runs=int(row.run_count or 0),
            failures=int(row.failure_count or 0),
            last_run=row.last_run_at.isoformat() if row.last_run_at else None,
            last_result=row.last_result or "",
            created_at=row.created_at.isoformat() if row.created_at else "",
        )


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


class RuleStore:
    """CRUD for automation rules, backed by SQLite/PostgreSQL."""

    async def save(self, rule: AutomationRule) -> Dict[str, Any]:
        if not rule.id:
            slug = re.sub(r"[^a-z0-9]+", "-", rule.name.lower())[:24].strip("-") or "rule"
            rule.id = f"auto-{slug}-{int(time.time() * 1000) % 100000}"
        async with session_scope() as db:
            existing = await db.get(Automation, rule.id)
            if existing is None:
                db.add(rule.to_row())
            else:
                payload = rule.to_row()
                for column in ("name", "description", "enabled", "trigger_type",
                               "trigger_clause", "trigger_json", "condition_clause",
                               "condition_json", "actions_json", "verify_clause",
                               "verify_json", "device", "priority", "confirmation",
                               "source", "last_result", "run_count", "failure_count"):
                    setattr(existing, column, getattr(payload, column))
        log.info("automation rule saved: %s (%s)", rule.id, rule.when)
        return rule.to_dict()

    async def get(self, rule_id: str) -> Optional[Dict[str, Any]]:
        async with session_scope() as db:
            row = await db.get(Automation, rule_id)
            return AutomationRule.from_row(row).to_dict() if row else None

    async def list_all(self, include_disabled: bool = True, search: str = "") -> List[Dict[str, Any]]:
        async with session_scope() as db:
            rows = (await db.execute(select(Automation))).scalars().all()
        out: List[Dict[str, Any]] = []
        for row in rows:
            rule = AutomationRule.from_row(row)
            if not include_disabled and not rule.enabled:
                continue
            if search:
                blob = f"{rule.name} {rule.description} {rule.when} {rule.condition}".lower()
                if search.lower() not in blob:
                    continue
            out.append(rule.to_dict())
        return sorted(out, key=lambda r: (not r["enabled"], r["priority"] != "high", r["name"]))

    async def enabled_rules(self) -> List[AutomationRule]:
        async with session_scope() as db:
            rows = (await db.execute(select(Automation))).scalars().all()
        return [AutomationRule.from_row(r) for r in rows if r.enabled]

    async def update(self, rule_id: str, **values: Any) -> Optional[Dict[str, Any]]:
        renames = {"when": "trigger_clause", "when_type": "trigger_type",
                   "runs": "run_count", "failures": "failure_count",
                   "last_result": "last_result"}
        async with session_scope() as db:
            row = await db.get(Automation, rule_id)
            if row is None:
                return None
            for key, value in values.items():
                column = renames.get(key, key)
                if key == "actions" and isinstance(value, list):
                    row.actions_json = json.dumps([AutomationAction.from_dict(a).to_dict()
                                                   for a in value])
                elif key == "trigger" and isinstance(value, dict):
                    row.trigger_json = json.dumps(value)
                elif hasattr(row, column):
                    setattr(row, column, value)
            return AutomationRule.from_row(row).to_dict()

    async def record_run(self, rule_id: str, ok: bool, result: str) -> None:
        async with session_scope() as db:
            row = await db.get(Automation, rule_id)
            if row is None:
                return
            row.run_count = int(row.run_count or 0) + 1
            if not ok:
                row.failure_count = int(row.failure_count or 0) + 1
            row.last_run_at = datetime.utcnow()
            row.last_result = (result or "")[:1000]

    async def delete(self, rule_id: str) -> bool:
        async with session_scope() as db:
            row = await db.get(Automation, rule_id)
            if row is None:
                return False
            await db.delete(row)
            return True


rule_store = RuleStore()
