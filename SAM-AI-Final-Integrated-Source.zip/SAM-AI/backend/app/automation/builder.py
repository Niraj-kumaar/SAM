"""
backend.app.automation.builder
==============================

Turns a sentence into a WHEN → IF → DO → VERIFY rule.

The builder is deliberately two-stage:

1. a deterministic parser that handles the shapes people actually say
   ("when battery is low, enable battery saver", "every day at 9am, summarise my inbox");
2. a model call that fills in anything the parser could not resolve, and — most
   importantly — maps the DO clause onto **real registered tools** with real
   parameters, so an automation is executable rather than decorative.

If no model is configured, stage 2 is skipped and the rule keeps a
natural-language DO clause, which the executor then runs as a normal SAM task.
"""

from __future__ import annotations

import re
import time
from typing import Any, Dict, List, Optional, Tuple

from backend.app.automation.rules import AutomationAction, AutomationRule
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import registry

log = get_logger("automation.builder")

# trigger phrase -> (when_type, trigger payload)
TRIGGER_PATTERNS: List[Tuple[str, str, Dict[str, Any]]] = [
    (r"battery (?:is )?(?:low|below (\d+))", "battery", {"metric": "battery_percent", "op": "<=", "value": 20}),
    (r"battery (?:is )?(?:full|charged|100)", "battery", {"metric": "battery_percent", "op": ">=", "value": 95}),
    (r"battery (?:is )?charging", "battery", {"metric": "power_plugged", "op": "==", "value": True}),
    (r"disk (?:space )?(?:is )?(?:low|full)", "condition", {"metric": "disk_free_percent", "op": "<=", "value": 10}),
    (r"cpu (?:is )?(?:high|busy)", "condition", {"metric": "cpu_percent", "op": ">=", "value": 85}),
    (r"(?:when )?i (?:am |'m )?idle", "idle", {"metric": "idle_minutes", "op": ">=", "value": 10}),
    (r"(?:on |at )?startup|when sam starts|boot", "startup", {}),
    (r"file (?:is )?(?:changed|modified)", "file", {"watch": "changed"}),
    (r"file (?:is )?(?:added|created|new)", "file", {"watch": "added"}),
    (r"new (?:e-?mail|message|email)", "notification", {"source": "email"}),
    (r"device (?:is )?connected", "device", {"state": "online"}),
    (r"device (?:is )?disconnected", "device", {"state": "offline"}),
    (r"screenshot", "event", {"event": "screenshot taken"}),
    (r"task (?:is )?finished", "event", {"event": "task finished"}),
]

# DO phrase -> tool call
ACTION_PATTERNS: List[Tuple[str, str, Dict[str, Any], str]] = [
    (r"battery saver", "phone.system_state", {"battery_saver": True}, "turn on battery saver"),
    (r"(?:turn|switch) (?:on|off) (?:the )?wifi", "phone.wifi", {"action": "toggle"}, "toggle Wi-Fi"),
    (r"(?:turn|switch) (?:on|off) (?:the )?bluetooth", "phone.bluetooth", {"action": "toggle"}, "toggle Bluetooth"),
    (r"(?:mute|unmute)", "pc.volume", {"action": "mute"}, "mute the PC"),
    (r"volume (?:to|at) (\d+)", "pc.volume", {"level": 0}, "set the volume"),
    (r"brightness (?:to|at) (\d+)", "pc.brightness", {"level": 0}, "set the brightness"),
    (r"(?:take|grab) a screenshot", "pc.screenshot", {}, "take a screenshot"),
    (r"lock (?:the )?(?:pc|computer|screen)", "pc.power_lock", {}, "lock the PC"),
    (r"(?:go to )?sleep|hibernate", "pc.power_sleep", {}, "put the PC to sleep"),
    (r"shut ?down", "pc.power_shutdown", {}, "shut the PC down"),
    (r"restart|reboot", "pc.power_restart", {}, "restart the PC"),
    (r"notify me|send (?:me )?(?:a )?notification|alert me", "pc.notify", {"title": "SAM", "message": ""}, "notify you"),
    (r"play (?:some )?music", "pc.launch_app", {"target": ""}, "start music"),
    (r"open (\w[\w .\-]*)", "pc.launch_app", {"target": ""}, "open an application"),
    (r"close (\w[\w .\-]*)", "pc.close_app", {"target": ""}, "close an application"),
    (r"back ?up", "files.backup", {}, "back up files"),
    (r"clean(?: up)? (?:the )?(?:temp|cache|junk)", "files.clean", {}, "clean temporary files"),
    (r"summar(?:ise|ize) (?:my )?(?:inbox|emails|mail)", "email.summarise", {}, "summarise your inbox"),
    (r"git (?:pull|push|status|commit)", "coding.git", {"action": "status"}, "run a git command"),
    (r"run tests", "coding.run_tests", {}, "run the project tests"),
]


def _split_clauses(text: str) -> Tuple[str, str, str, str]:
    """Split a sentence into (when, condition, action, verify) using plain language."""
    raw = (text or "").strip()
    when = condition = action = verify = ""

    m = re.search(r"\b(?:verify|then check|and check|confirm)\b\s*[:\-]?\s*(.+)$", raw, re.I)
    if m:
        verify = m.group(1).strip(" .,")
        raw = raw[: m.start()].strip(" .,")

    m = re.search(r"\b(?:if|only if|when)\b\s+(?=.+\b(?:then|,)\b)([^,]+)", raw, re.I)
    if m and re.search(r"\bthen\b|,", raw[m.end():], re.I):
        condition = m.group(1).strip(" .,")
        raw = (raw[: m.start()] + " " + raw[m.end():]).strip(" ,")

    parts = re.split(r"\bthen\b|->|→|\s+do\s+|\s*,\s*", raw, maxsplit=1, flags=re.I)
    if len(parts) == 2:
        when, action = parts[0].strip(" ."), parts[1].strip(" .")
    else:
        # no explicit DO clause: treat the whole thing as the action
        m2 = re.match(r"^(when|on|at|every|after|before|if)\b(.*)$", raw, re.I)
        if m2:
            when = raw.strip(" .")
            action = ""
        else:
            action = raw.strip(" .")
    return when, condition, action, verify


def _match_trigger(when_text: str, fallback_text: str) -> Tuple[str, Dict[str, Any], str]:
    blob = f"{when_text} {fallback_text}".lower()

    m = re.search(r"every\s+(\d+)\s*(second|sec|minute|min|hour|hr|day|week|month)s?", blob)
    if m:
        from backend.app.tools.scheduler_tools import UNIT_SECONDS
        seconds = int(m.group(1)) * UNIT_SECONDS[m.group(2)]
        return "interval", {"kind": "interval", "seconds": seconds}, \
            f"every {m.group(1)} {m.group(2)}"

    for key in ("daily", "every day", "everyday", "weekdays", "weekly", "monthly", "hourly"):
        if key in blob:
            from backend.app.tools.scheduler_tools import CRON_PRESETS
            cron = CRON_PRESETS.get(key if key != "every day" and key != "everyday" else "daily")
            if cron:
                return "cron", {"kind": "cron", "cron": cron}, key.replace("every ", "")

    for pattern, when_type, payload in TRIGGER_PATTERNS:
        m = re.search(pattern, blob)
        if m:
            data = dict(payload)
            if m.groups() and m.group(1) and m.group(1).isdigit():
                data["value"] = int(m.group(1))
            if when_type == "event":
                data.setdefault("kind", "event")
                return "event", data, data.get("event", when_type)
            if when_type in ("cron", "interval"):
                data["kind"] = when_type
            return when_type, data, when_text.strip() or when_type

    if re.search(r"\b(at|by)\s+\d{1,2}(:\d{2})?\s*(am|pm)?\b", blob):
        from backend.app.tools.scheduler_tools import _parse_when
        spec = _parse_when(when_text or fallback_text)
        if spec.get("at"):
            return "time", {"kind": "once", "at": spec["at"]}, spec.get("human", "once")
        if spec.get("cron"):
            return "cron", {"kind": "cron", "cron": spec["cron"]}, spec.get("human", "recurring")

    if not (when_text or "").strip():
        return "manual", {"kind": "manual"}, "run manually"
    return "event", {"kind": "event", "event": (when_text or "manual").lower()}, when_text.strip()


def _match_actions(action_text: str, full_text: str) -> List[AutomationAction]:
    blob = f"{action_text} {full_text}".lower()
    actions: List[AutomationAction] = []
    seen: set = set()
    for pattern, tool_name, params, description in ACTION_PATTERNS:
        m = re.search(pattern, blob)
        if not m or tool_name in seen:
            continue
        if registry.get(tool_name) is None:
            continue
        resolved = dict(params)
        for i, group in enumerate(m.groups(), start=1):
            key = next((k for k, v in resolved.items() if v == 0 and k in ("level",)), None)
            if group and group.isdigit() and key:
                resolved[key] = int(group)
            elif group and not group.isdigit() and resolved.get("target") == "":
                resolved["target"] = group.strip()
        if tool_name == "phone.wifi" or tool_name == "phone.bluetooth":
            resolved["action"] = "off" if re.search(r"turn off|disable|switch off", blob) else "on"
        if tool_name == "pc.volume" and "unmute" in blob:
            resolved["action"] = "unmute"
        if tool_name == "pc.notify":
            resolved["message"] = action_text.strip()[:200] or "Automation triggered"
        seen.add(tool_name)
        actions.append(AutomationAction(tool=tool_name, params=resolved, description=description))
    if not actions and action_text.strip():
        actions.append(AutomationAction(instruction=action_text.strip(),
                                        description=action_text.strip()[:120]))
    return actions


def _guess_verify(action_text: str, actions: List[AutomationAction]) -> str:
    if not actions:
        return "SAM reports what happened"
    first = actions[0]
    table = {
        "pc.power_lock": "the session is locked",
        "pc.power_sleep": "the machine entered sleep",
        "pc.screenshot": "a screenshot file exists",
        "phone.wifi": "the phone reports the new Wi-Fi state",
        "phone.bluetooth": "the phone reports the new Bluetooth state",
        "phone.system_state": "the phone reports battery saver is on",
        "pc.volume": "the reported volume matches the requested level",
        "pc.brightness": "the reported brightness matches the requested level",
        "pc.launch_app": "the application appears in the process list",
        "pc.close_app": "the application no longer appears in the process list",
        "files.backup": "the backup archive exists and is non-empty",
        "files.clean": "the reclaimed space is reported",
        "coding.run_tests": "the test run reports zero failures",
        "coding.git": "the git command exits 0",
    }
    return table.get(first.tool, f"the tool '{first.tool or first.instruction}' returns ok=true")


async def build_rule(text: str, name: str = "", when: str = "", condition: str = "",
                     action: str = "", verify: str = "", priority: str = "normal",
                     enabled: bool = True, device: str = "pc") -> AutomationRule:
    """Parse ``text`` into an executable :class:`AutomationRule`."""
    p_when, p_cond, p_action, p_verify = _split_clauses(text)
    when_text = (when or p_when or "").strip()
    cond_text = (condition or p_cond or "").strip()
    action_text = (action or p_action or "").strip() or (text if not when_text else "")
    verify_text = (verify or p_verify or "").strip()

    when_type, trigger, when_human = _match_trigger(when_text, text)
    actions = _match_actions(action_text, text)

    # Ask the model to refine: it can pick better tools and fill parameters.
    refined = await _refine_with_model(text, when_human, cond_text, action_text, actions)
    if refined:
        if refined.get("when_type") in ("time", "cron", "interval", "event", "file", "device",
                                        "battery", "idle", "startup", "condition",
                                        "notification", "manual"):
            when_type = refined["when_type"]
            when_human = refined.get("when") or when_human
        if isinstance(refined.get("trigger"), dict) and refined["trigger"]:
            trigger = {**trigger, **refined["trigger"]}
        if refined.get("condition"):
            cond_text = refined["condition"]
        if isinstance(refined.get("actions"), list) and refined["actions"]:
            model_actions: List[AutomationAction] = []
            for item in refined["actions"][:6]:
                if not isinstance(item, dict):
                    continue
                tool_name = str(item.get("tool") or "")
                if tool_name and registry.get(tool_name) is None:
                    log.debug("model proposed unknown tool %s — keeping it as an instruction",
                              tool_name)
                    model_actions.append(AutomationAction(
                        instruction=item.get("instruction") or tool_name,
                        description=str(item.get("description") or item.get("instruction")
                                        or tool_name)[:120]))
                    continue
                model_actions.append(AutomationAction(
                    tool=tool_name,
                    params=item.get("params") if isinstance(item.get("params"), dict) else {},
                    instruction=str(item.get("instruction") or ""),
                    description=str(item.get("description") or tool_name or "")[:120],
                ))
            if model_actions:
                actions = model_actions
        if refined.get("verify"):
            verify_text = refined["verify"]

    if not verify_text:
        verify_text = _guess_verify(action_text, actions)

    title = name or _title_for(text, when_human, actions)
    return AutomationRule(
        name=title[:200],
        description=(text or "")[:500],
        when=when_human[:200],
        when_type=when_type,
        trigger=trigger,
        condition=cond_text[:500],
        condition_data=_condition_data(cond_text),
        actions=actions,
        verify=verify_text[:500],
        verify_data={"kind": "auto"},
        enabled=enabled,
        priority=priority,
        device=device,
        confirmation="required" if any(a.tool in HIGH_RISK_TOOLS for a in actions) else "auto",
        source="builder",
    )


HIGH_RISK_TOOLS = {"pc.power_shutdown", "pc.power_restart", "pc.power_sleep", "pc.power_lock",
                   "files.delete", "files.clean", "phone.message.send", "phone.call",
                   "coding.run_tests", "pc.terminal", "security.set_permission"}


def _title_for(text: str, when_human: str, actions: List[AutomationAction]) -> str:
    if actions and actions[0].description:
        return f"{actions[0].description} — {when_human}".strip(" -")[:200]
    return (text or "Automation")[:120]


def _condition_data(condition: str) -> Dict[str, Any]:
    """Extract a machine-testable condition when the phrasing allows it."""
    text = (condition or "").lower()
    if not text:
        return {}
    m = re.search(r"(battery|cpu|disk|memory|ram|free space)\s*(?:is\s*)?"
                  r"(<=|>=|<|>|==|below|under|above|over|at least|at most)\s*(\d+)\s*(%|percent|gb|mb)?",
                  text)
    if m:
        metric = {"battery": "battery_percent", "cpu": "cpu_percent", "disk": "disk_free_percent",
                  "free space": "disk_free_gb", "memory": "memory_percent",
                  "ram": "memory_percent"}.get(m.group(1), m.group(1))
        op = {"below": "<", "under": "<", "above": ">", "over": ">",
              "at least": ">=", "at most": "<="}.get(m.group(2), m.group(2))
        value = float(m.group(3))
        if m.group(4) in ("gb", "mb"):
            metric = metric.replace("_percent", "_gb")
            if m.group(4) == "mb":
                value /= 1024
        return {"metric": metric, "op": op, "value": value, "raw": condition}
    if re.search(r"\b(on|connected|plugged in|charging)\b", text):
        return {"flag": True, "raw": condition}
    if re.search(r"\b(off|disconnected|unplugged)\b", text):
        return {"flag": False, "raw": condition}
    if "weekday" in text or "working day" in text:
        return {"weekday_only": True, "raw": condition}
    if "weekend" in text:
        return {"weekend_only": True, "raw": condition}
    return {"raw": condition}


def _models_available(router: Any) -> bool:
    """True when at least one provider can actually answer a prompt."""
    try:
        status = router.status()
    except Exception:
        return False
    providers = status.get("providers") or {}
    return any(p.get("available") for p in providers.values())


async def _refine_with_model(text: str, when_human: str, condition: str, action: str,
                             actions: List[AutomationAction]) -> Optional[Dict[str, Any]]:
    from backend.app.models.router import router

    if not _models_available(router):
        return None

    tool_list = "\n".join(
        f"- {t.name}: {t.description}" for t in registry.all()
        if t.name.split(".")[0] in ("pc", "phone", "files", "browser", "coding", "email",
                                    "calendar", "creative", "data", "documents", "research",
                                    "memory", "scheduler", "automation")
    )[:6000]

    prompt = f"""You are SAM's Automation Builder. Convert the user's sentence into a rule.

USER SENTENCE: {text}

PARSED SO FAR:
- WHEN: {when_human}
- IF: {condition or '(none)'}
- DO: {action or '(none)'}
- Current tool mapping: {[a.to_dict() for a in actions]}

AVAILABLE TOOLS (name: description):
{tool_list}

Return ONLY valid JSON:
{{
  "when": "short human description of the trigger",
  "when_type": "time|cron|interval|event|file|device|battery|idle|startup|condition|notification|manual",
  "trigger": {{"kind": "...", "cron": "...", "at": "ISO", "seconds": 0, "event": "..."}},
  "condition": "the IF clause, or empty",
  "actions": [{{"tool": "exact tool name from the list, or empty",
                "params": {{"...": "..."}},
                "instruction": "natural language if no tool fits",
                "description": "5-8 words for the UI"}}],
  "verify": "how to prove it worked, in one line"
}}
Only use tool names from the list. Keep parameters minimal and concrete."""
    data = await router.ask_json(prompt, role="reasoning", temperature=0.15, default=None)
    return data if isinstance(data, dict) else None


def describe_rule(rule: AutomationRule) -> str:
    """One-line human summary used in notifications and the UI."""
    return (f"WHEN {rule.when} → IF {rule.condition or 'always'} → "
            f"DO {rule.action_description} → VERIFY {rule.verify or 'result reported'}")


def stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")
