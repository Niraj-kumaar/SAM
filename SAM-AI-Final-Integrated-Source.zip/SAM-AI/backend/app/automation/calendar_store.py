"""
backend.app.automation.calendar_store
=====================================

SAM's calendar. Events live in the ``calendar_events`` table so they are visible
in the desktop UI, on the phone dashboard and to the scheduler (every event with
a reminder gets a real scheduled job).

Google Calendar / Outlook sync is optional and read-mostly: when an account is
connected, :meth:`CalendarStore.merge_external` writes those events in with
``source='google'`` and their external id, so updates are idempotent.
"""

from __future__ import annotations

import re
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from backend.app.core.logging_config import get_logger
from backend.app.core.models import CalendarEvent
from backend.app.core.database import session_scope
from sqlalchemy import select

log = get_logger("automation.calendar")


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (text or "event").lower())[:28].strip("-") or "event"


class CalendarStore:
    async def upsert(self, *, event_id: Optional[str] = None, title: str, start: datetime,
                     end: Optional[datetime] = None, location: str = "", notes: str = "",
                     all_day: bool = False, reminder_minutes: int = 15, device: str = "pc",
                     source: str = "sam", external_id: str = "",
                     status: str = "scheduled") -> Dict[str, Any]:
        async with session_scope() as db:
            row: Optional[CalendarEvent] = None
            if event_id:
                row = await db.get(CalendarEvent, event_id)
            if row is None and external_id:
                found = (await db.execute(
                    select(CalendarEvent).where(CalendarEvent.external_id == external_id)
                )).scalars().first()
                row = found
            if row is None:
                row = CalendarEvent(
                    id=event_id or f"evt-{_slug(title)}-{int(time.time() * 1000) % 100000}",
                    title=title[:255], start_at=start, end_at=end,
                    location=location[:255], description=notes, all_day=all_day,
                    reminder_minutes=int(reminder_minutes), device=device, source=source,
                    external_id=external_id[:255], status=status,
                )
                db.add(row)
            else:
                row.title = title[:255]
                row.start_at = start
                row.end_at = end
                row.location = location[:255]
                row.description = notes
                row.all_day = all_day
                row.reminder_minutes = int(reminder_minutes)
                row.device = device or row.device
                row.source = source or row.source
                row.external_id = external_id or row.external_id
                row.status = status
            await db.flush()
            return row.to_dict()

    async def get(self, event_id: str) -> Optional[Dict[str, Any]]:
        async with session_scope() as db:
            row = await db.get(CalendarEvent, event_id)
            return row.to_dict() if row else None

    async def set_reminder_job(self, event_id: str, job_id: str) -> None:
        async with session_scope() as db:
            row = await db.get(CalendarEvent, event_id)
            if row is not None:
                row.reminder_job_id = job_id

    async def list_events(self, *, days: int = 7, date: str = "", include_past: bool = False,
                          search: str = "", limit: int = 200) -> List[Dict[str, Any]]:
        async with session_scope() as db:
            rows = (await db.execute(select(CalendarEvent))).scalars().all()
        now = datetime.utcnow().replace(tzinfo=None)

        if date:
            try:
                anchor = datetime.fromisoformat(date.replace("Z", "+00:00")).replace(tzinfo=None)
            except ValueError:
                anchor = now
            start = anchor.replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=max(1, days))
        elif include_past:
            start = now - timedelta(days=max(days, 1))
            end = now + timedelta(days=max(days, 1))
        else:
            start = now
            end = now + timedelta(days=max(1, days))

        out: List[Dict[str, Any]] = []
        for row in rows:
            when = row.start_at.replace(tzinfo=None) if row.start_at and row.start_at.tzinfo \
                else row.start_at
            if when is None or not (start <= when < end):
                continue
            if search:
                blob = f"{row.title} {row.location} {row.description}".lower()
                if search.lower() not in blob:
                    continue
            item = row.to_dict()
            item["in_minutes"] = int((when - now).total_seconds() // 60) if when else None
            item["human"] = _humanise(when, row.all_day)
            out.append(item)
        out.sort(key=lambda e: e["start"] or "")
        return out[:limit]

    async def upcoming(self, minutes: int = 60) -> List[Dict[str, Any]]:
        """Events starting within the next ``minutes`` — used by Proactive mode."""
        async with session_scope() as db:
            rows = (await db.execute(select(CalendarEvent))).scalars().all()
        now = datetime.utcnow().replace(tzinfo=None)
        out: List[Dict[str, Any]] = []
        for row in rows:
            when = row.start_at.replace(tzinfo=None) if row.start_at and row.start_at.tzinfo \
                else row.start_at
            if when and now <= when <= now + timedelta(minutes=minutes):
                out.append(row.to_dict())
        return sorted(out, key=lambda e: e["start"] or "")

    async def delete(self, event_id: str) -> bool:
        async with session_scope() as db:
            row = await db.get(CalendarEvent, event_id)
            if row is None:
                return False
            await db.delete(row)
            return True

    async def merge_external(self, events: List[Dict[str, Any]], source: str = "google") -> int:
        """Idempotently import events from an external calendar provider."""
        merged = 0
        for item in events:
            start = _parse(item.get("start") or item.get("start_at"))
            if not start:
                continue
            end = _parse(item.get("end") or item.get("end_at")) or start + timedelta(hours=1)
            await self.upsert(
                title=str(item.get("title") or item.get("summary") or "Untitled")[:255],
                start=start, end=end,
                location=str(item.get("location") or ""),
                notes=str(item.get("notes") or item.get("description") or ""),
                all_day=bool(item.get("all_day")),
                reminder_minutes=int(item.get("reminder_minutes") or 15),
                device=item.get("device") or "pc", source=source,
                external_id=str(item.get("id") or item.get("external_id") or ""),
            )
            merged += 1
        return merged

    async def stats(self) -> Dict[str, Any]:
        events = await self.list_events(days=3650, include_past=True)
        now = datetime.utcnow()
        upcoming = [e for e in events if (e.get("start") or "") >= now.isoformat()]
        return {"total": len(events), "upcoming": len(upcoming),
                "next_7_days": len(await self.list_events(days=7)),
                "today": len(await self.list_events(days=1))}


def _parse(value: Any) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value.replace(tzinfo=None) if value.tzinfo else value
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt.replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        return None


def _humanise(when: Optional[datetime], all_day: bool) -> str:
    if when is None:
        return ""
    now = datetime.now()
    if all_day:
        return when.strftime("%a %d %b (all day)")
    if when.date() == now.date():
        return f"today {when.strftime('%H:%M')}"
    if when.date() == (now + timedelta(days=1)).date():
        return f"tomorrow {when.strftime('%H:%M')}"
    return when.strftime("%a %d %b %H:%M")


calendar_store = CalendarStore()
