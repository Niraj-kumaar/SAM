"""
backend.app.automation.executor
===============================

Runs one automation rule end to end::

    WHEN (already satisfied — the scheduler or an event fired)
      -> IF     evaluate the condition against live device/system state
      -> DO     execute each action through the tool registry (and therefore
                through permission + risk + confirmation + audit)
      -> VERIFY observe the result and report honestly

Failures are never swallowed: the rule records its last result, emits an event,
and the Task Control Center shows the error text.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

import psutil

from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.tools.registry import ToolContext, ToolExecutionError, registry

from .rules import AutomationAction, AutomationRule, rule_store

log = get_logger("automation.executor")


# ---------------------------------------------------------------------------
# IF — condition evaluation
# ---------------------------------------------------------------------------
async def evaluate_condition(rule: AutomationRule, device: str = "pc") -> Dict[str, Any]:
    """
    Evaluate the IF clause. Returns ``{"passed": bool, "detail": ...}``.

    A rule with no condition always passes. A condition SAM cannot measure is
    reported as ``unknown`` and the rule **does not run** — guessing would be
    worse than doing nothing.
    """
    data = dict(rule.condition_data or {})
    text = (rule.condition or "").strip()
    if not text and not data:
        return {"passed": True, "detail": "no condition", "measured": False}

    metric = data.get("metric")
    if metric:
        value = await _measure(metric, device)
        if value is None:
            return {"passed": False, "detail": f"cannot measure '{metric}' right now",
                    "measured": False, "metric": metric}
        op = data.get("op", ">=")
        threshold = float(data.get("value", 0))
        passed = _compare(float(value), op, threshold)
        return {"passed": passed, "measured": True, "metric": metric,
                "observed": value, "op": op, "threshold": threshold,
                "detail": f"{metric} = {value} ({op} {threshold}) -> "
                          f"{'pass' if passed else 'fail'}"}

    if "weekday_only" in data:
        passed = time.localtime().tm_wday < 5
        return {"passed": passed, "measured": True, "detail":
                "weekday only" + ("" if passed else f" (today is weekday {time.localtime().tm_wday})")}
    if "weekend_only" in data:
        passed = time.localtime().tm_wday >= 5
        return {"passed": passed, "measured": True, "detail": "weekend only"}
    if "flag" in data:
        flag = bool(data["flag"])
        observed = await _measure_flag(text, device)
        passed = observed is None or observed == flag
        return {"passed": passed, "measured": observed is not None,
                "detail": f"expected {'on' if flag else 'off'}, observed "
                          f"{'unknown' if observed is None else ('on' if observed else 'off')}"}

    # free-text condition: ask the model only if one is available
    from backend.app.models.router import router

    if _models_available(router):
        state = await _snapshot(device)
        verdict = await router.ask_json(
            "Decide whether the CONDITION is satisfied by the STATE.\n\n"
            f"CONDITION: {text}\nSTATE (JSON):\n{state}\n\n"
            'Return ONLY JSON: {"passed": true|false, "reason": "one sentence"}',
            role="reasoning", temperature=0.0, default=None,
        )
        if isinstance(verdict, dict) and "passed" in verdict:
            return {"passed": bool(verdict["passed"]), "measured": True,
                    "detail": str(verdict.get("reason", ""))[:300]}
    return {"passed": False, "measured": False,
            "detail": f"condition '{text[:80]}' could not be evaluated automatically"}


def _compare(value: float, op: str, threshold: float) -> bool:
    return {
        "<": value < threshold, "<=": value <= threshold, ">": value > threshold,
        ">=": value >= threshold, "==": abs(value - threshold) < 1e-9,
        "!=": abs(value - threshold) >= 1e-9,
    }.get(op, False)


async def _phone_call(bridge: Any, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """RPC to the first connected companion phone, or the ADB fallback."""
    device_id = bridge.first_device_id()
    if not device_id:
        return {"ok": False, "error": "no companion phone is connected"}
    try:
        result = await bridge.send(device_id, method, params)
    except Exception as exc:  # pragma: no cover
        return {"ok": False, "error": str(exc)[:200]}
    return result if isinstance(result, dict) else {"ok": False, "error": "unexpected reply"}


def _models_available(router: Any) -> bool:
    """True when at least one provider can actually answer a prompt."""
    try:
        status = router.status()
    except Exception:
        return False
    providers = status.get("providers") or {}
    return any(p.get("available") for p in providers.values())


async def _measure(metric: str, device: str = "pc") -> Optional[float]:
    metric = (metric or "").lower()
    try:
        if metric in ("battery_percent", "battery"):
            batt = psutil.sensors_battery()
            if device == "phone":
                from backend.app.devices.phone_bridge import phone_bridge
                info = await _phone_call(phone_bridge, "battery.get", {})
                if isinstance(info, dict) and info.get("ok"):
                    level = info.get("level", info.get("percent"))
                    return float(level) if level is not None else None
            return float(batt.percent) if batt else None
        if metric in ("power_plugged", "charging"):
            batt = psutil.sensors_battery()
            return float(bool(batt.power_plugged)) if batt else None
        if metric in ("cpu_percent", "cpu"):
            return float(psutil.cpu_percent(interval=0.4))
        if metric in ("memory_percent", "ram"):
            return float(psutil.virtual_memory().percent)
        if metric in ("disk_free_percent",):
            usage = psutil.disk_usage("/")
            return round(100.0 * usage.free / max(usage.total, 1), 2)
        if metric in ("disk_free_gb",):
            return round(psutil.disk_usage("/").free / (1024 ** 3), 2)
        if metric == "idle_minutes":
            return None            # requires OS idle-time API; measured by the watcher
        if metric == "hour":
            return float(time.localtime().tm_hour)
    except Exception as exc:  # pragma: no cover
        log.debug("metric %s unavailable: %s", metric, exc)
    return None


async def _measure_flag(text: str, device: str = "pc") -> Optional[bool]:
    low = text.lower()
    if "plugged" in low or "charging" in low:
        batt = psutil.sensors_battery()
        return bool(batt.power_plugged) if batt else None
    if "battery saver" in low:
        if device == "phone":
            from backend.app.devices.phone_bridge import phone_bridge
            info = await _phone_call(phone_bridge, "battery.get", {})
            if isinstance(info, dict):
                return bool(info.get("battery_saver", info.get("power_save")))
        return None
    if "wifi" in low or "wi-fi" in low:
        if device == "phone":
            from backend.app.devices.phone_bridge import phone_bridge
            info = await _phone_call(phone_bridge, "wifi.state", {})
            if isinstance(info, dict) and "enabled" in info:
                return bool(info["enabled"])
        return None
    return None


async def _snapshot(device: str = "pc") -> Dict[str, Any]:
    snap: Dict[str, Any] = {"device": device, "time": time.strftime("%Y-%m-%d %H:%M:%S")}
    try:
        snap["cpu_percent"] = psutil.cpu_percent(interval=0.2)
        snap["memory_percent"] = psutil.virtual_memory().percent
        batt = psutil.sensors_battery()
        if batt:
            snap["battery"] = {"percent": batt.percent, "plugged": batt.power_plugged}
        usage = psutil.disk_usage("/")
        snap["disk_free_gb"] = round(usage.free / (1024 ** 3), 1)
    except Exception:
        pass
    if device == "phone":
        try:
            from backend.app.devices.phone_bridge import phone_bridge
            snap["phone"] = phone_bridge.status()
        except Exception:
            pass
    return snap


# ---------------------------------------------------------------------------
# DO — action execution
# ---------------------------------------------------------------------------
async def run_action(action: AutomationAction, ctx: ToolContext,
                     dry_run: bool = False) -> Dict[str, Any]:
    """Execute one DO step. Always returns a dict; never raises."""
    if dry_run:
        return {"ok": True, "dry_run": True, "tool": action.tool,
                "instruction": action.instruction, "description": action.description,
                "detail": "dry run — nothing was executed"}

    if action.tool and registry.get(action.tool) is not None:
        try:
            value = await registry.execute(action.tool, ctx, **action.params)
            ok = True
            if isinstance(value, dict):
                ok = bool(value.get("ok", True))
            return {"ok": ok, "tool": action.tool, "params": action.params,
                    "description": action.description, "value": value}
        except ToolExecutionError as exc:
            return {"ok": False, "tool": action.tool, "params": action.params,
                    "description": action.description, "error": exc.message,
                    "denied_by": exc.denied_by, "confirmation_id": exc.confirmation_id,
                    "needs_confirmation": exc.denied_by == "confirmation"}
        except Exception as exc:
            log.exception("automation action %s failed", action.tool)
            return {"ok": False, "tool": action.tool, "error": str(exc)[:400],
                    "description": action.description}

    if action.instruction:
        # no tool matched: run it as a normal SAM task so the Planner can decide
        try:
            from backend.app.core.orchestrator import orchestrator

            task = await orchestrator.submit(action.instruction, source="automation",
                                             device=ctx.device, priority="normal",
                                             wait=True)
            outcome = task.to_dict() if hasattr(task, "to_dict") else dict(task or {})
            ok = outcome.get("status") in ("COMPLETED", "completed", "DONE")
            return {"ok": ok, "instruction": action.instruction,
                    "description": action.description, "task": outcome}
        except Exception as exc:
            return {"ok": False, "instruction": action.instruction, "error": str(exc)[:400]}

    return {"ok": False, "error": "action has neither a tool nor an instruction"}


# ---------------------------------------------------------------------------
# VERIFY
# ---------------------------------------------------------------------------
async def verify_rule(rule: AutomationRule, results: List[Dict[str, Any]],
                      ctx: ToolContext) -> Dict[str, Any]:
    checks: List[Dict[str, Any]] = []

    # 1. every action reported ok
    failed_actions = [r for r in results if not r.get("ok")]
    checks.append({
        "check": "all actions succeeded",
        "passed": not failed_actions,
        "detail": "ok" if not failed_actions else
                  "; ".join(str(r.get("error") or r.get("description") or "unknown")[:120]
                            for r in failed_actions[:3]),
    })

    # 2. observation-based check where we can make one
    for result in results:
        tool_name = result.get("tool") or ""
        value = result.get("value")
        observed: Optional[Dict[str, Any]] = None
        if tool_name == "pc.launch_app" and isinstance(value, dict):
            observed = {"check": "process is running",
                        "passed": bool(value.get("pid") or value.get("running")),
                        "detail": f"pid={value.get('pid')}"}
        elif tool_name in ("pc.power_lock", "pc.power_sleep") and isinstance(value, dict):
            observed = {"check": "power action accepted",
                        "passed": bool(value.get("ok")), "detail": value.get("detail", "")}
        elif tool_name in ("files.backup", "documents.render", "files.convert") \
                and isinstance(value, dict):
            path = value.get("path") or value.get("output") or ""
            if path:
                from pathlib import Path
                exists = Path(path).exists()
                observed = {"check": "output file exists", "passed": exists,
                            "detail": f"{path} ({'found' if exists else 'missing'})"}
        elif tool_name.startswith("phone.") and isinstance(value, dict):
            observed = {"check": "phone acknowledged the command",
                        "passed": bool(value.get("ok")),
                        "detail": str(value.get("transport") or value.get("error") or "")[:120]}
        if observed:
            checks.append(observed)

    passed = all(c["passed"] for c in checks)
    return {"passed": passed, "verdict": "success" if passed else "failed",
            "checks": checks, "expected": rule.verify or "(no explicit verification)"}


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
async def execute_rule(rule: AutomationRule, ctx_base: Optional[ToolContext] = None,
                       dry_run: bool = False, manual: bool = False) -> Dict[str, Any]:
    """Run WHEN → IF → DO → VERIFY for one rule."""
    started = time.perf_counter()
    ctx = ctx_base or ToolContext(task_id=rule.id, agent="planning", device=rule.device,
                                  user_text=rule.description)
    ctx.meta = dict(ctx.meta or {})
    ctx.meta.update({"automation_id": rule.id, "manual": manual, "dry_run": dry_run})

    emit(Topics.AUTOMATION_TRIGGERED, rule_id=rule.id, name=rule.name, when=rule.when,
         manual=manual, dry_run=dry_run, device=rule.device)
    log.info("automation %s fired (%s)", rule.id, rule.name)

    # ---- IF
    condition = await evaluate_condition(rule, device=rule.device)
    if not condition["passed"]:
        summary = f"condition not met: {condition.get('detail')}"
        await rule_store.record_run(rule.id, False, summary)
        result = {"ok": False, "rule_id": rule.id, "name": rule.name, "stage": "condition",
                  "condition": condition, "actions": [], "verify": None,
                  "summary": summary, "error": summary, "duration_ms": 0,
                  "answer": f"Automation “{rule.name}” did not run — {summary}."}
        emit(Topics.AUTOMATION_FINISHED, **{k: v for k, v in result.items()
                                            if k in ("rule_id", "name", "ok", "summary")})
        return result

    if dry_run:
        plan = [{"tool": a.tool, "instruction": a.instruction, "params": a.params,
                 "description": a.description,
                 "available": bool(a.tool and registry.get(a.tool))} for a in rule.actions]
        return {"ok": True, "rule_id": rule.id, "name": rule.name, "dry_run": True,
                "stage": "plan", "condition": condition, "actions": plan,
                "summary": rule.action_description,
                "answer": f"Dry run of “{rule.name}”: WHEN {rule.when} → "
                          f"IF {rule.condition or 'always'} → DO {rule.action_description} → "
                          f"VERIFY {rule.verify or 'result reported'}"}

    # ---- DO
    results: List[Dict[str, Any]] = []
    needs_confirmation: List[Dict[str, Any]] = []
    for action in rule.actions:
        outcome = await run_action(action, ctx)
        results.append(outcome)
        if outcome.get("needs_confirmation"):
            needs_confirmation.append({"action": action.tool or action.instruction,
                                       "confirmation_id": outcome.get("confirmation_id"),
                                       "error": outcome.get("error")})

    # ---- VERIFY
    verification = await verify_rule(rule, results, ctx)
    duration = int((time.perf_counter() - started) * 1000)
    ok = verification["passed"]

    summary = "; ".join(
        (r.get("description") or r.get("tool") or r.get("instruction") or "action")
        + (" ✓" if r.get("ok") else f" ✗ {str(r.get('error'))[:80]}")
        for r in results
    ) or "no actions"

    await rule_store.record_run(rule.id, ok, summary)
    payload = {
        "ok": ok, "rule_id": rule.id, "name": rule.name, "when": rule.when,
        "condition": condition, "actions": results, "verify": verification,
        "needs_confirmation": needs_confirmation, "summary": summary,
        "duration_ms": duration, "manual": manual,
        "answer": (f"Automation “{rule.name}” {'succeeded' if ok else 'did not fully succeed'}: "
                   f"{summary}"),
    }
    if not ok:
        first_error = next((r.get("error") for r in results if r.get("error")),
                           verification["checks"][-1]["detail"] if verification["checks"] else "")
        payload["error"] = str(first_error)[:400]
    emit(Topics.AUTOMATION_FINISHED, rule_id=rule.id, name=rule.name, ok=ok, summary=summary,
         duration_ms=duration, needs_confirmation=len(needs_confirmation))
    if not ok:
        emit(Topics.NOTIFICATION, title=f"Automation failed: {rule.name}", body=str(summary)[:300],
             level="warning", source="automation")
    return payload


async def execute_by_id(rule_id: str, dry_run: bool = False, manual: bool = False) -> Dict[str, Any]:
    data = await rule_store.get(rule_id)
    if data is None:
        return {"ok": False, "error": f"no automation rule with id '{rule_id}'"}
    return await execute_rule(AutomationRule.from_dict(data), dry_run=dry_run, manual=manual)
