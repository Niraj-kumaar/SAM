"""
backend.app.automation.scheduler
================================

The scheduling engine.

A thin, resilient wrapper around APScheduler's ``AsyncIOScheduler``:

* jobs are declared by the ``scheduler.*`` tools and persisted in the
  ``scheduled_jobs`` table, so they survive a restart;
* when a job fires it becomes a real SAM task through the orchestrator, which
  means it goes through the Planner, the brains, the tools, the guard and the
  audit trail exactly like a request the user typed;
* event-triggered jobs are not APScheduler jobs at all — they are armed here and
  fired by :meth:`Scheduler.trigger_event` when the event bus reports a match.

APScheduler is an optional dependency: if it is missing, SAM keeps the job list
in memory and a background loop polls it, so scheduling still works.
"""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional

from backend.app.core.event_bus import Topics, emit
from backend.app.core.logging_config import get_logger
from backend.app.core.models import ScheduledJob
from backend.app.core.database import session_scope
from sqlalchemy import select

log = get_logger("automation.scheduler")

try:
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.date import DateTrigger
    from apscheduler.triggers.interval import IntervalTrigger

    HAVE_APS = True
except Exception:  # pragma: no cover - optional dependency
    HAVE_APS = False


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt.replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        return None


def _iso(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat(timespec="seconds") if dt else None


class Scheduler:
    """Owns every scheduled job and event trigger."""

    def __init__(self) -> None:
        self._aps: Any = None
        self._memory: Dict[str, Dict[str, Any]] = {}
        self._events: Dict[str, List[str]] = {}          # event name -> [job ids]
        self.running = False
        self._poll_task: Optional[asyncio.Task] = None
        self._executor: Optional[Callable[..., Any]] = None
        self.started_at: Optional[str] = None
        self.fired = 0
        self.failed = 0

    # ------------------------------------------------------------------ setup
    def attach_executor(self, executor: Callable[..., Any]) -> None:
        """Register ``async def executor(job_id, title, instruction, device, priority, manual)``."""
        self._executor = executor

    async def start(self) -> Dict[str, Any]:
        if self.running:
            return {"ok": True, "already_running": True, "engine": "apscheduler" if HAVE_APS else "internal"}
        if HAVE_APS:
            self._aps = AsyncIOScheduler(timezone=None)
            self._aps.start()
        else:
            self._poll_task = asyncio.create_task(self._poll_loop())
        self.running = True
        self.started_at = time.strftime("%Y-%m-%dT%H:%M:%S")
        restored = await self.restore()
        emit(Topics.SYSTEM_STATUS, component="scheduler", engine="apscheduler" if HAVE_APS
             else "internal-poll", jobs=restored)
        log.info("scheduler started (%s), %d job(s) restored",
                 "apscheduler" if HAVE_APS else "internal poll", restored)
        return {"ok": True, "engine": "apscheduler" if HAVE_APS else "internal",
                "jobs_restored": restored}

    async def stop(self) -> None:
        self.running = False
        if self._poll_task:
            self._poll_task.cancel()
            self._poll_task = None
        if self._aps:
            try:
                self._aps.shutdown(wait=False)
            except Exception:
                pass
            self._aps = None
        log.info("scheduler stopped")

    async def restore(self) -> int:
        """Re-arm every enabled job that is still in the database."""
        count = 0
        async with session_scope() as db:
            rows = (await db.execute(select(ScheduledJob))).scalars().all()
            for row in rows:
                if not row.enabled:
                    continue
                payload = _load_json(row.payload_json)
                spec = {
                    "kind": row.kind,
                    "cron": payload.get("cron") if row.kind in ("cron", "recurring") else None,
                    "at": payload.get("at") if row.kind in ("once", "date", "one-time") else None,
                    "seconds": payload.get("seconds") if row.kind == "interval" else None,
                    "event": payload.get("event") if row.kind == "event" else None,
                    "human": payload.get("human", row.expression),
                }
                if row.expression and not spec["cron"] and row.kind in ("cron", "recurring"):
                    spec["cron"] = row.expression
                armed = self.add_job(row.id, spec, row.name, row.instruction,
                                     device=row.device, priority=row.priority,
                                     enabled=True, persist=False)
                if armed.get("ok"):
                    count += 1
        return count

    # ------------------------------------------------------------------- jobs
    def add_job(self, job_id: str, spec: Dict[str, Any], title: str, instruction: str,
                device: str = "pc", priority: str = "normal", enabled: bool = True,
                persist: bool = True) -> Dict[str, Any]:
        kind = (spec.get("kind") or "one-time").lower()
        if kind in ("one-time", "once", "date"):
            kind = "once"
        if kind == "recurring":
            kind = "cron"

        record = {
            "id": job_id, "title": title, "instruction": instruction, "kind": kind,
            "device": device, "priority": priority, "enabled": enabled,
            "cron": spec.get("cron"), "at": spec.get("at"),
            "seconds": spec.get("seconds"), "event": spec.get("event"),
            "human": spec.get("human") or kind, "next_run": None, "created": time.time(),
        }
        self._memory[job_id] = record

        if kind == "event":
            event = str(spec.get("event") or "manual").lower()
            self._events.setdefault(event, [])
            if job_id not in self._events[event]:
                self._events[event].append(job_id)
            record["next_run"] = f"on event: {event}"
            return {"ok": True, "engine": "event-listener", "event": event,
                    "next_run": record["next_run"]}

        if not self.running:
            return {"ok": True, "engine": "deferred",
                    "note": "scheduler not started yet — the job is persisted and will be armed on start"}

        if HAVE_APS and self._aps is not None:
            try:
                trigger = self._build_trigger(kind, spec)
                if trigger is None:
                    return {"ok": False, "error": f"cannot build a trigger for kind '{kind}'"}
                job = self._aps.add_job(self._fire_sync, trigger,
                                        args=[job_id, title, instruction, device, priority, False],
                                        id=job_id, replace_existing=True,
                                        misfire_grace_time=3600, coalesce=True)
                record["next_run"] = _iso(job.next_run_time.replace(tzinfo=None)) \
                    if getattr(job, "next_run_time", None) else None
                return {"ok": True, "engine": "apscheduler", "next_run": record["next_run"]}
            except Exception as exc:
                log.warning("APScheduler rejected job %s: %s — falling back to the poll loop",
                            job_id, exc)

        record["next_run"] = self._next_run_internal(record)
        return {"ok": True, "engine": "internal-poll", "next_run": record["next_run"]}

    def _build_trigger(self, kind: str, spec: Dict[str, Any]) -> Any:
        if kind == "once":
            dt = _parse_iso(spec.get("at"))
            if dt is None:
                return None
            if dt <= datetime.now():
                dt = datetime.now() + timedelta(seconds=2)
            return DateTrigger(run_date=dt)
        if kind == "interval":
            seconds = int(spec.get("seconds") or 0)
            return IntervalTrigger(seconds=seconds) if seconds > 0 else None
        if kind == "cron":
            cron = (spec.get("cron") or "").strip()
            if not cron:
                return None
            return CronTrigger.from_crontab(cron)
        return None

    def _next_run_internal(self, record: Dict[str, Any]) -> Optional[str]:
        kind = record.get("kind")
        if kind == "once":
            return record.get("at")
        if kind == "interval" and record.get("seconds"):
            return _iso(datetime.now() + timedelta(seconds=int(record["seconds"])))
        if kind == "cron":
            if HAVE_APS:
                try:
                    trig = CronTrigger.from_crontab(record["cron"])
                    nxt = trig.get_next_fire_time(None, datetime.now())
                    return _iso(nxt.replace(tzinfo=None) if nxt else None)
                except Exception:
                    return None
        return None

    def reschedule(self, job_id: str, snapshot: Dict[str, Any],
                   spec: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        record = self._memory.get(job_id)
        if record is None:
            return {"ok": False, "error": f"job {job_id} is not loaded in the engine"}
        record.update({k: v for k, v in snapshot.items() if k in
                       ("title", "instruction", "device", "priority", "enabled")})
        if spec:
            return self.add_job(job_id, spec, record["title"], record["instruction"],
                                device=record["device"], priority=record["priority"],
                                enabled=record["enabled"], persist=False)
        if not record["enabled"]:
            self.remove_job(job_id, keep_memory=True)
            record["enabled"] = False
            return {"ok": True, "engine": "disabled"}
        kind = record["kind"]
        spec = {"kind": kind, "cron": record.get("cron"), "at": record.get("at"),
                "seconds": record.get("seconds"), "event": record.get("event"),
                "human": record.get("human")}
        return self.add_job(job_id, spec, record["title"], record["instruction"],
                            device=record["device"], priority=record["priority"],
                            enabled=True, persist=False)

    def remove_job(self, job_id: str, keep_memory: bool = False) -> bool:
        removed = False
        if self._aps is not None:
            try:
                self._aps.remove_job(job_id)
                removed = True
            except Exception:
                pass
        for listeners in self._events.values():
            if job_id in listeners:
                listeners.remove(job_id)
                removed = True
        if not keep_memory:
            self._memory.pop(job_id, None)
        return removed

    def jobs(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        live: Dict[str, Any] = {}
        if self._aps is not None:
            try:
                for job in self._aps.get_jobs():
                    live[job.id] = _iso(job.next_run_time.replace(tzinfo=None)) \
                        if job.next_run_time else None
            except Exception:
                pass
        for record in self._memory.values():
            item = dict(record)
            if record["id"] in live and live[record["id"]]:
                item["next_run"] = live[record["id"]]
            out.append(item)
        return sorted(out, key=lambda r: (not r["enabled"], str(r["next_run"] or "9999")))

    # ------------------------------------------------------------------ firing
    def _fire_sync(self, job_id: str, title: str, instruction: str, device: str,
                   priority: str, manual: bool) -> None:
        """APScheduler callback (may be called from a worker thread)."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop and loop.is_running():
            loop.create_task(self.fire(job_id, title, instruction, device, priority, manual))
        else:
            try:
                asyncio.run(self.fire(job_id, title, instruction, device, priority, manual))
            except Exception as exc:  # pragma: no cover
                log.error("scheduled job %s could not run: %s", job_id, exc)

    async def fire(self, job_id: str, title: str, instruction: str, device: str = "pc",
                   priority: str = "normal", manual: bool = False) -> Dict[str, Any]:
        record = self._memory.get(job_id) or {"id": job_id, "title": title,
                                              "instruction": instruction, "kind": "unknown"}
        emit(Topics.TASK_CREATED, task_id=job_id, title=title, source="scheduler",
             device=device, priority=priority, manual=manual)
        log.info("firing scheduled job %s (%s)", job_id, title)

        result: Dict[str, Any] = {"ok": False, "job_id": job_id, "title": title}
        if self._executor is None:
            result["error"] = "no executor attached to the scheduler"
        else:
            try:
                outcome = await self._executor(job_id=job_id, title=title,
                                               instruction=instruction, device=device,
                                               priority=priority, manual=manual)
                result.update(outcome if isinstance(outcome, dict) else {"value": outcome})
            except Exception as exc:
                result["error"] = str(exc)[:500]
                log.exception("scheduled job %s failed", job_id)

        self.fired += 1
        if not result.get("ok"):
            self.failed += 1

        summary = result.get("answer") or result.get("summary") or result.get("error") or "done"
        await self._record_run(job_id, bool(result.get("ok")), str(summary)[:1000])
        emit(Topics.TASK_COMPLETED if result.get("ok") else Topics.TASK_FAILED,
             task_id=job_id, title=title, source="scheduler", ok=bool(result.get("ok")),
             summary=str(summary)[:400], result=result)
        return result

    async def _record_run(self, job_id: str, ok: bool, summary: str) -> None:
        async with session_scope() as db:
            row = await db.get(ScheduledJob, job_id)
            if row is None:
                return
            row.run_count = int(row.run_count or 0) + 1
            if not ok:
                row.failure_count = int(row.failure_count or 0) + 1
            row.last_run_at = datetime.utcnow()
            row.last_result = summary
            # a one-shot job that has run is disabled, so it never repeats by accident
            if row.kind in ("once", "date", "one-time"):
                row.enabled = False
            record = self._memory.get(job_id)
            if record:
                record["last_run"] = time.strftime("%Y-%m-%dT%H:%M:%S")
                record["last_result"] = summary

    # ------------------------------------------------------- event triggers
    async def trigger_event(self, event: str, payload: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Fire every job waiting on ``event``. Called from the event bridge."""
        key = str(event or "").lower()
        job_ids = list(self._events.get(key, []))
        if not job_ids:
            return []
        results: List[Dict[str, Any]] = []
        for job_id in job_ids:
            record = self._memory.get(job_id)
            if not record or not record.get("enabled"):
                continue
            results.append(await self.fire(job_id, record["title"], record["instruction"],
                                           device=record.get("device", "pc"),
                                           priority=record.get("priority", "normal"),
                                           manual=False))
        return results

    def event_listeners(self) -> Dict[str, List[str]]:
        return {k: list(v) for k, v in self._events.items() if v}

    # ----------------------------------------------------- internal fallback
    async def _poll_loop(self) -> None:
        """Runs only when APScheduler is unavailable."""
        while self.running:
            try:
                now = datetime.now()
                for record in list(self._memory.values()):
                    if not record.get("enabled") or record.get("kind") == "event":
                        continue
                    due = False
                    if record["kind"] == "once":
                        dt = _parse_iso(record.get("at"))
                        due = bool(dt and dt <= now)
                    elif record["kind"] == "interval":
                        last = record.get("_last_tick") or 0
                        due = (time.time() - last) >= int(record.get("seconds") or 0)
                    if due:
                        record["_last_tick"] = time.time()
                        await self.fire(record["id"], record["title"], record["instruction"],
                                        device=record.get("device", "pc"),
                                        priority=record.get("priority", "normal"), manual=False)
                        record["next_run"] = self._next_run_internal(record)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover
                log.debug("scheduler poll error: %s", exc)
            await asyncio.sleep(5)

    # ----------------------------------------------------------------- status
    def status(self) -> Dict[str, Any]:
        return {
            "running": self.running,
            "engine": "apscheduler" if (HAVE_APS and self._aps) else "internal-poll",
            "apscheduler_available": HAVE_APS,
            "started_at": self.started_at,
            "jobs": len(self._memory),
            "enabled": sum(1 for r in self._memory.values() if r.get("enabled")),
            "fired": self.fired,
            "failed": self.failed,
            "event_listeners": self.event_listeners(),
        }


def _load_json(raw: Optional[str]) -> Dict[str, Any]:
    if not raw:
        return {}
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else {}
    except (ValueError, TypeError):
        return {}


scheduler = Scheduler()
