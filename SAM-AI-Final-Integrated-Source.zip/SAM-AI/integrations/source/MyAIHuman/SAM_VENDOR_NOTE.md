# MyAIHuman source bundle inside SAM

This directory contains the source files from the user-provided `myaihuman-main.zip` archive. It is kept as a separate upstream project tree to avoid destructive file-name/dependency collisions with SAM.

- Files copied: 42
- Excluded generated/dependency directories: .git, .mypy_cache, .pytest_cache, .venv, __pycache__, node_modules, venv
- Exclusions: 0 (including platform-specific bundled binary where applicable).
- This is source inclusion, not proof that every upstream feature is wired into SAM's runtime.
- Follow the upstream README and license included in this directory before running or redistributing it.
