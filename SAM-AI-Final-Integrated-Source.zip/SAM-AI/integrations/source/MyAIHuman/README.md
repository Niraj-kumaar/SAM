# 🧠 MY AI HUMAN — Advanced AI Agent System

An advanced **AI voice assistant + autonomous PC control system** powered by LLMs, voice recognition, and computer vision.

---

## 🚀 Features

- 🎙️ Voice-controlled AI assistant
- 🌍 Multilingual support (English, Hindi, auto-detect)
- 👁️ Face recognition security system
- 🧠 AI agent reasoning (Groq / LLM-based)
- 🖥️ Full PC automation (apps, scripts, browser)
- 🔊 Smart alert system (tiered security levels)
- 💾 Memory system (short + long + semantic)
- 🧠 Auto-learning memory


---

## 🧠 Architecture

- LLM Brain → decision making
- Voice Engine → speech input/output
- Vision Module → face recognition
- Controller → system automation

---

## ⚙️ Installation

```bash
git clone https://github.com//Programmer-Hacktivist/myaihuman.git
cd myaihuman
pip install pvporcupine sounddevice
pip install face-recognition opencv-python
pip install opencv-python deepface pyqt6 pyautogui psutil
pip install -r requirements.txt
python main.py
```
