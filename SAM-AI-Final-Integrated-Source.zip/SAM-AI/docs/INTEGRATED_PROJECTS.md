# Integrated source projects and SAM tool inventory

## Upstream source trees

- `integrations/source/OpenJarvis/` — upstream OpenJarvis source and documentation.
- `integrations/source/MyAIHuman/` — upstream MyAIHuman source and documentation.
- `integrations/source/OpenClaw/` — upstream OpenClaw source and documentation.

These are vendored source snapshots, not automatically callable SAM plugins. Their licenses and upstream instructions are retained with each source tree. Use each project's own installation/build guidance and avoid mixing its dependencies into SAM's environment without isolation.

## Active SAM modules

SAM's current backend is in `backend/app/`. The primary active paths include `core/orchestrator.py`, `models/router.py`, `tools/registry.py`, `memory/store.py`, `security/permissions.py`, `security/confirmation_engine.py`, `security/audit.py`, `files/`, `voice/`, `devices/`, and the API routers under `api/v1/`.

Tool modules include browser, code execution, coding, core, creative, data, email, files, market, math, memory, PC, phone, research, scheduler, security, system, terminal, text, vision, and web tools.

## OpenClaw runtime status

`backend/app/integrations/openclaw.py` reads the opt-in environment settings and reports local configuration. It does not connect to the gateway, authenticate, list sessions, or execute agent commands. The `/api/v1/integrations` endpoint explicitly reports this boundary. Keep the integration disabled until a version-specific gateway adapter is implemented and tested.

## Safety boundary

Terminal/PC automation, file modification, device actions, and autonomous agent execution require scoped permissions, confirmation for sensitive actions, audit records, and tests. Presence of upstream code alone does not make any such capability active.
