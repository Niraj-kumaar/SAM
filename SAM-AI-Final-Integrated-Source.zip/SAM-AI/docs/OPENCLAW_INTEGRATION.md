# OpenClaw integration in SAM

## Architecture
SAM remains the UI, voice layer, API and permission boundary. OpenClaw is an optional agent runtime behind a server-side adapter. The browser must never call an OpenClaw gateway directly or receive gateway tokens.

## Current status
This archive includes a connector contract and integration plan, not a claim that OpenClaw has already been launched or that every OpenClaw tool is wired into SAM. The OpenClaw repository supplied as split ZIP volumes must be assembled and its exact version/API reviewed before enabling execution. Do not copy its entire repository into SAM's runtime or merge dependencies blindly.

## Configure
1. Install and run a compatible OpenClaw Gateway according to its own official documentation.
2. Review its authentication and API/WebSocket protocol for the exact installed version.
3. Implement/enable the adapter only against that documented protocol.
4. Keep gateway URL/token server-side in `.env`; never commit real secrets.
5. Add an allowlist of tools. Require explicit confirmation for file deletion, shell commands, purchases, messages, system settings and other consequential actions.
6. Test status, success, timeout, authentication failure, invalid response, cancellation and denied-permission paths.

## Safe integration phases
- Phase 1: read-only status/health and provider capability discovery.
- Phase 2: bounded text-agent requests without privileged tools.
- Phase 3: selected tools behind SAM permission checks and audit logging.
- Phase 4: OS/device-specific automation only after platform testing.

## Validation
A successful frontend build or Python syntax check does not verify gateway compatibility, model credentials, Windows automation, Android pairing or all OpenClaw skills. Report each separately.
