# SAM AI — Integrated Source Bundle

SAM is a local-first personal AI assistant project with a FastAPI backend, React/Vite desktop UI, tools, memory, model providers, permission checks, and device/voice modules. This repository also vendors source snapshots of **OpenJarvis**, **MyAIHuman**, and **OpenClaw** under `integrations/source/`.

## Quick start

Requirements: Python 3.11+, Node.js 20+, npm. From this directory:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r backend/requirements.txt
cp .env.example .env  # Windows: copy .env.example .env
cd desktop
npm install
npm run build
cd ..
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs`. The API root `/health` checks the backend. `GET /api/v1/integrations` reports source presence and OpenClaw configuration separately; it does not claim upstream projects are live-connected.

For the development UI, use two terminals: `npm run backend` from this directory and `npm run desktop` from this directory. On Windows, `start-sam.bat` is also provided.

## Validation

```bash
python scripts/doctor.py
python -m unittest tests.test_integrations -v
python -m compileall -q backend tests scripts
cd desktop && npm run typecheck && npm run build
```

The doctor checks required local modules and the vendored source trees. Install dependencies before expecting backend startup. A successful syntax check is not an end-to-end runtime test.

## Integration boundaries (read this)

- **SAM core:** the active runtime lives in `backend/app/` and includes the orchestrator, model routing, tool registry, memory, permission/confirmation/audit modules, voice, and device APIs.
- **OpenJarvis and MyAIHuman:** upstream source is preserved under `integrations/source/`. They are not automatically loaded as SAM plugins; dependency isolation and per-capability adapters are still needed before their tools can be invoked through SAM.
- **OpenClaw:** upstream source is preserved under `integrations/source/OpenClaw/`. `backend/app/integrations/openclaw.py` currently reports opt-in configuration only. It does **not** connect to a gateway or execute OpenClaw agent actions. Leave `OPENCLAW_ENABLED=false` until a version-pinned, authenticated adapter and permission tests have been implemented.
- **Voice and devices:** browser speech input is not an always-on wake-word system. Microphone, OS automation, Android pairing/APK, and physical-device actions must be validated on the target hardware.
- **Secrets:** keep provider and gateway tokens in a local `.env` file; never commit it.

See `docs/INTEGRATED_PROJECTS.md`, `docs/OPENCLAW_INTEGRATION.md`, and `BUILD_AND_VALIDATION_REPORT.md` for more detail.
