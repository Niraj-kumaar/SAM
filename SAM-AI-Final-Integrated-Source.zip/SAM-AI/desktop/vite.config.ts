import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The desktop UI is ONE codebase:
//   * `npm run dev`  -> browser at http://localhost:5173 (proxied to the API)
//   * `npm run build`-> desktop/dist, served by FastAPI at http://localhost:8000
//   * electron .     -> the same dist inside a native window
//
// Everything the browser calls is a RELATIVE url (/api, /ws) so it works behind
// any origin, including a tunnel or the Electron file:// + custom scheme setup.
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: false,
    // accept any host header so the UI also works through a preview proxy
    allowedHosts: true,
    proxy: {
      '/api': {
        target: process.env.SAM_API_URL || 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
      '/ws': {
        target: process.env.SAM_API_URL || 'ws://127.0.0.1:8000',
        ws: true,
        changeOrigin: true,
      },
      '/health': { target: process.env.SAM_API_URL || 'http://127.0.0.1:8000', changeOrigin: true },
      '/version': { target: process.env.SAM_API_URL || 'http://127.0.0.1:8000', changeOrigin: true },
      '/startup': { target: process.env.SAM_API_URL || 'http://127.0.0.1:8000', changeOrigin: true },
      '/docs': { target: process.env.SAM_API_URL || 'http://127.0.0.1:8000', changeOrigin: true },
    },
  },
  preview: { host: '0.0.0.0', port: 4173, allowedHosts: true },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    sourcemap: false,
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
        },
      },
    },
  },
})
