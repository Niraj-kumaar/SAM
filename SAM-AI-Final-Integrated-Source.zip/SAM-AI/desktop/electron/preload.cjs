/**
 * desktop/electron/preload.cjs
 * ============================
 *
 * The ONLY bridge between the sandboxed renderer and the OS. It exposes a tiny,
 * explicit surface (`window.sam`) — no `require`, no `fs`, no `child_process`.
 * Everything else the UI needs goes through the SAM HTTP/WS API, exactly like
 * the browser build does.
 */
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('sam', {
  isElectron: true,
  version: () => ipcRenderer.invoke('sam:version'),
  platform: () => ipcRenderer.invoke('sam:platform'),
  apiBase: () => ipcRenderer.invoke('sam:api-base'),
  startBackend: () => ipcRenderer.invoke('sam:start-backend'),
  stopBackend: () => ipcRenderer.invoke('sam:stop-backend'),
  minimize: () => ipcRenderer.invoke('sam:minimize'),
  maximize: () => ipcRenderer.invoke('sam:maximize'),
  close: () => ipcRenderer.invoke('sam:close'),
  openExternal: (url) => ipcRenderer.invoke('sam:open-external', url),
})
