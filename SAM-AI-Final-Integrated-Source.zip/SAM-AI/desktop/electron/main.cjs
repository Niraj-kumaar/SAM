/**
 * desktop/electron/main.cjs
 * =========================
 *
 * The native window around the SAME React build the browser uses.
 *
 * Two modes:
 *  - dev  (VITE_DEV_SERVER_URL set): loads http://localhost:5173
 *  - prod: loads desktop/dist/index.html from disk
 *
 * In production the renderer has no node integration at all; the only bridge is
 * the small, explicit API exposed by preload.cjs. The Python backend stays a
 * separate process — SAM's brain is the API, the window is just glass.
 */
const { app, BrowserWindow, Menu, Tray, ipcMain, shell, nativeImage } = require('electron')
const path = require('path')
const { spawn } = require('child_process')

const DEV_URL = process.env.VITE_DEV_SERVER_URL || ''
const API_BASE = process.env.SAM_API_URL || 'http://127.0.0.1:8000'
const SINGLE_INSTANCE_LOCK = app.requestSingleInstanceLock()

let mainWindow = null
let tray = null
let backendProcess = null

if (!SINGLE_INSTANCE_LOCK) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })
  boot()
}

function boot() {
  // a crash in one window must never take the whole assistant down silently
  process.on('uncaughtException', (err) => {
    console.error('[SAM] uncaught exception:', err)
  })

  app.whenReady().then(() => {
    createWindow()
    registerIpc()
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
  })

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
  })

  app.on('before-quit', () => {
    stopBackend()
  })
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1560,
    height: 980,
    minWidth: 1100,
    minHeight: 700,
    show: false,
    backgroundColor: '#070B14',
    title: 'SAM · AI Operating Platform',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  })

  mainWindow.once('ready-to-show', () => mainWindow.show())

  // external links open in the user's real browser, never inside SAM
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url)
    return { action: 'deny' }
  })

  if (DEV_URL) {
    mainWindow.loadURL(DEV_URL)
    mainWindow.webContents.openDevTools({ mode: 'detach' })
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'))
  }

  mainWindow.on('closed', () => {
    mainWindow = null
  })

  buildMenu()
}

function buildMenu() {
  const template = [
    {
      label: 'SAM',
      submenu: [
        { label: 'About SAM', role: 'about' },
        { type: 'separator' },
        {
          label: 'Reload UI',
          accelerator: 'CmdOrCtrl+R',
          click: () => mainWindow && mainWindow.webContents.reload(),
        },
        {
          label: 'Developer tools',
          accelerator: 'F12',
          click: () => mainWindow && mainWindow.webContents.toggleDevTools(),
        },
        { type: 'separator' },
        { label: 'Quit SAM', accelerator: 'CmdOrCtrl+Q', click: () => app.quit() },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { role: 'resetZoom' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
      ],
    },
    {
      label: 'Window',
      submenu: [{ role: 'minimize' }, { role: 'close' }],
    },
  ]
  Menu.setApplicationMenu(Menu.buildFromTemplate(template))
}

/**
 * Optionally start the Python backend as a child process.
 * Off by default: `start-sam.bat` / `start-sam.sh` already run both, and a
 * double-start would fight over port 8000.
 */
function registerIpc() {
  ipcMain.handle('sam:api-base', () => API_BASE)
  ipcMain.handle('sam:version', () => app.getVersion())
  ipcMain.handle('sam:platform', () => process.platform)

  ipcMain.handle('sam:start-backend', async () => {
    if (backendProcess) return { ok: true, alreadyRunning: true, pid: backendProcess.pid }
    const root = path.join(__dirname, '..', '..')
    const isWin = process.platform === 'win32'
    const python = isWin ? 'python' : 'python3'
    try {
      backendProcess = spawn(
        python,
        ['-m', 'uvicorn', 'backend.app.main:app', '--host', '127.0.0.1', '--port', '8000'],
        { cwd: root, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] },
      )
      backendProcess.stdout.on('data', (d) => process.stdout.write(`[backend] ${d}`))
      backendProcess.stderr.on('data', (d) => process.stderr.write(`[backend] ${d}`))
      backendProcess.on('exit', (code) => {
        console.log(`[SAM] backend exited with code ${code}`)
        backendProcess = null
      })
      return { ok: true, pid: backendProcess.pid }
    } catch (err) {
      return { ok: false, error: String(err) }
    }
  })

  ipcMain.handle('sam:stop-backend', () => {
    stopBackend()
    return { ok: true }
  })

  ipcMain.handle('sam:minimize', () => mainWindow && mainWindow.minimize())
  ipcMain.handle('sam:maximize', () => {
    if (!mainWindow) return
    mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize()
  })
  ipcMain.handle('sam:close', () => mainWindow && mainWindow.close())
  ipcMain.handle('sam:open-external', (_e, url) => {
    if (/^https?:\/\//i.test(String(url))) shell.openExternal(String(url))
  })
}

function stopBackend() {
  if (backendProcess) {
    try {
      backendProcess.kill()
    } catch (_) {
      /* already gone */
    }
    backendProcess = null
  }
}
